""" """
import sys
from config.experiment_config import FOLDER, N, I, Q, MAG, PHASE, RRA, SINGLE_SHOT, RRC
from qcore import Experiment, qua, Sweep
from qm import qua as qm_qua
from qcore.libs.qua_macros import QuaVariable
from qcore import Dataset


class RabiEF(Experiment):
    """Power Rabi EF"""

    ############################# DEFINE PRIMARY DATASETS ##############################
    # these Datasets form the "raw" experimental data and will be streamed by the OPX
    # they must be specified at experiment runtime
    primary_datasets = ["I", "Q", "single_shot"]

    ############################## DEFINE PRIMARY SWEEPS ###############################
    # these Sweeps are uniquely associated with the Experiment subclass
    # these Sweeps must be specified at experiment runtime
    primary_sweeps = ["qubitGF_pulse_amplitude"]

    ############################ DEFINE THE PULSE SEQUENCE #############################
    # ensure that you import 'qua' from 'qcore' and not from 'qm' library
    # attributes accessed via 'self' must be defined in 'if __name__ == "__main__"' code
    def sequence(self):
        """QUA sequence that defines this Experiment subclass"""


        self.qubitGF.play(self.qubitGF_drive, ampx=self.qubitGF_pulse_amplitude)
        #self.qubitEF.play(self.qubitEF_drive, ampx=self.qubitEF_pulse_amplitude)
        #self.qubitEF.play(self.qubitEF_drive, ampx=self.qubitEF_pulse_amplitude)
        #self.qubitEF.play(self.qubitEF_drive, ampx=self.qubitEF_pulse_amplitude)
        qua.align(self.qubitGF, self.resonator)

        self.resonator.measure(self.readout_pulse, (self.I, self.Q), ampx=self.ro_ampx, demod_type = 'dual')
        if self.plot_single_shot:  # assign state to G or E
            qm_qua.assign(self.single_shot,qm_qua.Cast.to_fixed(self.I > self.readout_pulse.threshold),)
        qua.wait(self.wait_time, self.resonator)


if __name__ == "__main__":
    """ """

    #################################### MODE MAP ######################################
    # key: name of the Mode as defined by the Experiment subclass
    # value: name of the Mode as defined by the user in modes.yml
    modes = {
        "qubitGF": "qA_GF",
        "resonator": "rrA",
    }

    ################################### PULSE MAP ######################################
    # key: name of the Pulse as defined by the Experiment subclass
    # value: name of the Pulse as defined by the user in modes.yml
    pulses = {
        "qubitGF_drive": "qA_GF_gaussian_pi_pulse",
        "readout_pulse": "rrA_readout_pulse",
    }

    ############################## CONTROL PARAMETERS ##################################
    parameters = {
        "wait_time": 300_000,
        "ro_ampx": 1,
        "plot_single_shot": True,
    }

    ######################## SWEEP (INDEPENDENT) VARIABLES #############################
    # must include an outermost averaging Sweep named "N"
    # must include all primary sweeps defined by the Experiment subclass

    # set number of repetitions for this Experiment run
    N.num = 4000

    # set the qubit amplitude sweep for this Experiment run
    QD_AMPX = Sweep(name="qubitGF_pulse_amplitude", start=-1.5, stop=1.5, num=101)
    sweeps = [N, QD_AMPX]

    ######################## DATASET (DEPENDENT) VARIABLES #############################
    # must include all primary datasets defined by the Experiment subclass
    I.fitfn = "sine"
    Q.fitfn = "sine"
    SINGLE_SHOT.fitfn = "sine"
    PHASE.datafn_args = {"delay": 2.792e-7, "freq": RRA.int_freq}
    #Q.plot,  MAG.plot = False, False
    datasets = [I, Q, SINGLE_SHOT]

    ######################## INITIALIZE AND RUN EXPERIMENT #############################

    expt = RabiEF(FOLDER, modes, pulses, sweeps, datasets, **parameters)
    expt.run()
