""" """

import sys

sys.path.append("C:/Users/admin/Desktop/qcore-yabba/yabba-main/")
import matplotlib.pyplot as plt
from qm import qua
from qcore.instruments import QM
from qcore.pulses import ConstantPulse
from qcore import Stage
from config.experiment_config import MODES_CONFIG, FOLDER
from config.experiment_config import (
    RRC,
    RRA,
    RRB,
    QUBITC,
    QUBITB,
    QUBITA,
)

with Stage(configpath=MODES_CONFIG, remote=True) as stage:
    (opx1000,) = stage.get("opx1000")

def get_sweep(mode, lo, sa, **kwargs):
    pulse = ConstantPulse("spectrum_analysis_constant_pulse")
    mode.add_operations(pulse)
    #qm = QM(modes=(mode,), oscillators=(lo,), opx_plus=opx_plus, config_path=f"{FOLDER}/config")
    #sa.configure(**kwargs)

    # RR must always be included in the modes passed into QM since the output lines are tied to it
    if mode.name == RRC.name: 
        mode_list = (RRC, )
    else:
        mode_list = (mode, RRC)
    
    #qm = QM(modes=mode_list, oscillators=(lo,), opx_plus=opx_plus, config_path=f"{FOLDER}/config")
    qm = QM(modes=mode_list, oscillators=(opx1000,), opx=opx1000, config_path=f"{FOLDER}/config")
    # print(sa)
    sa.configure(**kwargs)


    def get_qua_program(mode):
        with qua.program() as play_constant_pulse:
            with qua.infinite_loop_():
                mode.play(pulse, ampx=1)
        return play_constant_pulse

    job = qm.execute(get_qua_program(mode))  # play IF to mode
    freqs, amps = sa.sweep()  # get, plot, show sweep

    plt.plot(freqs, amps)
    job.halt()
    plt.show()


if __name__ == "__main__":
    mode = QUBITA
    mode_lo = opx1000.settings["RF_outputs"][3]
    print(opx1000.name)
    sweep_parameters = {  # set sweep parameters
        # "center": mode_lo.frequency,  # 1e9,
        "center": mode_lo["LO_frequency"],  # 1e9,
        "span": 590e6,
        "rbw": 250e3,
        "ref_power": 0,
    }
    get_sweep(mode, opx1000, SA, **sweep_parameters)
