
import sys
sys.path.append("C:/Users/admin/Desktop/qcore-yabba/yabba-main/")
from qcore import Stage
from qcore.instruments import QM
from qcore.scripts.octave_mixer_tuning import OctaveMixerTuner
from qm.octave import *

from config.experiment_config import MODES_CONFIG, FOLDER
from config.experiment_config import (
    RRB,RRA, RRC, QUBITC, QUBITA, QUBITB, CAVA, CAVB, QUBITC_EF,QUBITB_EF, QUBITA_EF, DRIVE)

if __name__ == "__main__":
    """ """
    with Stage(configpath=MODES_CONFIG, remote=True) as stage:

        
        
        (octave, opx_plus) = stage.get("oct1", "opx_plus")
        rrC_lo = octave.settings["RF_outputs"][1]["LO_frequency"]
        rrB_lo = octave.settings["RF_outputs"][1]["LO_frequency"]
        rrA_lo = octave.settings["RF_outputs"][1]["LO_frequency"]
        qubitC_lo = octave.settings["RF_outputs"][5]["LO_frequency"]
        qubitA_lo = octave.settings["RF_outputs"][5]["LO_frequency"]
        qubitB_lo = octave.settings["RF_outputs"][5]["LO_frequency"]
        drive_lo = octave.settings["RF_outputs"][5]["LO_frequency"]
        cavA_lo = octave.settings["RF_outputs"][3]["LO_frequency"]
        cavB_lo = octave.settings["RF_outputs"][2]["LO_frequency"]

        modes_to_tune =  [
            #(RRC, rrC_lo, (RRC.int_freq,)), 
           #(RRB, rrC_lo, (RRB.int_freq,)), 
            #(RRA, rrA_lo, (RRA.int_freq,)),
            #(DRIVE, drive_lo, (DRIVE.int_freq,)),
            #(QUBITC, qubitC_lo, (QUBITC.int_freq,)),
            #(QUBITB_EF, qubitB_lo, (QUBITB_EF.int_freq,)),
            (CAVB, cavB_lo, (CAVB.int_freq,)),
            #(QUBITA, qubitA_lo, (QUBITA.int_freq,)),
            #(QUBITB, qubitB_lo, (QUBITB.int_freq,)),
            #(QUBITA, qubitA_lo, (QUBITA.int_freq,)),
            #(CAVA, cavA_lo, (CAVA.int_freq,)),
           
         ] # add the modes you wish to tune here

        qm = QM(modes=(QUBITB_EF, RRB, RRC, RRA, DRIVE, QUBITC, QUBITB, QUBITA, CAVA, CAVB), oscillators=(octave,), opx_plus=opx_plus, config_path=f"{FOLDER}/config")

        ro_trainer = OctaveMixerTuner(modes_to_tune, qm)
        res = ro_trainer.tune_mixers()


        