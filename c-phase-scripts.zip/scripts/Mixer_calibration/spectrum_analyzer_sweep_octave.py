""" """

import sys

# sys.path.append("C:/Users/admin/Desktop/qcore-yabba/yabba-main/")
import matplotlib.pyplot as plt
from qm import qua
from qcore.instruments import QM
from qcore.pulses import ConstantPulse
from qcore import Stage
from config.experiment_config import MODES_CONFIG
from config.experiment_config import (
    RRC,
    QUBITC,
    QUBITA,
    QUBITB,
    CAVB,
    CAVA,
    SA,
    # DRIVE2,
    # CAVITY,
    # DRIVE
)
#from system_setup.hamiltonian_params import *

with Stage(configpath=MODES_CONFIG, remote=True) as stage:
    # (octave, opx_one) = stage.get("octave1", "opx_one")
    (opx1000,) = stage.get("opx1000")


def get_sweep(mode, lo, sa, **kwargs):
    pulse = ConstantPulse("spectrum_analysis_constant_pulse")
    mode.add_operations(pulse)
    # qm = QM(modes=(mode,), oscillators=(lo,), opx_one=opx_one)
    qm = QM(modes=(mode,), oscillators=(opx1000,), opx=opx1000)
    sa.configure(**kwargs)

    def get_qua_program(mode):
        with qua.program() as play_constant_pulse:
            with qua.infinite_loop_():
                mode.play(pulse, ampx=1)
        return play_constant_pulse

    job = qm.execute(get_qua_program(mode))  # play IF to mode
    freqs, amps = sa.sweep()  # get, plot, show sweep

    plt.plot(freqs, amps)
    job.halt()
    plt.show()


if __name__ == "__main__":
    mode = CAVA
    mode_lo = 5.0e9#octave.settings["RF_outputs"][3] # change this 1->RR 2->QUBIT  #Qubit_ef 3 4->Alice, 4->Bob, 5->Charlie
    sweep_parameters = {  # set sweep parameters
        "center": mode_lo, #mode_lo["LO_frequency"],  # 1e9,
        "span": 2e9, #700e6, #2.5e9, #750e6, #3e9,#
        "rbw": 250e3,
        "ref_power": 0,
    }
    get_sweep(mode, opx1000, SA, **sweep_parameters)
