""" Readout integration weights training for single-shot readout """

from qcore import Stage
from qcore.instruments import QM
from qcore.scripts.readout_training_octave import ReadoutTrainerOctave
from config.experiment_config import MODES_CONFIG, RRC, QUBITC, QUBITC_EF

if __name__ == "__main__":
    """ """

    with Stage(configpath=MODES_CONFIG, remote=True) as stage:

        (opx1000,) = stage.get("opx1000")
        qm = QM(modes=(RRC, QUBITC, QUBITC_EF), oscillators=(opx1000,), opx=opx1000)

        params = {
            "reps": 20_000,
            "wait_time": 5e5,  # ns
            "readout_pulse": "rrC_GF_readout_pulse",  # pulse name used to readout
            "qubit_pi_pulse": "qC_gaussian_pi_pulse",  # pulse name used to excite qubit
            "qubitEF_pi_pulse": "qC_EF_gaussian_pi_pulse",  # pulse name used to excite qubit
        }

        ro_trainer = ReadoutTrainerOctave(RRC, QUBITC, QUBITC_EF, qm, **params)
        threshold, data = ro_trainer.calculate_threshold(use_GF = True)
