""" """
from config.experiment_config import FOLDER, N, I, Q, MAG, PHASE, RRB, FREQ, SINGLE_SHOT
from qcore import Experiment, qua, Sweep
from qm import qua as qm_qua
from qcore.libs.qua_macros import QuaVariable
from qcore import Dataset


class TLS(Experiment):
    """TLS spectroscopy"""

    ############################# DEFINE PRIMARY DATASETS ##############################
    # these Datasets form the "raw" experimental data and will be streamed by the OPX
    # they must be specified at experiment runtime

    primary_datasets = ["I", "Q", "single_shot"]

    ############################## DEFINE PRIMARY SWEEPS ###############################
    # these Sweeps are uniquely associated with the Experiment subclass
    # these Sweeps must be specified at experiment runtime

    primary_sweeps = ["TLS_frequency"]

    ############################ DEFINE THE PULSE SEQUENCE #############################
    # ensure that you import 'qua' from 'qcore' and not from 'qm' library
    # attributes accessed via 'self' must be defined in 'if __name__ == "__main__"' code

    def sequence(self):
        """QUA sequence that defines this Experiment subclass"""
        qua.update_frequency(self.qubit, self.TLS_frequency)
        self.qubit.play(self.TLS_pulse)
        qua.align()

        qua.update_frequency(self.qubit, self.qubit.int_freq)
        self.qubit.play(self.qubit_pulse, ampx = 1.0)
        qua.align()

        self.resonator.measure(self.readout_pulse, (self.I, self.Q), demod_type="dual")
        if self.plot_single_shot:  # assign state to G or E
            qm_qua.assign(self.single_shot,qm_qua.Cast.to_fixed(self.I > self.readout_pulse.threshold),)
        qua.wait(self.wait_time, self.resonator)

if __name__ == "__main__":
    """ """

    #################################### MODE MAP ######################################
    modes = {
        "qubit": "qC",
        "resonator": "rrC",
    }

    ################################### PULSE MAP ######################################
    pulses = {      
        "TLS_pulse": "qC_gaussian_sel_pi_pulse",
        "qubit_pulse": "qC_gaussian_sel_pi_pulse",
        "readout_pulse": "rrC_readout_pulse",
    }

    ############################## CONTROL PARAMETERS ##################################

    parameters = {
        "wait_time": 6e5,
        "ro_ampx": 1,
        "fetch_interval": 2,
        "plot_single_shot": True,
    }

    ######################## SWEEP (INDEPENDENT) VARIABLES #############################
    N.num = 5000
    FREQ.name = "TLS_frequency"
    FREQ.start = -250e6
    FREQ.stop = -50e6
    FREQ.num = 401
    sweeps = [N, FREQ]

    ######################## DATASET (DEPENDENT) VARIABLES #############################
    PHASE.datafn_args = {"delay": 2.792e-7, "freq": RRB.int_freq}
    I.plot, Q.plot = True, True
    I.fitfn = "gaussian"
    SINGLE_SHOT.fitfn = "gaussian"
    PHASE.plot = False
    SINGLE_SHOT.plot= True
    datasets = [I, Q, SINGLE_SHOT]

    ######################## INITIALIZE AND RUN EXPERIMENT #############################
    expt = TLS(FOLDER, modes, pulses, sweeps, datasets, **parameters)
    expt.run()
