""" """
import sys
from config.experiment_config import FOLDER, N, I, Q, MAG, PHASE, RRB, SINGLE_SHOT, RRC
from qcore import Experiment, qua, Sweep
from qm import qua as qm_qua
from qcore.libs.qua_macros import QuaVariable
from qcore import Dataset

class Rabi(Experiment):
    """Power Rabi"""

    ############################# DEFINE PRIMARY DATASETS ##############################
    # these Datasets form the "raw" experimental data and will be streamed by the OPX
    # they must be specified at experiment runtime
    # primary_datasets = ["I", "Q"]
    primary_datasets = ["I", "Q", "single_shot"]
    ############################## DEFINE PRIMARY SWEEPS ###############################
    # these Sweeps are uniquely associated with the Experiment subclass
    # these Sweeps must be specified at experiment runtime
    primary_sweeps = ["pulse_length"]

    ############################ DEFINE THE PULSE SEQUENCE #############################
    # ensure that you import 'qua' from 'qcore' and not from 'qm' library
    # attributes accessed via 'self' must be defined in 'if __name__ == "__main__"' code
    def sequence(self):
        """QUA sequence that defines this Experiment subclass"""
        self.qubit.play(self.qubit_drive, duration = self.pulse_length/4, ampx = 0.02)
        #self.qubit.play(self.qubit_drive, ampx=self.qubit_pulse_amplitude)
        # self.qubit.play(self.qubit_drive, ampx=self.qubit_pulse_amplitude)
        # self.qubit.play(self.qubit_drive, ampx=self.qubit_pulse_amplitude)
        qua.align()

        self.resonator.measure(self.readout_pulse, (self.I, self.Q), ampx=self.ro_ampx, demod_type="dual")
        qua.wait(self.wait_time)
        if self.plot_single_shot:  # assign state to G or E
            qm_qua.assign(self.single_shot,qm_qua.Cast.to_fixed(self.I > self.readout_pulse.threshold))


if __name__ == "__main__":
    """ """

    #################################### MODE MAP ######################################
    # key: name of the Mode as defined by the Experiment subclass
    # value: name of the Mode as defined by the user in modes.yml
    modes = {
        "qubit": "qC",
        "resonator": "rrC",
    }

    ################################### PULSE MAP ######################################
    # key: name of the Pulse as defined by the Experiment subclass
    # value: name of the Pulse as defined by the user in modes.yml

    pulses = {
        "qubit_drive": "qC_gaussian_pi_pulse",
        "readout_pulse": "rrC_readout_pulse",
    }

    ############################## CONTROL PARAMETERS ##################################
    parameters = {
        "wait_time": 5e5,
        "ro_ampx": 1,
        "plot_single_shot": True,
    }

    ######################## SWEEP (INDEPENDENT) VARIABLES #############################
    # must include an outermost averaging Sweep named "N"
    # must include all primary sweeps defined by the Experiment subclass

    # set number of repetitions for this Experiment run
    N.num = 20000

    LENGTH = Sweep (name="pulse_length", dtype=int, units = "ns")
    LENGTH.start = 48
    LENGTH.stop = 50000
    LENGTH.step = 400

    sweeps = [N, LENGTH]

    ######################## DATASET (DEPENDENT) VARIABLES #############################
    # must include all primary datasets defined by the Experiment subclass
    I.fitfn, Q.fitfn, MAG.fitfn = "exp_decay_sine", "exp_decay_sine", "exp_decay_sine"
    
    PHASE.datafn_args = {"delay": 2.792e-7, "freq": RRC.int_freq}

    SINGLE_SHOT = Dataset(
        name="single_shot",
        save=False,
        plot=True,
    )
    SINGLE_SHOT.fitfn = "exp_decay_sine"

    # PHASE.plot = False
    Q.plot= True
    
    I.plot, MAG.plot = True, False

    # datasets = [I, Q, MAG, PHASE]
    datasets = [I, Q, SINGLE_SHOT]

    ######################## INITIALIZE AND RUN EXPERIMENT #############################
    expt = Rabi(FOLDER, modes, pulses, sweeps, datasets, **parameters)
    # expt.run(simulate=True)
    expt.run()
