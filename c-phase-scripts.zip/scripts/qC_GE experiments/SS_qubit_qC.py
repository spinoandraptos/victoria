""" """
from config.experiment_config import FOLDER, N, FREQ, I, Q, MAG, PHASE, SINGLE_SHOT
from qcore import Experiment, qua, Sweep
from qm import qua as qm_qua

class SSqubit(Experiment):
    """Qubit spectroscopy"""

    ############################# DEFINE PRIMARY DATASETS ##############################
    primary_datasets = ["I", "Q", "single_shot"]

    ############################## DEFINE PRIMARY SWEEPS ###############################
    primary_sweeps = ["qubit_frequency"]

    ############################ DEFINE THE PULSE SEQUENCE #############################
    def sequence(self):
        """QUA sequence that defines this Experiment subclass"""
        qua.update_frequency(self.qubit, self.qubit_frequency)
        qua.update_frequency(self.drive, 193.92e6)
        qua.align()
        self.qubit.play(self.qubit_pulse)
        self.drive.play(self.drive_pulse, ampx = self.drive_amp)
        qua.align()

        self.resonator.measure(self.readout_pulse, (self.I, self.Q), ampx=self.ro_ampx, demod_type="dual")
        qua.align()
        qua.wait(self.wait_time)
        if self.plot_single_shot:  # assign state to G or E
            qm_qua.assign(self.single_shot,qm_qua.Cast.to_fixed(self.I > self.readout_pulse.threshold),)


if __name__ == "__main__":
    """ """

    #################################### MODE MAP ######################################
    modes = {
        "drive": "drive",
        "cavityA":"cavA",
        "qubitA": "qA",
        "qubit": "qC",
        "resonator": "rrC",
    }

    ################################### PULSE MAP ######################################
    pulses = {
        "drive_pulse": "very_good_pulse_2880",
        "qubit_pulse": "qC_gaussian_very_sel_pi_pulse",
        "readout_pulse": "rrC_readout_pulse",        
    }

    ############################## CONTROL PARAMETERS ##################################
    parameters = {
        "wait_time": 500_000,
        "ro_ampx": 1,
        "plot_single_shot": True,
    }

    ######################## SWEEP (INDEPENDENT) VARIABLES #############################
    N.num = 10000
    FREQ.name = "qubit_frequency"
    FREQ.start = -102e6
    FREQ.stop = -65e6
    FREQ.num = 101
    I_AMPX = Sweep(name="drive_amp", start=0.0, stop=1.0, step=0.1)
    sweeps = [N, I_AMPX, FREQ]
    
    ######################## DATASET (DEPENDENT) VARIABLES #############################
    I.plot,MAG.plot, PHASE.plot, SINGLE_SHOT.plot = False, False, False, False
    Q.plot = True
    Q.plot_args["plot_type"] = "image"
    datasets = [I, Q, SINGLE_SHOT]

    ######################## INITIALIZE AND RUN EXPERIMENT #############################
    expt = SSqubit(FOLDER, modes, pulses, sweeps, datasets, **parameters)
    expt.run(simulate=False)
