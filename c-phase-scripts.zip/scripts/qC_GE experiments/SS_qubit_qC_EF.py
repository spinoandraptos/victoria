""" """
from config.experiment_config import FOLDER, N, FREQ, I, Q, MAG, PHASE, SINGLE_SHOT
from qcore import Experiment, qua, Sweep
from qm import qua as qm_qua

class SSqubit(Experiment):
    """Qubit spectroscopy"""

    ############################# DEFINE PRIMARY DATASETS ##############################
    primary_datasets = ["I", "Q", "single_shot"]

    ############################## DEFINE PRIMARY SWEEPS ###############################
    primary_sweeps = ["qubitEF_frequency"]

    ############################ DEFINE THE PULSE SEQUENCE #############################
    def sequence(self):
        """QUA sequence that defines this Experiment subclass"""
        
        self.qubit.play(self.qubit_pi_pulse)
        qua.align(self.qubit, self.qubitEF)
        
        qua.update_frequency(self.qubitEF, self.qubitEF_frequency)
        self.qubitEF.play(self.qubitEF_pi_pulse, ampx = 1.0)
        self.drive.play(self.drive_pulse, ampx = self.drive_amp)
        qua.align(self.drive, self.qubit, self.qubitEF)
        
        self.qubit.play(self.qubit_pi_pulse)
        qua.align(self.resonator, self.qubit)

        self.resonator.measure(self.readout_pulse, (self.I, self.Q), ampx=self.ro_ampx, demod_type="dual")
        qua.align()
        qua.wait(self.wait_time)
        if self.plot_single_shot:  # assign state to G or E
            qm_qua.assign(self.single_shot,qm_qua.Cast.to_fixed(self.I > self.readout_pulse.threshold),)


if __name__ == "__main__":
    """ """

    #################################### MODE MAP ######################################
    modes = {
        "drive": "drive",
        "qubit": "qC",
        "qubitEF": "qC_EF",
        "resonator": "rrC",
    }

    ################################### PULSE MAP ######################################
    pulses = {
        "drive_pulse": "SS_pulse_1440_ramp",
        "qubit_pi_pulse": "qC_gaussian_pi_pulse",
        "qubitEF_pi_pulse": "qC_EF_gaussian_sel_pi_pulse",
        "readout_pulse": "rrC_readout_pulse",        
    }

    ############################## CONTROL PARAMETERS ##################################
    parameters = {
        "wait_time": 5e5,
        "ro_ampx": 1,
        "plot_single_shot": True,
    }

    ######################## SWEEP (INDEPENDENT) VARIABLES #############################
    N.num = 10000
    FREQ.name = "qubitEF_frequency"
    FREQ.start = -50e6
    FREQ.stop = 50e6
    FREQ.num = 101
    I_AMPX = Sweep(name="drive_amp", start=0.1, stop=2.0, step=0.02)
    sweeps = [N, I_AMPX, FREQ]
    
    ######################## DATASET (DEPENDENT) VARIABLES #############################
    Q.plot,MAG.plot, PHASE.plot, I.plot = False, False, False, False
    SINGLE_SHOT.plot = True
    SINGLE_SHOT.plot_args["plot_type"] = "image"
    datasets = [I, Q, SINGLE_SHOT]

    ######################## INITIALIZE AND RUN EXPERIMENT #############################
    expt = SSqubit(FOLDER, modes, pulses, sweeps, datasets, **parameters)
    expt.run(simulate=False)
