from config.experiment_config import FOLDER, N, FREQ, I, Q, MAG, PHASE, RRC, SINGLE_SHOT
from qcore import Experiment, qua, Sweep
from qm import qua as qm_qua
from qcore.libs.qua_macros import QuaVariable
from qcore import Dataset


class QubitSpec(Experiment):
    """Qubit spectroscopy"""

    ############################# DEFINE PRIMARY DATASETS ##############################
    # these Datasets form the "raw" experimental data and will be streamed by the OPX
    # they must be specified at experiment runtime
    primary_datasets = ["I", "Q", "single_shot"]

    ############################## DEFINE PRIMARY SWEEPS ###############################
    # these Sweeps are uniquely associated with the Experiment subclass
    # these Sweeps must be specified at experiment runtime

    primary_sweeps = ["qubit_frequency"]

    ############################ DEFINE THE PULSE SEQUENCE #############################
    # ensure that you import 'qua' from 'qcore' and not from 'qm' library
    # attributes accessed via 'self' must be defined in 'if __name__ == "__main__"' code

    def sequence(self):
        """QUA sequence that defines this Experiment subclass"""
        qua.update_frequency(self.qC, self.qubit_frequency)
        self.qC.play(self.qubit_drive, ampx=self.qo_ampx)
        qua.align(self.qC, self.cavA)
        self.cavA.play(self.cavity_pulse, ampx = 2.0)
        qua.align(self.cavA, self.qA)
        self.qA.play(self.qA_selective_pulse)
        qua.align(self.qA, self.qA_EF)
        self.qA_EF.play(self.qAEF_pi_pulse)
        qua.align(self.qA_EF, self.resonator)
        self.resonator.measure(self.readout_pulse, (self.I, self.Q), ampx=self.ro_ampx, demod_type="dual")
        qua.align()
        qua.wait(self.wait_time)
        if self.plot_single_shot:  # assign state to G or E
            qm_qua.assign(self.single_shot, qm_qua.Cast.to_fixed(self.I > self.readout_pulse.threshold),)


if __name__ == "__main__":
    """ """

    #################################### MODE MAP ######################################
    # key: name of the Mode as defined by the Experiment subclass
    # value: name of the Mode as defined by the user in modes.yml

    modes = {
        "qC": "qC",
        "qA":"qA",
        "qA_EF":"qA_EF",
        "cavA": "cavA",
        "resonator": "rrA",
    }

    ################################### PULSE MAP ######################################
    # key: name of the Pulse as defined by the Experiment subclass
    # value: name of the Pulse as defined by the user in modes.yml

    pulses = {
        "qubit_drive": "qC_gaussian_pi_pulse",
        "qAEF_pi_pulse": "qAEF_EF_gaussian_pi_pulse",
        "cavity_pulse": "cavA_ramp_pulse_selective",
        "qA_selective_pulse": "qA_gaussian_very_sel_pi_pulse",
        "readout_pulse": "rrA_GF_CLEAR_readout_pulse",
    }

    ############################## CONTROL PARAMETERS ##################################

    parameters = {
        "wait_time": 4e6,
        "ro_ampx": 1.0,
        "qo_ampx": 1.0,
        "plot_single_shot": True,
    }

    ######################## SWEEP (INDEPENDENT) VARIABLES #############################
    # must include an outermost averaging Sweep named "N"
    # must include all primary sweeps defined by the Experiment subclass

    # set number of repetitions for this Experiment run
    N.num = 20_000

    # set the qubit frequency sweep for this Experiment run
    FREQ.name = "qubit_frequency"
    FREQ.start = -200e6
    FREQ.stop = 300e6

    FREQ.num = 201

    sweeps = [N, FREQ]

    ######################## DATASET (DEPENDENT) VARIABLES #############################
    # must include all primary datasets defined by the Experiment subclass

    PHASE.datafn_args = {"delay": 2.792e-7, "freq": RRC.int_freq}
    SINGLE_SHOT.fitfn = "sine"

    # PHASE.plot = False
    Q.plot= False
    
    I.plot, MAG.plot = True, False

    #datasets = [I, Q, MAG, PHASE]
    datasets = [I, Q, SINGLE_SHOT]


    

    ######################## INITIALIZE AND RUN EXPERIMENT #############################

    expt = QubitSpec(FOLDER, modes, pulses, sweeps, datasets, **parameters)
    expt.run()
