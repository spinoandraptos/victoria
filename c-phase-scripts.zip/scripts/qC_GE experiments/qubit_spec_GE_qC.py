""" """
from config.experiment_config import FOLDER, N, FREQ, I, Q, MAG, PHASE, RRC, SINGLE_SHOT
from qcore import Experiment, qua, Sweep
from qm import qua as qm_qua
from qcore.libs.qua_macros import QuaVariable
from qcore import Dataset


class QubitSpec(Experiment):
    """Qubit spectroscopy"""

    ############################# DEFINE PRIMARY DATASETS ##############################
    # these Datasets form the "raw" experimental data and will be streamed by the OPX
    # they must be specified at experiment runtime
    primary_datasets = ["I", "Q", "single_shot"]

    ############################## DEFINE PRIMARY SWEEPS ###############################
    # these Sweeps are uniquely associated with the Experiment subclass
    # these Sweeps must be specified at experiment runtime
    primary_sweeps = ["qubit_frequency"]

    ############################ DEFINE THE PULSE SEQUENCE #############################
    # ensure that you import 'qua' from 'qcore' and not from 'qm' library
    # attributes accessed via 'self' must be defined in 'if __name__ == "__main__"' code

    def sequence(self):
        """QUA sequence that defines this Experiment subclass"""
        # qua.reset_frame(self.cavityB)
        # qua.reset_frame(self.qB)
        # qua.reset_frame(self.qubit)
        # qua.reset_frame(self.resonator)
        self.cavityA.play(self.cavA_grape, ampx = self.drive_ampx)
        self.qA.play(self.qA_grape, ampx = self.drive_ampx)
        qua.align()

        # self.cavityB.play(self.cavB_grape, ampx = self.drive_ampx)
        # self.qB.play(self.qB_grape, ampx = self.drive_ampx)
        # qua.align()

        # self.cavityB.play(self.cavB_grape)
        # self.qB.play(self.qB_grape)
        # qua.align()

        # self.qB.play(self.qB_pulse, ampx = self.pulse_amp)
        # qua.align()
        # qua.update_frequency(self.qubit, self.qubit.int_freq)
        # self.qubit.play(self.qubit_drive)
        # qua.align()

        qua.update_frequency(self.drive, 193.92e6)
        qua.update_frequency(self.qubit, self.qubit_frequency)
        qua.align()
        self.qubit.play(self.qubit_pulse, ampx = 1.0)
        self.drive.play(self.drive_pulse)
        qua.align()
                
        # qua.update_frequency(self.qubit, self.qubit.int_freq)
        # self.qubit.play(self.qubit_drive)
        # qua.align()

        # qua.wait(20000, self.resonator)

        self.resonator.measure(self.readout_pulse, (self.I, self.Q), ampx=self.ro_ampx, demod_type="dual")
        qua.align()
        
        qua.wait(self.wait_time)

        if self.plot_single_shot:  # assign state to G or E
            qm_qua.assign(self.single_shot, qm_qua.Cast.to_fixed(self.I > self.readout_pulse.threshold),)


if __name__ == "__main__":
    """ """

    #################################### MODE MAP ######################################
    # key: name of the Mode as defined by the Experiment subclass
    # value: name of the Mode as defined by the user in modes.yml

    modes = {
        "qubit": "qC",
        "qA": "qA", 
        "cavityA": "cavA",
        "qB": "qB", 
        "cavityB": "cavB",
        "drive": "drive",
        "resonator": "rrC",
    }

    ################################### PULSE MAP ######################################
    # key: name of the Pulse as defined by the Experiment subclass
    # value: name of the Pulse as defined by the user in modes.yml

    pulses = {
        "drive_pulse": "SS_pulse_1440_ramp",
        "qubit_pulse": "qC_gaussian_very_sel_pi_pulse",
        "qB_pulse":"qB_gaussian_pi_pulse",
        "qB_grape":"qB_grape_fock1",
        "cavB_grape":"cavB_grape_fock1",
        "qA_grape":"qA_grape_fock1",
        "cavA_grape":"cavA_grape_fock1",
        # "qB_grape":"qA_grape_fock1",
        # "cavB_grape":"cavA_grape_fock1",   
        "drive_pulse": "very_good_pulse_2880",
        "readout_pulse": "rrC_readout_pulse",
    }

    ############################## CONTROL PARAMETERS ##################################

    parameters = {
        "wait_time": 5e6,
        "ro_ampx": 1.0,
        "qo_ampx": 1.0,
        "plot_single_shot": True,
    }

    ######################## SWEEP (INDEPENDENT) VARIABLES #############################
    # must include an outermost averaging Sweep named "N"
    # must include all primary sweeps defined by the Experiment subclass

    # set number of repetitions for this Experiment run
    N.num = 20_000

    # set the qubit frequency sweep for this Experiment run
    FREQ.name = "qubit_frequency"
    FREQ.start = -84e6
    FREQ.stop = -82e6
    FREQ.num = 101

    AMP = Sweep(name="drive_ampx", start=0.0, stop=1.0, step = 1.0, save=True)

    sweeps = [N, AMP, FREQ]

    ######################## DATASET (DEPENDENT) VARIABLES #############################
    # must include all primary datasets defined by the Experiment subclass

    PHASE.datafn_args = {"delay": 2.792e-7, "freq": RRC.int_freq}
    SINGLE_SHOT.fitfn = "sine"

    # PHASE.plot = False
    Q.plot= True
    
    I.plot, MAG.plot = True, True

    # datasets = [I, Q, MAG, PHASE]
    datasets = [I, Q, SINGLE_SHOT]


    

    ######################## INITIALIZE AND RUN EXPERIMENT #############################

    expt = QubitSpec(FOLDER, modes, pulses, sweeps, datasets, **parameters)
    expt.run(simulate =False)
