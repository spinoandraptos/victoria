import numpy as np
import os
import h5py
import matplotlib.pyplot as plt
from scipy.optimize import curve_fit

filepath = r"C:\Users\admin\Desktop\cphase\data\2025-07-08\10-21-12_SSqubit.hdf5"

data = h5py.File(filepath, "r")
# I_raw = np.array(data["I"])
# Q_raw = np.array(data["Q"])
flipped_state = np.mean(np.array(data["single_shot"]), axis = 0)
state = flipped_state[::-1, :]
reversed_amps =  np.array(data["drive_amp"])
amps = reversed_amps[::-1]
freqs_neg = np.array(data["qubit_frequency"])
freqs= freqs_neg/1e6 + 256

plt.imshow(state, cmap='seismic', interpolation='nearest', aspect='auto')
plt.colorbar(label='Value')
plt.xticks(np.arange(len(freqs)), [f'{x:.2f}' for x in freqs])
plt.yticks(np.arange(len(amps)),  [f'{y:.2f}' for y in amps])
plt.xlabel('X Axis')
plt.ylabel('Y Axis')
plt.title('Color Plot with Seismic Colormap')
plt.show()


max_indices = np.argmax(state, axis=1)
max_freqs = freqs[max_indices]

co_amps = amps[7:201]
co_freqs = max_freqs [7:201]

# Define a second-order polynomial function
def second_order_poly(amps, C):
    return -2 * 115 * (C*amps)**2

# # Fit a second-order polynomial to the max_indices against amplitudes
# popt, pcov = curve_fit(second_order_poly, co_amps, co_freqs)

# print(popt)

# # Plot the results
# plt.plot(co_amps, co_freqs, 'bo', label='Stark shift')
# plt.plot(co_amps, second_order_poly(co_amps, *popt), 'r-', label='Fitted Curve')
# plt.xlabel('Drive Amplitude')
# plt.ylabel('Frequency shift')
# plt.title('Stark shift')
# plt.legend()
# plt.grid(True)
# plt.show()

coeffs = np.polyfit(co_amps, co_freqs, 2)
poly_fn = np.poly1d(coeffs)

# Create smooth x values for plotting the curve
x_fit = np.linspace(min(co_amps), max(co_amps), 200)
y_fit = poly_fn(x_fit)

# Plot original data and polynomial fit
plt.scatter(co_amps, co_freqs, color='blue', label='Data points')
plt.plot(x_fit, y_fit, color='red', label='Polynomial fit')

# Annotate plot
plt.xlabel('Amplitude (co_amps)')
plt.ylabel('Frequency (co_freqs)')
plt.title('Second-Order Polynomial Fit')
plt.legend()
plt.grid(True)
plt.tight_layout()
plt.show()