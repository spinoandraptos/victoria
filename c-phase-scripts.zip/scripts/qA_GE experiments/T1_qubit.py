""" """
import sys

sys.path.append("C:/Users/admin/Desktop/qcore-yabba/yabba-main/")
from config.experiment_config import FOLDER, N, I, Q, MAG, PHASE, RRC, SINGLE_SHOT
from qcore import Experiment, qua, Sweep
from qm import qua as qm_qua


class QubitT1(Experiment):
    """Qubit T1"""

    ############################# DEFINE PRIMARY DATASETS ##############################
    # these Datasets form the "raw" experimental data and will be streamed by the OPX
    # they must be specified at experiment runtime

    primary_datasets = ["I", "Q", "single_shot"]
    # primary_datasets = ["I", "Q"]

    ############################## DEFINE PRIMARY SWEEPS ###############################
    # these Sweeps are uniquely associated with the Experiment subclass
    # these Sweeps must be specified at experiment runtime

    primary_sweeps = ["time_delay"]

    ############################ DEFINE THE PULSE SEQUENCE #############################
    # ensure that you import 'qua' from 'qcore' and not from 'qm' library
    # attributes accessed via 'self' must be defined in 'if __name__ == "__main__"' code

    def sequence(self):
        """QUA sequence that defines this Experiment subclass"""
        
        self.qubit.play(self.qubit_drive)
        qua.align()
        qua.wait(self.time_delay, self.qubit)
        qua.align()
        self.resonator.measure(self.readout_pulse, (self.I, self.Q), ampx=self.ro_ampx, demod_type="dual")
        qua.align()
        qua.wait(self.wait_time)

        if self.plot_single_shot:  # assign state to G or E
            qm_qua.assign(self.single_shot,qm_qua.Cast.to_fixed(self.I > self.readout_pulse.threshold))


if __name__ == "__main__":
    """ """

    #################################### MODE MAP ######################################
    # key: name of the Mode as defined by the Experiment subclass
    # value: name of the Mode as defined by the user in modes.yml

    modes = {
        "qubit": "qA",
        "resonator": "rrA",
    }

    ################################### PULSE MAP ######################################
    # key: name of the Pulse as defined by the Experiment subclass
    # value: name of the Pulse as defined by the user in modes.yml

    pulses = {
        "qubit_drive": "qA_gaussian_pi_pulse",
        "readout_pulse": "rrA_readout_pulse",
    }

    ############################## CONTROL PARAMETERS ##################################

    parameters = {
        "wait_time": 600_000,
        "ro_ampx": 1,
        "plot_single_shot": True,
    }

    ######################## SWEEP (INDEPENDENT) VARIABLES #############################
    # must include an outermost averaging Sweep named "N"
    # must include all primary sweeps defined by the Experiment subclass

    # set number of repetitions for this Experiment run
    N.num = 5000000

    # set the qubit frequency sweep for this Experiment run

    DEL = Sweep(name="time_delay", start=16, stop=200_000, num=100, dtype=int)
    sweeps = [N, DEL]

    ######################## DATASET (DEPENDENT) VARIABLES #############################
    # must include all primary datasets defined by the Experiment subclass
    # I.fitfn, Q.fitfn, MAG.fitfn = "exp_decay", "exp_decay", "exp_decay"
    # PHASE.plot = False
    datasets = [I, Q, SINGLE_SHOT]
    # MAG.plot = False
    # Q.plot = False
    # SINGLE_SHOT.plot = True
    # I.plot = False
    SINGLE_SHOT.fitfn = "exp_decay"
    I.fitfn = "exp_decay"
    MAG.fitfn = "exp_decay"
    ######################## INITIALIZE AND RUN EXPERIMENT #############################

    expt = QubitT1(FOLDER, modes, pulses, sweeps, datasets, **parameters)
    expt.run()
