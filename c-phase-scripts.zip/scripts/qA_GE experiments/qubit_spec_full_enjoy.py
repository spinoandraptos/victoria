""" """

import sys

sys.path.append("C:/Users/admin/Desktop/qcore-yabba/yabba-main/")
from config.experiment_config import FOLDER, N, FREQ, SINGLE_SHOT, I, Q, MAG, PHASE, RR
from qcore import Experiment, qua, Sweep
from qcore.helpers import Stage
from config.experiment_config import MODES_CONFIG
from qm import qua as qm_qua
from qcore.libs.qua_macros import QuaVariable
from qcore import Dataset
import numpy as np


class QubitSpec_with_DC(Experiment):
    """Qubit spectroscopy"""

    ############################# DEFINE PRIMARY DATASETS ##############################
    # these Datasets form the "raw" experimental data and will be streamed by the OPX
    # they must be specified at experiment runtime
    primary_datasets = ["I", "Q"]

    ############################## DEFINE PRIMARY SWEEPS ###############################
    # these Sweeps are uniquely associated with the Experiment subclass
    # these Sweeps must be specified at experiment runtime

    primary_sweeps = ["qubit_frequency"]

    ############################ DEFINE THE PULSE SEQUENCE #############################
    # ensure that you import 'qua' from 'qcore' and not from 'qm' library
    # attributes accessed via 'self' must be defined in 'if __name__ == "__main__"' code

    def sequence(self):
        """QUA sequence that defines this Experiment subclass"""
        qua.update_frequency(self.qubit, self.qubit_frequency)
        self.qubit.play(self.qubit_drive, ampx=self.qo_ampx)
        # qua.align()
        self.resonator.measure(
            self.readout_pulse, (self.I, self.Q), ampx=self.ro_ampx, demod_type="dual"
        )
        qua.wait(self.wait_time, self.resonator)
        if self.plot_single_shot:  # assign state to G or E
            qm_qua.assign(
                self.single_shot,
                qm_qua.Cast.to_fixed(self.I > self.readout_pulse.threshold),
            )


if __name__ == "__main__":
    """ """

    #################################### MODE MAP ######################################
    # key: name of the Mode as defined by the Experiment subclass
    # value: name of the Mode as defined by the user in modes.yml

    modes = {
        "qubit": "qubit",
        "resonator": "rr",
    }
    with Stage(configpath=MODES_CONFIG, remote=True) as stage:
        (yoko,) = stage.get("yoko",)
    yoko.ramp(0, step=1e-4)
    yoko.output = True

    ################################### PULSE MAP ######################################
    # key: name of the Pulse as defined by the Experiment subclass
    # value: name of the Pulse as defined by the user in modes.yml

    pulses = {
        "qubit_drive": "qubit_constant_pulse",
        "readout_pulse": "rr_readout_pulse",
    }

    ############################## CONTROL PARAMETERS ##################################

    parameters = {
        "wait_time": 30_000,
        "ro_ampx": 0.6,
        "qo_ampx": 1.0,
        "plot_single_shot": False,
    }

    ######################## SWEEP (INDEPENDENT) VARIABLES #############################
    # must include an outermost averaging Sweep named "N"
    # must include all primary sweeps defined by the Experiment subclass

    # set number of repetitions for this Experiment run
    N.num = 50_000

    # set the qubit frequency sweep for this Experiment run
    FREQ.name = "qubit_frequency"
    FREQ.start = -200e6
    FREQ.stop = 130e6
    FREQ.num = 825
    DC_currents = np.arange(start=-7.5e-3, stop=7.5e-3, step=0.04e-3)

    sweeps = [N, FREQ]

    ######################## DATASET (DEPENDENT) VARIABLES #############################
    # must include all primary datasets defined by the Experiment subclass

    PHASE.datafn_args = {"delay": 2.792e-7, "freq": RR.int_freq}
    I.plot = False
    Q.plot= False
    MAG.plot = False
    PHASE.plot= False
    datasets = [I, Q, MAG, PHASE]

    ######################## INITIALIZE AND RUN EXPERIMENT #############################

    for DC_current in DC_currents:
        yoko.ramp(DC_current, step=0.01e-3)
        expt = QubitSpec_with_DC(FOLDER, modes, pulses, sweeps, datasets, current_value=DC_current, **parameters)
        expt.run()
    yoko.ramp(0, step=0.5e-4)
    yoko.output = False