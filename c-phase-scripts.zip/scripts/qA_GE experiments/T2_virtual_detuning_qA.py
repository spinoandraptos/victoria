from config.experiment_config import FOLDER, N, I, Q, MAG, PHASE, RRA, SINGLE_SHOT
from qcore import Experiment, qua, Sweep
from cmath import phase
from qm import qua as qm_qua
from qcore.libs.qua_macros import QuaVariable
from qcore.helpers import logger


class QubitT2(Experiment):
    """Qubit T2 Virtual Detuning"""

    ############################# DEFINE PRIMARY DATASETS ##############################
    primary_datasets = ["I", "Q", "single_shot"]

    ############################## DEFINE PRIMARY SWEEPS ###############################
    primary_sweeps = ["time_delay"]

    ############################ DEFINE THE PULSE SEQUENCE #############################

    def sequence(self):
        qua.reset_frame(self.qubit)
        factor = qm_qua.declare(qm_qua.fixed)
        qm_qua.assign(factor, self.detuning * 1e-9)  # formerly with a 4*
        qua.reset_frame(self.qubit)


        # self.resonator.measure(self.readout_pulse, (self.I, self.Q), demod_type="dual")
        # qua.wait(1500, self.resonator)
        # qua.align(self.resonator, self.qubit)

        self.qubit.play(self.qubit_drive)
        qua.wait(self.time_delay, self.qubit) 
        qm_qua.assign(self.phase, qm_qua.Cast.mul_fixed_by_int(factor, self.time_delay))
        self.qubit.play(self.qubit_drive, phase=self.phase)
        qua.align(self.qubit, self.qubitEF)
        self.qubitEF.play(self.qubitEF_pi)
        qua.align(self.qubitEF, self.resonator)
        self.resonator.measure(self.readout_pulse, (self.I, self.Q), demod_type="dual")
        qua.align()
        qua.wait(self.wait_time)
        if self.plot_single_shot:  # assign state to G or E
            qm_qua.assign(self.single_shot,qm_qua.Cast.to_fixed(self.I > self.readout_pulse.threshold),)


if __name__ == "__main__":
    """ """

    #################################### MODE MAP ######################################
    modes = {"qubit": "qA", 
             "qubitEF": "qA_EF", 
            #  "drive": "drive",
             "resonator": "rrA",
             }
    ################################### PULSE MAP ######################################
    pulses = {"qubit_drive": "qA_gaussian_pi2_pulse", 
              "readout_pulse": "rrA_GF_CLEAR_readout_pulse",
            #   "drive_pulse": "exchange_pulse",
              "echo_pulse":"qA_gaussian_pi_pulse",
              "qubitEF_pi":"qAEF_EF_gaussian_pi_pulse",
            }

    ############################## CONTROL PARAMETERS ##################################
    parameters = {
        "wait_time": 600_000,
        "detuning": 500e3,  # Hz
        "phase": QuaVariable(value=0.0,dtype=qm_qua.fixed,tag="phase",buffer=True,stream=True),
        "plot_single_shot": True,
    }

    ######################## SWEEP (INDEPENDENT) VARIABLES #############################
    N.num = 5000
    DEL = Sweep(name="time_delay", start=16, stop=60_000, step=200, dtype=int)  # ns
    sweeps = [N, DEL]

    ######################## DATASET (DEPENDENT) VARIABLES #############################
    I.fitfn = "exp_decay_sine"
    Q.fitfn = "exp_decay_sine"
    MAG.fitfn = "exp_decay_sine"
    PHASE.datafn_args = {"delay": 2.792e-7, "freq": RRA.int_freq}
    # PHASE.plot = False
    I.plot, Q.plot = False, False
    SINGLE_SHOT.plot = True
    SINGLE_SHOT.fitfn = "exp_decay_sine"
    datasets = [I, Q, SINGLE_SHOT]

    ######################## INITIALIZE AND RUN EXPERIMENT #############################
    expt = QubitT2(FOLDER, modes, pulses, sweeps, datasets, **parameters)
    expt.run(simulate=False)
