""" """
import sys
from config.experiment_config import FOLDER, N, I, Q, MAG, PHASE, RRA, SINGLE_SHOT, RRC
from qcore import Experiment, qua, Sweep
from qm import qua as qm_qua
from qcore.libs.qua_macros import QuaVariable
from qcore import Dataset

class Rabi(Experiment):
    """Power Rabi"""

    ############################# DEFINE PRIMARY DATASETS ##############################
    # these Datasets form the "raw" experimental data and will be streamed by the OPX
    # they must be specified at experiment runtime
    # primary_datasets = ["I", "Q"]
    primary_datasets = ["I", "Q", "single_shot"]
    ############################## DEFINE PRIMARY SWEEPS ###############################
    # these Sweeps are uniquely associated with the Experiment subclass
    # these Sweeps must be specified at experiment runtime
    primary_sweeps = ["qubit_pulse_amplitude"]

    ############################ DEFINE THE PULSE SEQUENCE #############################
    # ensure that you import 'qua' from 'qcore' and not from 'qm' library
    # attributes accessed via 'self' must be defined in 'if __name__ == "__main__"' code
    def sequence(self):
        """QUA sequence that defines this Experiment subclass"""
      
        qua.update_frequency(self.qubit, self.qubit.int_freq)
        self.qubit.play(self.qubit_grape)
        self.cavity.play(self.cavity_grape)
        qua.align()
        qua.update_frequency(self.qubit, 250.22e6)
        self.qubit.play(self.qubit_drive, ampx=self.qubit_pulse_amplitude)
        qua.align()
        self.qubitEF.play(self.qubitEF_pi)
        qua.align()
        self.resonator.measure(self.readout_pulse, (self.I, self.Q), ampx=self.ro_ampx, demod_type="dual")
        qua.wait(self.wait_time)
        if self.plot_single_shot:  # assign state to G or E
            qm_qua.assign(self.single_shot,qm_qua.Cast.to_fixed(self.I > self.readout_pulse.threshold),)


if __name__ == "__main__":
    """ """

    #################################### MODE MAP ######################################
    # key: name of the Mode as defined by the Experiment subclass
    # value: name of the Mode as defined by the user in modes.yml
    modes = {
        "qubit": "qA",
        "qubitEF": "qA_EF",
        "resonator": "rrA",
        "cavity": "cavA", 
    }

    ################################### PULSE MAP ######################################
    # key: name of the Pulse as defined by the Experiment subclass
    # value: name of the Pulse as defined by the user in modes.yml

    pulses = {
        # "qubit_drive": "qA_gaussian_pi2_pulse",
        "qubit_drive": "qA_gaussian_very_sel_pi_pulse",
        "qubit_grape": "qA_grape_fock2",
        "cavity_grape": "cavA_grape_fock2",
        "qubitEF_pi": "qAEF_EF_gaussian_pi_pulse",
        "readout_pulse": "rrA_GF_CLEAR_readout_pulse",
    }

    ############################## CONTROL PARAMETERS ##################################
    parameters = {
        "wait_time": 6e6,
        "ro_ampx": 1,
        "plot_single_shot": True,
    }

    ######################## SWEEP (INDEPENDENT) VARIABLES #############################
    # must include an outermost averaging Sweep named "N"
    # must include all primary sweeps defined by the Experiment subclass

    # set number of repetitions for this Experiment run
    N.num = 20000

    # set the qubit amplitude sweep for this Experiment run
    QD_AMPX = Sweep(name="qubit_pulse_amplitude", start=-1.8, stop=1.8, num=101)

    sweeps = [N, QD_AMPX]

    ######################## DATASET (DEPENDENT) VARIABLES #############################
    # must include all primary datasets defined by the Experiment subclass
    I.fitfn, Q.fitfn, MAG.fitfn = "sine", "sine", "sine"
    
    PHASE.datafn_args = {"delay": 2.792e-7, "freq": RRA.int_freq}

    SINGLE_SHOT = Dataset(
        name="single_shot",
        save=True,
        plot=True,
    )
    SINGLE_SHOT.fitfn = "sine"

    # PHASE.plot = False
    Q.plot= True
    
    I.plot, MAG.plot = True, True

    #datasets = [I, Q, MAG, PHASE]
    datasets = [I, Q, SINGLE_SHOT]

    ######################## INITIALIZE AND RUN EXPERIMENT #############################
    expt = Rabi(FOLDER, modes, pulses, sweeps, datasets, **parameters)
    expt.run()
    # expt.run()
