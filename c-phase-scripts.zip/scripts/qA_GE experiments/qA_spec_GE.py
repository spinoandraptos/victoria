from config.experiment_config import FOLDER, N, FREQ, I, Q, MAG, PHASE, RRA, SINGLE_SHOT
from qcore import Experiment, qua, Sweep
from qm import qua as qm_qua
from qcore.libs.qua_macros import QuaVariable
from qcore import Dataset


class QubitSpec(Experiment):
    """Qubit spectroscopy"""

    ############################# DEFINE PRIMARY DATASETS ##############################
    # these Datasets form the "raw" experimental data and will be streamed by the OPX
    # they must be specified at experiment runtime
    primary_datasets = ["I", "Q", "single_shot"]

    ############################## DEFINE PRIMARY SWEEPS ###############################
    # these Sweeps are uniquely associated with the Experiment subclass
    # these Sweeps must be specified at experiment runtime

    primary_sweeps = ["qubit_frequency"]

    ############################ DEFINE THE PULSE SEQUENCE #############################
    # ensure that you import 'qua' from 'qcore' and not from 'qm' library
    # attributes accessed via 'self' must be defined in 'if __name__ == "__main__"' code

    def sequence(self):
        """QUA sequence that defines this Experiment subclass"""
        # qua.update_frequency(self.qubit, self.qubit.int_freq)
        # self.qubit.play(self.qubit_grape)
        # self.cavity.play(self.cavity_grape)
        # qua.align()

        qua.update_frequency(self.qubit, self.qubit_frequency)
        self.qubit.play(self.qubit_drive)
        # self.drive.play(self.drive_pulse, ampx = 0.8, duration = 16*60*4)
        qua.align(self.qubit, self.qubitEF)
        
        self.qubitEF.play(self.qubitEF_pi)
        qua.align(self.qubitEF, self.resonator)
        self.resonator.measure(self.readout_pulse, (self.I, self.Q), demod_type="dual")
        if self.plot_single_shot:  # assign state to G or E
            qm_qua.assign(self.single_shot,qm_qua.Cast.to_fixed(self.I > self.readout_pulse.threshold),)

        qua.align()
        qua.wait(self.wait_time)

if __name__ == "__main__":
    """ """

    #################################### MODE MAP ######################################
    modes = {
        "qubit": "qA",
        "qubitEF": "qA_EF",
        "resonator": "rrA",
        "cavity":"cavA",
        # "drive": "drive",
    }

    ################################### PULSE MAP ######################################
    pulses = {
        "qubitEF_pi": "qAEF_EF_gaussian_pi_pulse",
        "qubit_drive": "qA_gaussian_very_sel_pi_pulse",
        # "qubit_grape": "qA_grape_fock4",
        # "cavity_grape": "cavA_grape_fock4",
        "readout_pulse": "rrA_GF_CLEAR_readout_pulse",
        # "drive_pulse": "exchange_pulse",
    }

    ############################## CONTROL PARAMETERS ##################################
    parameters = {
        "wait_time": 6e6,
        "plot_single_shot": True,
    }

    ######################## SWEEP (INDEPENDENT) VARIABLES #############################
    N.num = 20_000
    FREQ.name = "qubit_frequency"
    FREQ.start = 350e6
    FREQ.stop = 353e6
    FREQ.num = 101
    sweeps = [N, FREQ]

    ######################## DATASET (DEPENDENT) VARIABLES #############################
    PHASE.datafn_args = {"delay": 2.792e-7, "freq": RRA.int_freq}
    SINGLE_SHOT.fitfn = "gaussian"
    # PHASE.plot = False
    Q.plot= False
    I.plot, MAG.plot = False, False
    #datasets = [I, Q, MAG, PHASE]
    datasets = [I, Q, SINGLE_SHOT]

    ######################## INITIALIZE AND RUN EXPERIMENT #############################
    expt = QubitSpec(FOLDER, modes, pulses, sweeps, datasets, **parameters)
    expt.run()
