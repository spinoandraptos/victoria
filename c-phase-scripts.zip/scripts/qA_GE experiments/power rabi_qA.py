""" """
import sys
from config.experiment_config import FOLDER, N, I, Q, MAG, PHASE, RRA, SINGLE_SHOT, RRC
from qcore import Experiment, qua, Sweep
from qm import qua as qm_qua
from qcore.libs.qua_macros import QuaVariable
from qcore import Dataset

class Rabi(Experiment):
    """Power Rabi"""

    ############################# DEFINE PRIMARY DATASETS ##############################
    # these Datasets form the "raw" experimental data and will be streamed by the OPX
    # they must be specified at experiment runtime
    # primary_datasets = ["I", "Q"]
    primary_datasets = ["I", "Q", "single_shot"]
    ############################## DEFINE PRIMARY SWEEPS ###############################
    # these Sweeps are uniquely associated with the Experiment subclass
    # these Sweeps must be specified at experiment runtime
    primary_sweeps = ["qubit_pulse_amplitude"]

    ############################ DEFINE THE PULSE SEQUENCE #############################
    # ensure that you import 'qua' from 'qcore' and not from 'qm' library
    # attributes accessed via 'self' must be defined in 'if __name__ == "__main__"' code
    def sequence(self):
        """QUA sequence that defines this Experiment subclass"""
        qua.reset_frame(self.cavity)
        qua.reset_frame(self.qubitA)

        self.qubitA.play(self.qubit_drive, ampx = self.qubit_pulse_amplitude)  # play selective qubit pulse
        # self.qubitA.play(self.qubit_drive, ampx = self.qubit_pulse_amplitude)  # play selective qubit pulse
        # self.qubitA.play(self.qubit_drive, ampx = self.qubit_pulse_amplitude)  # play selective qubit pulse
        # self.qubitA.play(self.qubit_drive, ampx = self.qubit_pulse_amplitude)  # play selective qubit pulse
        qua.align(self.qubitA, self.qubitEF)

        self.qubitEF.play(self.qubitEF_pi)
        qua.align(self.qubitEF, self.resonator)
        self.resonator.measure(self.readout_pulse, (self.I, self.Q), demod_type="dual")
        qua.align()
        qua.wait(self.wait_time)
        if self.plot_single_shot:  # assign state to G or E
            qm_qua.assign(self.single_shot,qm_qua.Cast.to_fixed(self.I > self.readout_pulse.threshold),)


if __name__ == "__main__":
    """ """

    #################################### MODE MAP ######################################
    modes = {
        "qubitA": "qA",
        "cavity": "cavA",
        "qubitEF": "qA_EF",
        "resonator": "rrA",
    }

    ################################### PULSE MAP ######################################
    pulses = {
        # "qubit_drive": "qA_gaussian_pi_pulse",
        # "qubit_drive": "qA_grape_pi",
       "qubit_drive": "qA_gaussian_very_sel_pi_pulse",

        #"qubitA_grape": "qA_grape_fock1",
        # "cavityA_grape": "cavA_grape_fock1",
        "qubitEF_pi": "qAEF_EF_gaussian_pi_pulse",
        "readout_pulse": "rrA_GF_CLEAR_readout_pulse",
    }

    ############################## CONTROL PARAMETERS ##################################
    parameters = {
        "wait_time": 8e5,
        "ro_ampx": 1,
        "plot_single_shot": True,
    }

    ######################## SWEEP (INDEPENDENT) VARIABLES #############################
    N.num = 20000
    QD_AMPX = Sweep(name="qubit_pulse_amplitude", start=-1.6, stop=1.6, num=101)
    sweeps = [N, QD_AMPX]

    ######################## DATASET (DEPENDENT) VARIABLES #############################
    I.fitfn, Q.fitfn, MAG.fitfn = "sine", "sine", "sine"
    PHASE.datafn_args = {"delay": 2.792e-7, "freq": RRA.int_freq}
    SINGLE_SHOT = Dataset(name="single_shot",save=True,plot=True)
    SINGLE_SHOT.fitfn = "sine"
    Q.plot= False
    I.plot, MAG.plot = False, True

    #datasets = [I, Q, MAG, PHASE]
    datasets = [I, Q, SINGLE_SHOT]

    ######################## INITIALIZE AND RUN EXPERIMENT #############################
    expt = Rabi(FOLDER, modes, pulses, sweeps, datasets, **parameters)
    expt.run()
