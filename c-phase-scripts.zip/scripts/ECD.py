
from pulses import disp_gaussian, rotate
import numpy as np
import seaborn as sns
import matplotlib.pyplot as plt
from scipy.signal import find_peaks
from scipy.optimize import fmin
from qutip import tensor, sigmaz, sigmax, sigmay, fock, displace, qeye  # for
from jax import jit, lax
import jax.numpy as jnp
import logging


class ECD(object):
    """
    Class that constructs ECD sequences. The default sequence uses the instant pulse approximation. 
    The class also provides a method to calculate the analytical parameters of the ECD sequence.
    Furthermore, it allows to optimze th sequence to get the best possible fidelity.

    Something i still dont like is that the default pulse and optimzied pulse are in a different format. The optimized pulse is a dict  while the default pulse is just 
    the two pulses. This is because the optimized pulse is a result of a minimization problem, and the default pulse is just a sequence that is calculated.
    """

    def __init__(self, beta, system_dict):

        self.beta = beta
        self.system_dict = system_dict
        self.chi = system_dict["chi_e"]
        self.chi_prime = system_dict["chi_e_prime"]
        self.K_s = system_dict["K_s"]
        self.sigma_q = system_dict["sigma_q"]
        self.sigma_c = system_dict["sigma_c"]
        self.chop = system_dict["chop"]
        self.tw = system_dict["tw"]
        self.default_ratios = [1.0, 1.0, np.cos((self.chi / 2.0) * self.tw), np.cos(self.chi * self.tw)]

        self.cavity_pulse, self.qubit_pulse = self.get_ecd_pulses(self.beta)
        self.tlist = np.arange(0, len(self.cavity_pulse), dtype=np.double)
        self.alphas = self.disp_frame_alpha_from_epsilon_non_linear_finite_difference(
            self.cavity_pulse)
        self.analytical_ecd_param_dict = self.analytic_ecd_params()

        logging.info("Calculated default cavity_pulse, qubit_pulse")
        logging.info("Calculated default alphas")
        logging.info("Calculated default analytic_ecd_params")

    def get_ecd_pulses(self, β: complex, α: complex = None, ratios=None, dt=1,
                       ) -> tuple[np.ndarray, np.ndarray]:
        """Constructs an approximate ECD sequence for the cavity and qubit pulses

        Args:
            param_dict (dict): dictionary that holds chi and pulse parameters
            ratios (_type_, optional): in case we want to scale the individual ecd pulses. If none, the default scaling of the fast control paper is used
            dt (int, optional): _description_. Defaults to 1.

        Returns:
            tuple[np.ndarray, np.ndarray]: cavity_pulse, qubit_pulse
        """

        β_abs = np.abs(β)
        β_phase = np.angle(β)

        χ = self.chi  # in GHz
        σ_q = self.sigma_q  # in ns
        σ_c = self.sigma_c  # in n s
        chop = self.chop
        tw = self.tw  # in ns

        if α is None:
            α = β_abs / (2 * np.sin(χ * tw))
        else:
            α = float(α) if isinstance(α, int) else α

        α = np.abs(α)
        α_phase = β_phase + np.pi / 2.0

        d = disp_gaussian(α, σ_c, chop, dt)

        # corresponding to sy pi flip
        p = rotate(np.pi, 0, sigma=σ_q, chop=chop, dt=dt)

        tw
        if ratios is not None:
            r = ratios[0]
            r0 = ratios[1]
            r1 = ratios[2]
            r2 = ratios[3]
        else:
            r = 1.0
            r0 = 1.0
            r1 = np.cos((χ / 2.0) * tw)
            r2 = np.cos(χ * tw)

        def construct_CD(tw, r, r0, r1, r2):
            cavity_pulse = r * np.concatenate(
                [
                    r0 * d * np.exp(1j * α_phase),
                    np.zeros(tw),
                    r1 * d * np.exp(1j * (α_phase + np.pi)),
                    np.zeros(len(p)),
                    r1 * d * np.exp(1j * (α_phase + np.pi)),
                    np.zeros(tw),
                    r2 * d * np.exp(1j * α_phase),
                ]
            )
            qubit_pulse = np.concatenate(
                [
                    np.zeros(tw + 2 * len(d)),
                    p,
                    np.zeros(tw + 2 * len(d)),
                ]
            )
            
            ecd_dict = {
            "cavity_pulse": cavity_pulse,
            "qubit_pulse": qubit_pulse,
            "alpha": α,
            "tw": tw,
            "ratios": (r, r0, r1, r2),
            }
            self.ecd_dict = ecd_dict
            
            return cavity_pulse, qubit_pulse

        return construct_CD(tw, r, r0, r1, r2)

    def _get_flip_idxs(self, qubit_pulse):
        return find_peaks(np.abs(qubit_pulse), height=np.max(qubit_pulse) * 0.975)[0]

    def analytic_ecd_params(self, cavity_pulse=None, qubit_pulse=None):

        if cavity_pulse is None:
            cavity_pulse = self.cavity_pulse
        if qubit_pulse is None:
            qubit_pulse = self.qubit_pulse

        χ = self.system_dict["chi_e"]
        flip_idxs = self._get_flip_idxs(qubit_pulse)
        pm = +1
        z = []
        for i in range(len(flip_idxs) + 1):
            l_idx = 0 if i == 0 else flip_idxs[i - 1]
            r_idx = len(qubit_pulse) if i == len(flip_idxs) else flip_idxs[i]
            z.append(pm * np.ones(r_idx - l_idx))
            pm = -1 * pm
        z = np.concatenate(z)
        phi = -(χ / 2.0) * np.cumsum(z)
        gamma = np.zeros_like(phi, dtype=np.complex64)
        delta = np.zeros_like(gamma)
        for i in range(len(phi)):
            delta[i] = -1 * \
                np.sum(np.sin(phi[: i + 1] - phi[i]) * cavity_pulse[: i + 1])
            gamma[i] = -1j * \
                np.sum(np.cos(phi[: i + 1] - phi[i]) * cavity_pulse[: i + 1])
        theta = -2 * np.cumsum(np.real(np.conj(cavity_pulse) * delta))
        correction = 2 * np.imag(gamma[-1] * delta[-1])
        theta_prime = theta[-1] + correction
        beta = 2 * delta[-1]

        analytical_ecd_param_dict = {
            "phi": phi,
            "delta": delta,
            "gamma": gamma,
            "theta": theta,  # actual qubit phase
            "correction": correction,
            "theta_prime": theta_prime,  # corrected qubit phase
            "qubit_phase": theta_prime,
            "beta": beta,
        }
        return analytical_ecd_param_dict

    def analytic_ecd_unitary(self, analytical_ecd_param_dict=None,  N=50):

        if analytical_ecd_param_dict is None:
            analytical_ecd_param_dict = self.analytical_ecd_param_dict

        # return unitary as calculated in the fast control paper
        β = analytical_ecd_param_dict["beta"]
        λ = analytical_ecd_param_dict["gamma"][-1]
        θ_prime = analytical_ecd_param_dict["theta_prime"]

        proj_g = fock(2, 0) * fock(2, 0).dag()
        proj_e = fock(2, 1) * fock(2, 1).dag()
        cd = tensor(proj_g, displace(N, +β/2)) + \
            tensor(proj_e, displace(N, -β/2))
        d = tensor(qeye(2), displace(N, λ))
        sx = tensor(sigmax(), qeye(N))
        sy = tensor(sigmay(), qeye(N))
        sz = tensor(sigmaz(), qeye(N))
        unitary = sx*(1j*θ_prime*sz/2).expm()*d*cd
        return unitary

    def plot_analytical_params(self, analytical_ecd_param_dict=None):

        if analytical_ecd_param_dict is None:
            analytical_ecd_param_dict = self.analytical_ecd_param_dict

        # Set the aesthetic style of the plots
        sns.set_theme(style="whitegrid")
        print("currently plotting abs of alpha and beta")
        # Create a figure and a set of subplots
        fig, axs = plt.subplots(2, 2, figsize=(8, 4), sharex=True)

        # phi plot
        sns.lineplot(
            data=analytical_ecd_param_dict["phi"], ax=axs[0, 0], color="blue")
        axs[0, 0].set_title(
            f'Phi - Final Value: {analytical_ecd_param_dict["phi"][-1]:.4f}')

        # delta plot
        sns.lineplot(data=np.abs(
            analytical_ecd_param_dict["delta"]), ax=axs[0, 1], color="green")
        axs[0, 1].set_title(
            f'Beta/2 - Final Value: {np.abs(analytical_ecd_param_dict["delta"][-1]):.4f}')

        # gamma plot
        sns.lineplot(data=np.abs(
            analytical_ecd_param_dict["gamma"]), ax=axs[1, 0], color="red")
        axs[1, 0].set_title( f'Alpha(uncond.) - Final Value: {np.abs(analytical_ecd_param_dict["gamma"][-1]): .4f}')

        # theta plot
        sns.lineplot(data=analytical_ecd_param_dict["theta"],
                     ax=axs[1, 1], color="purple")
        axs[1, 1].set_title(
            f'theta - Final Value: {analytical_ecd_param_dict["theta"][-1]:.4f}')

        plt.tight_layout()
        plt.show()

    def disp_frame_alpha_from_epsilon_non_linear_finite_difference(self,
                                                                   epsilon_array, alpha_init=0 + 0j, dt=1
                                                                   ):
        Δ = self.system_dict["detuning"]
        K_s = self.system_dict["K_s"]
        κ = self.system_dict["kappa"]

        @jit
        def compute_alpha(epsilon_array, alpha_init, dt, Δ, K_s, kappa):

            def body(j, alpha):
                new_alpha = (
                    2
                    * dt
                    * (
                        -1j * Δ * alpha[j]
                        + 2j * K_s * jnp.abs(alpha[j]) ** 2 * alpha[j]
                        - (κ / 2.0) * alpha[j]
                        - 1j * epsilon_array[j]
                    )
                    + alpha[j - 1]
                )
                return alpha.at[j + 1].set(new_alpha)

            alpha = jnp.zeros_like(epsilon_array, dtype=complex)
            alpha = alpha.at[0].set(alpha_init)
            alpha = alpha.at[1].set(alpha_init)
            alpha = lax.fori_loop(1, len(epsilon_array) - 1, body, alpha)

            return alpha

        alpha = compute_alpha(epsilon_array, alpha_init, dt, Δ, K_s, κ)
        return alpha
    # Calculate the phase space trajectories

    def alpha_from_epsilon_ge_finite_difference(
        self,
        cavity_pulse,
        alpha_g_init=0 + 0j,
        alpha_e_init=0 + 0j,
        dt=1,
    ) -> tuple[np.ndarray, np.ndarray]:
        Δ = self.system_dict["detuning"]
        K_s = self.system_dict["K_s"]
        κ = self.system_dict["kappa"]
        χ = self.system_dict["chi_e"]
        χ_prime = self.system_dict["chi_e_prime"]

        @jit
        def compute_alphas(
            cavity_pulse,
            alpha_g_init,
            alpha_e_init,
            dt,
            Δ,
            K_s,
            κ,
            χ,
            χ_prime,
        ):

            def body(j, state):
                alpha_g, alpha_e = state

                new_alpha_g = (
                    2
                    * dt
                    * (
                        -1j * Δ * alpha_g[j]
                        + 2j * K_s * jnp.abs(alpha_g[j]) ** 2 * alpha_g[j]
                        - (κ / 2.0) * alpha_g[j]
                        - 1j * cavity_pulse[j]
                    )
                    + alpha_g[j - 1]
                )

                new_alpha_e = (
                    2
                    * dt
                    * (
                        -1j * Δ * alpha_e[j]
                        + 2j * K_s * jnp.abs(alpha_e[j]) ** 2 * alpha_e[j]
                        - (κ / 2.0) * alpha_e[j]
                        - 1j * cavity_pulse[j]
                        + 1j
                        * (χ + 2 * χ_prime * jnp.abs(alpha_e[j]) ** 2)
                        * alpha_e[j]
                    )
                    + alpha_e[j - 1]
                )

                alpha_g = alpha_g.at[j + 1].set(new_alpha_g)
                alpha_e = alpha_e.at[j + 1].set(new_alpha_e)

                return alpha_g, alpha_e

            alpha_g = jnp.zeros_like(cavity_pulse, dtype=complex)
            alpha_e = jnp.zeros_like(cavity_pulse, dtype=complex)
            alpha_g = alpha_g.at[0].set(alpha_g_init)
            alpha_g = alpha_g.at[1].set(alpha_g_init)
            alpha_e = alpha_e.at[0].set(alpha_e_init)
            alpha_e = alpha_e.at[1].set(alpha_e_init)

            final_state = lax.fori_loop(
                1, len(cavity_pulse) - 1, body, (alpha_g, alpha_e)
            )
            return final_state

        alpha_g, alpha_e = compute_alphas(
            cavity_pulse,
            alpha_g_init,
            alpha_e_init,
            dt,
            Δ,
            K_s,
            κ,
            χ,
            χ_prime,
        )
        return alpha_g, alpha_e

    # NOTE, currently only finite_difference implemented. The other method used by alec seems to be very slow.
    def get_ge_trajectories(
        self,
        cavity_pulse=None,
        qubit_pulse=None,
        finite_difference=True,
    ):

        if cavity_pulse is None:
            cavity_pulse = self.cavity_pulse
        if qubit_pulse is None:
            qubit_pulse = self.qubit_pulse

        func = (
            self.alpha_from_epsilon_ge_finite_difference
            if finite_difference
            else self.alpha_from_epsilon_ge
        )

        def f(cavity_pulse, alpha_g_init, alpha_e_init): return func(
            cavity_pulse,
            alpha_g_init=alpha_g_init,
            alpha_e_init=alpha_e_init,
        )

        # Replace numpy split and concatenation with JAX operations
        flip_idxs = self._get_flip_idxs(qubit_pulse)
        epsilons = np.split(cavity_pulse, flip_idxs)
        alpha_g_list = []
        alpha_e_list = []
        g_state = 0
        alpha_g_init = 0 + 0j
        alpha_e_init = 0 + 0j

        # Since the original code uses a loop to process splits, we maintain the loop structure
        # This part can also be optimized further by using JAX transformations like lax.scan
        for epsilon_segment in epsilons:
            alpha_g_current, alpha_e_current = f(
                epsilon_segment, alpha_g_init, alpha_e_init
            )
            if g_state == 0:
                alpha_g_list.append(alpha_g_current)
                alpha_e_list.append(alpha_e_current)
            else:
                alpha_g_list.append(alpha_e_current)
                alpha_e_list.append(alpha_g_current)

            # Update initial conditions for the next segment
            alpha_g_init = alpha_e_current[-1]
            alpha_e_init = alpha_g_current[-1]
            g_state = 1 - g_state  # Flip the bit

        # Concatenate results into a single array
        alpha_g = np.concatenate(alpha_g_list)
        alpha_e = np.concatenate(alpha_e_list)

        return alpha_g, alpha_e

    ### Optimized ECD sequence ###

    def optimized_ecd_sequence(
        self,
        alpha=None,
        tw_us=None,
        curvature_correction=True,
        finite_difference=True,
        output=False,
        dt=1
    ):
        logging.info("Optimizing ECD sequence")

        # Define the parameters
        β = self.beta
        β_abs = np.abs(β)
        β_phase = np.angle(β)

        χ = self.chi  # in GHz
        χ_prime = self.chi_prime  # in GHz
        σ_q = self.sigma_q  # in ns
        σ_c = self.sigma_c  # in n s
        chop = self.chop
        tw = self.tw  # in ns
        α = alpha
        if α is None:
            α = β_abs / (2 * np.sin(χ * tw))
        else:
            α = float(α) if isinstance(α, int) else α

        α_abs = np.abs(α)
        α_phase = β_phase + np.pi / 2.0

        d = disp_gaussian(α, σ_c, chop, dt)

        # corresponding to sy pi flip
        p = rotate(np.pi, sigma=σ_q, chop=chop, dt=dt)

        n = np.abs(α) ** 2
        χ_effective = χ + 2 * χ_prime * n

        if tw_us is None:
            tw_us = np.abs(np.arcsin(β_abs / (2 * α_abs)) / χ_effective)
            # tw = int(tw_us) # dont htink it is really in tw_us.
            # print(tw)

        d = disp_gaussian(1, σ_c, chop, dt)
        p = rotate(np.pi, 0,  sigma=σ_q, chop=chop, dt=dt)

        def construct_CD(alpha, tw, r, r0, r1, r2):
            cavity_pulse = r * np.concatenate(
                [
                    r0 * alpha * d * np.exp(1j * α_phase),
                    np.zeros(tw),
                    r1 * alpha * d * np.exp(1j * (α_phase + np.pi)),
                    np.zeros(len(p)),
                    r1 * alpha * d * np.exp(1j * (α_phase + np.pi)),
                    np.zeros(tw),
                    r2 * alpha * d * np.exp(1j * α_phase),
                ]
            )

            qubit_pulse = np.concatenate(
                [
                    np.zeros(tw + 2 * len(d)),
                    p,
                    np.zeros(tw + 2 * len(d)),
                ]
            )
            return cavity_pulse, qubit_pulse

        def integrated_beta_and_displacement(cavity_pulse, qubit_pulse):
            # note that the trajectories are first solved without kerr.
            flip_idx = int(len(cavity_pulse) / 2)
            alpha_g, alpha_e = self.get_ge_trajectories(
                cavity_pulse,
                qubit_pulse,
                finite_difference=finite_difference,
            )
            mid_disp = np.abs(alpha_g[flip_idx] + alpha_e[flip_idx])
            final_disp = np.abs(alpha_g[-1] + alpha_e[-1])
            first_radius = np.abs(
                (alpha_g[int(flip_idx / 2)] + alpha_e[int(flip_idx / 2)]) / 2.0
            )
            second_radius = np.abs(
                (alpha_g[int(3 * flip_idx / 2)] +
                    alpha_e[int(3 * flip_idx / 2)]) / 2.0
            )
            if output:
                print(
                    "\r  mid_disp: %.4f" % mid_disp
                    + " final_disp: %.4f" % final_disp
                    + " first_radius: %.4f" % first_radius
                    + " second_radius: %.4f" % second_radius
                    + " beta: %.4f" % np.abs(alpha_g[-1] - alpha_e[-1]),
                    # end="",
                )
            return np.abs(alpha_g[-1] - alpha_e[-1]), np.abs(alpha_g[-1] + alpha_e[-1])

        # ratios will perform a minimization problem:
        # given the alpha, and the tw, find the ratio of the middle pulses and the
        # final pulse which:
        # 1. returns the state to the middle after the first half
        # 2.  returns the state to the middle after the full thing.
        # as a bonus:
        # 3. uses an equal radius in the second half as the first half.
        def ratios(alpha, tw):
            # guess ratios:
            n = jnp.abs(alpha) ** 2
            χ_effective = χ + 2 * χ_prime * n
            r = 1.0
            r0 = np.cos((χ_effective / 2.0) * tw)
            r1 = r0
            r2 = np.cos(χ_effective * tw)

            # the cost function
            def cost(x):
                r = x[0]
                r0 = x[1]
                r1 = x[2]
                r2 = x[3]
                cavity_pulse, qubit_pulse = construct_CD(
                    alpha, tw, r, r0, r1, r2)

                flip_idx = int(len(cavity_pulse) / 2)
                alpha_g, alpha_e = self.get_ge_trajectories(
                    cavity_pulse,
                    qubit_pulse,
                    finite_difference=finite_difference,
                )
                mid_disp = jnp.abs(alpha_g[flip_idx] + alpha_e[flip_idx])
                final_disp = jnp.abs(alpha_g[-1] + alpha_e[-1])
                first_radius = jnp.abs(
                    (alpha_g[int(flip_idx / 2)] +
                     alpha_e[int(flip_idx / 2)]) / 2.0
                )
                second_radius = jnp.abs(
                    (alpha_g[int(3 * flip_idx / 2)] +
                        alpha_e[int(3 * flip_idx / 2)]) / 2.0
                )
                current_β = jnp.abs(alpha_g[-1] - alpha_e[-1])
                if output:
                    print(
                        "\r  mid_disp: %.4f" % mid_disp
                        + " final_disp: %.4f" % final_disp
                        + " first_radius: %.4f" % first_radius
                        + " second_radius: %.4f" % second_radius
                        + " beta: %.4f" % current_β,
                        # end="",
                    )
                return (
                    np.abs(mid_disp)
                    + np.abs(final_disp)
                    + np.abs(first_radius - jnp.abs(alpha))
                    + np.abs(second_radius - jnp.abs(alpha))
                    + 2 * (current_β - jnp.abs(β)) ** 2
                )

            result = fmin(cost, x0=[r, r0, r1, r2],
                          ftol=1e-3, xtol=1e-3, disp=False)
            r = result[0]
            r0 = result[1]
            r1 = result[2]
            r2 = result[3]
            return r, r0, r1, r2

        # the initial guesses
        # ratios of the displacements

        r, r0, r1, r2 = ratios(α, tw)

        cavity_pulse, qubit_pulse = construct_CD(α, tw, r, r0, r1, r2)

        if curvature_correction:

            current_β, current_disp = integrated_beta_and_displacement(
                cavity_pulse, qubit_pulse
            )
            diff = jnp.abs(current_β) - jnp.abs(β)
            ratio = jnp.abs(current_β) / jnp.abs(β)
            if output:
                print(
                    "tw: "
                    + str(tw)
                    + " alpha: "
                    + str(α)
                    + " beta: "
                    + str(current_β)
                    + " diff: "
                    + str(diff)
                )
            # usually we expect the beta to be larger than the target beta, if this is not the case, drastically increase tw to make it happen.
            # can be modified to change alpha instead of tw
            if diff < 0:
                tw = int(tw * 1.5)
                ratio = 1.01
            while jnp.abs(diff) > 2e-2:  # / jnp.abs(beta)
                if ratio > 1.0:
                    tw = int(tw / ratio)
                    tw = 4 * ((tw + 3) // 4)  # ensure its a mutliple of 4

                # update the ratios for the new tw and alpha given chi_prime
                r, r0, r1, r2 = ratios(α, tw)
                cavity_pulse, qubit_pulse = construct_CD(
                    α, tw, r, r0, r1, r2)
                current_β, current_disp = integrated_beta_and_displacement(
                    cavity_pulse, qubit_pulse
                )
                diff = jnp.abs(current_β) - jnp.abs(β)
                ratio = jnp.abs(current_β) / jnp.abs(β)
                if output:
                    print(
                        "tw: "
                        + str(tw)
                        + " alpha: "
                        + str(α)
                        + " beta: "
                        + str(current_β)
                        + " diff: "
                        + str(diff)
                    )
        # create result dict
        optimized_ecd_dict = {
            "cavity_pulse": cavity_pulse,
            "qubit_pulse": qubit_pulse,
            "alpha": α,
            "tw": tw,
            "ratios": (r, r0, r1, r2),
        }
        self.optimized_cavity_pulse = cavity_pulse
        self.optimized_qubit_pulse = qubit_pulse
        self.optimized_ecd_dict = optimized_ecd_dict
        return optimized_ecd_dict
