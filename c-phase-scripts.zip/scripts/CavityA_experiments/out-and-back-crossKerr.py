""" """

from config.experiment_config import FOLDER, N, FREQ, I, Q, MAG, PHASE, RRC, SINGLE_SHOT
from qm import qua as qm_qua
from qcore import Experiment, qua, Sweep
import numpy as np
from qcore.libs.qua_macros import QuaVariable


class OutAndBackCrossKerr(Experiment):
    """Dispersive shift between cavity and qubit"""

    ############################# DEFINE PRIMARY DATASETS ##############################
    # these Datasets form the "raw" experimental data and will be streamed by the OPX
    # they must be specified at experiment runtime

    primary_datasets = ["I", "Q", "single_shot"]

    ############################## DEFINE PRIMARY SWEEPS ###############################
    # these Sweeps are uniquely associated with the Experiment subclass
    # these Sweeps must be specified at experiment runtime

    #primary_sweeps = ["time_delay"]
    primary_sweeps = ["disp_phase"]

    ############################ DEFINE THE PULSE SEQUENCE #############################
    # ensure that you import 'qua' from 'qcore' and not from 'qm' library
    # attributes accessed via 'self' must be defined in 'if __name__ == "__main__"' code

    def sequence(self):
        #factor = qm_qua.declare(qm_qua.fixed)
        # phase = qm_qua.declare(float)
        #qm_qua.assign(factor, self.detuning * 1e-9) 
        """QUA sequence that defines this Experiment subclass"""
        qua.reset_frame(self.cavB)
        qua.reset_frame(self.cavA)
        qua.reset_frame(self.qubitA)
        qua.reset_frame(self.qB)
        qm_qua.reset_global_phase()
        qua.update_frequency(self.drive, 357e6)
        qua.align()
        #qm_qua.assign(self.phase, qm_qua.Cast.mul_fixed_by_int(factor, self.time_delay))
        total_disp_phase = qm_qua.declare(qm_qua.fixed)
        qm_qua.assign(total_disp_phase, self.phase + self.ramp_phase + self.disp_phase)

        self.cavA.play(self.cavA_pulse, ampx=self.disp_amp) 
        qua.align() 

        self.drive.play(self.drive_pulse, duration = self.time_delay/4)
        qua.align() 

        self.cavA.play(self.cavA_pulse, ampx=self.disp_amp, phase=total_disp_phase)
        qua.align()  

        self.qubitA.play(self.qubit_sel_pi)  
        qua.align(self.qubitAEF, self.qubitA)
        self.qubitAEF.play(self.qubitEF_pi)  # play selective qubit pulse
        qua.align(self.qubitAEF, self.resonatorA)

        # Measure and wait
        self.resonatorA.measure(self.readoutA_pulse, (self.I, self.Q), ampx=self.ro_ampx, demod_type="dual")
        qua.align()
        qua.wait(self.wait_time)
        if self.plot_single_shot:  
            qm_qua.assign(self.single_shot,qm_qua.Cast.to_fixed(self.I > self.readoutA_pulse.threshold),)


if __name__ == "__main__":
    """ """

    #################################### MODE MAP ######################################
    # key: name of the Mode as defined by the Experiment subclass
    # value: name of the Mode as defined by the user in modes.yml

    modes = {
        "qubitAEF": "qA_EF",
        "drive": "drive",
        "qubitA": "qA",
        "qB": "qB",
        "cavA": "cavA",
        "cavB": "cavB",
        "resonatorA": "rrA",
        "resonatorB": "rrB",
    }

    ################################### PULSE MAP ######################################
    # key: name of the Pulse as defined by the Experiment subclass
    # value: name of the Pulse as defined by the user in modes.yml

    pulses = {
        "qubit_grape": "qB_grape_fock1",
        "cavity_grape": "cavB_grape_fock1",
        # "qB_pulse": "qB_gaussian_sel_pi_pulse",
        "drive_pulse": "exchange_pulse", 
        "cavA_pulse": "cavA_ramp_pulse",
        #"cavB_pulse": "cavB_ramp_pulse",
        "qubitEF_pi": "qAEF_EF_gaussian_pi_pulse",
        "qubit_sel_pi": "qA_gaussian_very_sel_pi_pulse",
        "readoutA_pulse": "rrA_GF_CLEAR_readout_pulse",
        # "readout_pulseB": "rrB_readout_pulse",
    }

    ############################## CONTROL PARAMETERS ##################################

    parameters = {
        "ramp_phase": -0.098,
        "detuning": 0, #-729e3,
        "phase": QuaVariable(value=0.0, dtype=qm_qua.fixed, tag="phase", buffer=True, stream=True),
        "wait_time": 6e6,
        "plot_single_shot": True,
        "qubit_in_e": False,
        "ro_ampx": 1,
    }

    ######################## SWEEP (INDEPENDENT) VARIABLES #############################
    # must include an outermost averaging Sweep named "N"
    # must include all primary sweeps defined by the Experiment subclass

    # set number of repetitions for this Experiment run
    N.num = 5000

    # set the delay sweep
    DEL = Sweep(name="time_delay", start=4, stop=4000, step=140, dtype=int)

    DISPL_PHASE = Sweep(name="disp_phase", start=0.4, stop=0.6, step=0.01, dtype=float)
    ALPHA = Sweep(name="disp_amp", start=1.0, stop=2.5, step=0.5, dtype=float)

    #sweeps = [N, DISPL_PHASE, DEL]
    sweeps = [N, ALPHA, DISPL_PHASE]

    ######################## DATASET (DEPENDENT) VARIABLES #############################
    # must include all primary datasets defined by the Experiment subclass

    # MAG.axes = sweeps[1:]
    # PHASE.axes = sweeps[1:]
    #SINGLE_SHOT.plot_args["plot_type"] = "image"

    PHASE.datafn_args = {"delay": 2.792e-7, "freq": RRC.int_freq}  # 2.792e-7
   
    PHASE.plot = False
    MAG.plot = False
    Q.plot = False
    I.plot = False
    SINGLE_SHOT.plot = True
    SINGLE_SHOT.fitfn = 'gaussian'
    datasets = [I, Q, SINGLE_SHOT]

    ######################## INITIALIZE AND RUN EXPERIMENT #############################

    expt = OutAndBackCrossKerr(FOLDER, modes, pulses, sweeps, datasets, **parameters)
    expt.run()



