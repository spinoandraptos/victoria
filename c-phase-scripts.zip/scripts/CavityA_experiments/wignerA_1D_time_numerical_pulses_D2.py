from config.experiment_config import FOLDER, N, FREQ, I, Q, MAG, PHASE, RRB, SINGLE_SHOT
from qcore import Experiment, qua, Sweep, Dataset
from qm import qua as qm_qua
from qcore.libs.qua_macros import QuaVariable

Ipost = Dataset(name="Ipost",save=False,plot=False)
Qpost = Dataset(name="Qpost",save=False,plot=False)
SINGLE_SHOTpost = Dataset(name="single_shotpost",save=True, plot=False)

class Wigner1D_A(Experiment):
    """Wigner_function"""

    ############################# DEFINE PRIMARY DATASETS ##############################
    primary_datasets = ["I", "Q", "single_shot", "Ipost", "Qpost", "single_shotpost"]

    primary_sweeps = ["gate_id"]

    def __init__(self, folder, modes, pulses, sweeps, datasets, **parameters):
        super().__init__(folder,modes,pulses,sweeps,datasets,**parameters,)  # Passes other parameters to parent
        self.pulse_list = [f"self.exchange_pulse_cos2_{d}" for d in range (self.time_start, self.time_stop+self.time_step, self.time_step)]


    def sequence(self):
        """QUA sequence that defines this Experiment subclass"""
        qua.reset_frame(self.cavityA)   
        qua.reset_frame(self.qubitA)
        qua.reset_frame(self.cavityB)   
        qua.reset_frame(self.qubitB)
        qua.update_frequency(self.drive, 371e6-7e6)

        factor = qm_qua.declare(qm_qua.fixed)
        new_phase = qm_qua.declare(qm_qua.fixed)

        qm_qua.assign(factor, self.detuningA * 1e-9)  # formerly with a 4*
        qua.align()

        # PREPARE STATE
        self.qubitB.play(self.qubitB_grape, ampx = self.grape_amplitude)
        self.cavityB.play(self.cavityB_grape, ampx = self.grape_amplitude) 
        self.cavityA.play(self.cavityA_grape)
        self.qubitA.play(self.qubitA_grape)
        qua.align()

        with qm_qua.switch_(self.gate_id):
            for i in range(self.time_start, self.time_stop+self.time_step, self.time_step):
                with qm_qua.case_(i):
                    qm_qua.assign(self.phase, qm_qua.Cast.mul_fixed_by_int(factor, i))
                    self.drive.play(getattr(self,f"exchange_pulse_cos2_{i}"))
                    self.drive.play(getattr(self,f"exchange_pulse_cos2_{i}"))
                    self.drive.play(getattr(self,f"exchange_pulse_cos2_{i}"))
        qm_qua.assign(new_phase, 3*self.phase + 0.25 + 3*self.ramp_phaseA)
        qua.align() 

        # qua.wait(self.drive_time, self.cavityA)  # wait for state to rotate
        # qua.align()

        # # MEASURE WIGNER
        self.cavityA.play(self.cav_op, ampx=0.4, phase = new_phase)  # displacement in I direction
        qua.align(self.cavityA, self.qubitA)
        self.qubitA.play(self.qubit_op)  # play pi/2 pulse around X
        qua.wait(self.time_delay, self.qubitA)  # conditional phase gate on even, odd Fock state
        self.qubitA.play(self.qubit_op, phase = 0)  # play pi/2 pulse around X
        qua.align(self.qubitB, self.qubitAEF)
        self.qubitAEF.play(self.qubitEF_pi)
        qua.align(self.qubitAEF, self.resonatorA)  # align measurement

        # Measure cavity state
        #self.resonatorC.measure(self.readout_pulseC, (self.Ipost, self.Qpost), ampx=self.ro_ampx, demod_type= 'dual')
        self.resonatorA.measure(self.readout_pulseA, (self.I, self.Q), demod_type= 'dual')  # measure transmitted signal
        qua.align()
        qua.wait(self.wait_time)
        if self.plot_single_shot:  # assign state to G or E
            qm_qua.assign(self.single_shot, qm_qua.Cast.to_fixed(self.I > self.readout_pulseA.threshold))
            #qm_qua.assign(self.single_shotpost,qm_qua.Cast.to_fixed(self.Ipost > self.readout_pulseC.threshold),)

if __name__ == "__main__":
    """ """

    #################################### MODE MAP ######################################
    modes = {
       # "qC": "qC",
        "qubitAEF": "qA_EF",
        "cavityA": "cavA",
        "cavityB": "cavB",
        "drive":"drive",
        "qubitA": "qA",
        "qubitB": "qB",
        "resonatorA": "rrA",
        # "resonatorC": "rrC",
    }

    ################################### PULSE MAP ######################################
    # key: name of the Pulse as defined by the Experiment subclass
    # value: name of the Pulse as defined by the user in modes.yml
    pulses = {
        "qubitA_grape": "qA_grape_fock01_test",
        "cavityA_grape": "cavA_grape_fock01_test",
        "qubitB_grape": "qB_grape_fock1",
        "cavityB_grape": "cavB_grape_fock1",

        "qubitEF_pi": "qAEF_EF_gaussian_pi_pulse",
        "cav_op": "cavA_ramp_pulse",
        "qubit_op": "qA_gaussian_pi2_pulse",
        "readout_pulseA": "rrA_GF_CLEAR_readout_pulse", 

    }

    
    time_start = 16
    time_stop = 5000
    time_step = 100
    
    for d in range(time_start, time_stop+time_step, time_step):
        pulses[f"exchange_pulse_cos2_{d}"] = f"exchange_pulse_cos2_{d}"

    ############################## CONTROL PARAMETERS ##################################
    parameters = {
        "ramp_phaseA":  -0.08,
        "detuningA": - 728e3,
        "phase": QuaVariable(value=0.0, dtype=qm_qua.fixed, tag="phase", buffer=True, stream=True),
        "wait_time": 7e6,
        "time_delay": 520,
        "plot_single_shot": True,
        "time_start":  time_start,
        "time_stop":  time_stop,
        "time_step":  time_step,
        # "grape_amplitude": 1.0,
    }

    ######################## SWEEP (INDEPENDENT) VARIABLES #############################
    N.num = 50000
    QD_AMPX = Sweep(name="grape_amplitude", start=0.0, stop=1.0, step=1.0)
    # TIME = Sweep(name="drive_time", start = 16, stop=60_000, step = 600, dtype = int)
    GATES = Sweep(name="gate_id", start=time_start, stop=time_stop, step=time_step, dtype=int, save=True)
    # sweeps = [N, GATES]
    sweeps = [N, QD_AMPX, GATES]

    ######################## DATASET (DEPENDENT) VARIABLES #############################
    PHASE.datafn_args = {"delay": 2.792e-7, "freq": RRB.int_freq}
    I.plot, Q.plot, MAG.plot, PHASE.plot = False, False, False, False
    SINGLE_SHOT.fitfn = 'exp_decay_sine'
    datasets = [I, Q, SINGLE_SHOT, Ipost, Qpost, SINGLE_SHOTpost]
    #datasets = [I, Q, SINGLE_SHOT]

    ######################## INITIALIZE AND RUN EXPERIMENT #############################
    expt = Wigner1D_A(FOLDER, modes, pulses, sweeps, datasets, **parameters)
    expt.run()
