""" """
from config.experiment_config import FOLDER, N, FREQ, I, Q, MAG, PHASE, RR, SINGLE_SHOT
from qm import qua as qm_qua
from qcore import Experiment, qua, Sweep
from qcore.libs.qua_macros import QuaVariable

class crossKerr(Experiment):
    """Cavity-cavity cross-Kerr"""

    ############################# DEFINE PRIMARY DATASETS ##############################
    # these Datasets form the "raw" experimental data and will be streamed by the OPX
    # they must be specified at experiment runtime
    primary_datasets = ["I", "Q", "single_shot"]

    ############################## DEFINE PRIMARY SWEEPS ###############################
    # these Sweeps are uniquely associated with the Experiment subclass
    # these Sweeps must be specified at experiment runtime
    primary_sweeps = ["time_delay"]

    ############################ DEFINE THE PULSE SEQUENCE #############################
    # ensure that you import 'qua' from 'qcore' and not from 'qm' library
    # attributes accessed via 'self' must be defined in 'if __name__ == "__main__"' code

    def sequence(self):
        qua.reset_frame(self.cav)

        # Displace Bob
        self.cav.play(self.cavity_pulse, ampx = 1.0) # displace cavity
        qua.align()

        # Initialize Alice in 1
        # self.qubitAGF.play(self.qubitA_drive)
        # qua.align(self.qubitAGF, self.driveA)
        # self.driveA.play(self.driveA_pulse)
        # qua.align()

        # Wait
        qua.wait(self.time_delay, self.cav)  # wait for self-kerr to dephase cavity

        self.cav.play(self.cavity_pulse, ampx = 1.0, phase = self.disp_phase) # displace cavity back
        
        qua.align()
        # qua.update_frequency(self.qubit, -86.16e6)
        self.qubit.play(self.qubit_pulse)
        qua.align()
        self.resonator.measure(
            self.readout_pulse, (self.I, self.Q), ampx=self.ro_ampx, demod_type="dual"
        )
        qua.wait(self.wait_time, self.resonator)
        if self.plot_single_shot:  # assign state to G or E
            qm_qua.assign(
                self.single_shot,
                qm_qua.Cast.to_fixed(self.I > self.readout_pulse.threshold),
            )

if __name__ == "__main__":
    """ """
    #################################### MODE MAP ######################################
    # key: name of the Mode as defined by the Experiment subclass
    # value: name of the Mode as defined by the user in modes.yml
    modes = {"qubitAGF": "qubitAGF",
            "driveA": "driveA",
            "qubit": "qubit", 
            "cav":"cavB",
            "resonator": "rr"}
    ################################### PULSE MAP ######################################
    # key: name of the Pulse as defined by the Experiment subclass
    # value: name of the Pulse as defined by the user in modes.yml
    pulses = {"qubit_pulse": "qubit_gaussian_selective_pi_pulse",
            "cavity_pulse":"cavityB_gaussian_coherent_4",
            "qubitA_drive": "qubitAGF_gaussian_pi_pulse",
            "driveA_pulse": "driveA_constant_ramp_pulse_short",
            "readout_pulse": "rr_readout_pulse"}

    ############################## CONTROL PARAMETERS ##################################
    parameters = {
        "wait_time": 7e6,
        "ro_ampx": 1,
        "phase": QuaVariable(
            value=0.0,
            dtype=qm_qua.fixed,
            tag="phase",
            buffer=True,
            stream=True,
        ),
        "plot_single_shot": True,
    }

    ######################## SWEEP (INDEPENDENT) VARIABLES #############################
    # must include an outermost averaging Sweep named "N"
    # must include all primary sweeps defined by the Experiment subclass

    # set number of repetitions for this Experiment run
    N.num = 5000

    # set the qubit frequency sweep for this Experiment run

    DEL = Sweep(name="time_delay", start=16, stop=30000, step=1000, dtype=int)  # ns
    # CAV_AMPX = Sweep(name="cavity_pulse_amplitude", start=0.1, stop=1.8, num=10)
    DIRECTION = Sweep(name="disp_phase", start=0.2, stop=0.6, step=0.01, dtype=float)  # ns

    sweeps = [N, DIRECTION, DEL]

    ######################## DATASET (DEPENDENT) VARIABLES #############################
    # must include all primary datasets defined by the Experiment subclass
    # I.fitfn = "exp_decay_sine"
    # Q.fitfn = "exp_decay_sine"
    Q.plot = False
    # SINGLE_SHOT.fitfn = "exp_decay_sine"
    PHASE.datafn_args = {"delay": 2.792e-7, "freq": RR.int_freq}
    # PHASE.plot = False
    # I.plot, Q.plot = False, False
    SINGLE_SHOT.plot_args["plot_type"] = "image"
    I.plot_args["plot_type"] = "image"




    datasets = [I, Q, SINGLE_SHOT]

    ######################## INITIALIZE AND RUN EXPERIMENT #############################

    expt = crossKerr(FOLDER, modes, pulses, sweeps, datasets, **parameters)
    expt.run()
