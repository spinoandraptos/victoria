from config.experiment_config import FOLDER, N, FREQ, I, Q, MAG, PHASE, RRC, SINGLE_SHOT, RRA
from qm import qua as qm_qua
from qcore import Experiment, qua, Sweep, Dataset

IA_PARITY= Dataset(name="IA_parity",save=True,plot=False)
QA_PARITY = Dataset(name="QA_parity",save=False,plot=False)
SINGLE_SHOT_A_PARITY = Dataset(name="single_shotA_parity",save=True,plot=False)

class NumberSplittingA(Experiment):
    """Number splitting"""

    primary_datasets = ["I", "Q", "single_shot", "IA_parity", "QA_parity", "single_shotA_parity"]
    
    primary_sweeps = ["qubit_frequency"]

    def sequence(self):
        """QUA sequence that defines this Experiment subclass"""
        qua.reset_frame(self.cavityA)
        qua.reset_frame(self.qubitA)
        qm_qua.reset_global_phase()
        qua.update_frequency(self.qubitA, self.qubitA.int_freq)
        qua.align()

        self.cavityA.play(self.cavityA_grape)
        self.qubitA.play(self.qubitA_grape)
        qua.align()

        # self.qubitA.play(self.qubitA_pi2)
        # qua.wait(int(self.time_delayA), self.qubitA)  
        # self.qubitA.play(self.qubitA_pi2, phase = 0.5) 
        # qua.align(self.qubitA, self.resonator)  
        # self.resonator.measure(self.readout_pulse, (self.IA_parity, self.QA_parity), demod_type = 'dual')
        # qua.wait(1500, self.resonator)
        # qua.align()
       
        qua.update_frequency(self.qubitA, self.qubit_frequency)
        self.qubitA.play(self.qubit_spec_pulse)
        qua.align(self.qubitA, self.qA_EF)
        self.qA_EF.play(self.qubitAEF_pi)
        qua.align(self.qA_EF, self.resonator)

        # Measurement
        self.resonator.measure(self.readout_pulse, (self.I, self.Q), demod_type="dual")
        qua.align()
        qua.wait(self.wait_time)
        if self.plot_single_shot:  # assign state to G or E
            qm_qua.assign(self.single_shot,qm_qua.Cast.to_fixed(self.I > self.readout_pulse.threshold))
            # qm_qua.assign(self.single_shotA_parity,qm_qua.Cast.to_fixed(self.IA_parity > 0))


if __name__ == "__main__":
    """ """

    #################################### MODE MAP ######################################
    modes = {
        "cavityA": "cavA",
        "qubitA": "qA",
        "cavityB": "cavB",
        "qubitB": "qB",
        "qA_EF": "qA_EF",
        "drive": "drive",
        "qC": "qC",
        "resonator": "rrA",
    }
    ################################### PULSE MAP ######################################
    pulses = {
        # "qubitA_grape0": "qA_grape_fock02_new2",
        # "cavityA_grape0": "cavA_grape_fock02_new2",
        # "qubitA_grape1": "qA_grape_fock0-2_new2",
        # "cavityA_grape1": "cavA_grape_fock0-2_new2",
        # "qubitA_grape2": "qA_grape_fock0i2_new2",
        # "cavityA_grape2": "cavA_grape_fock0i2_new2",
        # "qubitA_grape3": "qA_grape_fock0-i2_new2",
        # "cavityA_grape3": "cavA_grape_fock0-i2_new2",
        "qubitA_grape": "qA_grape_fock1",
        "cavityA_grape": "cavA_grape_fock1",
        # "qubitB_grape": "qB_grape_fock1",
        # "cavityB_grape": "cavB_grape_fock1",
        # "cavity_pulse": "cavA_ramp_pulse",
        "qubit_spec_pulse": "qA_gaussian_very_sel_pi_pulse",
        "qubitAEF_pi": "qAEF_EF_gaussian_pi_pulse",
        "readout_pulse": "rrA_GF_CLEAR_readout_pulse",
        "qubitA_pi2":"qA_gaussian_pi2_pulse",
    }
                                       
    ############################## CONTROL PARAMETERS ##################################
    parameters = {
        "wait_time": 7e6,
        "plot_single_shot": True,
        "time_delayA":560,
    }

    ######################## SWEEP (INDEPENDENT) VARIABLES #############################
    N.num = 500
    FREQ.name = "qubit_frequency"
    FREQ.start = 349e6 
    FREQ.stop = 354e6
    FREQ.num = 101
    
    # ORENS = Sweep(name="orens_id", start=0, stop=3, num=4, dtype=int, save=True)
    #AMPX = Sweep(name="drive_ampx", start=0.0, stop=1.0, step=1.0, dtype=float, save=True)

    sweeps = [N, FREQ]
    #sweeps = [N, AMPX, FREQ]

    #QD_AMPX = Sweep(name="cavity_drive_ampx", points= [0.0, 1.0]) #needs to be floating point numbers 
    #QD_AMPX = Sweep(name="qubit_drive_ampx", points=[0.0, 1.0])
    # sweeps = [N, QD_AMPX, FREQ]

    ######################## DATASET (DEPENDENT) VARIABLES #############################
    PHASE.datafn_args = {"delay": 2.792e-7, "freq": RRA.int_freq}
    SINGLE_SHOT.plot = True
    I.plot, Q.plot, MAG.plot = False, False, False
    SINGLE_SHOT.fitfn = "gaussian"
    datasets = [I, Q, SINGLE_SHOT, IA_PARITY, QA_PARITY, SINGLE_SHOT_A_PARITY]

    ######################## INITIALIZE AND RUN EXPERIMENT #############################
    expt = NumberSplittingA(FOLDER, modes, pulses, sweeps, datasets, **parameters)
    expt.run()
