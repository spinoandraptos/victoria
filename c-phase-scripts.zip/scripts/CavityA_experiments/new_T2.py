import sys
from config.experiment_config import FOLDER, N, FREQ, I, Q, MAG, PHASE, RRC, SINGLE_SHOT
from qm import qua as qm_qua
from qcore import Experiment, qua, Sweep, Dataset
import shutil
import os
from datetime import datetime

# SCREENSHOT FILE 
current_script_path = os.path.realpath(__file__) # Get the path to the current script
script_name = os.path.basename(current_script_path)[:-3] # Get filename only (e.g., 'my_script.py')
date, time = datetime.now().strftime("%Y-%m-%d %H-%M-%S").split()
destination_path = os.path.join(FOLDER + "data/" + str(date) + '/', f"{script_name}_screenhsot_{time}.py") # Define destination path
shutil.copy(current_script_path, destination_path) # Copy the script



SINGLE_SHOT_A_pre = Dataset(
    name="single_shotApre",
    save=True,
    plot=False, 
)

SINGLE_SHOT_A = Dataset(
    name="single_shotA",
    save=True,
    plot=False, 
)

SINGLE_SHOT_B = Dataset(
    name="single_shotB",
    save=True,
    plot=False, 
)

SINGLE_SHOT_C = Dataset(
    name="single_shotC",
    save=True,
    plot=True, 
)

IApre = Dataset(
    name="IApre",
    save=False,
    plot=False,
    # fitfn="exp_decay",
)

QApre = Dataset(
    name="QApre",
    save=False,
    plot=False,
)

IA = Dataset(
    name="IA",
    save=False,
    plot=False,
)

QA= Dataset(
    name="QA",
    save=False,
    plot=False,
)

IB = Dataset(
    name="IB",
    save=False,
    plot=False,
)

QB = Dataset(
    name="QB",
    save=False,
    plot=False,
)

IC = Dataset(
    name="IC",
    save=False,
    plot=False,
)

QC= Dataset(
    name="QC",
    save=False,
    plot=False,
)

class ResonantExchange1D(Experiment):
    """Resonant exchange"""

    primary_datasets = ["IA", "QA", "single_shotA"]

    primary_sweeps = ["drive_length"]

    def sequence(self):
        """QUA sequence that defines this Experiment subclass"""
        qua.reset_frame(self.cavA)
        qua.reset_frame(self.drive)
        qua.reset_frame(self.qA)

        qua.align()

        #Prepare 1 in A
        self.cavA.play(self.cavity_grape)
        self.qA.play(self.qubit_grape)

        qua.update_frequency(self.drive, 350.5e6)

        qua.align(self.qA,self.cavA,self.drive)
    

        self.drive.play(self.exchange_drive, ampx = 1.8, duration = self.drive_length/4)
        qua.align(self.drive, self.qA)

        # Check if cavA in 0 or 1
        self.qA.play(self.qA_pulse)
        qua.align(self.qA, self.rrA)
        self.rrA.measure(self.readoutA_pulse, (self.IA, self.QA), ampx=self.ro_ampx, demod_type="dual")


        if self.plot_single_shot:  # assign state to G or E
            qm_qua.assign(self.single_shotA, qm_qua.Cast.to_fixed(self.IA > self.readoutA_pulse.threshold),)


        qua.align()
        qua.wait(self.wait_time)

if __name__ == "__main__":
    """ """

    modes = {"qA": "qA",
             #"qB": "qB",
             #"qC": "qC",
             "drive": "drive",
             "rrA": "rrA",
            #  "rrB": "rrB",
            #  "rrC": "rrC",
             "cavA": "cavA",
             #"cavB": "cavB"
             }


    pulses = {
        "qubit_grape": "qA_grape_fock1",
        "cavity_grape": "cavA_grape_fock1",
        # "qubitB_grape": "qB_grape_fock01_new",
        # "cavityB_grape": "cavB_grape_fock01_new",
        "qA_pulse": "qA_gaussian_very_sel_pi_pulse",
        #"qB_pulse": "qB_gaussian_very_sel_pi_pulse",
        "exchange_drive": "exchange_pulse",
        "readoutA_pulse": "rrA_readout_pulse",
        #"readoutB_pulse": "rrB_readout_pulse",
        #"readoutC_pulse": "rrC_readout_pulse",
    }
                   
                    
    parameters = {
        "wait_time": 6e6,
        "ro_ampx": 1,
        "plot_single_shot": True,
        # "drive_ampx": 1.6,
    }

    ######################## SWEEP (INDEPENDENT) VARIABLES #############################
    N.num = 50000
    LENGTH = Sweep (name="drive_length", dtype=int, units = "ns")
    LENGTH.start = 16
    LENGTH.stop = 2000
    LENGTH.step = 20
    SINGLE_SHOT_A.fitfn = "sine"

    sweeps = [N, LENGTH]

    IA.plot = True
    QA.plot = True
    SINGLE_SHOT_A.plot = True
    datasets = [IA, QA, SINGLE_SHOT_A]

    expt = ResonantExchange1D(FOLDER, modes, pulses, sweeps, datasets, **parameters)
    expt.run(simulate=True)
