""" """
from config.experiment_config import FOLDER, N, I, Q, MAG, PHASE, RRC, SINGLE_SHOT, FREQ
from qcore import Experiment, qua, Sweep, Dataset
from qm import qua as qm_qua
from qcore.libs.qua_macros import QuaVariable
from qm.qua import frame_rotation_2pi
# from qm.qua._dsl.frame_rotation import frame_rotation_2pi


Ipre = Dataset(name="Ipre",save=False,plot=False)
Qpre = Dataset(name="Qpre",save=False,plot=False)
SINGLE_SHOTpre = Dataset(name="single_shotpre",save=True, plot=True)

IBpre = Dataset(name="IBpre",save=False,plot=False)
QBpre = Dataset(name="QBpre",save=False,plot=False)
SINGLE_SHOTBpre = Dataset(name="single_shotBpre",save=True, plot=True)

class CavityT2_A(Experiment):
    """Cavity T2"""

    primary_datasets = ["I", "Q", "single_shot", "Ipre", "Qpre", "single_shotpre", "IBpre", "QBpre", "single_shotBpre"]

    primary_sweeps = ["time_delay"]

    def sequence(self):
        """QUA sequence that defines this Experiment subclass"""
        qua.reset_frame(self.cavityA)
        qua.reset_frame(self.cavityB)
        qua.reset_frame(self.qubitA)
        qua.reset_frame(self.qubitB)
        qua.reset_frame(self.drive)
        qua.reset_frame(self.drive_ramp)
        qua.reset_frame(self.resonator)
        qua.reset_frame(self.resonatorB)

        # qua.align()

        factor = qm_qua.declare(qm_qua.fixed)
        qm_qua.assign(factor, self.detuning * 1e-9)
        qm_qua.assign(self.phase, qm_qua.Cast.mul_fixed_by_int(factor, self.time_delay))
        extra_factor = qm_qua.declare(qm_qua.fixed)
        qm_qua.assign(extra_factor, self.drive_detuning * 1e-9)
        qm_qua.assign(self.correcting_phase, qm_qua.Cast.mul_fixed_by_int(extra_factor, self.time_delay))
        
        total_phase = qm_qua.declare(qm_qua.fixed)
        qm_qua.assign(total_phase, self.phase + self.correcting_phase + self.ramp_phase)
        qm_qua.reset_global_phase()
        
        qua.update_frequency(self.drive_ramp, 153e6 - 7e6)

        qua.align()

        self.cavityA.play(self.cavityA_grape)
        self.qubitA.play(self.qubitA_grape)
        # self.cavityB.play(self.cavityB_grape)
        # self.qubitB.play(self.qubitB_grape)
        # qua.update_frequency(self.drive, 335e6)
        qua.align()


        # WAIT / DRIVE
        #qua.wait(self.time_delay, self.cavityA)
        #qm_qua.assign(total_phase, self.phase)

        # self.drive.play(self.drive_pulse, ampx = 2.0,  duration = self.time_delay/4)
        
        # self.drive_ramp.play(self.exchange_ramp_up)
        # qua.align(self.drive, self.drive_ramp)
        # self.drive.play(self.exchange_constant, duration = self.time_delay/4)
        # qua.wait(self.time_delay-7, self.drive_ramp)
        # self.drive_ramp.play(self.exchange_ramp_down)
        qua.align()


        # MEASURE
        self.cavityA.play(self.cavityA_pulse, ampx=0.8, phase = total_phase)
        qua.align(self.cavityA, self.qubitA) 
        self.qubitA.play(self.qubit_sel_pi)  # play selective qubit pulse
        qua.align(self.qubitAEF, self.qubitA)
        self.qubitAEF.play(self.qubitEF_pi)  # play selective qubit pulse
        qua.align(self.qubitAEF, self.resonator)

        # self.cavityA.play(self.cavityA_pulse, ampx=0.8, phase = total_phase)
        # qua.align(self.cavityA, self.qubitC) 
        # self.qubitC.play(self.qubitC_sel_pi)  # play selective qubit pulse
        # qua.align(self.qubitC, self.resonator)

        self.resonator.measure(self.readout_pulse, (self.I, self.Q), demod_type="dual")
        if self.plot_single_shot:  # assign state to G or E
            qm_qua.assign(self.single_shot, qm_qua.Cast.to_fixed(self.I > self.readout_pulse.threshold),)
        qua.align()
        # self.resetA.play(self.resetA_pulse)
        # qua.align()
        qua.wait(self.wait_time)


if __name__ == "__main__":
    """ """

    #################################### MODE MAP ######################################
    # key: name of the Mode as defined by the Experiment subclass
    # value: name of the Mode as defined by the user in modes.yml

    modes = {
        "cavityA": "cavA",
        "cavityB": "cavB",
        "qubitA": "qA",
        "qubitAEF": "qA_EF",
        "qubitB": "qB",
        "qubitB_EF": "qB_EF",
        "qubitC": "qC",
        "resonator": "rrA",
        "resonatorB": "rrB",
        "drive":"drive",
        "drive_ramp":"drive_ramp",
    }

    ################################### PULSE MAP ######################################
    # key: name of the Pulse as defined by the Experiment subclass
    # value: name of the Pulse as defined by the user in modes.yml

    pulses = {
        "cavityA_pulse": "cavA_ramp_pulse",
        # "qubitA_grape": "qA_grape_fock02",
        # "cavityA_grape": "cavA_grape_fock02",
        "qubitA_grape": "qA_grape_fock01_test",
        "cavityA_grape": "cavA_grape_fock01_test",
        "qubitB_grape": "qB_grape_fock1",
        "cavityB_grape": "cavB_grape_fock1",
        "qubit_pi": "qA_gaussian_pi_pulse",
        "qubit_sel_pi": "qA_gaussian_very_sel_pi_pulse",
        "qubitEF_pi": "qAEF_EF_gaussian_pi_pulse",
        "exchange_ramp_up": "exchange_ramp_up",
        "exchange_constant": "exchange_pulse",
        "exchange_ramp_down": "exchange_ramp_down",
        "qubitB_pi": "qB_gaussian_pi_pulse",
        "qubitB_sel_pi": "qB_gaussian_very_sel_pi_pulse",
        "qubitB_EF_pi": "qBEF_gaussian_pi_pulse",
        "drive_pulse": "vanilla_pulse",
        "qubitC_sel_pi": "qC_gaussian_sel_pi_pulse",

        "readout_pulseB": "rrB_readout_pulse", 
        "readout_pulse": "rrA_GF_CLEAR_readout_pulse", 
    }

    ############################## CONTROL PARAMETERS ##################################

    parameters = {
        "wait_time": 6e6,
        "detuning": 100e3,
        "ramp_phase": 0, 
        "drive_detuning": 0,
        "phase": QuaVariable(value=0.0, dtype=qm_qua.fixed, tag="phase", buffer=True, stream=True),
        "correcting_phase": QuaVariable(value=0.0, dtype=qm_qua.fixed, tag="correcting_phase", buffer=True, stream=True),
        "plot_single_shot": True,
    }

    ######################## SWEEP (INDEPENDENT) VARIABLES #############################
    N.num = 50000
    # FREQ.name = "drive_freq"
    # FREQ.start = 257.13e6 - 100e6
    # FREQ.stop = 257.13e6 + 100e6
    # FREQ.num = 201

    DEL = Sweep(name = "time_delay", start = 16, stop = 200_00, step = 200, dtype = int)
    sweeps = [N, DEL]

    ######################## DATASET (DEPENDENT) VARIABLES #############################
    I.fitfn, SINGLE_SHOT.fitfn, Q.fitfn = "exp_decay_sine", "exp_decay_sine", "exp_decay_sine"
    # PHASE.datafn_args = {"delay": 2.792e-7, "freq": RRC.int_freq}
    Q.plot, MAG.plot = False, False
    SINGLE_SHOT.plot_args = {"plot_err": False}
    # I.plot_args = {"plot_err": False}
    # SINGLE_SHOT.plot = False
    datasets = [I, Q, SINGLE_SHOT, Ipre, Qpre, SINGLE_SHOTpre, IBpre, QBpre, SINGLE_SHOTBpre]

    ######################## INITIALIZE AND RUN EXPERIMENT #############################
    expt = CavityT2_A(FOLDER, modes, pulses, sweeps, datasets, **parameters)
    expt.run(simulate=False)
