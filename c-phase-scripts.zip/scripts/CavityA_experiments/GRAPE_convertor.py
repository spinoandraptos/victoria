import numpy as np
import matplotlib.pyplot as plt

#file = np.load(r"C:\Users\admin\Downloads\working pi pulse 100ns\working pi pulse 100ns\waves.npz")

file = np.load(r"C:\Users\admin\Desktop\yabba-main\fock1_success\fock1_A_3modes\fock1_A_3modes\0\waves.npz")

# qubit_I = file['Qubit_I']
# qubit_Q = file['Qubit_Q']
# qubit_complex = qubit_I + 1j * qubit_Q

#qubit_complex = np.append( qubit_complex, [0,0])
# np.save(r"C:\Users\admin\Desktop\yabba-main\fock1_success\fock1A_qubit.npy", qubit_complex)

cavity_I = file['CavityA_I']
cavity_Q = file['CavityA_Q']
cavity_complex = cavity_I + 1j*cavity_Q
# np.save(r"C:\Users\admin\Desktop\yabba-main\fock1_success\fock1A_cavA.npy", cavity_complex)

cavityB_I = file['CavityB_I']
cavityB_Q = file['CavityB_Q']
cavityB_complex = cavityB_I + 1j*cavityB_Q
# np.save(r"C:\Users\admin\Desktop\yabba-main\fock1_success\fock1A_cavB.npy", cavityB_complex)
#print(len(qubit_complex))
plt.plot(cavityB_I)
plt.plot(cavityB_Q)
print(max(cavityB_I))
print(max(cavityB_Q))
plt.show()

# time = np.linspace(-500,499,1000)

# sigma = 250

# i_env = 1/100 * np.exp(-0.5 * (time/sigma)**2 )

# plt.plot(i_env)
# np.save(r"C:\Users\admin\Desktop\yabba-main\old GRAPE qA\gaussian_onlyq.npy", 1j * i_env )


