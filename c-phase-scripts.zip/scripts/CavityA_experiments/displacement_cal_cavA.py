""" """
import sys
from config.experiment_config import FOLDER, N, FREQ, I, Q, MAG, PHASE, RRB, SINGLE_SHOT
from qcore import Experiment, qua, Sweep
from qm import qua as qm_qua
from qcore.libs.qua_macros import QuaVariable
from qcore import Dataset


class DisplacementCal_A(Experiment):
    """Cavity spectroscopy"""

    ############################# DEFINE PRIMARY DATASETS ##############################
    # these Datasets form the "raw" experimental data and will be streamed by the OPX
    # they must be specified at experiment runtime
    primary_datasets = ["I", "Q", "single_shot"]

    ############################## DEFINE PRIMARY SWEEPS ###############################
    # these Sweeps are uniquely associated with the Experiment subclass
    # these Sweeps must be specified at experiment runtime
    primary_sweeps = ["cavity_drive_amplitude"]

    ############################ DEFINE THE PULSE SEQUENCE #############################
    # ensure that you import 'qua' from 'qcore' and not from 'qm' library
    # attributes accessed via 'self' must be defined in 'if __name__ == "__main__"' code
    def sequence(self):
        """QUA sequence that defines this Experiment subclass"""
        qua.reset_frame(self.cavity)
        qua.reset_frame(self.qubit)
        qua.align()

        self.cavity.play(self.cavity_drive, ampx = self.cavity_drive_amplitude)  # play displacement to cavity
        self.cavity.play(self.cavity_drive, ampx = self.cavity_drive_amplitude)  # play displacement to cavity
        # self.cavity.play(self.cavity_drive, ampx = self.cavity_drive_amplitude)  # play displacement to cavity
        # self.cavity.play(self.cavity_drive, ampx = self.cavity_drive_amplitude)  # play displacement to cavity
        qua.align(self.cavity, self.qubit)  # align all modes
        
        self.qubit.play(self.qubit_sel)  # play qubit pulse
        qua.align(self.qubit, self.qubitEF)  # align all modes
        
        self.qubitEF.play(self.qubitEF_pi)
        qua.align(self.qubitEF, self.resonator)
        self.resonator.measure(self.readout_pulse, (self.I, self.Q), demod_type="dual")
        qua.align()
        qua.wait(self.wait_time)
        if self.plot_single_shot:  # assign state to G or E
            qm_qua.assign(self.single_shot,qm_qua.Cast.to_fixed(self.I > self.readout_pulse.threshold),)

if __name__ == "__main__":
    """ """

    #################################### MODE MAP ######################################
    modes = {
        "cavity": "cavA",
        "qubit": "qA",
        "qubitEF": "qA_EF",
        "resonator": "rrA",
    }

    ################################### PULSE MAP ######################################
    pulses = {
        "cavity_drive": "cavA_grape_coherent",
        # "cavity_drive": "cavA_ramp_pulse",
        "qubit_sel": "qA_gaussian_very_sel_pi_pulse",
        "qubitEF_pi": "qAEF_EF_gaussian_pi_pulse",
        "readout_pulse": "rrA_GF_CLEAR_readout_pulse",
    }

    ############################## CONTROL PARAMETERS ##################################
    parameters = {
        "wait_time": 6e6,
        "plot_single_shot": True,
    }

    ######################## SWEEP (INDEPENDENT) VARIABLES #############################
    N.num = 20000
    # QD_AMPX = Sweep(name="cavity_drive_amplitude", start=0.01, stop=1.8, num=100)
    QD_AMPX = Sweep(name="cavity_drive_amplitude", start=0.0, stop=1.8, step=0.04)
    sweeps = [N, QD_AMPX]

    ######################## DATASET (DEPENDENT) VARIABLES #############################
    I.fitfn = "displacement_cal"
    Q.fitfn = "displacement_cal"
    SINGLE_SHOT.fitfn = "displacement_cal"
    PHASE.datafn_args = {"delay": 2.792e-7, "freq": RRB.int_freq}
    I.plot, Q.plot, MAG.plot = False, False, False
    datasets = [I, Q, SINGLE_SHOT]

    ######################## INITIALIZE AND RUN EXPERIMENT #############################
    expt = DisplacementCal_A(FOLDER, modes, pulses, sweeps, datasets, **parameters)
    expt.run()
