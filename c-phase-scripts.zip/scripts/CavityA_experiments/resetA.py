from config.experiment_config import FOLDER, N, FREQ, I, Q, MAG, PHASE, RRC, SINGLE_SHOT
from qm import qua as qm_qua
from qcore import Experiment, qua, Sweep


class ResonantExchange1D(Experiment):
    """Resonant exchange"""

    primary_datasets = ["I", "Q", "single_shot"]

    primary_sweeps = ["drive_length"]

    def sequence(self):
        """QUA sequence that defines this Experiment subclass"""

        qua.reset_frame(self.cavA)
        qua.reset_frame(self.qA)
        qua.reset_frame(self.resetA)

        self.cavA.play(self.cavA_grape)
        self.qA.play(self.qA_grape)
        qua.align()

        # Drive resonant exchange
        # qua.update_frequency(self.resetA, self.resetA_freq)
        qua.update_frequency(self.resetA, 141.6e6)

        self.resetA.play(self.resetA_pulse, duration = self.drive_length/4 , ampx = 1.0)
        qua.align()

        self.qA.play(self.qA_sel_pulse)
        qua.align(self.qA, self.qA_EF)
        self.qA_EF.play(self.qubitAEF_pi)
        qua.align(self.qA_EF, self.resonatorA)
        
        self.resonatorA.measure(self.readout_pulseA, (self.I, self.Q), ampx=self.ro_ampx, demod_type="dual")
        qua.align()
        qua.wait(self.wait_time)
        if self.plot_single_shot:  # assign state to G or E
            qm_qua.assign(self.single_shot, qm_qua.Cast.to_fixed(self.I > self.readout_pulseA.threshold))

if __name__ == "__main__":
    """ """

    modes = {
            "resetA":"resetA",
            "cavA": "cavA",
            "qA": "qA",
            "qA_EF": "qA_EF",
            "resonatorA": "rrA",
             }

    pulses = {
        "cavA_grape": "cavA_grape_fock1",
        "qA_grape": "qA_grape_fock1",
        "qA_sel_pulse": "qA_gaussian_very_sel_pi_pulse",
        "qubitAEF_pi":"qAEF_EF_gaussian_pi_pulse",
        "resetA_pulse":"resetA_pulse",
        "readout_pulseA": "rrA_GF_CLEAR_readout_pulse", 
    }
                                       
    parameters = {
        "wait_time": 6e6,
        "ro_ampx": 1,
        "plot_single_shot": True,
        # "drive_length": 80,
    }

    N.num = 50_000
    FREQ.name = "resetA_freq"
    FREQ.start = 50e6
    FREQ.stop = 400e6
    FREQ.num = 301

    LENGTH = Sweep (name="drive_length", dtype=int, units = "ns")
    LENGTH.start = 16
    LENGTH.stop = 400
    LENGTH.step = 4 ###PREV 2000

    sweeps = [N, LENGTH]

    Q.plot,MAG.plot, PHASE.plot, I.plot = True, False, False, True
    SINGLE_SHOT.plot = True
    datasets = [I, Q, SINGLE_SHOT]

    expt = ResonantExchange1D(FOLDER, modes, pulses, sweeps, datasets, **parameters)
    expt.run(simulate = False)
