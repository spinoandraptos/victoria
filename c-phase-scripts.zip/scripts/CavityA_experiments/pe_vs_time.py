""" """

import sys
sys.path.append("C:/Users/admin/Desktop/qcore-yabba/yabba-main/")
from config.experiment_config import FOLDER, N, FREQ, I, Q, MAG, PHASE, RR, SINGLE_SHOT
from qm import qua as qm_qua
from qcore import Experiment, qua, Sweep

class Pe(Experiment):
    """Pe_vs_time"""

    ############################# DEFINE PRIMARY DATASETS ##############################
    # these Datasets form the "raw" experimental data and will be streamed by the OPX
    # they must be specified at experiment runtime
    primary_datasets = ["I", "Q", "single_shot"]

    ############################## DEFINE PRIMARY SWEEPS ###############################
    # these Sweeps are uniquely associated with the Experiment subclass
    # these Sweeps must be specified at experiment runtime
    primary_sweeps = ["drive_length"]

    ############################ DEFINE THE PULSE SEQUENCE #############################
    # ensure that you import 'qua' from 'qcore' and not from 'qm' library
    # attributes accessed via 'self' must be defined in 'if __name__ == "__main__"' code
    def sequence(self):
        """QUA sequence that defines this Experiment subclass"""
        # qubit_0 = -86.03e6 + 32e3 # Alice in 0
        # qubit_1 = -86.16e6 

        # # PREPARE STATE
        # qua.update_frequency(self.qubit, qubit_0)
        # self.qubit.play(self.qubit_grape)
        # self.cavity.play(self.cavity_grape)
        # qua.align()
        # self.qubitAGF.play(self.qubitA_drive)
        # qua.align(self.qubitAGF, self.driveA)
        # self.driveA.play(self.driveA_pulse)
        # qua.align()

        # DRIVE 
        # qua.wait(10000)
        self.drive.play(self.drive_pulse, duration = self.drive_length/4, ampx = self.qubit_drive_ampx)
        qua.align()


        #qua.align()  # align measurement
        self.resonator.measure(
            self.readout_pulse, (self.I, self.Q), ampx=self.ro_ampx, demod_type = 'dual')  # measure transmitted signal

        qua.align()
        qua.wait(self.wait_time, self.resonator)
        if self.plot_single_shot:  # assign state to G or E
            qm_qua.assign(
                self.single_shot,
                qm_qua.Cast.to_fixed(self.I > self.readout_pulse.threshold),
            )

if __name__ == "__main__":
    """ """

    #################################### MODE MAP ######################################
    # key: name of the Mode as defined by the Experiment subclass
    # value: name of the Mode as defined by the user in modes.yml
    modes = {
        "qubitAGF": "qubitAGF",
        "driveA": "driveA",
        "cavity": "cavB",
        "drive":"drive",
        "qubit": "qubit",
        "resonator": "rr",
    }

    ################################### PULSE MAP ######################################
    # key: name of the Pulse as defined by the Experiment subclass
    # value: name of the Pulse as defined by the user in modes.yml
    pulses = {
        #"qubitA_drive": "qubitAGF_gaussian_pi_pulse",
        #"driveA_pulse": "driveA_constant_ramp_pulse_short",
        #"qubit_grape": "qubit_grape_B_fock01",
        #"cavity_grape": "cavityB_grape_B_fock01",
        #"cav_op": "cavityB_gaussian_coherent_1",
        #"qubit_op": "qubit_gaussian_pi2_pulse",
        "drive_pulse": "SS_pulse",
        "readout_pulse": "rr_readout_pulse",
    }

    ############################## CONTROL PARAMETERS ##################################
    parameters = {
        "wait_time": 7e6,
        "ro_ampx": 1,
        "plot_single_shot": True,
    }

    ######################## SWEEP (INDEPENDENT) VARIABLES #############################
    # must include an outermost averaging Sweep named "N"
    # must include all primary sweeps defined by the Experiment subclass

    # set number of repetitions for this Experiment run
    N.num = 2000

    LENGTH = Sweep (name="drive_length", dtype=int, units = "ns")
    LENGTH.start = 200
    LENGTH.stop = 10000
    LENGTH.step = 100

    QD_AMPX = Sweep(name="qubit_drive_ampx", points=[0.0, 2.0])

    sweeps = [N, QD_AMPX, LENGTH]

    ######################## DATASET (DEPENDENT) VARIABLES #############################
    # must include all primary datasets defined by the Experiment subclass
    I.fitfn = "gaussian"
    PHASE.datafn_args = {"delay": 2.792e-7, "freq": RR.int_freq}
    Q.plot, MAG.plot = False, False

    datasets = [I, Q, SINGLE_SHOT]

    ######################## INITIALIZE AND RUN EXPERIMENT #############################
    expt = Pe(FOLDER, modes, pulses, sweeps, datasets, **parameters)
    expt.run()
