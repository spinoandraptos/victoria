from cmath import cos
from qcore import qua
import numpy as np
from qm import qua as qm_qua
from qm.qua import *

# ECD scaled through ampitude and phase
def ECD_point(
    cav,
    qubit,
    displacement_pulse,
    qubit_pi_pulse,
    ratio,
    ECD_wait_time,
    qubit_phase,
    ampx,
    phase,
):


    qua.align(qubit, cav)  # wait for qubit pulse to end
    cav.play(
        displacement_pulse, ampx=ampx * ratio[0] * ratio[1], phase=phase
    )  # First positive displacement
    qua.wait(int(ECD_wait_time), cav)
    cav.play(
        displacement_pulse,
        ampx=-ampx * ratio[0] * ratio[2],
        phase=phase,
    )
    # cav.play(displacement_pulse, ampx=-ampx*cos(chi*ECD_wait_time/2) if scale==True else -ampx, phase=phase)   # First negative displacement
    qua.align(qubit, cav)
    qubit.play(qubit_pi_pulse, phase=qubit_phase)  # play pi to flip qubit around X
    qua.align(qubit, cav)  # wait for qubit pulse to end
    cav.play(
        displacement_pulse,
        ampx=-ampx * ratio[0] * ratio[2],
        phase=phase,
    )
    # cav.play(displacement_pulse, ampx=-ampx*cos(chi*ECD_wait_time/2) if scale==True else -ampx, phase=phase)# Second negative displacement
    qua.wait(int(ECD_wait_time), cav)
    cav.play(
        displacement_pulse,
        ampx=ampx * ratio[0] * ratio[3],
        phase=phase,
    )  # Second positive displacement
    # cav.play(displacement_pulse, ampx=ampx*cos(chi*ECD_wait_time) if scale==True else ampx, phase=phase)
    return None

def ECD_3modes_point(
    cav1,
    cav2,
    cav3,
    qubit,
    cav1_displacement_pulse,
    cav2_displacement_pulse,
    cav3_displacement_pulse,
    qubit_pi_pulse,
    cav1_ratio,
    cav2_ratio,
    cav3_ratio,
    cav1_ECD_wait_time,
    cav2_ECD_wait_time,
    cav3_ECD_wait_time,
    qubit_phase,
    cav1_ampx,
    cav2_ampx,
    cav3_ampx,
    cav1_phase,
    cav2_phase,
    cav3_phase,
    wait_between_cavities1,
    wait_between_cavities2
):


    qua.align()  
    
    cav1.play(cav1_displacement_pulse, ampx=cav1_ampx * cav1_ratio[0] * cav1_ratio[1], phase=cav1_phase)
    qua.wait(wait_between_cavities1, cav2)
    cav2.play(cav2_displacement_pulse, ampx=cav2_ampx * cav2_ratio[0] * cav2_ratio[1], phase=cav2_phase)
    qua.wait(wait_between_cavities2, cav3)
    cav3.play(cav3_displacement_pulse, ampx=cav3_ampx * cav3_ratio[0] * cav3_ratio[1], phase=cav3_phase)  
    qua.wait(int(cav1_ECD_wait_time), cav1)
    qua.wait(int(cav2_ECD_wait_time), cav2)
    qua.wait(int(cav3_ECD_wait_time), cav3)
    cav1.play(cav1_displacement_pulse,ampx=-cav1_ampx * cav1_ratio[0] * cav1_ratio[2],phase=cav1_phase)
    cav2.play(cav2_displacement_pulse, ampx=-cav2_ampx * cav2_ratio[0] * cav2_ratio[2], phase=cav2_phase)
    cav3.play(cav3_displacement_pulse, ampx=-cav3_ampx * cav3_ratio[0] * cav3_ratio[2], phase=cav3_phase)
    qua.align()
    qubit.play(qubit_pi_pulse, phase=qubit_phase)  
    qua.align()
    cav1.play(cav1_displacement_pulse,ampx=-cav1_ampx * cav1_ratio[0] * cav1_ratio[2],phase=cav1_phase)
    cav2.play(cav2_displacement_pulse, ampx=-cav2_ampx * cav2_ratio[0] * cav2_ratio[2], phase=cav2_phase)
    cav3.play(cav3_displacement_pulse, ampx=-cav3_ampx * cav3_ratio[0] * cav3_ratio[2], phase=cav3_phase)
    qua.wait(int(cav1_ECD_wait_time), cav1)
    qua.wait(int(cav2_ECD_wait_time), cav2)
    qua.wait(int(cav3_ECD_wait_time), cav3)
    cav1.play(cav1_displacement_pulse,ampx=cav1_ampx * cav1_ratio[0] * cav1_ratio[3],phase=cav1_phase)
    cav2.play(cav2_displacement_pulse, ampx=cav2_ampx * cav2_ratio[0] * cav2_ratio[3], phase=cav2_phase)
    cav3.play(cav3_displacement_pulse, ampx=cav3_ampx * cav3_ratio[0] * cav3_ratio[3], phase=cav3_phase) 
    return None

# ECD based on real and imagnary displacement values
def ECD_charFunc(
    cav,
    qubit,
    displacement_pulse,
    qubit_pi_pulse,
    ampx_x,
    ampx_y,
    ratio,
    ECD_wait_time,
    phase=0,
    qubit_phase=0,
):

    qua.align(qubit, cav)  # wait for qubit pulse to end
    cav.play(
        displacement_pulse,
        ampx=(
            ampx_x * ratio[0] * ratio[1],
            -ampx_y * ratio[0] * ratio[1],
            ampx_y * ratio[0] * ratio[1],
            ampx_x * ratio[0] * ratio[1],
        ),
        phase=phase,
    )  # First positive displacement
    qua.wait(ECD_wait_time, cav)
    cav.play(
        displacement_pulse,
        ampx=(
            -ampx_x * ratio[0] * ratio[2],
            ampx_y * ratio[0] * ratio[2],
            -ampx_y * ratio[0] * ratio[2],
            -ampx_x * ratio[0] * ratio[2],
        ),
        phase=phase,
    )  # First negative displacement
    qua.align(qubit, cav)
    qubit.play(qubit_pi_pulse, phase=qubit_phase)  # play pi to flip qubit around X
    qua.align(qubit, cav)  # wait for qubit pulse to end
    cav.play(
        displacement_pulse,
        ampx=(
            -ampx_x * ratio[0] * ratio[2],
            ampx_y * ratio[0] * ratio[2],
            -ampx_y * ratio[0] * ratio[2],
            -ampx_x * ratio[0] * ratio[2],
        ),
        phase=phase,
    )  # Second negative displacement
    qua.wait(ECD_wait_time, cav)
    cav.play(
        displacement_pulse,
        ampx=(
            ampx_x * ratio[0] * ratio[3],
            -ampx_y * ratio[0] * ratio[3],
            ampx_y * ratio[0] * ratio[3],
            ampx_x * ratio[0] * ratio[3],
        ),
        phase=phase,
    )  # Second positive displacement

    return None

def ECD_3modes_charfunc(
    cav1,
    cav2,
    cav3,
    qubit,
    cav1_displacement_pulse,
    cav2_displacement_pulse,
    cav3_displacement_pulse,
    qubit_pi_pulse,
    cav1_ratio,
    cav2_ratio,
    cav3_ratio,
    cav1_ECD_wait_time,
    cav2_ECD_wait_time,
    cav3_ECD_wait_time,
    qubit_phase,
    cav1_ampx_x,
    cav2_ampx_x,
    cav3_ampx_x,
    cav1_ampx_y,
    cav2_ampx_y,
    cav3_ampx_y,
    cav1_phase,
    cav2_phase,
    cav3_phase,
    wait_between_cavities1,
    wait_between_cavities2
):


    qua.align()  
    
    cav1.play(cav1_displacement_pulse, 
                ampx=(cav1_ampx_x * cav1_ratio[0] * cav1_ratio[1], 
                      -cav1_ampx_y * cav1_ratio[0] * cav1_ratio[1], 
                      cav1_ampx_y * cav1_ratio[0] * cav1_ratio[1],
                      cav1_ampx_x * cav1_ratio[0] * cav1_ratio[1]), 
                phase=cav1_phase)
    qua.wait(wait_between_cavities1, cav2)
    cav2.play(cav2_displacement_pulse, 
              ampx=(cav2_ampx_x * cav2_ratio[0] * cav2_ratio[1], 
                      -cav2_ampx_y * cav2_ratio[0] * cav2_ratio[1], 
                      cav2_ampx_y * cav2_ratio[0] * cav2_ratio[1],
                      cav2_ampx_x * cav2_ratio[0] * cav2_ratio[1]), 
              phase=cav2_phase)
    qua.wait(wait_between_cavities2, cav3)
    cav3.play(cav3_displacement_pulse,
              ampx=(cav3_ampx_x * cav3_ratio[0] * cav3_ratio[1], 
                      -cav3_ampx_y * cav3_ratio[0] * cav3_ratio[1], 
                      cav3_ampx_y * cav3_ratio[0] * cav3_ratio[1],
                      cav3_ampx_x * cav3_ratio[0] * cav3_ratio[1]), 
              phase=cav3_phase)  
    qua.wait(int(cav1_ECD_wait_time), cav1)
    qua.wait(int(cav2_ECD_wait_time), cav2)
    qua.wait(int(cav3_ECD_wait_time), cav3)
    cav1.play(cav1_displacement_pulse, 
                ampx=(-cav1_ampx_x * cav1_ratio[0] * cav1_ratio[2], 
                      cav1_ampx_y * cav1_ratio[0] * cav1_ratio[2], 
                      -cav1_ampx_y * cav1_ratio[0] * cav1_ratio[2],
                      -cav1_ampx_x * cav1_ratio[0] * cav1_ratio[2]), 
                phase=cav1_phase)
    cav2.play(cav2_displacement_pulse, 
              ampx=(-cav2_ampx_x * cav2_ratio[0] * cav2_ratio[2], 
                      cav2_ampx_y * cav2_ratio[0] * cav2_ratio[2], 
                      -cav2_ampx_y * cav2_ratio[0] * cav2_ratio[2],
                      -cav2_ampx_x * cav2_ratio[0] * cav2_ratio[2]), 
              phase=cav2_phase)
    cav3.play(cav3_displacement_pulse,
              ampx=(-cav3_ampx_x * cav3_ratio[0] * cav3_ratio[2], 
                      cav3_ampx_y * cav3_ratio[0] * cav3_ratio[2], 
                      -cav3_ampx_y * cav3_ratio[0] * cav3_ratio[2],
                      -cav3_ampx_x * cav3_ratio[0] * cav3_ratio[2]), 
              phase = cav3_phase)
    qua.align()
    qubit.play(qubit_pi_pulse, phase=qubit_phase)  
    qua.align()
    cav1.play(cav1_displacement_pulse, 
                ampx=(-cav1_ampx_x * cav1_ratio[0] * cav1_ratio[2], 
                      cav1_ampx_y * cav1_ratio[0] * cav1_ratio[2], 
                      -cav1_ampx_y * cav1_ratio[0] * cav1_ratio[2],
                      -cav1_ampx_x * cav1_ratio[0] * cav1_ratio[2]), 
                phase=cav1_phase)
    cav2.play(cav2_displacement_pulse, 
              ampx=(-cav2_ampx_x * cav2_ratio[0] * cav2_ratio[2], 
                      cav2_ampx_y * cav2_ratio[0] * cav2_ratio[2], 
                      -cav2_ampx_y * cav2_ratio[0] * cav2_ratio[2],
                      -cav2_ampx_x * cav2_ratio[0] * cav2_ratio[2]), 
              phase=cav2_phase)
    cav3.play(cav3_displacement_pulse,
              ampx=(-cav3_ampx_x * cav3_ratio[0] * cav3_ratio[2], 
                      cav3_ampx_y * cav3_ratio[0] * cav3_ratio[2], 
                      -cav3_ampx_y * cav3_ratio[0] * cav3_ratio[2],
                      -cav3_ampx_x * cav3_ratio[0] * cav3_ratio[2]), 
              phase = cav3_phase)
    qua.wait(int(cav1_ECD_wait_time), cav1)
    qua.wait(int(cav2_ECD_wait_time), cav2)
    qua.wait(int(cav3_ECD_wait_time), cav3)
    cav1.play(cav1_displacement_pulse, 
                ampx=(cav1_ampx_x * cav1_ratio[0] * cav1_ratio[3], 
                      -cav1_ampx_y * cav1_ratio[0] * cav1_ratio[3], 
                      cav1_ampx_y * cav1_ratio[0] * cav1_ratio[3],
                      cav1_ampx_x * cav1_ratio[0] * cav1_ratio[3]), 
                phase=cav1_phase)
    cav2.play(cav2_displacement_pulse, 
              ampx=(cav2_ampx_x * cav2_ratio[0] * cav2_ratio[3], 
                      -cav2_ampx_y * cav2_ratio[0] * cav2_ratio[3], 
                      cav2_ampx_y * cav2_ratio[0] * cav2_ratio[3],
                      cav2_ampx_x * cav2_ratio[0] * cav2_ratio[3]), 
              phase=cav2_phase)
    cav3.play(cav3_displacement_pulse,
              ampx=(cav3_ampx_x * cav3_ratio[0] * cav3_ratio[3], 
                      -cav3_ampx_y * cav3_ratio[0] * cav3_ratio[3], 
                      cav3_ampx_y * cav3_ratio[0] * cav3_ratio[3],
                      cav3_ampx_x * cav3_ratio[0] * cav3_ratio[3]), 
              phase = cav3_phase)
    return None


def Char2modes_point_single_shot(
    single_shot,
    resonator,
    readout_pulse,
    I,
    Q,
    wait_time,
    cav,
    cav2,
    qubit,
    qubit2,
    displacement_pulse,
    displacement2_pulse,
    qubit_pi_pulse,
    qubit2_pi_pulse,
    qubit_pi2_pulse,
    cav1_ECD_wait_time,
    cav2_ECD_wait_time,
    measure_real,
    ratio,
    ratio2,
    wait_between_cavities,
    plot_single_shot,
    ampx_cav1,
    ampx_cav2,
    cav1_geometrical_phase,
    cav2_geometrical_phase,
    cav1_tomo_phase,
    cav2_tomo_phase,
    phase1=None,
    phase2=None,
):
    ### calculating phase to be played in qubit
    ECD_scale = 3
    # if type(ampx_cav1) == int:
    if measure_real:
        char_phase = np.abs(ampx_cav1/ECD_scale)**2 * cav1_geometrical_phase + np.abs(ampx_cav2/ECD_scale)**2 * cav2_geometrical_phase + 0.5 
    else:
        char_phase = np.abs(ampx_cav1/ECD_scale)**2 * cav1_geometrical_phase + np.abs(ampx_cav2/ECD_scale)**2 * cav2_geometrical_phase + 0.75
    # else:
    # cav1_disp = declare(fixed, value = ampx_cav1)
    # cav2_disp = declare(fixed, value = ampx_cav2)
    # char_phase = declare(fixed)
    # cav1_phi0 = declare(fixed, value = cav1_geometrical_phase)
    # cav2_phi0 = declare(fixed, value = cav2_geometrical_phase)
    # ECD_scale_var = declare(fixed, value = ECD_scale)
    # if measure_real:
    #     assign(char_phase, qm_qua.Math.pow(qm_qua.Math.abs(ampx_cav1/ECD_scale_var),2)*cav1_phi0  + qm_qua.Math.pow(qm_qua.Math.abs(ampx_cav2/ECD_scale_var),2)*cav2_phi0 +0.5)
        
    # else:
    #     assign(char_phase, qm_qua.Math.pow(qm_qua.Math.abs(ampx_cav1/ECD_scale_var),2)*cav1_phi0 + qm_qua.Math.pow(qm_qua.Math.abs(ampx_cav2/ECD_scale_var),2)*cav2_phi0 +0.75)
    
    # bring qubit into superposition
    qua.align(qubit, cav, cav2)
    qubit.play(qubit_pi2_pulse)
    qua.align(cav, cav2, qubit)  # wait for qubit pulse to end
    # start ECD gate
    

    ECD_point(
        cav,
        qubit,
        displacement_pulse,
        qubit_pi_pulse,
        ratio,
        cav1_ECD_wait_time,
        0,
        ampx_cav1/ECD_scale,
        phase1+cav1_tomo_phase,
    )
    qua.wait(wait_between_cavities, cav2)
    ECD_point(
        cav2,
        qubit2,
        displacement2_pulse,
        qubit2_pi_pulse,
        ratio2,
        cav2_ECD_wait_time,
        0,
        ampx_cav2/ECD_scale,
        phase2+cav2_tomo_phase,
    )

    qua.align(qubit, cav, cav2)

    qubit.play(qubit_pi2_pulse, phase=char_phase)
    qua.align(qubit, resonator)  # align measurement
    resonator.measure(readout_pulse, (I, Q), demod_type="dual")  # measure transmitted signal

    if plot_single_shot:  # assign state to G or E
        qm_qua.assign(
            single_shot,
            qm_qua.Cast.to_fixed(I > readout_pulse.threshold),
        )
    # wait system reset
    qua.wait(int(wait_time), cav)
    qua.wait(int(wait_time), cav2)
    return None

def Char2modes_xxyy_single_shot(
    single_shot,
    resonator,
    readout_pulse,
    I,
    Q,
    wait_time,
    cav,
    cav2,
    qubit,
    qubit2,
    displacement_pulse,
    displacement2_pulse,
    qubit_pi_pulse,
    qubit2_pi_pulse,
    qubit_pi2_pulse,
    cav1_ECD_wait_time,
    cav2_ECD_wait_time,
    measure_real,
    ratio,
    ratio2,
    wait_between_cavities,
    plot_single_shot,
    ampx_cav1,
    ampx_cav2,
    cav1_geometrical_phase,
    cav2_geometrical_phase,
    cav1_tomo_phase,
    cav2_tomo_phase,
    phase1=None,
    phase2=None,
):
    ### calculating phase to be played in qubit
    ECD_scale = 3
    # if type(ampx_cav1) == int:
    # if measure_real:
    #     char_phase = np.abs(ampx_cav1/ECD_scale)**2 * cav1_geometrical_phase + np.abs(ampx_cav2/ECD_scale)**2 * cav2_geometrical_phase + 0.5 
    # else:
    #     char_phase = np.abs(ampx_cav1/ECD_scale)**2 * cav1_geometrical_phase + np.abs(ampx_cav2/ECD_scale)**2 * cav2_geometrical_phase + 0.75
    # else:
    # cav1_disp = declare(fixed, value = ampx_cav1)
    # cav2_disp = declare(fixed, value = ampx_cav2)
    char_phase = declare(fixed)
    cav1_phi0 = declare(fixed, value = cav1_geometrical_phase)
    cav2_phi0 = declare(fixed, value = cav2_geometrical_phase)
    ECD_scale_var = declare(fixed, value = ECD_scale)
    if measure_real:
        assign(char_phase, qm_qua.Math.pow(qm_qua.Math.abs(ampx_cav1),2)*cav1_phi0  + qm_qua.Math.pow(qm_qua.Math.abs(ampx_cav2),2)*cav2_phi0 +0.5)
        
    else:
        assign(char_phase, qm_qua.Math.pow(qm_qua.Math.abs(ampx_cav1),2)*cav1_phi0 + qm_qua.Math.pow(qm_qua.Math.abs(ampx_cav2),2)*cav2_phi0 +0.75)
    
    # bring qubit into superposition
    qua.align(qubit, cav, cav2)
    qubit.play(qubit_pi2_pulse)
    qua.align(cav, cav2, qubit)  # wait for qubit pulse to end
    # start ECD gate
    

    ECD_point(
        cav,
        qubit,
        displacement_pulse,
        qubit_pi_pulse,
        ratio,
        cav1_ECD_wait_time,
        0,
        ampx_cav1,
        phase1+cav1_tomo_phase,
    )
    qua.wait(wait_between_cavities, cav2)
    ECD_point(
        cav2,
        qubit2,
        displacement2_pulse,
        qubit2_pi_pulse,
        ratio2,
        cav2_ECD_wait_time,
        0,
        ampx_cav2,
        phase2+cav2_tomo_phase,
    )

    qua.align(qubit, cav, cav2)

    qubit.play(qubit_pi2_pulse, phase=char_phase)
    qua.align(qubit, resonator)  # align measurement
    resonator.measure(readout_pulse, (I, Q), demod_type="dual")  # measure transmitted signal

    if plot_single_shot:  # assign state to G or E
        qm_qua.assign(
            single_shot,
            qm_qua.Cast.to_fixed(I > readout_pulse.threshold),
        )
    # wait system reset
    qua.wait(int(wait_time), cav)
    qua.wait(int(wait_time), cav2)
    return None


def Char2D(
    single_shot,
    resonator,
    readout_pulse,
    I,
    Q,
    wait_time,
    cav,
    qubit,
    displacement_pulse,
    qubit_pi_pulse,
    qubit_pi2_pulse,
    ampx_x,
    ampx_y,
    ratio,
    ECD_wait_time,
    measure_real,
    tomo_phase,
    plot_single_shot,
    qubit_phase = 0,
):
    # bring qubit into superposition
    qua.align(qubit, cav)
    qubit.play(qubit_pi2_pulse)
    qua.align(cav, qubit)  # wait for qubit pulse to end
    # start ECD gate
    ECD_charFunc(
        cav,
        qubit,
        displacement_pulse,
        qubit_pi_pulse,
        ampx_x,
        ampx_y,
        ratio,
        ECD_wait_time,
        tomo_phase,
        0,
    )

    qua.align(qubit, cav)

    qubit.play(qubit_pi2_pulse, phase=(0.5 if measure_real else 0.75))
    qua.align(qubit, resonator)  # align measurement
    resonator.measure(
        readout_pulse, (I, Q), demod_type="dual"
    )  # measure transmitted signal
    
    if plot_single_shot:  # assign state to G or E
        qm_qua.assign(
            single_shot,
            qm_qua.Cast.to_fixed(I > readout_pulse.threshold),
        )
    # wait system reset
    qua.wait(int(wait_time), cav)
    return None

def Char2D_phaseCorrection(
    single_shot,
    resonator,
    readout_pulse,
    I,
    Q,
    wait_time,
    cav,
    qubit,
    displacement_pulse,
    qubit_pi_pulse,
    qubit_pi2_pulse,
    ampx_x,
    ampx_y,
    ratio,
    ECD_wait_time,
    measure_real,
    tomo_phase,
    plot_single_shot,
    qubit_phase = 0,
):
    
    char_phase = declare(fixed)
    phi0 = declare(fixed, value = qubit_phase)
    if measure_real:
        assign(char_phase, (qm_qua.Math.pow(qm_qua.Math.abs(ampx_x),2) + qm_qua.Math.pow(qm_qua.Math.abs(ampx_y),2))*phi0+0.5)
        
    else:
        assign(char_phase, (qm_qua.Math.pow(qm_qua.Math.abs(ampx_x),2) + qm_qua.Math.pow(qm_qua.Math.abs(ampx_y),2))*phi0+0.75)
    
    # bring qubit into superposition
    qua.align(qubit, cav)
    qubit.play(qubit_pi2_pulse)
    qua.align(cav, qubit)  # wait for qubit pulse to end
    # start ECD gate
    ECD_charFunc(
        cav,
        qubit,
        displacement_pulse,
        qubit_pi_pulse,
        ampx_x,
        ampx_y,
        ratio,
        ECD_wait_time,
        tomo_phase,
        0,
    )

    qua.align(qubit, cav)

    qubit.play(qubit_pi2_pulse, phase= char_phase)
    qua.align(qubit, resonator)  # align measurement
    resonator.measure(
        readout_pulse, (I, Q), demod_type="dual"
    )  # measure transmitted signal
    
    if plot_single_shot:  # assign state to G or E
        qm_qua.assign(
            single_shot,
            qm_qua.Cast.to_fixed(I > readout_pulse.threshold),
        )
    # wait system reset
    qua.wait(int(wait_time), cav)
    return None

def Char2D_single_shot(
    single_shot,
    resonator,
    readout_pulse,
    I,
    Q,
    wait_time,
    cav,
    qubit,
    displacement_pulse,
    qubit_pi_pulse,
    qubit_pi2_pulse,
    ampx_x,
    ampx_y,
    ratio,
    ECD_wait_time,
    measure_real,
    tomo_phase,
    plot_single_shot,
):
    # bring qubit into superposition
    qua.align(qubit, cav)
    qubit.play(qubit_pi2_pulse)
    qua.align(cav, qubit)  # wait for qubit pulse to end
    # start ECD gate
    ECD_charFunc(
        cav,
        qubit,
        displacement_pulse,
        qubit_pi_pulse,
        ampx_x,
        ampx_y,
        ratio,
        ECD_wait_time,
        tomo_phase,
        0,
    )

    qua.align(qubit, cav)

    qubit.play(qubit_pi2_pulse, phase=0 if measure_real else 0.25)
    qua.align(qubit, resonator)  # align measurement
    resonator.measure(
        readout_pulse, (I, Q), demod_type="dual"
    )  # measure transmitted signal

    # wait system reset
    if plot_single_shot:  # assign state to G or E
        qm_qua.assign(
            single_shot,
            qm_qua.Cast.to_fixed(I > readout_pulse.threshold),
        )

    qua.wait(int(wait_time), cav)
    return None


def Char2D_2modes(
    resonator,
    readout_pulse,
    I,
    Q,
    cav,
    cav2,
    qubit,
    qubit2,
    displacement_pulse,
    displacement2_pulse,
    qubit_pi_pulse,
    qubit_empty_pulse,
    qubit_pi2_pulse,
    ECD_wait_time,
    measure_real,
    ampx_x1,
    ampx_y1,
    wait_between_cavities,
    ampx_x2,
    ampx_y2,
    wait_time,
    phase1=None,
    phase2=None,
):
    qua.align(qubit, cav, cav2)

    ECD_charFunc(
        cav,
        qubit,
        displacement_pulse,
        qubit_pi_pulse,
        ampx_x1,
        ampx_y1,
        ECD_wait_time,
        phase1,
        0,
    )
    qua.wait(wait_between_cavities, cav2)
    ECD_charFunc(
        cav,
        qubit2,
        displacement2_pulse,
        qubit_empty_pulse,
        ampx_x2,
        ampx_y2,
        ECD_wait_time,
        phase2,
        0,
    )
    qua.align()

    qubit.play(qubit_pi2_pulse, phase=0 if measure_real else 0.25)
    qua.align(qubit, resonator)  # align measurement
    resonator.measure(readout_pulse, (I, Q))
    # wait system reset
    qua.wait(int(wait_time), cav)
    return None


def Char2D_2modes_singleshot(
    resonator,
    readout_pulse,
    I,
    Q,
    cav1,
    cav2,
    qubit,
    qubit2,
    displacement1_pulse,
    displacement2_pulse,
    qubit_pi_pulse,
    qubit_empty_pulse,
    qubit_pi2_pulse,
    ECD_wait_time_cav1,
    ECD_wait_time_cav2,
    measure_real,
    ampx_cav1,
    wait_between_cavities,
    ampx_cav2,
    ratios1,
    ratios2,
    wait_time,
    axis,
    cav1_measure_real,
    cav2_measure_real,
    single_shot,
    plot_single_shot,
    cav1_geometrical_phase,
    cav2_geometrical_phase,
    phase1=None,
    phase2=None,
):
    char_phase = declare(fixed)
    cav1_phi0 = declare(fixed, value = cav1_geometrical_phase)
    cav2_phi0 = declare(fixed, value = cav2_geometrical_phase)
    if measure_real:
        assign(char_phase, qm_qua.Math.pow(qm_qua.Math.abs(ampx_cav1),2)*cav1_phi0  + qm_qua.Math.pow(qm_qua.Math.abs(ampx_cav2),2)*cav2_phi0 +0.5)
        
    else:
        assign(char_phase, qm_qua.Math.pow(qm_qua.Math.abs(ampx_cav1),2)*cav1_phi0 + qm_qua.Math.pow(qm_qua.Math.abs(ampx_cav2),2)*cav2_phi0 +0.75)
    

    qua.align()
    qubit.play(qubit_pi2_pulse)
    qua.align()  # wait for qubit pulse to end

    ECD_charFunc(
        cav1,
        qubit,
        displacement1_pulse,
        qubit_pi_pulse,
        ampx_cav1 * axis[0] if cav1_measure_real else ampx_cav1 * axis[1],
        ampx_cav1 * axis[1] if cav1_measure_real else ampx_cav1 * axis[0],
        ratios1,
        ECD_wait_time_cav1,
        phase1,
        0,
    )
    qua.wait(wait_between_cavities, cav2)
    ECD_charFunc(
        cav2,
        qubit2,
        displacement2_pulse,
        qubit_empty_pulse,
        ampx_cav2 * axis[0] if cav2_measure_real else ampx_cav2 * axis[1],
        ampx_cav2 * axis[1] if cav2_measure_real else ampx_cav2 * axis[0],
        ratios2,
        ECD_wait_time_cav2,
        phase2,
        0,
    )

    qua.align()

    qubit.play(qubit_pi2_pulse, phase = char_phase)
    qua.align(qubit, resonator)  # align measurement
    resonator.measure(
        readout_pulse, (I, Q), demod_type="dual"
    )  # measure transmitted signal

    # wait system reset
    if plot_single_shot:  # assign state to G or E
        qm_qua.assign(
            single_shot,
            qm_qua.Cast.to_fixed(I > readout_pulse.threshold),
        )

    qua.wait(int(wait_time), cav1)
    qua.wait(int(wait_time), cav2)
    return None

def Char3modes_singleshot(
    single_shot,
    resonator,
    readout_pulse,
    I,
    Q,
    wait_time,
    cav1_ge,
    cav2_ge,
    cav3_ge,
    qubit,
    cav1_displacement_pulse,
    cav2_displacement_pulse,
    cav3_displacement_pulse,
    qubit_pi_pulse,
    qubit_pi2_pulse,
    cav1_ECD_wait_time,
    cav2_ECD_wait_time,
    cav3_ECD_wait_time,
    measure_real,
    cav1_ratio,
    cav2_ratio,
    cav3_ratio,
    wait_between_cavities1,
    wait_between_cavities2,
    ampx_cav1,
    ampx_cav2,
    ampx_cav3,
    phase_cav1,
    phase_cav2,
    phase_cav3,
    plot_single_shot,
    cav1_geometrical_phase,
    cav2_geometrical_phase,
    cav3_geometrical_phase,
    cav1_tomo_phase,
    cav2_tomo_phase,
    cav3_tomo_phase,
):
    ECD_scale = 3
    
    if measure_real:
        char_phase = np.abs(ampx_cav1/ECD_scale)**2 * cav1_geometrical_phase + np.abs(ampx_cav2/ECD_scale)**2 * cav2_geometrical_phase + np.abs(ampx_cav3/ECD_scale)**2 * cav3_geometrical_phase + 0.5 
    else:
        char_phase = np.abs(ampx_cav1/ECD_scale)**2 * cav1_geometrical_phase + np.abs(ampx_cav2/ECD_scale)**2 * cav2_geometrical_phase + np.abs(ampx_cav3/ECD_scale)**2 * cav3_geometrical_phase + 0.75
    
    # bring qubit into superposition
    qua.align() # align all modes
    qubit.play(qubit_pi2_pulse)
    qua.align()  # wait for qubit pulse to end
    
    ECD_3modes_point(
        cav1_ge,
        cav2_ge,
        cav3_ge,
        qubit,
        cav1_displacement_pulse,
        cav2_displacement_pulse,
        cav3_displacement_pulse,
        qubit_pi_pulse,
        cav1_ratio,
        cav2_ratio,
        cav3_ratio,
        cav1_ECD_wait_time,
        cav2_ECD_wait_time,
        cav3_ECD_wait_time,
        0, #qubit phase in the middle of ECD
        ampx_cav1/ECD_scale,
        ampx_cav2/ECD_scale,
        ampx_cav3/ECD_scale,
        phase_cav1 + cav1_tomo_phase,
        phase_cav2 + cav2_tomo_phase,
        phase_cav3 + cav3_tomo_phase,
        wait_between_cavities1,
        wait_between_cavities2
)
    
    # start ECD gate
    # ECD_point(
    #     cav1_ge,
    #     qubit,
    #     displacement_pulse,
    #     qubit_pi_pulse,
    #     ratio1,
    #     ECD_wait_time1,
    #     0,
    #     ampx_cav1/ECD_scale,
    #     phase_cav1 + cav1_tomo_phase,
    # )
    # qua.wait(wait_between_cavities1, cav2_ge)
    # ECD_point(
    #     cav2_ge,
    #     qubit2,
    #     displacement2_pulse,
    #     qubit2_pi_pulse,
    #     ratio2,
    #     ECD_wait_time2,
    #     0,
    #     ampx_cav2/ECD_scale,
    #     phase_cav2 + cav2_tomo_phase,
    # )
    # qua.wait(wait_between_cavities2, cav3_ge)
    # ECD_point(
    #     cav3_ge,
    #     qubit3,
    #     displacement3_pulse,
    #     qubit3_pi_pulse,
    #     ratio3,
    #     ECD_wait_time3,
    #     0,
    #     ampx_cav3/ECD_scale,
    #     phase_cav3 + cav3_tomo_phase,
    # )

    qua.align()

    qubit.play(qubit_pi2_pulse, phase=char_phase)
    qua.align(qubit, resonator)  # align measurement
    resonator.measure(readout_pulse, (I, Q), demod_type="dual")  # measure transmitted signal

    # wait system reset
    if plot_single_shot:  # assign state to G or E
        qm_qua.assign(
            single_shot,
            qm_qua.Cast.to_fixed(I > readout_pulse.threshold),
        )

    qua.wait(int(wait_time), cav1_ge)
    qua.wait(int(wait_time), cav2_ge)
    qua.wait(int(wait_time), cav3_ge)
    return None

def Char3modes_singleshot_offset_cal(
    single_shot,
    resonator,
    readout_pulse,
    I,
    Q,
    wait_time,
    cav1_ge,
    cav2_ge,
    cav3_ge,
    qubit,
    cav1_displacement_pulse,
    cav2_displacement_pulse,
    cav3_displacement_pulse,
    qubit_pi_pulse,
    qubit_pi2_pulse,
    cav1_ECD_wait_time,
    cav2_ECD_wait_time,
    cav3_ECD_wait_time,
    measure_real,
    cav1_ratio,
    cav2_ratio,
    cav3_ratio,
    wait_between_cavities1,
    wait_between_cavities2,
    ampx_cav1,
    ampx_cav2,
    ampx_cav3,
    phase_cav1,
    phase_cav2,
    phase_cav3,
    plot_single_shot,
    cav1_geometrical_phase,
    cav2_geometrical_phase,
    cav3_geometrical_phase,
    cav1_tomo_phase,
    cav2_tomo_phase,
    cav3_tomo_phase,
):
    ECD_scale = 3
    char_phase = 0.5 if measure_real else 0.75
    # char_phase = declare(fixed)
    # cav1_phi0 = declare(fixed, value = cav1_geometrical_phase)
    # cav2_phi0 = declare(fixed, value = cav2_geometrical_phase)
    # cav3_phi0 = declare(fixed, value = cav3_geometrical_phase)
    # if measure_real:
    #     assign(char_phase, qm_qua.Math.pow(qm_qua.Math.abs(ampx_cav1/ECD_scale),2)*cav1_phi0  + qm_qua.Math.pow(qm_qua.Math.abs(ampx_cav2/ECD_scale),2)*cav2_phi0 + qm_qua.Math.pow(qm_qua.Math.abs(ampx_cav3/ECD_scale),2)*cav3_phi0+0.5)
        
    # else:
    #     assign(char_phase, qm_qua.Math.pow(qm_qua.Math.abs(ampx_cav1/ECD_scale),2)*cav1_phi0 + qm_qua.Math.pow(qm_qua.Math.abs(ampx_cav2/ECD_scale),2)*cav2_phi0 +qm_qua.Math.pow(qm_qua.Math.abs(ampx_cav3/ECD_scale),2)*cav3_phi0+0.75)
    
    # if measure_real:
    #     char_phase = np.abs(ampx_cav1/ECD_scale)**2 * cav1_geometrical_phase + np.abs(ampx_cav2/ECD_scale)**2 * cav2_geometrical_phase + np.abs(ampx_cav3/ECD_scale)**2 * cav3_geometrical_phase + 0.5 
    # else:
    #     char_phase = np.abs(ampx_cav1/ECD_scale)**2 * cav1_geometrical_phase + np.abs(ampx_cav2/ECD_scale)**2 * cav2_geometrical_phase + np.abs(ampx_cav3/ECD_scale)**2 * cav3_geometrical_phase + 0.75
    
    # bring qubit into superposition
    qua.align() # align all modes
    qubit.play(qubit_pi2_pulse)
    qua.align()  # wait for qubit pulse to end
    
    ECD_3modes_point(
        cav1_ge,
        cav2_ge,
        cav3_ge,
        qubit,
        cav1_displacement_pulse,
        cav2_displacement_pulse,
        cav3_displacement_pulse,
        qubit_pi_pulse,
        cav1_ratio,
        cav2_ratio,
        cav3_ratio,
        cav1_ECD_wait_time,
        cav2_ECD_wait_time,
        cav3_ECD_wait_time,
        0, #qubit phase in the middle of ECD
        ampx_cav1,
        ampx_cav2,
        ampx_cav3, #removed ECD scale
        phase_cav1 + cav1_tomo_phase,
        phase_cav2 + cav2_tomo_phase,
        phase_cav3 + cav3_tomo_phase,
        wait_between_cavities1,
        wait_between_cavities2
)
    
    # start ECD gate
    # ECD_point(
    #     cav1_ge,
    #     qubit,
    #     displacement_pulse,
    #     qubit_pi_pulse,
    #     ratio1,
    #     ECD_wait_time1,
    #     0,
    #     ampx_cav1/ECD_scale,
    #     phase_cav1 + cav1_tomo_phase,
    # )
    # qua.wait(wait_between_cavities1, cav2_ge)
    # ECD_point(
    #     cav2_ge,
    #     qubit2,
    #     displacement2_pulse,
    #     qubit2_pi_pulse,
    #     ratio2,
    #     ECD_wait_time2,
    #     0,
    #     ampx_cav2/ECD_scale,
    #     phase_cav2 + cav2_tomo_phase,
    # )
    # qua.wait(wait_between_cavities2, cav3_ge)
    # ECD_point(
    #     cav3_ge,
    #     qubit3,
    #     displacement3_pulse,
    #     qubit3_pi_pulse,
    #     ratio3,
    #     ECD_wait_time3,
    #     0,
    #     ampx_cav3/ECD_scale,
    #     phase_cav3 + cav3_tomo_phase,
    # )

    qua.align()

    qubit.play(qubit_pi2_pulse, phase=char_phase)
    qua.align(qubit, resonator)  # align measurement
    resonator.measure(readout_pulse, (I, Q), demod_type="dual")  # measure transmitted signal

    # wait system reset
    if plot_single_shot:  # assign state to G or E
        qm_qua.assign(
            single_shot,
            qm_qua.Cast.to_fixed(I > readout_pulse.threshold),
        )

    qua.wait(int(wait_time), cav1_ge)
    qua.wait(int(wait_time), cav2_ge)
    qua.wait(int(wait_time), cav3_ge)
    return None

def Char3modes_2D_singleshot(
    single_shot,
    resonator,
    readout_pulse,
    I,
    Q,
    wait_time,
    cav1_ge,
    cav2_ge,
    cav3_ge,
    qubit,
    cav1_displacement_pulse,
    cav2_displacement_pulse,
    cav3_displacement_pulse,
    qubit_pi_pulse,
    qubit_pi2_pulse,
    cav1_ECD_wait_time,
    cav2_ECD_wait_time,
    cav3_ECD_wait_time,
    measure_real,
    cav1_ratio,
    cav2_ratio,
    cav3_ratio,
    wait_between_cavities1,
    wait_between_cavities2,
    ampx_cav1,
    ampx_cav2,
    ampx_cav3,
    phase_cav1,
    phase_cav2,
    phase_cav3,
    plot_single_shot,
    cav1_geometrical_phase,
    cav2_geometrical_phase,
    cav3_geometrical_phase,
    cav1_tomo_phase,
    cav2_tomo_phase,
    cav3_tomo_phase,
):
    ECD_scale = 3
    char_phase = declare(fixed)
    cav1_phi0 = declare(fixed, value = cav1_geometrical_phase)
    cav2_phi0 = declare(fixed, value = cav2_geometrical_phase)
    #cav3_phi0 = declare(fixed, value = cav3_geometrical_phase)
    if measure_real:
        assign(char_phase, qm_qua.Math.pow(qm_qua.Math.abs(ampx_cav1),2)*cav1_phi0  + qm_qua.Math.pow(qm_qua.Math.abs(ampx_cav2),2)*cav2_phi0 + np.abs(ampx_cav3)**2*cav3_geometrical_phase+0.5)
        
    else:
        assign(char_phase, qm_qua.Math.pow(qm_qua.Math.abs(ampx_cav1),2)*cav1_phi0 + qm_qua.Math.pow(qm_qua.Math.abs(ampx_cav2),2)*cav2_phi0 + np.abs(ampx_cav3)**2*cav3_geometrical_phase+0.75)
    
    # bring qubit into superposition
    qua.align() # align all modes
    qubit.play(qubit_pi2_pulse)
    qua.align()  # wait for qubit pulse to end
    
    ECD_3modes_point(
        cav1_ge,
        cav2_ge,
        cav3_ge,
        qubit,
        cav1_displacement_pulse,
        cav2_displacement_pulse,
        cav3_displacement_pulse,
        qubit_pi_pulse,
        cav1_ratio,
        cav2_ratio,
        cav3_ratio,
        cav1_ECD_wait_time,
        cav2_ECD_wait_time,
        cav3_ECD_wait_time,
        0, #qubit phase in the middle of ECD
        ampx_cav1,
        ampx_cav2,
        ampx_cav3,
        phase_cav1 + cav1_tomo_phase,
        phase_cav2 + cav2_tomo_phase,
        phase_cav3 + cav3_tomo_phase,
        wait_between_cavities1,
        wait_between_cavities2
)
    
    # start ECD gate
    # ECD_point(
    #     cav1_ge,
    #     qubit,
    #     displacement_pulse,
    #     qubit_pi_pulse,
    #     ratio1,
    #     ECD_wait_time1,
    #     0,
    #     ampx_cav1/ECD_scale,
    #     phase_cav1 + cav1_tomo_phase,
    # )
    # qua.wait(wait_between_cavities1, cav2_ge)
    # ECD_point(
    #     cav2_ge,
    #     qubit2,
    #     displacement2_pulse,
    #     qubit2_pi_pulse,
    #     ratio2,
    #     ECD_wait_time2,
    #     0,
    #     ampx_cav2/ECD_scale,
    #     phase_cav2 + cav2_tomo_phase,
    # )
    # qua.wait(wait_between_cavities2, cav3_ge)
    # ECD_point(
    #     cav3_ge,
    #     qubit3,
    #     displacement3_pulse,
    #     qubit3_pi_pulse,
    #     ratio3,
    #     ECD_wait_time3,
    #     0,
    #     ampx_cav3/ECD_scale,
    #     phase_cav3 + cav3_tomo_phase,
    # )

    qua.align()

    qubit.play(qubit_pi2_pulse, phase=char_phase)
    qua.align(qubit, resonator)  # align measurement
    resonator.measure(readout_pulse, (I, Q), demod_type="dual")  # measure transmitted signal

    # wait system reset
    if plot_single_shot:  # assign state to G or E
        qm_qua.assign(
            single_shot,
            qm_qua.Cast.to_fixed(I > readout_pulse.threshold),
        )

    qua.wait(int(wait_time), cav1_ge)
    qua.wait(int(wait_time), cav2_ge)
    qua.wait(int(wait_time), cav3_ge)
    return None