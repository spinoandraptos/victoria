""" """
import sys

# sys.path.append("C:/Users/admin/Desktop/qcore-yabba/yabba-main/")
from config.experiment_config import FOLDER, N, FREQ, I, Q, MAG, PHASE, RRC, SINGLE_SHOT
from qcore import Experiment, qua, Sweep
from qm import qua as qm_qua

class SSqubit(Experiment):
    """Qubit spectroscopy"""

    ############################# DEFINE PRIMARY DATASETS ##############################
    # these Datasets form the "raw" experimental data and will be streamed by the OPX
    # they must be specified at experiment runtime

    primary_datasets = ["I", "Q", "single_shot"]

    ############################## DEFINE PRIMARY SWEEPS ###############################
    # these Sweeps are uniquely associated with the Experiment subclass
    # these Sweeps must be specified at experiment runtime

    primary_sweeps = ["cavity_frequency"]

    ############################ DEFINE THE PULSE SEQUENCE #############################
    # ensure that you import 'qua' from 'qcore' and not from 'qm' library
    # attributes accessed via 'self' must be defined in 'if __name__ == "__main__"' code

    def sequence(self):
        """QUA sequence that defines this Experiment subclass"""
        qua.reset_phase(self.cavityA)
        qua.reset_frame(self.cavityA)
        qua.reset_phase(self.qubit)
        qua.reset_frame(self.qubit)
        qua.reset_phase(self.cavB)
        qua.reset_frame(self.cavB)
        qua.reset_phase(self.qB)
        qua.reset_frame(self.qB)
        qua.reset_phase(self.drive)
        qua.reset_frame(self.drive)
        qua.align()


        qua.update_frequency(self.cavityA, self.cavity_frequency)
        #qua.update_frequency(self.drive, self.drive_frequency)
        qua.align()
        self.qB.play(self.qubitB_grape)
        self.cavB.play(self.cavityB_grape) 
        qua.align()

        self.cavityA.play(self.cavity_pulse)
        self.drive.play(self.drive_pulse, duration = 2000/4, ampx = self.drive_amp)
        qua.align()


        # qua.update_frequency(self.qC, -165.75e6) # Sample qC when cavB is in 1 and cavA in vacuum
        self.qubit.play(self.qubit_pulse, ampx = 1.0)
        qua.align()

        self.resonator.measure(self.readout_pulse, (self.I, self.Q), ampx=self.ro_ampx, demod_type="dual")
        if self.plot_single_shot:  # assign state to G or E
            qm_qua.assign(self.single_shot,qm_qua.Cast.to_fixed(self.I > self.readout_pulse.threshold),)
        qua.wait(self.wait_time, self.resonator)

if __name__ == "__main__":
    """ """

    #################################### MODE MAP ######################################
    # key: name of the Mode as defined by the Experiment subclass
    # value: name of the Mode as defined by the user in modes.yml

    modes = {
        "cavityA": "cavA",
        "cavB": "cavB",
        "qubit": "qA",
        "qB": "qB",
        #"qC": "qC",
        "resonator": "rrA",
        "drive": "drive",
    }

    ################################### PULSE MAP ######################################
    # key: name of the Pulse as defined by the Experiment subclass
    # value: name of the Pulse as defined by the user in modes.yml

    pulses = { 
        "qubitB_grape": "qB_grape_fock1",
        "cavityB_grape": "cavB_grape_fock1",       
        "cavity_pulse": "cavA_constant_pulse",
        #"cavityB_pulse": "cavB_ramp_pulse",
        "drive_pulse": "exchange_pulse",
        #"qB_pulse": "qB_gaussian_very_sel_pi_pulse",
        "qubit_pulse": "qA_gaussian_sel_pi_pulse",
        "readout_pulse": "rrA_readout_pulse",
    }


    ############################## CONTROL PARAMETERS ##################################

    parameters = {
        "wait_time": 5e6,
        "ro_ampx": 1,
        "plot_single_shot": True,
    }

    ######################## SWEEP (INDEPENDENT) VARIABLES #############################
    # must include an outermost averaging Sweep named "N"
    # must include all primary sweeps defined by the Experiment subclass

    # set number of repetitions for this Experiment run
    N.num = 10000

    # set the qubit frequency sweep for this Experiment run
    FREQ.name = "cavity_frequency"
    FREQ.start = -177e6
    FREQ.stop = -169e6
    FREQ.num = 41

    # FREQ2 = Sweep(
    # name="freq",
    # dtype=int,
    # units="Hz",
    # )
    
    # FREQ2.name = "drive_frequency"
    # FREQ2.start = 80e6
    # FREQ2.stop = 92e6
    # FREQ2.num= 41

    I_AMPX = Sweep(name="drive_amp", start=0.0, stop=2.0, step=0.2)

    #sweeps = [N, FREQ, FREQ2]
    
    sweeps = [N, I_AMPX, FREQ]
    ######################## DATASET (DEPENDENT) VARIABLES #############################
    # must include all primary datasets defined by the Experiment subclass

    Q.plot,MAG.plot, PHASE.plot, I.plot = False, False, False, False
    #SINGLE_SHOT.plot = False
    # PHASE.datafn_args = {"delay": 2.792e-7, "freq": RR.int_freq}
    SINGLE_SHOT.plot_args["plot_type"] = "image"
    SINGLE_SHOT.plot = True

    MAG.fitfn = "lorentzian"

    
    # PHASE.datafn_args = {"delay": 2.792e-7, "freq": RRC.int_freq}
    # SINGLE_SHOT.fitfn = "sine"

    # # PHASE.plot = False
    # Q.plot= True
    
    # I.plot, MAG.plot = True, False
    # SINGLE_SHOT.plot = True

    #datasets = [I, Q, MAG, PHASE]

    datasets = [I, Q, SINGLE_SHOT]

    ######################## INITIALIZE AND RUN EXPERIMENT #############################

    expt = SSqubit(FOLDER, modes, pulses, sweeps, datasets, **parameters)
    expt.run()
