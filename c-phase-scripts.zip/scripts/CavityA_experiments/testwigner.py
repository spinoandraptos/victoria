import shutil
import os
from datetime import datetime
from config.experiment_config import FOLDER, N, FREQ, I, Q, MAG, PHASE, RRB, SINGLE_SHOT
from qcore import Experiment, qua, Sweep
from qm import qua as qm_qua
from qcore.libs.qua_macros import QuaVariable





current_script_path = os.path.realpath(__file__) # Get the path to the current script
script_name = os.path.basename(current_script_path)[:-3] # Get filename only (e.g., 'my_script.py')
datafolder = FOLDER + "data/"
print(datafolder)
date, time = datetime.now().strftime("%Y-%m-%d %H-%M-%S").split()
folderpath = datafolder + str(date) + '/'
print(folderpath)
print(script_name)
print(time)
destination_path = os.path.join(folderpath, f"{script_name}_screenhsot_{time}.py") # Define destination path
shutil.copy(current_script_path, destination_path) # Copy the script

