""" """
import sys
from config.experiment_config import FOLDER, N, FREQ, I, Q, MAG, PHASE, RRC, SINGLE_SHOT
from qcore import Experiment, qua, Sweep
from qm import qua as qm_qua
from qcore.libs.qua_macros import QuaVariable
from qcore import Dataset


class DisplacementCal(Experiment):
    """Cavity spectroscopy"""

    ############################# DEFINE PRIMARY DATASETS ##############################
    # these Datasets form the "raw" experimental data and will be streamed by the OPX
    # they must be specified at experiment runtime
    primary_datasets = ["I", "Q", "single_shot"]

    ############################## DEFINE PRIMARY SWEEPS ###############################
    # these Sweeps are uniquely associated with the Experiment subclass
    # these Sweeps must be specified at experiment runtime
    primary_sweeps = ["cavity_drive_amplitude"]

    ############################ DEFINE THE PULSE SEQUENCE #############################
    # ensure that you import 'qua' from 'qcore' and not from 'qm' library
    # attributes accessed via 'self' must be defined in 'if __name__ == "__main__"' code
    def sequence(self):
        """QUA sequence that defines this Experiment subclass"""
        # qua.reset_frame(self.cavity)

        self.cavity.play(self.cavity_drive, ampx=self.cavity_drive_amplitude)  # play displacement to cavity
        self.cavity.play(self.cavity_drive, ampx=self.cavity_drive_amplitude, phase = self.phase_sweep)  # play displacement to cavity
        # self.cavity.play(self.cavity_drive, ampx=self.cavity_drive_amplitude)  # play displacement to cavity
        # self.cavity.play(self.cavity_drive, ampx=self.cavity_drive_amplitude)  # play displacement to cavity

        qua.align(self.cavity, self.qubit)  # align all modes
        self.qubit.play(self.qubit_drive)  # play qubit pulse

        qua.align(self.qubit, self.resonator)  # align all modes
        self.resonator.measure(self.readout_pulse, (self.I, self.Q), ampx=self.ro_ampx, demod_type="dual")

        qua.wait(self.wait_time, self.resonator)
        if self.plot_single_shot:  # assign state to G or E
            qm_qua.assign(self.single_shot,qm_qua.Cast.to_fixed(self.I > self.readout_pulse.threshold),)

if __name__ == "__main__":
    """ """

    #################################### MODE MAP ######################################
    # key: name of the Mode as defined by the Experiment subclass
    # value: name of the Mode as defined by the user in modes.yml
    modes = {
        "cavity": "cavB",
        "qubit": "qC",
        "resonator": "rrC",
    }

    ################################### PULSE MAP ######################################
    # key: name of the Pulse as defined by the Experiment subclass
    # value: name of the Pulse as defined by the user in modes.yml
    pulses = {
        "cavity_drive": "cavB_ramp_pulse",
        "qubit_drive": "qC_gaussian_very_sel_pi_pulse",
        "readout_pulse": "rrC_readout_pulse",
    }

    ############################## CONTROL PARAMETERS ##################################
    parameters = {
        "wait_time": 10e6,
        "ro_ampx": 1,
        "plot_single_shot": True,
    }

    ######################## SWEEP (INDEPENDENT) VARIABLES #############################
    # must include an outermost averaging Sweep named "N"
    # must include all primary sweeps defined by the Experiment subclass

    # set number of repetitions for this Experiment run
    N.num = 2000
    QD_AMPX = Sweep(name="cavity_drive_amplitude", start=0.01, stop=1.8, num=100)
    PHASE = Sweep(name="phase_sweep", start=0.0, stop=1.0, num=10)
    sweeps = [N, PHASE, QD_AMPX]

    ######################## DATASET (DEPENDENT) VARIABLES #############################
    # must include all primary datasets defined by the Experiment subclass
    # I.fitfn = "displacement_cal"
    # Q.fitfn = "displacement_cal"
    SINGLE_SHOT.fitfn = "displacement_cal"
    SINGLE_SHOT.plot_args["plot_type"] = "image"
    PHASE.datafn_args = {"delay": 2.792e-7, "freq": RRC.int_freq}
    I.plot, Q.plot, MAG.plot = False, False, False
    datasets = [I, Q, SINGLE_SHOT]

    ######################## INITIALIZE AND RUN EXPERIMENT #############################
    expt = DisplacementCal(FOLDER, modes, pulses, sweeps, datasets, **parameters)
    expt.run()
