""" """

import sys

sys.path.append("C:/Users/admin/Desktop/qcore-yabba/yabba-main/")
from config.experiment_config import FOLDER, N, FREQ, I, Q, MAG, PHASE, RRA, SINGLE_SHOT
from qm import qua as qm_qua
from qcore import Experiment, qua, Sweep


class Sideband(Experiment):
    """Number splitting"""

    ############################# DEFINE PRIMARY DATASETS ##############################
    # these Datasets form the "raw" experimental data and will be streamed by the OPX
    # they must be specified at experiment runtime

    primary_datasets = ["I", "Q", "single_shot"]

    ############################## DEFINE PRIMARY SWEEPS ###############################
    # these Sweeps are uniquely associated with the Experiment subclass
    # these Sweeps must be specified at experiment runtime

    primary_sweeps = ["drive_frequency"]

    ############################ DEFINE THE PULSE SEQUENCE #############################
    # ensure that you import 'qua' from 'qcore' and not from 'qm' library
    # attributes accessed via 'self' must be defined in 'if __name__ == "__main__"' code

    def sequence(self):
        """QUA sequence that defines this Experiment subclass"""
        # Generate state in the cavity
        # qua.update_frequency(self.qubit, self.qubit.int_freq)
        # self.qubitGF.play(self.qubit_drive)
        # qua.align()
        # self.drive.play(self.drive_pulse)
        # qua.align()

        self.qubitGF.play(self.qubit_drive)
        qua.align()
        qua.update_frequency(self.drive, self.drive_frequency)
        self.drive.play(self.drive_pulse)
        qua.align()
        # Measurement
        self.resonator.measure(self.readout_pulse, (self.I, self.Q), ampx=self.ro_ampx, demod_type="dual")
        qua.wait(self.wait_time, self.resonator)
        if self.plot_single_shot:  # assign state to G or E
            qm_qua.assign(
                self.single_shot,
                qm_qua.Cast.to_fixed(self.I > self.readout_pulse.threshold),
            )


if __name__ == "__main__":
    """ """

    #################################### MODE MAP ######################################
    # key: name of the Mode as defined by the Experiment subclass
    # value: name of the Mode as defined by the user in modes.yml

    modes = {"qubitGF": "qA_GF",
            "drive": "driveA",
            "resonator": "rrA",
            }

    ################################### PULSE MAP ######################################
    # key: name of the Pulse as defined by the Experiment subclass
    # value: name of the Pulse as defined by the user in modes.yml

    pulses = {
        "qubit_drive": "qA_GF_gaussian_pi_pulse",
        "drive_pulse": "fock_pulse",
        "readout_pulse": "rrA_readout_pulse",
    }
                                       
    ############################## CONTROL PARAMETERS ##################################
    parameters = {
        "wait_time": 5e6,
        "ro_ampx": 1,
        "plot_single_shot": True,
    }

    ######################## SWEEP (INDEPENDENT) VARIABLES #############################
    # must include an outermost averaging Sweep named "N"
    # must include all primary sweeps defined by the Experiment subclass

    # set number of repetitions for this Experiment run
    N.num = 5000

    # set the qubit frequency sweep for this Experiment run
    FREQ.name = "drive_frequency"
    FREQ.start = -100e6
    FREQ.stop = -10e6
    FREQ.num = 201

    # QD_AMPX = Sweep(name="qubit_drive_ampx", points=[0.0, 1.0])

    sweeps = [N, FREQ]
    # sweeps = [N, QD_AMPX, FREQ]

    ######################## DATASET (DEPENDENT) VARIABLES #############################
    # must include all primary datasets defined by the Experiment subclass

    PHASE.datafn_args = {"delay": 2.792e-7, "freq": RRA.int_freq}
    Q.plot, PHASE.plot, MAG.plot = False, False, False
    datasets = [I, Q, SINGLE_SHOT]
    SINGLE_SHOT.fitfn = 'gaussian'
    SINGLE_SHOT.plot_args = {"plot_err": False}

    ######################## INITIALIZE AND RUN EXPERIMENT #############################

    expt = Sideband(FOLDER, modes, pulses, sweeps, datasets, **parameters)
    expt.run()
