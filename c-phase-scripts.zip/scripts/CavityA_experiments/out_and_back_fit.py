import numpy as np
import os
import h5py
import matplotlib.pyplot as plt
from scipy.optimize import curve_fit
from scipy.stats import linregress
from scipy import optimize

### Load by default the latest script in the latest folder!

import glob
from datetime import datetime


# Get latest file to not have to manually go into the folder and get it.
def get_latest_file(base_dir, file_suffix):
    # Get the list of all directories in the base directory
    all_dirs = [
        d for d in os.listdir(base_dir) if os.path.isdir(os.path.join(base_dir, d))
    ]

    # Filter directories to only those that match the YYYY-MM-DD format
    valid_dirs = []
    for d in all_dirs:
        try:
            datetime.strptime(d, "%Y-%m-%d")
            valid_dirs.append(d)
        except ValueError:
            # Skip directories that do not match the format
            continue

    if not valid_dirs:
        raise FileNotFoundError("No valid directories found in base directory")

    # Sort valid directories by date in reverse order
    latest_dir = max(valid_dirs, key=lambda d: datetime.strptime(d, "%Y-%m-%d"))

    # Get the path of the latest directory
    latest_dir_path = os.path.join(base_dir, latest_dir)

    # Get the list of all .hdf5 files in the latest directory with the specific suffix
    pattern = os.path.join(latest_dir_path, f"*{file_suffix}")
    all_files = glob.glob(pattern)

    if not all_files:
        raise FileNotFoundError(
            f"No files ending with {file_suffix} found in the latest directory"
        )

    # Sort files by modification time in reverse order
    latest_file = max(all_files, key=os.path.getmtime)

    return latest_file


# Define the base directory and file suffix
base_dir = r"C:\Users\admin\Desktop\cphase\data"

# file_suffix = "OutAndBackChi.hdf5"
file_suffix = "OutAndBackChi.hdf5"

# Get the latest file
latest_file = get_latest_file(base_dir, file_suffix)


# filepath = (
#     r"C:\Users\qcrew\Documents\jon\cheddar\data\2024-07-22\19-27-30_OutAndBackChi.hdf5"
# )

# READ DATA
data = h5py.File(latest_file, "r")
disp_phase = np.array(data["disp_phase"])[::-1] * 2 * np.pi
time_delays = np.array(data["time_delay"])[1:] / 1000  # us
# minus sign depending on data. We are fitting peaks.
flipped_state =  -np.average(np.array(data["single_shot"]), axis=0)
probs = flipped_state[::-1, 1:]
 

## Directly plot Data
# plt.plot(disp_phase, flipped_state[:,20])
# plt.show()


# FIT GAUSSIAN FOR EACH TIME AND EXTRACT MAX
def gaussian(x, amplitude, x0, stddev):
    return amplitude * np.exp(-(((x - x0) / stddev) ** 2) / 2)


max_positions = []
max_times = []
fitted_curves = []

for i, time in enumerate(time_delays):
    slice_data = probs[:, i]

    y = disp_phase
    I_max = np.max(slice_data)
    I_min = np.min(slice_data)
    phase_max = disp_phase[np.argmax(slice_data)]
    stddev_guess = (I_max - I_min) / 4
    try:
        popt, _ = optimize.curve_fit(
            gaussian, y, I_max, p0=[I_max, phase_max, stddev_guess]
        )
        max_positions.append(popt[1])
        max_times.append(time)

        fitted_curve = gaussian(y, *popt)
        fitted_curves.append(fitted_curve)

    except RuntimeError:
        continue

## PLOTTING
plt.figure(figsize=(10, 6))

for i in range(len(max_positions)):
    plt.plot(disp_phase, fitted_curves[i], linestyle="--", color="orange", alpha=0.5)
plt.xlabel("Time Delay (us)")
plt.ylabel("Dispersion Phase")
plt.title("Fitted Gaussian Curves")
plt.tight_layout()
plt.show()
start = 0
end = 1

## CUT SOME DATA OUT IF NECESSARY
max_positions = max_positions[start:-end]
max_times = max_times[start:-end]

# # # LINEAR REGRESSION OF THOSE MAXIMUMS
slope, intercept, r_value, p_value, std_err = linregress(max_times, max_positions)

# print(intercept)
# # # PLOTTING

X, Y = np.meshgrid(time_delays, disp_phase)
plt.pcolormesh(X, Y, probs, cmap="viridis")
plt.colorbar(label="Value")
plt.scatter(max_times, max_positions, c="r")
plt.plot(
    time_delays[:],
    slope * time_delays[:] + intercept,
    color="blue",
    label=f"Linear Regression: y = {slope:.2f}x + {intercept:.2f}",
)

plt.show()
print("slope (rads/us):", slope)
print("slope (kHz):", slope / (2 * np.pi) * 1000)
print("intercept (rads):", intercept)
print("std_err:", std_err)
