import sys
sys.path.append("C:/Users/admin/Desktop/cphase/scripts")
from config.experiment_config import FOLDER, N, I, Q, MAG, PHASE, RRB, FREQ, SINGLE_SHOT
from qcore import Experiment, qua, Sweep
from ECD_routines import Char2D
from hamiltonian_params import *


class CharFunc2D(Experiment):
    """ECD Calibration"""

    ############################# DEFINE PRIMARY DATASETS ##############################
    # these Datasets form the "raw" experimental data and will be streamed by the OPX
    # they must be specified at experiment runtime

    primary_datasets = ["I", "Q", "single_shot"]

    ############################## DEFINE PRIMARY SWEEPS ###############################
    # these Sweeps are uniquely associated with the Experiment subclass
    # these Sweeps must be specified at experiment runtime

    primary_sweeps = ["x_displace"]

    ############################ DEFINE THE PULSE SEQUENCE #############################
    # ensure that you import 'qua' from 'qcore' and not from 'qm' library
    # attributes accessed via 'self' must be defined in 'if __name__ == "__main__"' code

    def sequence(self):
        """QUA sequence that defines this Experiment subclass"""

        # Please check which cavity mode is used
        qua.reset_phase(self.cav_g)
        qua.reset_phase(self.qubit)

        qua.reset_frame(self.cav_ge)
        qua.reset_frame(self.qubit)

        # create state
        # qua.update_frequency(self.cav, self.cav_g_frame)
        # qua.update_frequency(self.cav, self.cavity_ge_frame, keep_phase=True)
        self.cav_g.play(self.cav_state_creation, phase=0.0)
        #qua.wait(self.time_delay, self.cav_g)
        # measure char func
        # qua.update_frequency(self.cav_ge, self.cavity_ge_frame, keep_phase=True)
        # measure char func
        Char2D(
            self.single_shot,
            self.resonator,
            self.readout_pulse,
            self.I,
            self.Q,
            self.wait_time,
            self.cav_ge,
            self.qubit,
            self.ecd_drive,
            self.qubit_pi_pulse,
            self.qubit_pi2_pulse,
            self.x_displace,
            self.y_displace,
            self.ratios,
            self.ecd_wait_time,
            self.measure_real,
            self.tomo_phase,
            self.plot_single_shot,
        )


# -------------------------------- Execution -----------------------------------

if __name__ == "__main__":
    """ """

    #################################### MODE MAP ######################################
    # key: name of the Mode as defined by the Experiment subclass
    # value: name of the Mode as defined by the user in modes.yml

    modes = {
        "qubit": "qB",
        "cav_g": "cavB",
        "cav_ge": "cavB_ge",
        "resonator": "rrB",
    }

    ################################### PULSE MAP ######################################
    # key: name of the Pulse as defined by the Experiment subclass
    # value: name of the Pulse as defined by the user in modes.yml

    pulses = {
        "qubit_pi2_pulse": "qB_gaussian_pi2_pulse",
        "qubit_pi_pulse": "qB_gaussian_pi_pulse",
        "cav_state_creation": "cavB_gaussian_pulse",
        "ecd_drive": "cavB_ge_ECD3_coh3",
        "readout_pulse": "rrB_readout_pulse",
    }

    ############################## CONTROL PARAMETERS ##################################
    Cavity = Bob
    parameters = {
        "wait_time": 7_000_000,
        "ro_ampx": 1,
        "plot_single_shot": True,
        # "time_delay": 16,  # 8000,
        "ecd_wait_time": Cavity["ecd_wait_time_optimized"],  # 700,
        "measure_real": False,
        "tomo_phase": 0,  # 0.317,
        "fetch_period": 3,
        # "keep_phase": 0,#Cavity["chi"] / (2 * np.pi) * (8000 + 10 * 4) / 2,
        "keep_phase": 0,
        # "cavity_g_frame": frequencies["charlie_IF"],
        # "qubit_ge_freq": Qubit["ge_freq"],
        # "cavity_ge_frame": frequencies["charlie_ge_IF"],
        "ratios": Cavity["ratios_optimized"],
    }

    ######################## SWEEP (INDEPENDENT) VARIABLES #############################
    # must include an outermost averaging Sweep named "N"
    # must include all primary sweeps defined by the Experiment subclass

    # set number of repetitions for this Experiment run
    N.num = 800

    # set the cav amplitude sweep for this Experiment run
    x_displace = Sweep(name="x_displace", start=-1.1, stop=1.1, num=24)
    y_displace = Sweep(name="y_displace", start=-1.1, stop=1.1, num=24)
    sweeps = [N, y_displace, x_displace]

    ######################## DATASET (DEPENDENT) VARIABLES #############################
    # must include all primary datasets defined by the Experiment subclass

    # MAG.axes = sweeps[1:]
    # PHASE.axes = sweeps[1:]
    PHASE.datafn_args = {"delay": 2.792e-7, "freq": RRB.int_freq}
    PHASE.plot = False
    MAG.plot = False
    Q.plot = False
    I.plot= False
    SINGLE_SHOT.plot_args["plot_type"] = "image"
    # datasets = [I, Q, SINGLE_SHOT, PRESELECT]
    datasets = [I, Q, SINGLE_SHOT]
    #SINGLE_SHOT.plot_args["plot_type"] = "image"

    ######################## INITIALIZE AND RUN EXPERIMENT #############################

    expt = CharFunc2D(FOLDER, modes, pulses, sweeps, datasets, **parameters)
    expt.run(simulate=False)