""" """
from config.experiment_config import FOLDER, N, FREQ, I, Q, MAG, PHASE, RRA, SINGLE_SHOT
from qcore import Experiment, qua, Sweep
from qm import qua as qm_qua
from qcore.libs.qua_macros import QuaVariable

class WignerA2D(Experiment):
    """Wigner_function"""

    ############################# DEFINE PRIMARY DATASETS ##############################
    primary_datasets = ["I", "Q", "single_shot"]

    ############################## DEFINE PRIMARY SWEEPS ###############################
    primary_sweeps = ["cavity_drive_I"]

    ############################ DEFINE THE PULSE SEQUENCE #############################
    def sequence(self):
        factor = qm_qua.declare(qm_qua.fixed)
        qm_qua.assign(factor, self.detuning * 1e-9)  # formerly with a 4*

        qua.reset_frame(self.cavityB)
        qua.reset_frame(self.cavityA)
        qua.reset_frame(self.qubitB)
        qua.reset_frame(self.qubitA)
        qua.align()

        qm_qua.assign(self.phase, qm_qua.Cast.mul_fixed_by_int(factor, self.drive_length))
        new_phase = qm_qua.declare(qm_qua.fixed)
        qm_qua.assign(new_phase, self.ramp_phase * self.gate_num + self.gate_num * self.phase + 0.25 - 0.222)

        qua.update_frequency(self.drive, 334e6)
        qua.align()
        #qua.update_frequency(self.qubitB, self.qubitB.int_freq) 


        # #load fock 1 in cavity A
        self.cavityA.play(self.cavityA_grape)
        self.qubitA.play(self.qubitA_grape)
        # self.cavityB.play(self.cavityB_grape)
        # self.qubitB.play(self.qubitB_grape)
        qua.align()

        self.qubitA.play(self.qubit_op)  # play pi/2 pulse around X
        qua.wait(int(self.time_delay), self.qubitA)  # conditional phase gate on even, odd Fock state
        self.qubitA.play(self.qubit_op, phase = 0.5)  # play pi/2 pulse around X
        qua.align(self.qubitA,self.resonator)
        self.resonator.measure(self.readout_pulse, (self.I, self.Q),  demod_type="dual")
        qua.wait(1500, self.resonator)

        ## SNAP
        # self.cavityA.play(self.cavA_op, ampx = 0.56)
        # qua.align(self.cavityA, self.qubitA)
        # self.qubitA.play(self.qubit_sel_pulse, phase = 0)
        # self.qubitA.play(self.qubit_sel_pulse, phase = 0.5)
        # qua.align(self.cavityA, self.qubitA)
        # self.cavityA.play(self.cavA_op, ampx = -0.24)
        # qua.align()

        # qm_qua.assign(self.phase, qm_qua.Cast.mul_fixed_by_int(factor, 5_000))
        # qm_qua.assign(new_phase, self.phase + 0.25)
        for i in range (0, self.gate_num, 1):
            self.drive.play(self.drive_pulse)

        qua.align() 

        # WIGNER
        self.cavityA.play(self.cavA_op, ampx = (self.cavity_drive_I, -self.cavity_drive_Q, self.cavity_drive_Q, self.cavity_drive_I), phase = new_phase)  # displacement
        qua.align()
        self.qubitA.play(self.qubit_op)  # play pi/2 pulse around X
        qua.wait(int(self.time_delay), self.qubitA)  # conditional phase gate on even, odd Fock state
        self.qubitA.play(self.qubit_op)  # play pi/2 pulse around X
        qua.align(self.qubitA,self.qubitEF)
        self.qubitEF.play(self.qubitEF_pi)  # play selective qubit pulse
        qua.align(self.qubitA, self.resonator)
        self.resonator.measure(self.readout_pulse, (self.I, self.Q), demod_type="dual")
        
        qua.wait(self.wait_time)
        qua.align()
        if self.plot_single_shot:  # assign state to G or E
            qm_qua.assign(self.single_shot, qm_qua.Cast.to_fixed(self.I > self.readout_pulse.threshold),)

if __name__ == "__main__":
    """ """

    #################################### MODE MAP ######################################
    modes = {
       # "qC": "qC",
        "qubitEF": "qA_EF",
        "cavityA": "cavA",
        "cavityB": "cavB",
        "drive":"drive",
        "qubitA": "qA",
        "qubitB": "qB",
        "resonator": "rrA",
        #"resonatorB": "rrB",
    }

    ################################### PULSE MAP ######################################
    pulses = {
        "qubitEF_pi": "qAEF_EF_gaussian_pi_pulse",
        "drive_pulse": "very_good_pulse_4000",
        "qubitA_grape": "qA_grape_fock02",
        "cavityA_grape": "cavA_grape_fock02",
        "qubitB_grape": "qB_grape_fock2",
        "cavityB_grape": "cavB_grape_fock2",
        "cavA_op": "cavA_ramp_pulse",
        "qubit_sel_pulse": "qA_gaussian_very_sel_pi_pulse",
        "qubit_op": "qA_gaussian_pi2_pulse",
        "readout_pulse": "rrA_GF_CLEAR_readout_pulse", 
        #"readout_pulseB": "rrB_CLEAR_readout_pulse",
        # "drive_pulse": "exchange_pulse",
    }

    ############################## CONTROL PARAMETERS ##################################
    parameters = {
        "ramp_phase": -0.138/2-0.016/2,
        "detuning":-1529e3/2, 
        "phase": QuaVariable(value=0.0, dtype=qm_qua.fixed, tag="phase", buffer=True, stream=True),
        "wait_time": 6e6,
        "ro_ampx": 1,
        "time_delay": 520, #632
        "plot_single_shot": True,
        "qubit_drive_ampx": 1.0,
        "drive_length": 1940, 
        "gate_num": 0,
    }

    ######################## SWEEP (INDEPENDENT) VARIABLES #############################
    N.num = 20000

    QD_AMPX_I = Sweep(name="cavity_drive_I", start=-1.8, stop=1.8, step=0.2)
    QD_AMPX_Q = Sweep(name="cavity_drive_Q", start=-1.8, stop=1.8, step=0.2)
    
    # LENGTH = Sweep (name="drive_length", dtype=int, units = "ns")
    # LENGTH.start = 1000
    # LENGTH.stop = 11000
    # LENGTH.step = 2000

    #sweeps = [N, QD_AMPX_Q, QD_AMPX_I, LENGTH]
    sweeps = [N, QD_AMPX_Q, QD_AMPX_I]

    ######################## DATASET (DEPENDENT) VARIABLES #############################
    I.fitfn = "gaussian"
    PHASE.datafn_args = {"delay": 2.792e-7, "freq": RRA.int_freq}
    I.plot, Q.plot, MAG.plot = False, False, False
    SINGLE_SHOT.plot_args["plot_type"] = "image"
    # I.plot_args["plot_type"] = "image"

    datasets = [I, Q, SINGLE_SHOT]

    ######################## INITIALIZE AND RUN EXPERIMENT #############################
    expt = WignerA2D(FOLDER, modes, pulses, sweeps, datasets, **parameters)
    expt.run()




