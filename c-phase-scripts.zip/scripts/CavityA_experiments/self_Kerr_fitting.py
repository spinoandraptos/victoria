import numpy as np
import h5py
import matplotlib.pyplot as plt
from scipy import optimize
from numpy import pi

#unit is us and MHz
filepath = r"C:\Users\admin\Desktop\cphase\data\2025-10-23\16-37-30_SelfKerr.hdf5"
data = h5py.File(filepath, "r")
probs = np.average(np.array(data["single_shot"]), axis = 0)
print(np.shape(probs))
times = np.array(data["time_delay"]) /1000 # in us
alphalist = np.array(data["cavity_pulse_amplitude"])
omega = 2*np.pi * 5 # unit is MHz

class fit_selfKerr(object):
    def __init__(self, alpha, omega, scaling_flag = True):
        self.alpha = alpha
        self.omega = omega
        self.scaling_flag = scaling_flag
    
    def probabilities(self, t, fre, offset, scaling, t0):
        alpha = self.alpha
        omega = self.omega
        n = alpha**2
        if self.scaling_flag == True:
            return offset + scaling*np.exp(-2*n*(1-np.cos((omega + fre)*(t-t0))))
        else:
            return np.exp(-2*n*(1-np.cos((omega + fre)*(t-t0))))
    
    def fit_curve(self, xData, yData):
        fre_0 = 2*np.pi * 400e-3 / 2 # Guess of |alpha|^2 * K/2
        offset_0 = 0
        scaling_0 = 1
        t0_0 = 0
        guess = [fre_0, offset_0, scaling_0, t0_0]
        fre_fitted, offset_fitted, scaling_fitted, t0_fitted= optimize.curve_fit(self.probabilities, xData, yData, p0=guess)[0]
        
        xfit = np.linspace(np.min(xData), np.max(xData), len(xData))
        yfit = self.probabilities(xfit, fre_fitted, offset_fitted, scaling_fitted, t0_fitted)
        return [[fre_fitted, offset_fitted, scaling_fitted, t0_fitted], [xfit, yfit]]
 
colorlist = ['r', 'b', 'g', 'r', 'r', 'r', 'r', 'r']
fre_list = []

plt.figure()
for i, alpha in enumerate(alphalist):
    xData = times
    yData = probs[i,:]
    
    fit = fit_selfKerr(alpha = alpha, omega = omega, scaling_flag = True)
    fit_data = fit.fit_curve(xData, yData)
    fre_list.append(fit_data[0][0]/(2*np.pi))
    
    plt.scatter(xData, yData + i, c = 'r', s =10, label=r'$\alpha$ = {}'.format(alpha))
    plt.plot(fit_data[1][0], fit_data[1][1] + i, c = 'k')
    plt.xlabel(r'Time ($\mu$s)')
    plt.ylabel(r'Pe + i')
    plt.legend()
plt.show()

print(fre_list)

fre_list = np.array(fre_list)

# plt.figure()
# plt.scatter(alphalist**2, fre_list*1000) # in kHz
# # plt.scatter((alphalist**2)[[0, -1]], (fre_list*1000)[[0, -1]], s = 20, label = 'removed points for fitting')
# plt.xlabel(r'$\bar{n}$')
# plt.ylabel(r'Frequency (kHz)')
# # plt.legend()
# plt.show()

nbars = (alphalist**2)[6::]
selfKerrs = (fre_list)[6::]
linearfit = np.polyfit(nbars, selfKerrs, deg = 1)
yfitf_f = np.poly1d(linearfit)
xfit = np.linspace(0, 4, 11)


plt.figure()
plt.scatter(nbars, selfKerrs, s = 20)
plt.plot(xfit, yfitf_f(xfit), c = 'k')
plt.xlabel(r'$\bar{n}$')
plt.ylabel(r'Frequency (kHz)')
plt.text(1, 1, 'slope = {} \n offset = {}'.format(linearfit[0], linearfit[1]))
plt.show()

print("Detuning = ", linearfit[1]/(2*np.pi) * 1000, "kHz")

print("Self-Kerr (K) = ", 2*linearfit[0]/(2*np.pi) * 1000, "kHz")
print(nbars)
