""" """
import sys

from config.experiment_config import FOLDER, N, FREQ, I, Q, MAG, PHASE, RRB, SINGLE_SHOT
from qcore import Experiment, qua, Sweep
from qm import qua as qm_qua
from qcore.libs.qua_macros import QuaVariable

class Wigner1D(Experiment):
    """Wigner_function"""

    ############################# DEFINE PRIMARY DATASETS ##############################
    # these Datasets form the "raw" experimental data and will be streamed by the OPX
    # they must be specified at experiment runtime
    primary_datasets = ["I", "Q", "single_shot"]

    ############################## DEFINE PRIMARY SWEEPS ###############################
    # these Sweeps are uniquely associated with the Experiment subclass
    # these Sweeps must be specified at experiment runtime
    primary_sweeps = ["cavity_drive_amplitude"]

    ############################ DEFINE THE PULSE SEQUENCE #############################
    # ensure that you import 'qua' from 'qcore' and not from 'qm' library
    # attributes accessed via 'self' must be defined in 'if __name__ == "__main__"' code
    def sequence(self):
        """QUA sequence that defines this Experiment subclass"""
        
        qua.reset_frame(self.cavity)   
        qua.reset_phase(self.cavity)
        qua.reset_phase(self.qubit)
        qua.reset_frame(self.qubit)

        qua.update_frequency(self.qubit, self.qubit.int_freq) 

        factor = qm_qua.declare(qm_qua.fixed)
        phase2 = qm_qua.declare(qm_qua.fixed)

        # phase = qm_qua.declare(float)
        qm_qua.assign(factor, self.detuning * 1e-9)  # formerly with a 4*
        # qua.initialize_cavity_AND_qubit(
        #     rr=self.resonator,
        #     qubit = self.qubit, 
        #     readout_pulse=self.readout_pulse,
        #     qubit_pulse = self.qubit_drive,
        #     demod_type="dual",
        #     threshold_g=self.readout_pulse.threshold,
        #     ro_ampx=self.ro_ampx,
        #     wait_time=2_000,
        #     n_consecutive=3
        # )

        # PREPARE STATE
        # self.cavity.play(self.cav_op, phase = 0.0)
        # Prepare 1 in A
        self.qubitB.play(self.qubitB_grape)
        self.cavityB.play(self.cavityB_grape) 
        self.cavity.play(self.cavity_grape)
        self.qubit.play(self.qubit_grape)
        qua.align()

        qm_qua.assign(self.phase, qm_qua.Cast.mul_fixed_by_int(factor, 4100))
        new_phase = qm_qua.declare(qm_qua.fixed)
        qm_qua.assign(new_phase, self.phase + 0.25)
        qua.update_frequency(self.drive, 345e6 - 5e6)

        
        self.drive.play(self.drive_pulse,ampx = 1.0, duration = 4100/4)
        #qua.wait(4000, self.cavityA)  # wait for state to rotate
        qua.align() 


        # self.cavity.play(self.cavity_pulse, ampx= 1.14)  # displace by beta = 1.14
        # qua.align()
        # self.qubit.play(self.qubit_pulse, ampx = 2.0)    # SNAP: play pi pulse around X
        # qua.align()  # align pulses
        # self.cavity.play(self.cavity_pulse, ampx=-0.58)  # displace by beta = -0.58



        # MEASURE WIGNER
        self.cavity.play(self.cav_op, ampx=self.cavity_drive_amplitude, phase = new_phase)  # displacement in I direction
        qua.align()
        self.qubit.play(self.qubit_op)  # play pi/2 pulse around X
        qua.wait(self.time_delay, self.qubit)  # conditional phase gate on even, odd Fock state
        self.qubit.play(self.qubit_op, phase = 0.0)  # play pi/2 pulse around X
        qua.align(self.qubit, self.qubitEF)
        self.qubitEF.play(self.qubitEF_pi)
        qua.align()  # align measurement

        # Measure cavity state
        self.resonator.measure(self.readout_pulse, (self.I, self.Q), ampx=self.ro_ampx, demod_type= 'dual')  # measure transmitted signal
        if self.plot_single_shot:  # assign state to G or E
            qm_qua.assign(self.single_shot,qm_qua.Cast.to_fixed(self.I > self.readout_pulse.threshold),)
        qua.wait(self.wait_time, self.resonator)

if __name__ == "__main__":
    """ """

    #################################### MODE MAP ######################################
    # key: name of the Mode as defined by the Experiment subclass
    # value: name of the Mode as defined by the user in modes.yml
    modes = {
       # "qC": "qC",
        "qubitEF": "qA_EF",
        "cavity": "cavA",
        "cavityB": "cavB",
        "drive":"drive",
        "qubit": "qA",
        "qubitB": "qB",
        "resonator": "rrA",
        #"resonatorB": "rrB",
    }

    ################################### PULSE MAP ######################################
    # key: name of the Pulse as defined by the Experiment subclass
    # value: name of the Pulse as defined by the user in modes.yml
    pulses = {
        "qubitB_grape": "qB_grape_fock01_new",
        "cavityB_grape": "cavB_grape_fock01_new",
        "qubitEF_pi": "qAEF_EF_gaussian_pi_pulse",
        "qubit_grape": "qA_grape_fock01",
        "cavity_grape": "cavA_grape_fock01",
        "cav_op": "cavA_ramp_pulse",
        #"qubit_sel_pulse": "qB_gaussian_sel_pi_pulse",
        "qubit_op": "qA_gaussian_pi2_pulse",
        "readout_pulse": "rrA_GF_CLEAR_readout_pulse", 
        #"readout_pulseB": "rrB_CLEAR_readout_pulse",
        "drive_pulse": "exchange_pulse_ramp",
    }


    ############################## CONTROL PARAMETERS ##################################
    parameters = {
        "detuning": -735e3 - 2.9e3 + 0.2e3 - 99e3 - 2.6e3, #0.21e5,#-0.38e6 + 0.023e6,
        "phase": QuaVariable(value=0.0, dtype=qm_qua.fixed, tag="phase", buffer=True, stream=True),
        "wait_time": 6e6,
        "ro_ampx": 1,
        "time_delay": 520, # 620,
        "plot_single_shot": True,
        "qubit_drive_ampx": 1.0,
    }

    ######################## SWEEP (INDEPENDENT) VARIABLES #############################
    # must include an outermost averaging Sweep named "N"
    # must include all primary sweeps defined by the Experiment subclass

    # set number of repetitions for this Experiment run
    N.num = 2000
    QD_AMPX = Sweep(name="cavity_drive_amplitude", start=-2.0, stop=2.0, step=0.05)
    PHASE = Sweep(name="qb_phase", start=0, stop=0.5, step=0.5)
    #RIVE_AMP = Sweep(name="drive_amp", start=0, stop=2.0, step=2.0)
    sweeps = [N, QD_AMPX]

    ######################## DATASET (DEPENDENT) VARIABLES #############################
    # must include all primary datasets defined by the Experiment subclass
    # I.fitfn = "gaussian"
    PHASE.datafn_args = {"delay": 2.792e-7, "freq": RRB.int_freq}
    I.plot, Q.plot, MAG.plot, PHASE.plot = False, False, False, False
    SINGLE_SHOT.fitfn = 'gaussian'
    datasets = [I, Q, SINGLE_SHOT]
    ######################## INITIALIZE AND RUN EXPERIMENT #############################
    expt = Wigner1D(FOLDER, modes, pulses, sweeps, datasets, **parameters)
    expt.run()
