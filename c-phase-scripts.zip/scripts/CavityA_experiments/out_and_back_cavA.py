""" """

from config.experiment_config import FOLDER, N, FREQ, I, Q, MAG, PHASE, RRB, SINGLE_SHOT
from qm import qua as qm_qua
from qcore import Experiment, qua, Sweep
import numpy as np


class OutAndBackChi(Experiment):
    """Dispersive shift between cavity and qubit"""

    ############################# DEFINE PRIMARY DATASETS ##############################
    # these Datasets form the "raw" experimental data and will be streamed by the OPX
    # they must be specified at experiment runtime

    primary_datasets = ["I", "Q", "single_shot"]

    ############################## DEFINE PRIMARY SWEEPS ###############################
    # these Sweeps are uniquely associated with the Experiment subclass
    # these Sweeps must be specified at experiment runtime

    primary_sweeps = ["disp_phase"]

    ############################ DEFINE THE PULSE SEQUENCE #############################
    # ensure that you import 'qua' from 'qcore' and not from 'qm' library
    # attributes accessed via 'self' must be defined in 'if __name__ == "__main__"' code

    def sequence(self):
        """QUA sequence that defines this Experiment subclass"""
        qua.reset_frame(self.cavity)
        qua.reset_frame(self.qubit)
        # qua.update_frequency(self.drive, 357e6)
        qua.align()

        self.cavity.play(self.cav_displacement) 
        qua.align()
        qua.wait(self.time_delay, self.cavity)  # wait for state to rotate
        # self.drive.play(self.exchange)
        qua.align()
        self.cavity.play(self.cav_displacement, phase=self.disp_phase) # displace cavity back
        qua.align()  # qubit and cavity
        
        self.qubit.play(self.qubit_selective_pi)  # flip qubit if cav is in vac.
        qua.align()

        self.qubitEF.play(self.qubitEF_pi)
        qua.align(self.qubitEF, self.resonator)
        self.resonator.measure(self.readout_pulse, (self.I, self.Q), ampx=self.ro_ampx, demod_type="dual")
        qua.align()
        qua.wait(self.wait_time)
        if self.plot_single_shot:  # assign state to G or E
            qm_qua.assign(self.single_shot,qm_qua.Cast.to_fixed(self.I > self.readout_pulse.threshold),)



if __name__ == "__main__":
    """ """

    #################################### MODE MAP ######################################
    modes = {
        "qubit": "qA",
        "cavity": "cavA",
        "qubitEF":"qA_EF",
        # "cavity_e": "alice_e",
        "resonator": "rrA",
        # "drive":"drive",
    }

    ################################### PULSE MAP ######################################
    pulses = {
        "cav_displacement": "cavA_ramp_pulse",
        "qubit_selective_pi": "qA_gaussian_very_sel_pi_pulse",
        "qubitEF_pi": "qAEF_EF_gaussian_pi_pulse",
        "readout_pulse": "rrA_GF_CLEAR_readout_pulse",
        # "exchange":"just_ramp",
    }

    ############################## CONTROL PARAMETERS ##################################
    parameters = {
        "wait_time": 5e6,
        "plot_single_shot": True,
        "qubit_in_e": False,
        "ro_ampx": 1,
    }

    ######################## SWEEP (INDEPENDENT) VARIABLES #############################
    N.num = 5000
    DEL = Sweep(name="time_delay", start=16, stop=10_000, num=50, dtype=int)
    DISPL_PHASE = Sweep(name="disp_phase", start=0.0, stop=1.0, step=0.05, dtype=float)
    sweeps = [N, DISPL_PHASE, DEL]
    # sweeps = [N, DISPL_PHASE]

    ######################## DATASET (DEPENDENT) VARIABLES #############################
    SINGLE_SHOT.plot_args["plot_type"] = "image"
    PHASE.datafn_args = {"delay": 2.792e-7, "freq": RRB.int_freq}  # 2.792e-7
    PHASE.plot = False
    MAG.plot = False
    Q.plot = False
    I.plot = False
    datasets = [I, Q, SINGLE_SHOT]

    ######################## INITIALIZE AND RUN EXPERIMENT #############################

    expt = OutAndBackChi(FOLDER, modes, pulses, sweeps, datasets, **parameters)
    expt.run()



