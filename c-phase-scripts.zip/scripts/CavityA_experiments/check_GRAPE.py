""" """

import sys

sys.path.append("C:/Users/admin/Desktop/qcore-yabba/yabba-main/")
from config.experiment_config import FOLDER, N, FREQ, I, Q, MAG, PHASE, RRC, SINGLE_SHOT, RRA
from qm import qua as qm_qua
from qcore import Experiment, qua, Sweep


class NumberSplitting(Experiment):
    """Number splitting"""

    ############################# DEFINE PRIMARY DATASETS ##############################
    # these Datasets form the "raw" experimental data and will be streamed by the OPX
    # they must be specified at experiment runtime

    primary_datasets = ["I", "Q", "single_shot"]

    ############################## DEFINE PRIMARY SWEEPS ###############################
    # these Sweeps are uniquely associated with the Experiment subclass
    # these Sweeps must be specified at experiment runtime

    primary_sweeps = ["qubit_frequency"]
    #primary_sweeps = ["qubit_amplitude"]

    ############################ DEFINE THE PULSE SEQUENCE #############################
    # ensure that you import 'qua' from 'qcore' and not from 'qm' library
    # attributes accessed via 'self' must be defined in 'if __name__ == "__main__"' code

    def sequence(self):
        """QUA sequence that defines this Experiment subclass"""
        qua.reset_phase(self.cavity)
        qua.reset_frame(self.cavity)
        qua.reset_phase(self.qubit)
        qua.reset_frame(self.qubit)
        qua.align()

        ##GRAPE
        qua.update_frequency(self.qubit, self.qubit.int_freq)
        self.cavity.play(self.cavity_grape, ampx = self.grape_amp)#, ampx = self.qubit_drive_ampx)
        self.qubit.play(self.qubit_grape, ampx = self.grape_amp)
        qua.align()

        # Measurement
        self.resonator.measure(self.readout_pulse, (self.I, self.Q), ampx=self.ro_ampx, demod_type="dual")
        qua.wait(self.wait_time, self.resonator)
        if self.plot_single_shot:  # assign state to G or E
            qm_qua.assign(self.single_shot,qm_qua.Cast.to_fixed(self.I > self.readout_pulse.threshold),)


if __name__ == "__main__":
    """ """

    #################################### MODE MAP ######################################
    # key: name of the Mode as defined by the Experiment subclass
    # value: name of the Mode as defined by the user in modes.yml

    modes = {
        "cavity": "cavA",
        "qubit": "qA",
        #"qB": "qB",
        "resonator": "rrA",
        #"drive": "drive",
        #"qC": "qB",
    }
    ################################### PULSE MAP ######################################
    # key: name of the Pulse as defined by the Experiment subclass
    # value: name of the Pulse as defined by the user in modes.yml

    pulses = {
        "qubit_grape": "qA_grape_fock0i1",
        "cavity_grape": "cavA_grape_fock0i1",
        "cavity_pulse": "cavA_ramp_pulse",
        "qubit_spec_pulse": "qA_gaussian_very_sel_pi_pulse",
        "readout_pulse": "rrA_CLEAR_readout_pulse",

    }
                                       
    ############################## CONTROL PARAMETERS ##################################
    parameters = {
        "wait_time": 5e6,
        "ro_ampx": 1,
        "plot_single_shot": True,
    }

    ######################## SWEEP (INDEPENDENT) VARIABLES #############################
    # must include an outermost averaging Sweep named "N"
    # must include all primary sweeps defined by the Experiment subclass

    # set number of repetitions for this Experiment run
    N.num = 10000

    # set the qubit frequency sweep for this Experiment run
    FREQ.name = "qubit_frequency"
    FREQ.start = 250e6 
    FREQ.stop = 252.5e6
    FREQ.num = 101

    GRAPE_AMPX = Sweep(name="grape_amp", points=[0.0, 1.0])

    sweeps = [N, GRAPE_AMPX, FREQ]
    # QD_AMPX = Sweep(name="cavity_drive_ampx", points= [0.0, 1.8]) #needs to be floating point numbers 
    #sweeps = [N, QD_AMPX, FREQ]

    ######################## DATASET (DEPENDENT) VARIABLES #############################
    # must include all primary datasets defined by the Experiment subclass

    PHASE.datafn_args = {"delay": 2.792e-7, "freq": RRA.int_freq}

    Q.plot= True
    SINGLE_SHOT.plot = True
    I.plot, MAG.plot = True, True
    SINGLE_SHOT.fitfn = "gaussian"

    datasets = [I, Q, SINGLE_SHOT]

    ######################## INITIALIZE AND RUN EXPERIMENT #############################

    expt = NumberSplitting(FOLDER, modes, pulses, sweeps, datasets, **parameters)
    expt.run()
