import sys
sys.path.append("C:/Users/admin/Desktop/cphase/scripts")
from tkinter import SINGLE
from config.experiment_config import FOLDER, N, I, Q, MAG, PHASE, RRB, FREQ, SINGLE_SHOT
from qcore import Experiment, qua, Sweep
from ECD_routines import Char2D
from hamiltonian_params import *
from qm import qua as qm_qua


class CohCrosshair(Experiment):
    """ECD Calibration"""

    ############################# DEFINE PRIMARY DATASETS ##############################
    # these Datasets form the "raw" experimental data and will be streamed by the OPX
    # they must be specified at experiment runtime

    primary_datasets = ["I", "Q", "single_shot"]

    ############################## DEFINE PRIMARY SWEEPS ###############################
    # these Sweeps are uniquely associated with the Experiment subclass
    # these Sweeps must be specified at experiment runtime

    primary_sweeps = ["displace"]

    ############################ DEFINE THE PULSE SEQUENCE #############################
    # ensure that you import 'qua' from 'qcore' and not from 'qm' library
    # attributes accessed via 'self' must be defined in 'if __name__ == "__main__"' code

    def sequence(self):
        """QUA sequence that defines this Experiment subclass"""
        qua.reset_phase(self.cav)
        qua.reset_phase(self.cav_ge)
        qua.reset_phase(self.qubit)

        qua.reset_frame(self.cav)
        qua.reset_frame(self.qubit)
        qua.reset_frame(self.cav_ge)
        
    
        #keep_phase = ((6.575005624e9 - 50e6 - 56.55e3 / 2) * (20 * 4 * 1e-9)) % 1

        # create state
        # self.qubit.play(self.qubit_pi_pulse) #qubit in e
        qua.align()
        # qua.wait(1000,self.cav)
        self.cav.play(self.cav_state_creation, ampx= 1, phase=0)
        # qua.wait(self.wait, self.cav)
        # self.cav.play(self.cav_state_creation, ampx= self.ecd1_ds[0]*self.ecd1_ds[4], phase=  self.ecd1_ds[1]+self.ecd1_ds[5])
        # qua.align()
        # self.qubit.play(self.qubit_pi_pulse)
        # qua.align()
        # self.cav.play(self.cav_state_creation, ampx= self.ecd1_ds[0]*self.ecd1_ds[4], phase=  self.ecd1_ds[1]+self.ecd1_ds[5])
        # qua.wait(self.wait ,self.cav)
        # self.cav.play(self.cav_state_creation, ampx=self.ecd1_ds[0]*self.ecd1_ds[6], phase=   self.ecd1_ds[1]+self.ecd1_ds[7])

        # qua.align()
        # self.qubit.play(self.qubit_pi_pulse)
        
        # measure char func
        qua.align()
        #self.qubit.play(self.qubit_pi_pulse)
        
        Char2D(
            self.single_shot,
            self.resonator,
            self.readout_pulse,
            self.I,
            self.Q,
            self.wait_time,
            self.cav_ge,
            self.qubit,
            self.ecd_drive,
            self.qubit_pi_pulse,
            self.qubit_pi2_pulse,
            -self.displace * (1 - self.axis),
            self.displace * self.axis,
            self.ratios,
            self.ecd_wait_time,
            self.measure_real,
            self.tomo_phase,
            self.plot_single_shot,
        )
        # qua.reset_frame(self.cav_g)
        # qua.reset_frame(self.qubit)


# -------------------------------- Execution -----------------------------------

if __name__ == "__main__":
    """ """

    #################################### MODE MAP ######################################
    # key: name of the Mode as defined by the Experiment subclass
    # value: name of the Mode as defined by the user in modes.yml

    modes = {
        "qubit": "qB",
        "cav": "cavB",
        "cav_ge": "cavB_ge", # change to cav in g to supress rotation
        "resonator": "rrB",
    }

    ################################### PULSE MAP ######################################
    # key: name of the Pulse as defined by the Experiment subclass
    # value: name of the Pulse as defined by the user in modes.yml

    pulses = {
        "qubit_pi_pulse": "qB_gaussian_pi_pulse",
        "qubit_pi2_pulse": "qB_gaussian_pi2_pulse",
        "cav_state_creation": "cavB_gaussian_pulse",
        "ecd_drive": "cavB_ge_ECD3_coh3",
        "readout_pulse": "rrB_readout_pulse",
    }

    ############################## CONTROL PARAMETERS ##################################
    Cavity = Bob
    parameters = {
        "wait_time": 7_000_000,
        "plot_single_shot": True,
        "ecd_wait_time": Cavity["ecd_wait_time_optimized"],
        "measure_real": False,
        "tomo_phase": 0, #-0.021, 
        "fetch_period": 3,
        "wait": 500,
        "ratios": Cavity["ratios_optimized"],
        "plot_single_shot": True,
    }

    ######################## SWEEP (INDEPENDENT) VARIABLES #############################
    # must include an outermost averaging Sweep named "N"
    # must include all primary sweeps defined by the Experiment subclass

    # set number of repetitions for this Experiment run
    N.num = 600

    # set the cav amplitude sweep for this Experiment run
    displace_sweep = Sweep(name="displace", start=-1.6, stop=1.6, num=51)
    axis = Sweep(name="axis", points=[0.0, 1.0])
    sweeps = [N, axis, displace_sweep]
    # tomo_phase = Sweep(name="tomo_phase", points = [0.25,0.26,0.27,0.28,0.29,0.3,0.345])
    # sweeps = [N,tomo_phase,displace_sweep]

    ######################## DATASET (DEPENDENT) VARIABLES #############################
    # must include all primary datasets defined by the Experiment subclass

    # MAG.axes = sweeps[1:]
    # PHASE.axes = sweeps[1:]
    PHASE.datafn_args = {"delay": 2.792e-7, "freq": RRB.int_freq}
    PHASE.plot = False
    datasets = [I, Q, SINGLE_SHOT]
    MAG.plot = False
    Q.plot = False
    I.plot = False
    SINGLE_SHOT.plot = True
    
    SINGLE_SHOT.fitfn = "char_func_coh_state_3"  # "gaussian"

    ######################## INITIALIZE AND RUN EXPERIMENT #############################
    # RUN TO OBSERVE DRIFT OF FRAME AND CHECK CONSISTENCY OF PLOTTING

    expt = CohCrosshair(FOLDER, modes, pulses, sweeps, datasets, **parameters)
    expt.run(simulate=False)