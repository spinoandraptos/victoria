import numpy as np
import os
import h5py
import matplotlib.pyplot as plt
from scipy.optimize import curve_fit

import numpy as np
from scipy.optimize import curve_fit
import matplotlib.pyplot as plt



# Z DATA 
# file_fock0 = r"C:\Users\admin\Desktop\yabba-main\yabba-main\data\2024-06-04\12-07-51_Wigner2D.hdf5"
# file_fock1 = r"C:\Users\admin\Desktop\yabba-main\yabba-main\data\2024-06-04\20-25-17_Wigner2D.hdf5"

# file_fock = r"C:\Users\admin\Desktop\cphase\data\2025-07-15\00-44-51_WignersAB.hdf5"
# data =  h5py.File(file_fock, "r")
# # times = np.array(data["time_delay"])/1e6
# array = np.average(data["single_shotA"], axis = 0)
# freqs = np.array(data['drive_frequency'])


# for cut in [10,15,20,25, 30,35,40,45]:


#     plt.plot(times, array[:,cut], '.', label = f"IF: {freqs[cut]/1e6} MHz")
#     popt, pcov = curve_fit(exp_decay, times,  array[:,cut], p0=(1, 1, 0))
#     A_fit, tau_fit, C_fit = popt
#     t_fit = np.linspace(min(times), max(times), 500)
#     y_fit = exp_decay(t_fit, *popt)
#     plt.plot(t_fit, y_fit, '--',)
#     plt.text(0.3, 0.8 - 0.015* cut, f"$\\tau$ at {freqs[cut]/1e6} = {tau_fit:.3f} ms", transform=plt.gca().transAxes,
#             fontsize=12, verticalalignment='top', bbox=dict(facecolor='white', alpha=0.6))
# plt.legend()
# plt.ylabel("Pe")
# plt.xlabel("Drive lengths (ms)")
# plt.show()




file_w1 =  r"C:\Users\admin\Desktop\cphase\data\2025-07-15\00-44-51_WignersAB.hdf5"
data = h5py.File(file_w1, "r")
# data1 = h5py.File(file_fock1, "r")
wignerA = np.mean(np.array(data["single_shotA"]), axis = 0) * 2 - 1
wignerB = np.mean(np.array(data["single_shotB"]), axis = 0) * 2 - 1

# XY DATA
drive_length = data["drive_length"]
I_values = data['cavity_drive_I']
Q_values = data['cavity_drive_Q']
x_axis, y_axis = np.meshgrid(I_values, Q_values)


# # PLOTTING
fig, axs = plt.subplots(4, 2, figsize=(4, 10))

for i, length in enumerate([0,1,2,3]):
    # Plot for Alice in 0
    axs[i, 0].pcolormesh(x_axis, y_axis, wignerA[:,:,length], cmap='bwr', vmin=-1, vmax=1)
    axs[i, 0].set_title('Alice0, Drive: {}'.format(drive_length[length]))
    # axs[i, 0].set_xlabel('I')
    # axs[i, 0].set_ylabel('Q')
    axs[i, 0].set_aspect('equal')
    axs[i, 0].axis('tight')
    
    # Plot for Alice in 1
    axs[i, 1].pcolormesh(x_axis, y_axis, wignerB[:,:,length], cmap='bwr', vmin=-1, vmax=1)
    axs[i, 1].set_title('Alice1, Drive: {}'.format(drive_length[length]))
    # axs[i, 1].set_xlabel('I')
    # axs[i, 1].set_ylabel('Q')
    axs[i, 1].set_aspect('equal')
    axs[i, 1].axis('tight')

plt.tight_layout()
plt.show()