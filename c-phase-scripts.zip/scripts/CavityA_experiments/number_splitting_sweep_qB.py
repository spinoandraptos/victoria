""" """

import sys

sys.path.append("C:/Users/admin/Desktop/qcore-yabba/yabba-main/")
from config.experiment_config import FOLDER, N, FREQ, I, Q, MAG, PHASE, RRC, SINGLE_SHOT, RRA
from qm import qua as qm_qua
from qcore import Experiment, qua, Sweep


class NumberSplitting(Experiment):
    """Number splitting"""

    ############################# DEFINE PRIMARY DATASETS ##############################
    # these Datasets form the "raw" experimental data and will be streamed by the OPX
    # they must be specified at experiment runtime

    primary_datasets = ["I", "Q", "single_shot"]

    ############################## DEFINE PRIMARY SWEEPS ###############################
    # these Sweeps are uniquely associated with the Experiment subclass
    # these Sweeps must be specified at experiment runtime

    primary_sweeps = ["side_qubit_freq"]
    #primary_sweeps = ["qubit_amplitude"]

    ############################ DEFINE THE PULSE SEQUENCE #############################
    # ensure that you import 'qua' from 'qcore' and not from 'qm' library
    # attributes accessed via 'self' must be defined in 'if __name__ == "__main__"' code

    def sequence(self):
        """QUA sequence that defines this Experiment subclass"""
        qua.reset_phase(self.cavity)
        qua.reset_frame(self.cavity)
        qua.reset_phase(self.qubit)
        qua.reset_frame(self.qubit)

        # U2: 0 -> 1 in cavB
        qua.update_frequency(self.qubit, self.side_qubit_freq) #!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
        #qua.update_frequency(self.qubit, self.qubit_frequency)
        self.cavity.play(self.cavity_pulse, ampx= 1.14)  # displace by beta = 1.14
        qua.align()
        self.qubit.play(self.qubit_SNAP_pulse, ampx = 2.0)    # SNAP: play pi pulse around X
        qua.align()  # align pulses
        self.cavity.play(self.cavity_pulse, ampx= -0.58)  # displace by beta = -0.58
        qua.align()

        #Selective pi pulse
        qua.update_frequency(self.qC,-165.71e6) # Fock1 frequency
        self.qC.play(self.qubit_spec_pulse)
        qua.align()

        # Measurement
        self.resonator.measure(self.readout_pulse, (self.I, self.Q), ampx=self.ro_ampx, demod_type="dual")
        qua.wait(self.wait_time, self.resonator)
        if self.plot_single_shot:  # assign state to G or E
            qm_qua.assign(self.single_shot,qm_qua.Cast.to_fixed(self.I > self.readout_pulse.threshold),)


if __name__ == "__main__":
    """ """

    #################################### MODE MAP ######################################
    # key: name of the Mode as defined by the Experiment subclass
    # value: name of the Mode as defined by the user in modes.yml

    modes = {
        "cavity": "cavB",
        "qubit": "qB",
        #"qB": "qB",
        "resonator": "rrC",
        #"drive": "drive",
        "qC": "qC",
    }
    ################################### PULSE MAP ######################################
    # key: name of the Pulse as defined by the Experiment subclass
    # value: name of the Pulse as defined by the user in modes.yml

    pulses = {
        # "qubit_grape": "qB_grape_fock03",
        # "cavity_grape": "cavB_grape_fock03",
        "cavity_pulse": "cavB_ramp_pulse",
        "qubit_SNAP_pulse": "qB_gaussian_very_sel_pi_pulse",
        #"drive_pulse": "SS_pulse_long"
        "qubit_spec_pulse": "qC_gaussian_sel_pi_pulse",
        "readout_pulse": "rrC_readout_pulse",

    }
                                       
    ############################## CONTROL PARAMETERS ##################################
    parameters = {
        "wait_time": 6e6,
        "ro_ampx": 1,
        "plot_single_shot": True,
    }

    ######################## SWEEP (INDEPENDENT) VARIABLES #############################
    # must include an outermost averaging Sweep named "N"
    # must include all primary sweeps defined by the Experiment subclass

    # set number of repetitions for this Experiment run
    N.num = 10000

    # set the qubit frequency sweep for this Experiment run
    FREQ.name = "side_qubit_freq"
    FREQ.start = 177.4e6 
    FREQ.stop = 178e6
    FREQ.num = 101

    # QD_AMPX = Sweep(name="qubit_drive_ampx", points=[0.0, 1.0])

    sweeps = [N, FREQ]
    # QD_AMPX = Sweep(name="cavity_drive_ampx", points= [0.0, 1.8]) #needs to be floating point numbers 
    # sweeps = [N, QD_AMPX, FREQ]

    ######################## DATASET (DEPENDENT) VARIABLES #############################
    # must include all primary datasets defined by the Experiment subclass

    PHASE.datafn_args = {"delay": 2.792e-7, "freq": RRC.int_freq}

    Q.plot= True
    SINGLE_SHOT.plot = True
    I.plot, MAG.plot = True, True
    SINGLE_SHOT.fitfn = "gaussian"

    datasets = [I, Q, SINGLE_SHOT]

    ######################## INITIALIZE AND RUN EXPERIMENT #############################

    expt = NumberSplitting(FOLDER, modes, pulses, sweeps, datasets, **parameters)
    expt.run()
