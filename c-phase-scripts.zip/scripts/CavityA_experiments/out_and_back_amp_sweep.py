""" """

from config.experiment_config import FOLDER, N, FREQ, I, Q, MAG, PHASE, RRB, SINGLE_SHOT
from qm import qua as qm_qua
from qcore import Experiment, qua, Sweep
import numpy as np


class OutAndBackAmpSweep(Experiment):
    """Dispersive shift between cavity and qubit"""

    ############################# DEFINE PRIMARY DATASETS ##############################
    # these Datasets form the "raw" experimental data and will be streamed by the OPX
    # they must be specified at experiment runtime

    primary_datasets = ["I", "Q", "single_shot"]

    ############################## DEFINE PRIMARY SWEEPS ###############################
    # these Sweeps are uniquely associated with the Experiment subclass
    # these Sweeps must be specified at experiment runtime

    primary_sweeps = ["amp"]

    ############################ DEFINE THE PULSE SEQUENCE #############################
    # ensure that you import 'qua' from 'qcore' and not from 'qm' library
    # attributes accessed via 'self' must be defined in 'if __name__ == "__main__"' code

    def sequence(self):
        """QUA sequence that defines this Experiment subclass"""
        qua.reset_phase()

        self.cavity.play(
            self.cav_displacement, ampx=self.amp
        )  # create a coherent state
        qua.align()  # put qubit into excited state to start rotation of cohstate
        
        if self.qubit_in_e:
            self.qubit.play(self.qubit_pi_pulse)
            qua.align()
        
        qua.wait(self.time_delay, self.cavity)  # wait for state to rotate

        self.cavity.play(
            self.cav_displacement, ampx=self.amp, phase=self.disp_phase
        )  # displace cavity back

        # # # conditional measurement to filter out states were decay or heating occured.
        # if self.qubit_in_e:
        #     qua.align()
        #     self.resonator.measure(self.readout_pulse, (self.I, self.Q), demod_type="dual")

        #     if self.plot_single_shot:  # assign state to G or E
        #         qm_qua.assign(
        #             self.preselect,
        #             qm_qua.Cast.to_fixed(self.I > self.readout_pulse.threshold),
        #         )
        

        #     qua.wait(self.wait_time_post_selection, self.resonator)
        
        
        qua.align()
        self.qubit.play(self.qubit_selective_pi)  # flip qubit if cav is in vac.

        
        
        # measurement
        qua.align()
        self.resonator.measure(self.readout_pulse, (self.I, self.Q), demod_type="dual")

        if self.plot_single_shot:  # assign state to G or E
            qm_qua.assign(
                self.single_shot,
                qm_qua.Cast.to_fixed(self.I > self.readout_pulse.threshold),
            )

        qua.wait(self.wait_time, self.resonator)


if __name__ == "__main__":
    """ """

    #################################### MODE MAP ######################################
    # key: name of the Mode as defined by the Experiment subclass
    # value: name of the Mode as defined by the user in modes.yml

    modes = {
        "qubit": "qB",
        "cavity": "cavB",
        "resonator": "rrB",
    }

    ################################### PULSE MAP ######################################
    # key: name of the Pulse as defined by the Experiment subclass
    # value: name of the Pulse as defined by the user in modes.yml

    pulses = {
        "cav_displacement": "cavB_gaussian_pulse",
        "qubit_pi_pulse": "qB_gaussian_pi_pulse",
        "qubit_selective_pi": "qB_gaussian_sel_pi_pulse",
        "readout_pulse": "rrB_readout_pulse",
    }

    ############################## CONTROL PARAMETERS ##################################
    parameters = {
        "wait_time": 5_000_000,
        "wait_time_post_selection" : 4500, # wait for readout resonator to decay
        "qubit_in_e" : True,
        "plot_single_shot": True,
        "time_delay": 1000,
    }

    ######################## SWEEP (INDEPENDENT) VARIABLES #############################
    # must include an outermost averaging Sweep named "N"
    # must include all primary sweeps defined by the Experiment subclass

    # set number of repetitions for this Experiment run
    N.num = 5000

    # set the delay sweep
    # DEL = Sweep(name="time_delay", start=10, stop=10000, step=200, dtype=int)

    # set the pulse duration sweep
    AMP = Sweep(name="amp", start=0.0, stop=1.8, num=51)

    DISPL_PHASE = Sweep(
        name="disp_phase", start=0.1, stop=0.9, step=0.05, dtype=float
    )
    sweeps = [N, DISPL_PHASE, AMP]

    ######################## DATASET (DEPENDENT) VARIABLES #############################
    # must include all primary datasets defined by the Experiment subclass

    from qcore import Dataset
    # PRESELECT = Dataset(
    #     name="preselect",
    #     save=True,
    #     plot=False,
    # )
    # MAG.axes = sweeps[1:]
    # PHASE.axes = sweeps[1:]
    PHASE.datafn_args = {"delay": 2.792e-7, "freq": RRB.int_freq}
    PHASE.plot = False
    MAG.plot = False
    Q.plot = False
    I.plot= False
    SINGLE_SHOT.plot_args["plot_type"] = "image"
    # datasets = [I, Q, SINGLE_SHOT, PRESELECT]
    datasets = [I, Q, SINGLE_SHOT]

    ######################## INITIALIZE AND RUN EXPERIMENT #############################

    expt = OutAndBackAmpSweep(FOLDER, modes, pulses, sweeps, datasets, **parameters)
    expt.run()