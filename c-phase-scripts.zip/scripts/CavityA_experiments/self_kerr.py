from config.experiment_config import FOLDER, N, FREQ, I, Q, MAG, PHASE, RRB, SINGLE_SHOT
from qm import qua as qm_qua
from qcore import Experiment, qua, Sweep
from qcore.libs.qua_macros import QuaVariable

class SelfKerr(Experiment):
    """Cavity self Kerr"""

    ############################# DEFINE PRIMARY DATASETS ##############################
    primary_datasets = ["I", "Q", "single_shot"]

    ############################## DEFINE PRIMARY SWEEPS ###############################
    primary_sweeps = ["time_delay"]

    ############################ DEFINE THE PULSE SEQUENCE #############################
    def sequence(self):
        factor = qm_qua.declare(qm_qua.fixed)
        qm_qua.assign(factor, self.detuning * 1e-9)  # formerly with a 4*
        qua.reset_frame(self.cav)
        qua.align()

        #self.cav.play(self.cavity_pulse, ampx = self.cavity_pulse_amplitude) # displace cavity
        self.cav.play(self.cavity_pulse, ampx = self.cavity_pulse_amplitude) # displace cavity
        qua.align()
        # qua.wait(self.time_delay, self.cav)
        self.drive.play(self.drive_pulse, duration = self.time_delay/4)
        qua.align()
       
        qm_qua.assign(self.phase, qm_qua.Cast.mul_fixed_by_int(factor, self.time_delay)+0.5) # virtual phase
        self.cav.play(self.cavity_pulse, ampx = self.cavity_pulse_amplitude, phase = self.phase) # displace cavity back
        qua.align()
        
        self.qubit.play(self.qubit_pulse)
        qua.align(self.qubit, self.qubitEF)
        self.qubitEF.play(self.qubitEF_pulse)
        qua.align(self.qubitEF, self.resonator)
        self.resonator.measure(self.readout_pulse, (self.I, self.Q), demod_type="dual")
        qua.align()
        qua.wait(self.wait_time)
        if self.plot_single_shot:  # assign state to G or E
            qm_qua.assign(self.single_shot,qm_qua.Cast.to_fixed(self.I > self.readout_pulse.threshold),)

if __name__ == "__main__":
    """ """
    #################################### MODE MAP ######################################
    modes = {
            "drive": "drive",
            "qubit": "qA", 
            "qubitEF": "qA_EF", 
            "cav":"cavA",
            "resonator": "rrA"}
    
    ################################### PULSE MAP ######################################
    pulses = {
            "qubit_pulse": "qA_gaussian_very_sel_pi_pulse",
            "cavity_pulse":"cavA_ramp_pulse",
            "qubitEF_pulse": "qAEF_EF_gaussian_pi_pulse",
            # "qubitA_drive": "qubitAGF_gaussian_pi_pulse",
            "drive_pulse": "exchange_pulse_ramp",
            "readout_pulse": "rrA_GF_CLEAR_readout_pulse"}

    ############################## CONTROL PARAMETERS ##################################
    parameters = {
        "wait_time": 6e6,
        "detuning": 5e6,  # Hz
        "phase": QuaVariable(value=0.0,dtype=qm_qua.fixed,tag="phase",buffer=True,stream=True),
        "plot_single_shot": True,
    }

    ######################## SWEEP (INDEPENDENT) VARIABLES #############################
    N.num = 5000
    DEL = Sweep(name="time_delay", start=500, stop=2000, step=16, dtype=int)  # ns
    CAV_AMPX = Sweep(name="cavity_pulse_amplitude", start=0.1, stop=2.0, step=0.1)
    sweeps = [N, CAV_AMPX, DEL]

    ######################## DATASET (DEPENDENT) VARIABLES #############################
    I.fitfn = "exp_decay_sine"
    Q.fitfn = "exp_decay_sine"
    Q.plot = False
    # SINGLE_SHOT.fitfn = "exp_decay_sine"
    # PHASE.datafn_args = {"delay": 2.792e-7, "freq": RRC.int_freq}
    # PHASE.plot = False
    # I.plot, Q.plot = False, False
    datasets = [I, Q, SINGLE_SHOT]

    ######################## INITIALIZE AND RUN EXPERIMENT #############################
    expt = SelfKerr(FOLDER, modes, pulses, sweeps, datasets, **parameters)
    expt.run()
