""" """

import sys

sys.path.append("C:/Users/admin/Desktop/qcore-yabba/yabba-main/")

from config.experiment_config import FOLDER, N, I, Q, MAG, PHASE, RRB, FREQ, SINGLE_SHOT
from qcore import Experiment, qua, Sweep
from qm import qua as qm_qua
from qcore.libs.qua_macros import QuaVariable
from qcore import Dataset


class CavitySpecA(Experiment):
    """Cavity spectroscopy"""

    ############################# DEFINE PRIMARY DATASETS ##############################
    # these Datasets form the "raw" experimental data and will be streamed by the OPX
    # they must be specified at experiment runtime

    primary_datasets = ["I", "Q", "single_shot"]

    ############################## DEFINE PRIMARY SWEEPS ###############################
    # these Sweeps are uniquely associated with the Experiment subclass
    # these Sweeps must be specified at experiment runtime

    primary_sweeps = ["cavity_frequency"]

    ############################ DEFINE THE PULSE SEQUENCE #############################
    # ensure that you import 'qua' from 'qcore' and not from 'qm' library
    # attributes accessed via 'self' must be defined in 'if __name__ == "__main__"' code

    def sequence(self):
        """QUA sequence that defines this Experiment subclass"""
        
        # qua.update_frequency(self.qubitA, self.qubitA.int_freq) #!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
        # qua.update_frequency(self.qubitB, self.qubitB.int_freq) #!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
        # self.qubitB.play(self.qubitB_grape)
        # self.cavityB.play(self.cavityB_grape) 
        # self.qubitA.play(self.qubitA_grape)
        # self.cavityA.play(self.cavityA_grape) 
        # qua.align()

        self.qC.play(self.qC_pi, ampx = self.pulse_ampx)

        # qua.update_frequency(self.drive, 228.7e6)
        # self.drive.play(self.drive_pulse, ampx = self.pulse_ampx,  duration = 40/4)
        qua.align()


        # qua.update_frequency(self.cavity, self.cavity.int_freq)
        # self.qubit.play(self.qubit_grape, ampx = self.pulse_ampx)
        # self.cavity.play(self.cavity_grape, ampx = self.pulse_ampx)
        # qua.align()
        qua.update_frequency(self.cavityA, self.cavity_frequency)
        self.cavityA.play(self.cavity_pulse, ampx = 0.1, duration = 8000/4)
        # self.drive.play(self.drive_pulse, duration = 2000/4, ampx = 1.8)
        qua.align()
        # qua.update_frequency(self.qubitA, 350.68e6) #fock1 qA
        self.qubitA.play(self.qubit_pulse)
        qua.align()
        self.qubitAEF.play(self.qubitEF_pi)
        qua.align()
        self.resonator.measure(self.readout_pulse, (self.I, self.Q), demod_type="dual")

        if self.plot_single_shot:  # assign state to G or E
            qm_qua.assign(self.single_shot,qm_qua.Cast.to_fixed(self.I > self.readout_pulse.threshold))
        qua.align()
        qua.wait(self.wait_time)

if __name__ == "__main__":
    """ """

    #################################### MODE MAP ######################################
    # key: name of the Mode as defined by the Experiment subclass
    # value: name of the Mode as defined by the user in modes.yml

    modes = {
        "cavityA": "cavA",
        "cavityB": "cavB",

        "qubitA": "qA",
        "qB": "qB",

        "qC": "qC",
        "qubitAEF":"qA_EF",
        "resonator": "rrA",
        "drive": "drive",
    }

    ################################### PULSE MAP ######################################
    # key: name of the Pulse as defined by the Experiment subclass
    # value: name of the Pulse as defined by the user in modes.yml

    pulses = {        
        "cavity_pulse": "cavA_constant_pulse",

        "cavityA_grape": "cavA_grape_fock1",
        "qubitA_grape": "qA_grape_fock1",
        "cavityB_grape": "cavB_grape_fock1",
        "qubitB_grape": "qB_grape_fock1",

        "qubitEF_pi": "qAEF_EF_gaussian_pi_pulse",
        "qubit_pulse": "qA_gaussian_very_sel_pi_pulse",
        "drive_pulse": "exchange_pulse",
        "qC_pi":"qC_gaussian_pi_pulse",
        "qB_pi":"qB_gaussian_pi_pulse",
        "qA_pi":"qA_gaussian_pi_pulse",
        "readout_pulse": "rrA_GF_CLEAR_readout_pulse",
    }

    ############################## CONTROL PARAMETERS ##################################

    parameters = {
        "wait_time": 6e6,
        "ro_ampx": 1,
        "fetch_interval": 2,
        "plot_single_shot": True,
    }

    ######################## SWEEP (INDEPENDENT) VARIABLES #############################
    # must include an outermost averaging Sweep named "N"
    # must include all primary sweeps defined by the Experiment subclass

    # set number of repetitions for this Experiment run
    N.num = 5000

    # set the qubit frequency sweep for this Experiment run
    FREQ.name = "cavity_frequency"
    FREQ.start = -173e6
    FREQ.stop = -171e6
    FREQ.num = 201

    DRIVE_AMPX = Sweep(name="pulse_ampx", points=[0.0, 1.0])

    sweeps = [N, DRIVE_AMPX, FREQ]

    ######################## DATASET (DEPENDENT) VARIABLES #############################
    # must include all primary datasets defined by the Experiment subclass
    # MAG.fitfn = "gaussian"

    PHASE.datafn_args = {"delay": 2.792e-7, "freq": RRB.int_freq}
    I.plot, Q.plot = True, True
    I.fitfn = "gaussian"
    SINGLE_SHOT.fitfn = "gaussian"
    PHASE.plot = False
    SINGLE_SHOT.plot= True

    datasets = [I, Q, SINGLE_SHOT]

    ######################## INITIALIZE AND RUN EXPERIMENT #############################

    expt = CavitySpecA(FOLDER, modes, pulses, sweeps, datasets, **parameters)
    expt.run(False)
