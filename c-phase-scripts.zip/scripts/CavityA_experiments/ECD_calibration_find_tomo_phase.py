import sys
sys.path.append("C:/Users/admin/Desktop/cphase/scripts")
from config.experiment_config import FOLDER, N, I, Q, MAG, PHASE, SINGLE_SHOT, RRB, FREQ
from qcore import Experiment, qua, Sweep
from ECD_routines import ECD_charFunc
from hamiltonian_params import *
from qm import qua as qm_qua


class ECDCalibrationTomoPhase(Experiment):
    """ECD Calibration"""

    ############################# DEFINE PRIMARY DATASETS ##############################
    # these Datasets form the "raw" experimental data and will be streamed by the OPX
    # they must be specified at experiment runtime

    primary_datasets = ["I", "Q", "single_shot"]

    ############################## DEFINE PRIMARY SWEEPS ###############################
    # these Sweeps are uniquely associated with the Experiment subclass
    # these Sweeps must be specified at experiment runtime

    primary_sweeps = ["cav_displacement_amplitude"]

    ############################ DEFINE THE PULSE SEQUENCE #############################
    # ensure that you import 'qua' from 'qcore' and not from 'qm' library
    # attributes accessed via 'self' must be defined in 'if __name__ == "__main__"' code

    def sequence(self):
        """QUA sequence that defines this Experiment subclass"""

        qua.reset_phase(self.qubit)
        qua.reset_frame(self.qubit)
        qua.reset_phase(self.cav)
        qua.reset_frame(self.cav)
        self.qubit.play(self.qubit_pi2_pulse)  # play pi/2 pulse around X

        qua.align()  # wait for qubit pulse to end
        # start ECD gate

        # please check which cavity mode is used
        ECD_charFunc(
            self.cav,
            self.qubit,
            self.cav_drive,
            self.qubit_pi_pulse,
            self.cav_displacement_amplitude,
            0,  # y displacement
            self.ratios,
            self.ecd_wait_time,
            self.tomo_phase,
            self.qubit_phase,
        )

        qua.align(self.qubit, self.cav)
        self.qubit.play(self.qubit_pi2_pulse, phase=self.qubit_phase)
        qua.align(self.qubit, self.resonator)  # align measurement
        self.resonator.measure(
            self.readout_pulse, (self.I, self.Q), ampx=self.ro_ampx, demod_type="dual"
        )  # measure transmitted signal
        if self.plot_single_shot:  # assign state to G or E
            qm_qua.assign(
                self.single_shot,
                qm_qua.Cast.to_fixed(self.I > self.readout_pulse.threshold),
            )
        # wait system reset
        qua.wait(int(self.wait_time), self.cav)


# -------------------------------- Execution -----------------------------------

if __name__ == "__main__":
    """ """
    # print(np.cos(Alice['chi']*Alice['ecd_wait_time']/2), np.cos(Alice['chi']*Alice['ecd_wait_time']))
    #################################### MODE MAP ######################################
    # key: name of the Mode as defined by the Experiment subclass
    # value: name of the Mode as defined by the user in modes.yml

    modes = {
        "qubit": "qB",
        "cav": "cavB_ge",
        # "cav": "charlie_ge",#"alice_ge",
        # "cav": "charlie",
        "resonator": "rrB",
    }

    ################################### PULSE MAP ######################################
    # key: name of the Pulse as defined by the Experiment subclass
    # value: name of the Pulse as defined by the user in modes.yml

    pulses = {
        "qubit_pi2_pulse": "qB_gaussian_pi2_pulse",
        "qubit_pi_pulse": "qB_gaussian_pi_pulse",
        "cav_drive": "cavB_ge_ECD3_coh3",
        "readout_pulse": "rrB_readout_pulse",
    }

    ############################## CONTROL PARAMETERS ##################################

    # be able to easily switch between cavities
    Cavity = Bob

    parameters = {
        "wait_time": 7_000_000,
        "ro_ampx": 1,
        "ecd_wait_time": Cavity["ecd_wait_time_optimized"], #Cavity["ecd_wait_time_optimized"], should use optimized one but here system is bad so I did not bother to optimize
        "phase": 0,
        "qubit_phase": 0,
        "fetch_period": 3,
        "ratios": Cavity["ratios_optimized"],
        "plot_single_shot": True,
    }

    ######################## SWEEP (INDEPENDENT) VARIABLES #############################
    # must include an outermost averaging Sweep named "N"
    # must include all primary sweeps defined by the Experiment subclass

    # set number of repetitions for this Experiment run
    N.num = 50000

    # set the cav amplitude sweep for this Experiment run
    CAV_AMPX = Sweep(name="cav_displacement_amplitude", start=-1.8, stop=1.8, num=31)
    TOMO_PHASE = Sweep(name="tomo_phase", start=-0.2, stop=0.2, num=31)
    sweeps = [N, TOMO_PHASE, CAV_AMPX]

    ######################## DATASET (DEPENDENT) VARIABLES #############################
    # must include all primary datasets defined by the Experiment subclass

    # MAG.axes = sweeps[1:]
    # PHASE.axes = sweeps[1:]
    PHASE.datafn_args = {"delay": 2.792e-7, "freq": RRB.int_freq}
    PHASE.plot = False
    datasets = [I, Q, SINGLE_SHOT]
    MAG.plot = False
    Q.plot = False
    SINGLE_SHOT.plot = True
    I.plot = False
    SINGLE_SHOT.fitfn = "gaussian"
    I.fitfn = "gaussian"
    MAG.fitfn = "gaussian"
    SINGLE_SHOT.plot_args["plot_type"] = "image"

    ######################## INITIALIZE AND RUN EXPERIMENT #############################

    expt = ECDCalibrationTomoPhase(FOLDER, modes, pulses, sweeps, datasets, **parameters)
    expt.run()