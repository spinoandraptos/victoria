""" """

import sys

sys.path.append("C:/Users/admin/Desktop/qcore-yabba/yabba-main/")
from config.experiment_config import FOLDER, N, FREQ, I, Q, MAG, PHASE, RRC, SINGLE_SHOT
from qcore import Experiment, qua, Sweep
from qm import qua as qm_qua

class RamseyRevival(Experiment):
    """Ramsey revival"""

    ############################# DEFINE PRIMARY DATASETS ##############################
    # these Datasets form the "raw" experimental data and will be streamed by the OPX
    # they must be specified at experiment runtime
    primary_datasets = ["I", "Q", "single_shot"]

    ############################## DEFINE PRIMARY SWEEPS ###############################
    # these Sweeps are uniquely associated with the Experiment subclass
    # these Sweeps must be specified at experiment runtime
    primary_sweeps = ["delay"]

    ############################ DEFINE THE PULSE SEQUENCE #############################
    # ensure that you import 'qua' from 'qcore' and not from 'qm' library
    # attributes accessed via 'self' must be defined in 'if __name__ == "__main__"' code

    def sequence(self):
        """QUA sequence that defines this Experiment subclass"""
        self.cavity.play(self.cavity_pulse, ampx = self.cavity_ampx)
        self.cavity.play(self.cavity_pulse, ampx = self.cavity_ampx)
        self.cavity.play(self.cavity_pulse, ampx = self.cavity_ampx)
        qua.align()


        self.qubit.play(self.qubit_pulse) # pi/2
        qua.wait(self.delay, self.qubit)  # wait
        self.qubit.play(self.qubit_pulse) # pi/2
        qua.align()

        self.cavity.play(self.cavity_pulse, ampx = -self.cavity_ampx)
        self.cavity.play(self.cavity_pulse, ampx = -self.cavity_ampx)
        self.cavity.play(self.cavity_pulse, ampx = -self.cavity_ampx)
        qua.align()

        self.resonator.measure(self.readout_pulse, (self.I, self.Q), ampx=self.ro_ampx,  demod_type="dual")
        if self.plot_single_shot:  # assign state to G or E
            qm_qua.assign(self.single_shot, qm_qua.Cast.to_fixed(self.I > self.readout_pulse.threshold),)
        qua.wait(self.wait_time, self.resonator)

if __name__ == "__main__":
    """ """

    #################################### MODE MAP ######################################
    # key: name of the Mode as defined by the Experiment subclass
    # value: name of the Mode as defined by the user in modes.yml

    modes = {
        # "qubitAGF": "qA",
        # "driveA": "driveA",
        "cavity": "cavA",
        "qubit": "qC",
        "resonator": "rrC",
    }

    ################################### PULSE MAP ######################################
    # key: name of the Pulse as defined by the Experiment subclass
    # value: name of the Pulse as defined by the user in modes.yml

    pulses = {
        # "qubitA_drive": "qubitAGF_gaussian_pi_pulse",
        # "driveA_pulse": "driveA_constant_ramp_pulse_short",
        "cavity_pulse": "cavA_ramp_pulse",
        "qubit_pulse": "qC_gaussian_pi2_pulse",
        "readout_pulse": "rrC_readout_pulse",
    }

    ############################## CONTROL PARAMETERS ##################################

    parameters = {
        "wait_time": 5e6,
        "ro_ampx": 1,
        "cavity_ampx": 1,
        "fetch_interval": 1,
        "plot_single_shot": True,
        "qubit_drive_ampx": 1.0,
    }

    ######################## SWEEP (INDEPENDENT) VARIABLES #############################
    # must include an outermost averaging Sweep named "N"
    # must include all primary sweeps defined by the Experiment subclass

    # set number of repetitions for this Experiment run
    N.num = 10000

    # set the qubit frequency sweep for this Experiment run
    DELAY = Sweep(
        name="delay",
        dtype=int,
        start=850,
        stop=1200,
        step=4,
    )

    sweeps = [N, DELAY]

    ######################## DATASET (DEPENDENT) VARIABLES #############################
    # must include all primary datasets defined by the Experiment subclass
    # MAG.fitfn = "gaussian"

    PHASE.datafn_args = {"delay": 2.792e-7, "freq": RRC.int_freq}
    MAG.plot = False
    # I.plot = False
    #Q.plot = False
    PHASE.plot = False,
    # I.fitfn = "gaussian"
    datasets = [I, Q, SINGLE_SHOT]

    ######################## INITIALIZE AND RUN EXPERIMENT #############################

    expt = RamseyRevival(FOLDER, modes, pulses, sweeps, datasets, **parameters)
    expt.run()
