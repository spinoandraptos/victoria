#%%
from scipy import optimize
import time
import numpy as np
from scipy.linalg import expm
import matplotlib.pyplot as plt
from qutip import *
from TK_basics import *
start_time = time.time()#checking how long the code takes

NM = 2#no of modes
D = 3#dimension to read
n_para1 = D**2-1#no para for single mode
Dt = D**NM#total dimension to read

#no of displacements on one mode
AL = np.array([ 0.21841281+0.40857803j,  1.27526808-0.03944858j,
        0.78701447+1.30379379j, -0.24961871+0.75413147j,
       -1.41136609+0.57889231j, -0.90260273+0.21038691j,
       -1.08786047-0.8881262j , -0.65582081+1.10398337j,
       -0.61667827-0.46690001j,  0.24196665-0.39232866j,
        0.58342168+0.66363423j,  0.16148649-1.47437816j,
       -0.46327263-0.0140931j ,  0.41139432-0.76836481j,
        0.75615557+0.13199463j])
n_dis = len(AL)

# xi = 1e-2 #strength for the added exp errors
RM = n_dis**NM #no of readouts
nD = (Dt)**2-1 #no of parameters for general states
Ntr = 1 #no of training for obtaining the map, at least Dt^2

cdim = 20 #truncation of one mode
cdimt = cdim**NM#total dimension
a = np.kron(destroy(cdim).full(), np.eye(cdim)) #annihilation for cavity1
b = np.kron(np.eye(cdim), destroy(cdim).full()) #annihilation for cavity2
adag = a.T.conj()
bdag = b.T.conj()
u22 = np.kron(fock(cdim,2).full(), fock(cdim,2).full())
p22 = u22@u22.T.conj()

#this part is for obtaining the map
X_r = np.zeros([1+RM, Ntr], dtype = float) #store readouts
X_r[0,:] = np.ones([1, Ntr]) #setting the ones
Y_r = np.zeros([nD, Ntr], dtype = np.complex128) #store the targets
for j in np.arange(0, Ntr):
    uin_qobj_trun = (tensor(fock(D,0),fock(D,1))+tensor(fock(D,1),fock(D,0))).unit()
    rdt_trun = ket2dm(uin_qobj_trun).full()

    uin_qobj = (tensor(fock(cdim,0),fock(cdim,1))+tensor(fock(cdim,1),fock(cdim,0))).unit()
    rdt = ket2dm(uin_qobj).full()

    #assign targets
    cw = 0
    #diagonal elements
    for j1 in np.arange(0, Dt-1):
        Y_r[cw, j] = rdt_trun[j1, j1].real
        cw += 1
    #off-diagonal elements
    for j1 in np.arange(0, Dt-1):
        for j2 in np.arange(j1+1, Dt):
            Y_r[cw, j] = rdt_trun[j1, j2].real
            cw += 1
            Y_r[cw, j] = rdt_trun[j1, j2].imag
            cw += 1
    # for j1 in range(nD):
    #     Y_r[cw, j] = np.trace(Gt[j1]@rdt_trun)
    #     cw += 1#assign targets
    
    w = 0
    for v1 in range(n_dis):
        for v2 in range(n_dis):
            U = expm(AL[v1]*adag-np.conj(AL[v1])*a+AL[v2]*bdag-np.conj(AL[v2])*b)
            X_r[w+1, j] = np.trace(U@rdt@U.T.conj()@ p22 ).real 
            w += 1

# Mapping
# data = np.load(r"C:\Users\tanju\Dropbox\NTU Grad\Research\Python codes\nus_tomo_23\20230619_condition_number\map_ideal_D3_new.npz")
data = np.load("/Users/tanjungkrisnanda/Library/CloudStorage/Dropbox/NTU Grad/Research/Python codes/nus_tomo_23/20230619_condition_number/map_ideal_D3_newreim_newdis.npz")
W = data["W"]
beta = data["beta"]

n_obs = beta.shape[0]
C = np.matmul(-W, beta[:, 0])
BETA = np.zeros([nD, n_obs + 1])
BETA[:, 0] = C
BETA[:, 1 : n_obs + 1] = W

Y_est = np.matmul(BETA, X_r) 

cw = 0
r_est = np.zeros([Dt, Dt], dtype = np.complex128)
# diagonal elements
for j1 in np.arange(0, Dt-1):
    r_est[j1, j1] = Y_est[cw, j]
    cw += 1
r_est[Dt-1,Dt-1] = 1 - np.trace(r_est)
# off-diagonal elements
for j1 in np.arange(0, Dt-1):
    for j2 in np.arange(j1+1, Dt):
        real_part = Y_est[cw, j]
        cw += 1
        imag_part = Y_est[cw, j]
        cw += 1
        r_est[j1, j2] = real_part + 1j * imag_part
        r_est[j2, j1] = real_part - 1j * imag_part  # Hermitian conjugate

#just linear inversion
qRho_est = Qobj(r_est)
#maximum likelihood
# qRho_est = PSD_rho(qRho_est.full())
#Bayesian inference
# _, _, qRho_est = Bysn_rho_v2(2**10, 8998*(nD), rdt_trun, qRho_est.full())


fidel = fidelity(Qobj(rdt_trun), qRho_est)
print(f'fidelity is {fidel}')

print("")
print("--- %s seconds ---" % (time.time() - start_time))

