#%%
from scipy import optimize
import time
import numpy as np
import matplotlib.pyplot as plt
from qutip import destroy, Qobj, rand_ket
from TK_basics import *
start_time = time.time()#checking how long the code takes

#the optimization
D = 3#dimension to read

AL = np.array([ 0.21841281+0.40857803j,  1.27526808-0.03944858j,
        0.78701447+1.30379379j, -0.24961871+0.75413147j,
       -1.41136609+0.57889231j, -0.90260273+0.21038691j,
       -1.08786047-0.8881262j , -0.65582081+1.10398337j,
       -0.61667827-0.46690001j,  0.24196665-0.39232866j,
        0.58342168+0.66363423j,  0.16148649-1.47437816j,
       -0.46327263-0.0140931j ,  0.41139432-0.76836481j,
        0.75615557+0.13199463j])
n_dis = len(AL)


# def singleC_func(AL):
    
xi = 1e-2 #strength for the added exp errors
TM = n_dis #no of time multiplexing instances
TM1 = 0*3
TM2 = 1*n_dis
TM3 = 0
TM4 = 0*2*24
TM5 = 0*1*35
TM6 = 0*1*48
TM7 = 0*63
TM10 = 0*120
# D = int(np.sqrt(TM+1)) #dimension to read
NM = 1 #no of diag elements read from rho
RM = TM*NM #no of readouts, at least D^2-1
nD = D**2-1 #no of parameters for general states
Ntr = 1 #no of training for obtaining the map, at least D^2

cdim = 50 #truncation 
a = destroy(cdim) #annihilation for cavity

#displacement operator
def Dis(alpha):
    U = (alpha*a.dag()-np.conj(alpha)*a).expm()
    return U

#this part if for obtaining the map
X_r = np.zeros([1+RM, Ntr]) #store readouts
X_r[0,:] = np.ones([1, Ntr]) #setting the ones
Y_r = np.zeros([nD, Ntr]) #store the targets
for j in np.arange(0, Ntr):
    #qudit mixed state embedded in the cavity mode
    rd1 = np.zeros([cdim, cdim], dtype = np.complex128)
    u_rand = (fock(D,0) + fock(D,1) + fock(D,2)).unit()
    r_rand = (u_rand*u_rand.dag()).full()
    rd1[0:D,0:D] = r_rand#randRho(D)

    #assign targets
    cw = 0
    #diagonal elements
    for j1 in np.arange(0, D-1):
        Y_r[cw, j] = rd1[j1, j1].real
        cw += 1
    #off-diagonal elements
    for j1 in np.arange(0, D-1):
        for j2 in np.arange(j1+1, D):
            Y_r[cw, j] = rd1[j1, j2].real
            cw += 1
            Y_r[cw, j] = rd1[j1, j2].imag
            cw += 1
    
    r0 = Qobj(rd1)
    #evolution (time multiplexing)
    # rt = r0
    w = 0
    for v in np.arange(0, TM1):
        #T = float(T)#because the optimize gives T an np.array type
        U = Dis(AL[w])
        rt = U*r0*U.dag()
        X_r[w+1, j] = rt[1, 1].real #+ 0*np.random.normal(0, xi, 1)
        w += 1
    for v1 in np.arange(0, TM2):
        #T = float(T)#because the optimize gives T an np.array type
        U = Dis(AL[w])
        rt = U*r0*U.dag()
        X_r[w+1, j] = rt[2, 2].real #+ 0*np.random.normal(0, xi, 1)
        w += 1
    for v2 in np.arange(0, TM3):
        #T = float(T)#because the optimize gives T an np.array type
        U = Dis(AL[w])
        rt = U*r0*U.dag()
        X_r[w+1, j] = rt[3, 3].real #+ 0*np.random.normal(0, xi, 1)
        w += 1
    for v3 in np.arange(0, TM4):
        #T = float(T)#because the optimize gives T an np.array type
        U = Dis(AL[w])
        rt = U*r0*U.dag()
        X_r[w+1, j] = rt[4, 4].real #+ 0*np.random.normal(0, xi, 1)
        w += 1
    for v4 in np.arange(0, TM5):
        #T = float(T)#because the optimize gives T an np.array type
        U = Dis(AL[w])
        rt = U*r0*U.dag()
        X_r[w+1, j] = rt[5, 5].real #+ 0*np.random.normal(0, xi, 1)
        w += 1
    for v5 in np.arange(0, TM6):
        #T = float(T)#because the optimize gives T an np.array type
        U = Dis(AL[w])
        rt = U*r0*U.dag()
        X_r[w+1, j] = rt[6, 6].real #+ 0*np.random.normal(0, xi, 1)
        w += 1
    for v6 in np.arange(0, TM7):
        #T = float(T)#because the optimize gives T an np.array type
        U = Dis(AL[w])
        rt = U*r0*U.dag()
        X_r[w+1, j] = rt[7, 7].real #+ 0*np.random.normal(0, xi, 1)
        w += 1
    for v9 in np.arange(0, TM10):
        #T = float(T)#because the optimize gives T an np.array type
        U = Dis(AL[w])
        rt = U*r0*U.dag()
        X_r[w+1, j] = rt[10, 10].real #+ 0*np.random.normal(0, xi, 1)
        w += 1

# Mapping
# Mapping
# data = np.load(r"C:\Users\tanju\Dropbox\NTU Grad\Research\Python codes\nus_tomo_23\20230619_condition_number\map_ideal_D3_new.npz")
data = np.load("/Users/tanjungkrisnanda/Library/CloudStorage/Dropbox/NTU Grad/Research/Python codes/nus_tomo_23/20230619_condition_number/map_ideal_D3_newreim_newdis_1mode.npz")
W = data["W"]
beta = data["beta"]

n_obs = beta.shape[0]
C = np.matmul(-W, beta[:, 0])
BETA = np.zeros([nD, n_obs + 1])
BETA[:, 0] = C
BETA[:, 1 : n_obs + 1] = W

Y_est = np.matmul(BETA, X_r)

# Initialize rd1
r_est = np.zeros((D, D), dtype=complex)

cw = 0
# diagonal elements
for j1 in np.arange(0, D-1):
    r_est[j1, j1] = Y_est[cw, j]
    cw += 1
r_est[D-1,D-1] = 1 - np.trace(r_est)
# off-diagonal elements
for j1 in np.arange(0, D-1):
    for j2 in np.arange(j1+1, D):
        real_part = Y_est[cw, j]
        cw += 1
        imag_part = Y_est[cw, j]
        cw += 1
        r_est[j1, j2] = real_part + 1j * imag_part
        r_est[j2, j1] = real_part - 1j * imag_part  # Hermitian conjugate

#just linear inversion
qRho_est = Qobj(r_est)
#maximum likelihood
# qRho_est = PSD_rho(qRho_est.full())
#Bayesian inference
# _, _, qRho_est = Bysn_rho_v2(2**10, 8998*(nD), rdt_trun, qRho_est.full())


print(f'Fidelity is {fidelity(Qobj(r_rand), qRho_est)}')

print("")
print("--- %s seconds ---" % (time.time() - start_time))

# %%
