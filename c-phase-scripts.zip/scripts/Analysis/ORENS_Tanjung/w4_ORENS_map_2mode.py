#%%
from scipy import optimize
import time
import numpy as np
from scipy.linalg import expm
import matplotlib.pyplot as plt
from qutip import *
from TK_basics import *
start_time = time.time()#checking how long the code takes

NM = 2#no of modes
D = 3#dimension to read
n_para1 = D**2-1#no para for single mode
Dt = D**NM#total dimension to read

#no of displacements on one mode
# AL = np.array([ 0.21841281+0.40857803j,  1.27526808-0.03944858j,
#         0.78701447+1.30379379j, -0.24961871+0.75413147j,
#        -1.41136609+0.57889231j, -0.90260273+0.21038691j,
#        -1.08786047-0.8881262j , -0.65582081+1.10398337j,
#        -0.61667827-0.46690001j,  0.24196665-0.39232866j,
#         0.58342168+0.66363423j,  0.16148649-1.47437816j,
#        -0.46327263-0.0140931j ,  0.41139432-0.76836481j,
#         0.75615557+0.13199463j])



# AL= np.array([-0.67152985-0.34296374j,
#                 0.4261962 +0.29391114j,
#                 0.97668197-0.76566442j,
#                 -0.30305089+0.2026751j,
#                 0.03902931-0.43510274j])
AL = np.array([
    0.17810928-1.32101934j,
    -0.21121299-0.41773907j,
    0.73130212+1.11075067j,
    -0.39162883+0.77796174j,
    -1.03344266+0.98572183j,
    0.48593934+0.03767621j,
    -1.3205937 -0.20939208j,
    -0.44173141-0.69979338j,
    0.86497711-0.02507866j,
    -0.2604925 +0.39819938j
    ])

n_dis = len(AL)

# xi = 1e-2 #strength for the added exp errors
RM = n_dis**NM #no of readouts
nD = (Dt)**2-1 #no of parameters for general states
Ntr = (Dt)**2 #no of training for obtaining the map, at least Dt^2

cdim = 20 #truncation of one mode
cdimt = cdim**NM#total dimension
a = np.kron(destroy(cdim).full(), np.eye(cdim)) #annihilation for cavity1
b = np.kron(np.eye(cdim), destroy(cdim).full()) #annihilation for cavity2
adag = a.T.conj()
bdag = b.T.conj()
u11 = np.kron(fock(cdim,2).full(), fock(cdim,2).full()) # CHANGE DEPEPNDING ON FOCK STATE
p11 = u11@u11.T.conj()

#this part is for obtaining the map
X_r = np.zeros([1+RM, Ntr], dtype = float) #store readouts
X_r[0,:] = np.ones([1, Ntr]) #setting the ones
Y_r = np.zeros([nD, Ntr], dtype = float) #store the targets
for j in np.arange(0, Ntr):
    #qudit mixed state embedded in the cavity mode
    rd1 = np.zeros([cdim, cdim], dtype = np.complex128)
    rd2 = np.zeros([cdim, cdim], dtype = np.complex128)
    # rdt = np.zeros([cdimt, cdimt], dtype = np.complex128)
    r1_rand = ket2dm(rand_ket(D)).full()
    r2_rand = ket2dm(rand_ket(D)).full()
    rdtrun = np.kron(r1_rand, r2_rand)#total state (within Dt)
    rd1[0:D,0:D] = r1_rand
    rd2[0:D,0:D] = r2_rand
    rdt = np.kron(rd1, rd2)#total state (within cdimt)

    #assign targets
    cw = 0
    # diagonal elements
    for j1 in np.arange(0, Dt-1):
        Y_r[cw, j] = rdtrun[j1, j1].real
        cw += 1
    #off-diagonal elements
    for j1 in np.arange(0, Dt-1):
        for j2 in np.arange(j1+1, Dt):
            Y_r[cw, j] = rdtrun[j1, j2].real
            cw += 1
            Y_r[cw, j] = rdtrun[j1, j2].imag
            cw += 1
    # for j1 in range(nD):
    #     Y_r[cw, j] = np.trace(Gt[j1]@rdtrun).real
    #     cw += 1
    
    # r0 = Qobj(rd1)
    # rt = r0
    w = 0
    for v1 in range(n_dis):
        for v2 in range(n_dis):
            U = expm(AL[v1]*adag-np.conj(AL[v1])*a+AL[v2]*bdag-np.conj(AL[v2])*b)
            X_r[w+1, j] = np.trace(U.T.conj()@rdt@U@ p11 ).real
            w += 1

#ridge regression
lamb = 0

#training, now to obtain the map
X_R = np.zeros([1+nD, Ntr], dtype = float) #will contain the parameters
X_R[0,:] = np.ones([1, Ntr]) #setting the ones
Y_R = np.zeros([RM, Ntr], dtype = float) #will contain the obs

#re-defining variables
X_R[1:nD+1,:] = Y_r
Y_R[:,:] = X_r[1:RM+1,:]

Error, beta = QN_regression(X_R, Y_R, lamb)

M = beta[:,1:nD+1] #the map
W = np.matmul(np.linalg.inv(np.matmul(np.transpose(M),M)),np.transpose(M))
eta = np.linalg.norm(M,2)*np.linalg.norm(W,2)
print(f'Error is {Error}')
print(eta)


print("")
print("--- %s seconds ---" % (time.time() - start_time))

# import os
# os.chdir(r"C:\Users\tanju\Dropbox\NTU Grad\Research\Python codes\nus_tomo_23\20230619_condition_number")
M = beta[:, 1 : nD + 1]  
W = np.matmul(np.linalg.inv(np.matmul(np.transpose(M), M)), np.transpose(M))
CN = np.linalg.norm(M, 2) * np.linalg.norm(W, 2)
print(f"Condition number is {CN}")
np.savez(f"Map_Ideal_D{D}_2modes_fock2_100points.npz", 
         M = M, W = W, beta = beta, CN = eta)


# %%
