#%%
from scipy import optimize
import time
import numpy as np
import matplotlib.pyplot as plt
from qutip import destroy, Qobj, rand_ket
from TK_basics import *
start_time = time.time()#checking how long the code takes

# #the optimization
D = 3 #dimension to read

# AL = np.array([ 0.21841281+0.40857803j,  1.27526808-0.03944858j,
#         0.78701447+1.30379379j, -0.24961871+0.75413147j,
#        -1.41136609+0.57889231j, -0.90260273+0.21038691j,
#        -1.08786047-0.8881262j , -0.65582081+1.10398337j,
#        -0.61667827-0.46690001j,  0.24196665-0.39232866j,
#         0.58342168+0.66363423j,  0.16148649-1.47437816j,
#        -0.46327263-0.0140931j ,  0.41139432-0.76836481j,
#         0.75615557+0.13199463j])


AL = np.array([
    0.17810928-1.32101934j,
    -0.21121299-0.41773907j,
    0.73130212+1.11075067j,
    -0.39162883+0.77796174j,
    -1.03344266+0.98572183j,
    0.48593934+0.03767621j,
    -1.3205937 -0.20939208j,
    -0.44173141-0.69979338j,
    0.86497711-0.02507866j,
    -0.2604925 +0.39819938j
    ])




#the optimization
#D = 2#dimension to read


# AL = np.array([-0.67152985-0.34296374j,
#                 0.4261962 +0.29391114j,
#                 0.97668197-0.76566442j,
#                 -0.30305089+0.2026751j,
#                 0.03902931-0.43510274j])

n_dis = len(AL)

# def singleC_func(AL):
    
xi = 1e-2 #strength for the added exp errors
TM = n_dis #no of time multiplexing instances
TM1 = 0
TM2 = n_dis
TM3 = 0
TM4 = 0*2*24
TM5 = 0*1*35
TM6 = 0*1*48
TM7 = 0*63
TM10 = 0*120
# D = int(np.sqrt(TM+1)) #dimension to read
NM = 1 #no of diag elements read from rho
RM = TM*NM #no of readouts, at least D^2-1
nD = D**2-1 #no of parameters for general states
Ntr = D**2 #no of training for obtaining the map, at least D^2

cdim = 50 #truncation 
a = destroy(cdim) #annihilation for cavity

#displacement operator
def Dis(alpha):
    U = (alpha*a.dag()-np.conj(alpha)*a).expm()
    return U

#this part if for obtaining the map
X_r = np.zeros([1+RM, Ntr]) #store readouts
X_r[0,:] = np.ones([1, Ntr]) #setting the ones
Y_r = np.zeros([nD, Ntr]) #store the targets
for j in np.arange(0, Ntr):
    #qudit mixed state embedded in the cavity mode
    rd1 = np.zeros([cdim, cdim], dtype = np.complex128)
    u_rand = rand_ket(D)
    r_rand = (u_rand*u_rand.dag()).full()
    rd1[0:D,0:D] = r_rand#randRho(D)

    #assign targets
    cw = 0
    #diagonal elements
    for j1 in np.arange(0, D-1):
        Y_r[cw, j] = rd1[j1, j1].real
        cw += 1
    #off-diagonal elements
    for j1 in np.arange(0, D-1):
        for j2 in np.arange(j1+1, D):
            Y_r[cw, j] = rd1[j1, j2].real
            cw += 1
            Y_r[cw, j] = rd1[j1, j2].imag
            cw += 1
    
    r0 = Qobj(rd1)
    #evolution (time multiplexing)
    # rt = r0
    w = 0
    for v in np.arange(0, TM1):
        #T = float(T)#because the optimize gives T an np.array type
        U = Dis(AL[w])
        rt = U.dag()*r0*U
        X_r[w+1, j] = rt[1, 1].real #+ 0*np.random.normal(0, xi, 1)
        w += 1
    for v1 in np.arange(0, TM2):
        #T = float(T)#because the optimize gives T an np.array type
        U = Dis(AL[w])
        rt = U*r0*U.dag()
        X_r[w+1, j] = rt[2, 2].real #+ 0*np.random.normal(0, xi, 1)
        w += 1
    for v2 in np.arange(0, TM3):
        #T = float(T)#because the optimize gives T an np.array type
        U = Dis(AL[w])
        rt = U*r0*U.dag()
        X_r[w+1, j] = rt[3, 3].real #+ 0*np.random.normal(0, xi, 1)
        w += 1
    for v3 in np.arange(0, TM4):
        #T = float(T)#because the optimize gives T an np.array type
        U = Dis(AL[w])
        rt = U*r0*U.dag()
        X_r[w+1, j] = rt[4, 4].real #+ 0*np.random.normal(0, xi, 1)
        w += 1
    for v4 in np.arange(0, TM5):
        #T = float(T)#because the optimize gives T an np.array type
        U = Dis(AL[w])
        rt = U*r0*U.dag()
        X_r[w+1, j] = rt[5, 5].real #+ 0*np.random.normal(0, xi, 1)
        w += 1
    for v5 in np.arange(0, TM6):
        #T = float(T)#because the optimize gives T an np.array type
        U = Dis(AL[w])
        rt = U*r0*U.dag()
        X_r[w+1, j] = rt[6, 6].real #+ 0*np.random.normal(0, xi, 1)
        w += 1
    for v6 in np.arange(0, TM7):
        #T = float(T)#because the optimize gives T an np.array type
        U = Dis(AL[w])
        rt = U*r0*U.dag()
        X_r[w+1, j] = rt[7, 7].real #+ 0*np.random.normal(0, xi, 1)
        w += 1
    for v9 in np.arange(0, TM10):
        #T = float(T)#because the optimize gives T an np.array type
        U = Dis(AL[w])
        rt = U*r0*U.dag()
        X_r[w+1, j] = rt[10, 10].real #+ 0*np.random.normal(0, xi, 1)
        w += 1

#ridge regression
lamb = 0

#training, now to obtain the map
X_R = np.zeros([1+nD, Ntr]) #will contain the parameters
X_R[0,:] = np.ones([1, Ntr]) #setting the ones
Y_R = np.zeros([RM, Ntr]) #will contain the obs

#re-defining variables
X_R[1:nD+1,:] = Y_r
Y_R[:,:] = X_r[1:RM+1,:]

Error, beta = QN_regression(X_R, Y_R, lamb)

M = beta[:,1:nD+1] #the map
W = np.matmul(np.linalg.inv(np.matmul(np.transpose(M),M)),np.transpose(M))
eta = np.linalg.norm(M,2)*np.linalg.norm(W,2)
print(eta)


print("")
print("--- %s seconds ---" % (time.time() - start_time))


# import os
# os.chdir("/Users/tanjungkrisnanda/Library/CloudStorage/Dropbox/NTU Grad/Research/Python codes/nus_tomo_23/20230619_condition_number")
M = beta[:, 1 : nD + 1]  
W = np.matmul(np.linalg.inv(np.matmul(np.transpose(M), M)), np.transpose(M))
CN = np.linalg.norm(M, 2) * np.linalg.norm(W, 2)
print(f"Condition number is {CN}")
np.savez(f"Map_Ideal_D{D}_1mode_fock2_10points.npz", M = M, W = W, beta = beta, CN = eta)

# %%
