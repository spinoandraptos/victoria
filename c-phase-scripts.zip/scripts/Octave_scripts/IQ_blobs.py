"""
        IQ BLOBS
This sequence involves measuring the state of the resonator 'N' times, first after thermalization (with the qubit
in the |g> state) and then after applying a pi pulse to the qubit (bringing the qubit to the |e> state) successively.
The resulting IQ blobs are displayed, and the data is processed to determine:
    - The rotation angle required for the integration weights, ensuring that the separation between |g> and |e> states
      aligns with the 'I' quadrature.
    - The threshold along the 'I' quadrature for effective qubit state discrimination.
    - The readout fidelity matrix, which is also influenced by the pi pulse fidelity.

Prerequisites:
    - Having found the resonance frequency of the resonator coupled to the qubit under study (resonator_spectroscopy).
    - Having calibrated qubit pi pulse (x180) by running qubit, spectroscopy, rabi_chevron, power_rabi and updated the config.

Next steps before going to the next node:
    - Update the rotation angle (rotation_angle) in the configuration.
    - Update the g -> e threshold (ge_threshold) in the configuration.
"""
from qcore.helpers import Stage
from qm.qua import *
from qm import SimulationConfig
from qm.QuantumMachinesManager import QuantumMachinesManager

# from configuration import *
from qualang_tools.analysis.discriminator import two_state_discriminator
import matplotlib.pyplot as plt
from qualang_tools.units import unit
from qcore.instruments import QM
import sys

sys.path.append("C:/Users/admin/Desktop/qcore-yabba/yabba-main/")
from config.experiment_config import MODES_CONFIG

u = unit(coerce_to_integer=True)

###################
# The QUA program #
###################


with Stage(configpath=MODES_CONFIG, remote=True) as stage:
    # RETRIEVE INSTRUMENTS AND MODES
    # lo_cav, lo_qubit, lo_rr = stage.get("lo_cav", "lo_qubit", "lo_rr")
    cav, qubit, qubitEF, rr = stage.get("cav", "qubit", "qubitEF", "rr")
    (octave,) = stage.get("oct1")
    # sa = stage.get("sa")

    modes = (cav, qubit, rr)
    oscillators = (octave,)
    qm = QM(modes, oscillators)
    qm._qcb.build_config(modes, oscillators)


n_runs = 10000  # Number of runs
thermalization_time = 500 * u.us

with program() as IQ_blobs:
    n = declare(int)
    a = declare(fixed, value=1)
    I_g = declare(fixed)
    Q_g = declare(fixed)
    I_g_st = declare_stream()
    Q_g_st = declare_stream()
    I_e = declare(fixed)
    Q_e = declare(fixed)
    I_e_st = declare_stream()
    Q_e_st = declare_stream()

    with for_(n, 0, n < n_runs, n + 1):
        # Measure the state of the resonator
        measure(
            "rr_readout_pulse",
            "rr",
            None,
            dual_demod.full("cos", "out1", "sin", "out2", I_g),
            dual_demod.full("sin", "out1", "cos", "out2", Q_g),
        )
        # Wait for the qubit to decay to the ground state in the case of measurement induced transitions
        wait(thermalization_time * u.ns, "rr")
        # Save the 'I' & 'Q' quadratures to their respective streams for the ground state
        save(I_g, I_g_st)
        save(Q_g, Q_g_st)

        align()  # global align
        # Play the x180 gate to put the qubit in the excited state
        play("qubit_gaussian_short_pi_pulse" * amp(a), "qubit")
        # Align the two elements to measure after playing the qubit pulse.
        align("qubit", "rr")
        # Measure the state of the resonator
        measure(
            "rr_readout_pulse",
            "rr",
            None,
            dual_demod.full("cos", "out1", "sin", "out2", I_e),
            dual_demod.full("sin", "out1", "cos", "out2", Q_e),
        )
        # Wait for the qubit to decay to the ground state
        wait(thermalization_time * u.ns, "rr")
        # Save the 'I' & 'Q' quadratures to their respective streams for the excited state
        save(I_e, I_e_st)
        save(Q_e, Q_e_st)

    with stream_processing():
        # Save all streamed points for plotting the IQ blobs
        I_g_st.save_all("I_g")
        Q_g_st.save_all("Q_g")
        I_e_st.save_all("I_e")
        Q_e_st.save_all("Q_e")

# Send the QUA program to the OPX, which compiles and executes it
job = qm._qm.execute(IQ_blobs)
# Creates a result handle to fetch data from the OPX
res_handles = job.result_handles
# Waits (blocks the Python console) until all results have been acquired
res_handles.wait_for_all_values()
# Fetch the 'I' & 'Q' points for the qubit in the ground and excited states
Ig = res_handles.get("I_g").fetch_all()["value"]
Qg = res_handles.get("Q_g").fetch_all()["value"]
Ie = res_handles.get("I_e").fetch_all()["value"]
Qe = res_handles.get("Q_e").fetch_all()["value"]
# Plot the IQ blobs, rotate them to get the separation along the 'I' quadrature, estimate a threshold between them
# for state discrimination and derive the fidelity matrix
angle, threshold, fidelity, gg, ge, eg, ee = two_state_discriminator(
    Ig, Qg, Ie, Qe, b_print=True, b_plot=True
)
plt.show()
