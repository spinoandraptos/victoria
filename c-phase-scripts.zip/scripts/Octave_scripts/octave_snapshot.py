# %%
from typing import Optional, Union, Any, List, Tuple
from enum import Enum


class LineStyle(Enum):
    ROUNDED = 1
    THIN = 2
    THICK = 3
    DOUBLE = 4
    DASHED = 5

class TudiText:

    def __init__(self, content: Optional[str] = None):
        if content is None:
            self._lines: List[str] = []
            self._mask: List[int] = []

        else:
            self._lines = content.split("\n")
            self._mask = [
                (1 << len(line))-1
                for line in self._lines
            ]

    @staticmethod
    def frame(width: int, height: int, style: LineStyle = LineStyle.THIN):
        assert 2 <= width <= 200, "Please be reasonable..."
        assert 2 <= height <= 200, "Please be reasonable..."

        res = TudiText()
        res._mask: List[int] = [
            (1 << width)-1 if li in (0, height-1) else 1+(1 << (width-1))
            for li in range(height)
        ]

        s = {
            LineStyle.ROUNDED: u'\u256d\u256e\u2570\u256f\u2500\u2502',
            LineStyle.THIN: u'\u250c\u2510\u2514\u2518\u2500\u2502',
            LineStyle.THICK: u'\u250f\u2513\u2517\u251b\u2501\u2503',
            LineStyle.DOUBLE: u'\u2554\u2557\u255a\u255d\u2550\u2551',
            LineStyle.DASHED: u'\u256d\u256e\u2570\u256f\u254c\u250a',
        }[style]


        top_line = s[0] + s[4]*(width-2) + s[1]
        middle_line = s[5] + ' '*(width-2) + s[5]
        bottom_line = s[2] + s[4]*(width-2) + s[3]

        res._lines = [top_line] + [middle_line]*(height-2) + [bottom_line]

        return res

    @staticmethod
    def line(p: List[Tuple[int, int]], style: LineStyle = LineStyle.THIN, arrow: bool = False) -> "TudiText":
        for pi in range(len(p)-1):
            assert (p[pi][0] == p[pi+1][0]) != (p[pi][1] == p[pi+1][1]), "Must be straight segments"

        sign = lambda x : -1 if x < 0 else 0 if x == 0 else 1
        direc = lambda d : { (0,-1):0, (1,0):1, (0,1):2, (-1,0):3 }[d]

        pd = None
        pi = 0
        cp = p[pi]

        res = TudiText()

        def draw(p: Tuple[int, int], pd: Optional[Tuple[int, int]], cd: Optional[Tuple[int, int]], s: Tuple[str, str, str]):
            if pd is None:
                res.put(*p, s[0][direc(cd)])
            elif cd is None:
                res.put(*p, s[2][direc(pd)])
            else:
                res.put(*p, s[1][direc(pd)*4+direc(cd)])

        s = {
            LineStyle.ROUNDED: (
                u"\u2575\u2576\u2577\u2574",
                u"\u2502\u256d\u2577\u256e\u256f\u2500\u256e\u2574\u2575\u2570\u2502\u256f\u2570\u2576\u256d\u2500",
                u"\u2577\u2574\u2575\u2576"),
            LineStyle.THIN: (
                u"\u2575\u2576\u2577\u2574",
                u"\u2502\u250c\u2577\u2510\u2518\u2500\u2510\u2574\u2575\u2514\u2502\u2518\u2514\u2576\u250c\u2500",
                u"\u2577\u2574\u2575\u2576"),
            LineStyle.THICK: (
                u"\u2579\u257a\u257b\u2578",
                u"\u2503\u250f\u2577\u2513\u251b\u2501\u2513\u2574\u2575\u2517\u2503\u251b\u2517\u2576\u250f\u2501",
                u"\u257b\u2578\u2579\u257a"),
            LineStyle.DASHED: (
                u"\u2575\u2576\u2577\u2574",
                u"\u250a\u256d\u2577\u256e\u256f\u254c\u256e\u2574\u2575\u2570\u250a\u256f\u2570\u2576\u256d\u254c",
                u"\u2577\u2574\u2575\u2576"),
        }[style]

        if arrow:
            s = (s[0], s[1], u"\u25b2\u25ba\u25bc\u25c4")

        while pi < len(p):
            if pi == len(p)-1:
                draw(cp, pd, None, s)
                break

            if cp == p[pi]:
                cd = (sign(p[pi+1][0]-p[pi][0]), sign(p[pi+1][1]-p[pi][1]))

            draw(cp, pd, cd, s)
            cp = (cp[0]+cd[0], cp[1]+cd[1])
            if cp == p[pi+1]:
                pi += 1

            pd = cd



        return res

    def put(self, x: int, y: int, content: Union[str, "TudiText"]) -> "TudiText":
        if isinstance(content, str):
            content = TudiText(content)

        if y+len(content._lines) >= len(self._lines):
            extra_lines = y+len(content._lines)-len(self._lines)
            self._lines += [""]*extra_lines
            self._mask += [0]*extra_lines

        for li in range(y, y+len(content._lines)):
            this_line = self._lines[li]
            that_line = content._lines[li-y]

            this_mask = self._mask[li]
            that_mask = content._mask[li-y]

            line_length = max(len(this_line), x+len(that_line))
            
            new_line = [" "] * line_length
            for ci in range(line_length):
                if ci >= x and ((that_mask >> (ci-x)) & 1):
                    new_line[ci] = that_line[ci-x]

                elif (this_mask >> ci) & 1:
                    new_line[ci] = this_line[ci]

            self._lines[li] = "".join(new_line)
            self._mask[li] |= (that_mask << x)

        return self

    def __repr__(self):
        return "\n".join(self._lines)



from octave_sdk import Octave
from octave_sdk._octave_client import OctaveClient
from octave_sdk.grpc.quantummachines.octave.api.v1 import *

from typing import Optional, Dict, Tuple, List, Mapping


class RfUpconvState:

    def __init__(self, state: RfUpConvUpdate):
        self.temp: Optional[float] = None
        self.state: Optional[RfUpConvUpdate] = state
        self.conn: Optional[RfUpConvIdentityConnectivity] = None

    def __repr__(self):
        lo_input_port = f"{self.conn.lo_input.synth_output.to_dict()['outputPort'][12:]}"
        if len(lo_input_port) > 4:
            lo_input_port = f'({lo_input_port[:3]}.)'
        else:        
            lo_input_port = f'({lo_input_port})'

        if self.state.input_attn == RfUpConvUpdateIfInputSelection.IF_INPUT_SELECTION_ATTENUATE_10DB:
            iq_attn = '[-10dB] '
        else:
            iq_attn = '[BYPASS] '

        fast_switch_mode = f"[{self.state.to_dict()['fastSwitchMode'][17:]}]"

        res = TudiText()
        res.put(10, 3, TudiText.frame(101, 9, LineStyle.ROUNDED))
        res.put(12, 3, f" RF UCONV #{self.state.index} ").put(99, 11, f" {self.temp:0.1f} deg ")
        res.put(27,4, TudiText.frame(16, 7))
        res.put(30,4, " IQ mixer ")
        res.put(30,5,"LO").put(30,7,"I").put(30,9,"Q").put(38,5,"RF")
        res.put(12,6,"LO IN").put(12,8,"I").put(12,10,"Q")
        res.put(9,5,TudiText.line(((0,0),(3,0)), arrow=True))
        res.put(0,5,f"SYNTH #{self.conn.lo_input.synth_output.index}\n{lo_input_port}")

        res.put(77,4, TudiText.frame(10,5))
        res.put(90,4, TudiText.frame(17,5))
        res.put(92,8," fast switch ")

        res.put(19,5,TudiText.line(((0,0),(9,0)), arrow=True))
        if self.state.enabled:
            res.put(14,5,"[+14dB] ")
            res.put(41,5,TudiText.line(((0,0),(6,0)), arrow=True, style=LineStyle.THICK))

            res.put(49,4,"1st amp. stage")

            if self.state.power_amp_enabled:
                res.put(45,5, TudiText.line(((16,0),(25,0),(25,2),(0,2),(0,4),(3,4)), style=LineStyle.THICK, arrow=True))
                res.put(69,7,TudiText.line(((0,2),(5,2),(5,0), (22,0)), style=LineStyle.THICK, arrow=True))

                res.put(50, 9, f"+14dB,[{self.state.power_amp_attn/2:0.1f}dB],+14dB ")
                res.put(48,10,"2nd (optional) amp. stage")
            else:
                res.put(45,5, TudiText.line(((16,0),(25,0),(25,2),(46,2)), style=LineStyle.THICK, arrow=True))

            res.put(49,5,f'+13dB,[-{self.state.mixer_output_attn/2:.1f}dB] ')

        else:
            res.put(14,5,"[OFF] ")
            res.put(41,5,TudiText.line(((0,0),(3,0)), style=LineStyle.THICK))
            res.put(44,5,u"\u2525")
            res.put(75,7,TudiText.line(((0,0),(16,0)), style=LineStyle.THICK, arrow=True))
            res.put(75,7,u"\u251D")


        res.put(96,2,f"TRIG{self.state.index}")
        res.put(97,3,u"\u2574 \u2576")
        res.put(97,4,u"\u2574 \u2576")
        res.put(98,3,TudiText.line(((0,0),(0,1)), arrow=True))
        res.put(98,3,u"\u2502")

        res.put(93,6,f"{fast_switch_mode:^11}")
        res.put(105,7,TudiText.line(((0,0),(6,0)), arrow=True, style=LineStyle.THICK))


        res.put(83,3,u"\u2574 \u2576")
        res.put(83,4,u"\u2574 \u2576")
        res.put(78,9,"direct.\n coupler")
        res.put(80,2,TudiText.line(((4,5),(4,1)),style=LineStyle.THIN, arrow=True))
        res.put(84,7, u"\u2537")
        res.put(79,5,"-20dB")
        res.put(79,1,f"RF DCONV #2\n  (DBG{self.state.index})")

        res.put(6,7,f'I{self.conn.i_input.external_if_input.i_index}')
        res.put(9,7,TudiText.line(((0,0),(3,0)), arrow=True))
        res.put(20,7,TudiText.line(((0,0),(8,0)), arrow=True))
        res.put(14,7,iq_attn)

        res.put(6,9,f'Q{self.conn.i_input.external_if_input.i_index}')
        res.put(9,9,TudiText.line(((0,0),(3,0)), arrow=True))
        res.put(18,9,TudiText.line(((0,0),(10,0)), arrow=True))
        res.put(14,9,iq_attn)

        res.put(113, 7, f'RF{self.state.index}')
        return res.__repr__()

class RfDownconvState:

    def __init__(self, state = RfDownConvUpdate):
        self.temp: Optional[float] = None
        self.state: Optional[RfDownConvUpdate] = state
        self.conn: Optional[RfDownConvIdentityConnectivity] = None

    def __repr__(self):

        lo1_synth = self.conn.lo_input_1.synth_output.index
        lo1_port = self.conn.lo_input_1.synth_output.to_dict()['outputPort'][12:]
        if len(lo1_port) > 4:
            lo1_port = f'({lo1_port[:3]}.)'
        else:
            lo1_port = f'({lo1_port})'

        lo2_synth = self.conn.lo_input_2.synth_output.index
        lo2_port = self.conn.lo_input_2.synth_output.to_dict()['outputPort'][12:]
        if len(lo2_port) > 4:
            lo2_port = f'({lo2_port[:3]}.)'
        else:
            lo2_port = f'({lo2_port})'

        res = TudiText()
        res.put(10, 3, TudiText.frame(75, 10, LineStyle.ROUNDED))

        res.put(12,3, f" RF DCONV #{self.state.index} ").put(73, 12, f" {self.temp:0.1f} deg ")


        res.put(1,5, f"RF {self.state.index} IN")
        res.put(0,8,f"SYNTH #{lo1_synth}\n{lo1_port}")
        res.put(0,10,f"SYNTH #{lo2_synth}\n{lo2_port}")

        res.put(12,6,"RF MAIN")
        res.put(12,9,"LO IN 1")
        res.put(12,11,"LO IN 2")


        if not self.state.enabled or self.state.lo_input == RfDownConvUpdateLoInput.LO_INPUT_2:
            res.put(8, 8, TudiText.line(((0,0), (6,0))))
            res.put(14, 8, u"\u2524")

        if not self.state.enabled or self.state.lo_input == RfDownConvUpdateLoInput.LO_INPUT_1:
            res.put(8, 10, TudiText.line(((0,0), (6,0))))
            res.put(14, 10, u"\u2524")
    
        res.put(36,6,TudiText.frame(14,5))
        res.put(38,10, " IQ mixer ")

        res.put(39,7,"RF     I\n\nLO     Q")

        res.put(32,9, TudiText.line(((0,0), (5,0)), arrow=True))
        if self.state.enabled:
            if self.state.lo_input == RfDownConvUpdateLoInput.LO_INPUT_1:
                res.put(8, 8, TudiText.line(((0,0), (13,0), (13,1), (17,1)), arrow=True, style=LineStyle.ROUNDED))
        
            else:
                res.put(8, 9, TudiText.line(((0,1), (13,1), (13,0), (17,0)), arrow=True, style=LineStyle.ROUNDED))

            res.put(26,9," +11dB ")
        else:
            res.put(32,9, u"\u251c")

        if self.state.rf_input != RfDownConvUpdateRfInput.RF_INPUT_MAIN:
            res.put(8,5, TudiText.line(((0,0),(6,0))))
            res.put(14,5, u"\u2524")

        elif self.state.rf_input == RfDownConvUpdateRfInput.RF_INPUT_MAIN:
            res.put(8,5, TudiText.line(((0,0),(17,0),(17,2),(29,2)), arrow=True, style=LineStyle.ROUNDED))

        if self.state.rf_input == RfDownConvUpdateRfInput.RF_INPUT_DISCONNECT:
            res.put(32,7,TudiText.line(((0,0), (5,0)), arrow=True))
            res.put(32,7, u"\u251c")


        for ii in range(1,6):
            res.put(31+10*(ii-1),4,f"DBG{ii}")
            if self.state.index == 1:
                res.put(35+10*(ii-1),2,f"N.C.")
            else:
                res.put(34+10*(ii-1),1,f"UPCONV")
                res.put(33+10*(ii-1),2,f"#{ii} (DBG)")

            res.put(35+10*(ii-1),3,u"\u2574\u2502\u2576")
            if self.state.rf_input != ii:
                res.put(36+10*(ii-1),4,u"\u2534")
            else:
                res.put(25,2,TudiText.line(((10*(ii-1)+11,1),(10*(ii-1)+11,3),(0,3),(0,5),(12,5)),arrow=True, style=LineStyle.ROUNDED))

            res.put(35+10*(ii-1),3,u"\u2574\u2502\u2576")

        res.put(87,7,f"IF DCONV #{self.state.index} (I)")
        res.put(87,9,f"IF DCONV #{self.state.index} (Q)")

        res.put(82,8,f"I")
        res.put(82,10,f"Q")

        if self.state.enabled:
            res.put(48,7,TudiText.line(((0,0),(5,0)),arrow=True))
            res.put(55,7,"LPF")
            res.put(59,7,TudiText.line(((0,0),(3,0)),arrow=True))
            res.put(64,7,"+20dB")
            res.put(70,7,TudiText.line(((0,0),(3,0)),arrow=True))
            res.put(75,7,"LPF")
            res.put(79,7,TudiText.line(((0,0),(6,0)),arrow=True))

            res.put(48,9,TudiText.line(((0,0),(5,0)),arrow=True))
            res.put(55,9,"LPF")
            res.put(59,9,TudiText.line(((0,0),(3,0)),arrow=True))
            res.put(64,9,"+20dB")
            res.put(70,9,TudiText.line(((0,0),(3,0)),arrow=True))
            res.put(75,9,"LPF")
            res.put(79,9,TudiText.line(((0,0),(6,0)),arrow=True))

        else:
            res.put(48,7,TudiText.line(((0,0),(5,0)))).put(53,7,u"\u2524")
            res.put(79,7,TudiText.line(((0,0),(6,0)),arrow=True)).put(79,7,u"\u251c")

            res.put(48,9,TudiText.line(((0,0),(5,0)))).put(53,9,u"\u2524")
            res.put(79,9,TudiText.line(((0,0),(6,0)),arrow=True)).put(79,9,u"\u251c")


        return res.__repr__()

class IfDownconvState:

    def __init__(self, state: IfDownConvUpdate):
        self.temp: Optional[float] = None
        self.state: Optional[IfDownConvUpdate] = state
        self.conn: Optional[IfDownConvIdentityConnectivity] = None

    def __repr__(self):

        def _left_switch_repr(up: bool):
            res = TudiText()

            if up:
                res.put(0, 0, TudiText.line(((0,1),(2,1),(2,0),(4,0)),style=LineStyle.ROUNDED))
                res.put(4, 0,u"\u257c")
                res.put(4, 2,u"\u257a")
            else:
                res.put(0, 0, TudiText.line(((0,1),(2,1),(2,2),(4,2)),style=LineStyle.ROUNDED))
                res.put(4, 0,u"\u257a")
                res.put(4, 2,u"\u257c")

            res.put(0,1,u"\u257e")
            return res

        def _right_switch_repr(up: bool):
            res = TudiText()

            if up:
                res.put(0, 0, TudiText.line(((0,0),(2,0),(2,1),(4,1)),style=LineStyle.ROUNDED))
                res.put(0, 0,u"\u257e")
                res.put(0, 2,u"\u2578")
            else:
                res.put(0, 0, TudiText.line(((0,2),(2,2),(2,1),(4,1)),style=LineStyle.ROUNDED))
                res.put(0, 0,u"\u2578")
                res.put(0, 2,u"\u257e")

            res.put(4,1,u"\u257c")
            return res


        def _channel_repr(ii:int, ch: IfDownConvUpdateChannel):
            ctrl6 = ch.mode != IfDownConvUpdateMode.MODE_MIXER
            ctrl3 = not ctrl6

            ctrl1 = ch.mode in (IfDownConvUpdateMode.MODE_OFF, IfDownConvUpdateMode.MODE_POWER_DETECT)
            ctrl2 = not ctrl1

            ctrl4 = ch.coupling == IfDownConvUpdateCoupling.COUPLING_DC
            ctrl5 = ch.coupling == IfDownConvUpdateCoupling.COUPLING_AC

            if_en1 = ch.mode in (IfDownConvUpdateMode.MODE_BYPASS, IfDownConvUpdateMode.MODE_POWER_DETECT)
            if_en2 = ch.mode == IfDownConvUpdateMode.MODE_MIXER

            mode = ch.to_dict()['mode'][5:]
            coupling = ch.to_dict()['coupling'][9:]

            res = TudiText()
            res.put(0,2,f"RF DCONV\n#{self.state.index} ({ {1:'I',2:'Q'}[ii]})")
            res.put(0,6,f"IF {self.state.index} LO { {1:'I',2:'Q'}[ii] }")

            res.put(9,2,TudiText.line(((0,0),(6,0))))

            res.put(22,0,TudiText.frame(9,3).put(1,0," +17dB ").put(1,1,f"{ {False:'OFF',True:'ON'}[if_en1] :^7}"))

            res.put(19,1,TudiText.line(((0,0),(3,0)),arrow=True))
            res.put(30,1,TudiText.line(((0,0),(5,0))))


            res.put(42,1,TudiText.frame(13,3).put(1,0," power ").put(2,2," detector ").put(1,1,f"{ {False:'OFF',True:'ON'}[ch.mode == IfDownConvUpdateMode.MODE_POWER_DETECT]:^11}"))
            res.put(39,2,TudiText.line(((0,0),(3,0)),arrow=True))

            res.put(54,2,TudiText.line(((0,0),(3,0))))
            res.put(39,0,TudiText.line(((0,0),(18,0))))

            res.put(14,5,TudiText.frame(9,3).put(1,0," +19dB ").put(1,1,f"{ {False:'OFF',True:'ON'}[if_en2] :^7}"))
            res.put(10,6,TudiText.line(((0,0),(4,0)), arrow=True))

            res.put(27,3,TudiText.frame(12,5).put(1,4," RF mixer ").put(2,1,"RF\n\nLO    IF"))
            res.put(22,6,TudiText.line(((0,0),(5,0)), arrow=True))

            res.put(19,3,TudiText.line(((0,0),(2,0),(2,1),(8,1)), arrow=True, style=LineStyle.ROUNDED))
            res.put(38,0,TudiText.line(((0,6),(21,6),(21,3),(24,3)), style=LineStyle.ROUNDED))

            res.put(66,2,TudiText.line(((0,0),(2,0)), arrow=True)).put(70,2,"LPF")

            res.put(74,2,TudiText.line(((0,0),(1,0))))
            res.put(79,1,TudiText.line(((0,0),(9,0)))).put(79,0,"DC coupling")
            res.put(79,3,TudiText.line(((0,0),(9,0)))).put(83,3,u"\u2524\u251c").put(79,4,"AC coupling")
            res.put(92,2,TudiText.line(((0,0),(7,0)), arrow=True))

            res.put(61,1,u"\u2500")

            res.put(15,1,_left_switch_repr(ctrl6))       # CTRL6
            res.put(35,0,_left_switch_repr(not ctrl1))   # !CTRL1
            res.put(57,0,_right_switch_repr(ctrl2))      # CTRL2
            res.put(62,1,_right_switch_repr(not ctrl3))  # !CTRL3
            res.put(61,1,u"\u2500")

            res.put(75,1,_left_switch_repr(ctrl4))       # CTRL4
            res.put(88,1,_right_switch_repr(not ctrl5))  # !CTRL5

            res.put(100,2,f" IF OUT {ii}\ncombined with\nIF DCONV #{3-self.state.index} (OUT{ii})")
            res.put(93,3,f"OUT{ii}")

            res.put(65,6,f"mode: {mode}")
            res.put(65,7,f"coupling: {coupling}")

            return res
        

        res = TudiText()
        res.put(11, 0, TudiText.frame(88, 19, LineStyle.ROUNDED))
        res.put(13,0, f" IF DCONV #{self.state.index} ").put(87, 18, f" {self.temp:0.1f} deg ")

        res.put(0,1, _channel_repr(1, self.state.channel1))
        res.put(0,10, _channel_repr(2, self.state.channel2))

        res.put(11,9,TudiText.line(((0,0),(87,0)),style=LineStyle.DASHED))
        res.put(11,9,u"\u251c").put(98,9,u"\u2524")

        return res.__repr__()

class SynthState:

    def __init__(self, state: SynthUpdate, context: "OctaveSnapshot"):
        self.context = context
        self.temp: Optional[float] = None
        self.state: Optional[SynthUpdate] = state
        self.conn: Optional[SynthIdentityConnectivity] = None

    def __repr__(self):

        def output_port_name(output_port:SynthRfOutputOutputPort):
            for ii,state in self.context.rf_downconvs.items():
                assert isinstance(state, RfDownconvState)

                if state.conn.lo_input_1.synth_output.index == self.state.index and state.conn.lo_input_1.synth_output.output_port == output_port:
                    return f"RF DCONV #{ii} (LO IN 1)"
                
                if state.conn.lo_input_2.synth_output.index == self.state.index and state.conn.lo_input_2.synth_output.output_port == output_port:
                    return f"RF DCONV #{ii} (LO IN 2)"

            for ii,state in self.context.rf_upconvs.items():
                assert isinstance(state, RfUpconvState)

                if state.conn.lo_input.synth_output.index == self.state.index and state.conn.lo_input.synth_output.output_port == output_port:
                    return f"RF UCONV #{ii} (LO IN)"
                
            for synth_out_port in self.context.panel.synth_outputs:
                assert isinstance(synth_out_port, PanelIdentitySynthOutput)

                if synth_out_port.source.synth_output.index == self.state.index and synth_out_port.source.synth_output.output_port == output_port:
                    return f"Synth{synth_out_port.index}"

            return "N.C."

        def lo_input_to_str(lo_input: RfSource):
            if lo_input._group_current['source'] is None:
                return "N.C."
            
            if lo_input._group_current['source'] != 'external_input':
                return "???"
            
            if lo_input.external_input._group_current['input'] == 'demod_lo_input_index':
                return f"Dmd {lo_input.external_input.demod_lo_input_index} LO"
            
            if lo_input.external_input._group_current['input'] == 'lo_input_index':
                return f"LO{lo_input.external_input.lo_input_index}"

            return "???"

        main_lo_in = lo_input_to_str(self.conn.main_lo_input)
        sec_lo_in = lo_input_to_str(self.conn.secondary_lo_input)

        synth_out = output_port_name(SynthRfOutputOutputPort.OUTPUT_PORT_SYNTH)
        main_out = output_port_name(SynthRfOutputOutputPort.OUTPUT_PORT_MAIN)
        secondary_out = output_port_name(SynthRfOutputOutputPort.OUTPUT_PORT_SECONDARY)

        int_frequency = "OFF" if self.state.synth_output.disabled else f"{self.state.synth_output.frequency/1e9:.3f}GHz"
        var_gain = "OFF" if self.state.synth_output.disabled else f"{self.state.gain}"
        var_attn = f"{self.state.digital_attn/2:0.1f}dB"
        # currently, this amplifier is always ON. 
        power_amp = 'ON'


        synth_output_power = self.state.to_dict()['synthOutputPower'][19:].replace("NEG","-").replace("POS","+").replace("D", "d")

        res = TudiText()

        frame = TudiText().put(0,0,TudiText.frame(96,13,LineStyle.ROUNDED))
        frame.put(2,0,f" SYNTHESIZER #{self.state.index} ")

        int_synth = TudiText().put(0,0,TudiText.frame(22,5)).put(1,0," int. synth ")
        int_synth.put(2,1,f"output:  {int_frequency:>9}")
        int_synth.put(2,3,f"gain:  {synth_output_power:>11}")

        frame.put(5,1,int_synth)

        var_attn = TudiText().put(0,0,TudiText.frame(13,3)).put(1,0," var. attn ").put(1,1,f"{var_attn:^11}")

        var_amp = TudiText().put(0,0,TudiText.frame(12,3)).put(1,0," var. amp ").put(1,1,f"{var_gain:^10}")
        power_amp = TudiText().put(0,0,TudiText.frame(9,3)).put(1,0," +21dB ").put(1,1,f"{power_amp:^7}")


        frame.put(37,2,var_attn)
        frame.put(56,2,var_amp)
        frame.put(38,6,power_amp)


        if self.state.synth_output.disabled:
            frame.put(
                26,3,
                TudiText().put(0,0,TudiText.line(((0,0),(3,0)))).put(0,0,TudiText.line(((7,0),(11,0)),arrow=True)).put(3,0,u"\u2524   \u251c"))
        else:
            frame.put(
                26,3,
                TudiText.line(((0,0),(11,0)),arrow=True))

        frame.put(49,3,TudiText.line(((0,0),(7,0)),arrow=True))

        frame.put(67,3,TudiText.line(((0,0),(7,0)),arrow=True))

        frame.put(0,1,TudiText.line(((67,2),(75,2),(75,0),(96,0)),arrow=True,style=LineStyle.ROUNDED))
        frame.put(0,1,TudiText.line(((67,2),(75,2),(75,4),(31,4),(31,5)),arrow=True,style=LineStyle.ROUNDED))
        frame.put(0,1,TudiText.line(((67,2),(74,2)),arrow=True))
        frame.put(75,3,u"\u2524")
        frame.put(31,6,u"\u2579")

        if self.state.main_source == SynthUpdateMainSource.MAIN_SOURCE_SYNTHESIZER:
            frame.put(31,6,TudiText.line(((0,0),(0,1),(7,1)),arrow=True,style=LineStyle.ROUNDED))
            frame.put(31,6,u"\u257f")
        else:
            frame.put(28,7,TudiText.line(((0,0),(10,0)),arrow=True,style=LineStyle.ROUNDED))
        frame.put(34,7,u"\u2501")

        frame.put(26,8,"main src.")

        frame.put(46,7,TudiText.line(((0,0),(8,0)),arrow=True))
        frame.put(55,6,TudiText.line(((0,1),(0,0),(25,0)), style=LineStyle.ROUNDED).put(25,0,u"\u2501"))
        frame.put(86,6,TudiText.line(((0,0),(10,0)), arrow=True).put(0,0,u"\u2501"))
        frame.put(77,7,u"\u251c\u2500\u2500\u2501")
        frame.put(79,5,"main out.")

        frame.put(55,7,TudiText.line(((0,0),(0,2),(10,2)), style=LineStyle.ROUNDED).put(10,2,u"\u2501"))
        frame.put(62,11,u"\u251c\u2500\u2500\u2501")
        frame.put(71,9,TudiText.line(((0,0),(25,0)), arrow=True).put(0,0,u"\u2501"))
        frame.put(64,8,"sec. out.")

        frame.put(55,7,u"\u2524")

        if self.state.main_output == SynthUpdateMainOutput.MAIN_OUTPUT_MAIN:
            frame.put(81,6,u"\u2500"*5)
        else:
            frame.put(81,6,u"  \u256d\u2500\u2500\n\u2500\u2500\u256f")

        if self.state.secondary_output == SynthUpdateSecondaryOutput.SECONDARY_OUTPUT_MAIN:
            frame.put(66,9,u"\u2500\u2500\u2500\u2500\u2500")
        elif self.state.secondary_output == SynthUpdateSecondaryOutput.SECONDARY_OUTPUT_AUXILARY:
            frame.put(66,9,u"  \u256d\u2500\u2500\n\u2500\u2500\u256f")
        else:
            frame.put(66,9,u"  \u256d\u2500\u2500\n  \u2502\n\u2500\u2500\u256f")


        frame.put(90,7,"MAIN")
        frame.put(85,10,"SECONDARY")
        frame.put(89,2,"SYNTH")

        frame.put(98,1,synth_out)
        frame.put(98,6,main_out)
        frame.put(98,9,secondary_out)


        frame.put(2,8,"MAIN EXT. LO")
        frame.put(2,11,"SECONDARY EXT. LO")

        frame.put(84, 12, f" {self.temp:0.1f} deg ")

        res.put(12,1,frame)

        res.put(0,8, TudiText.line(((0,0),(40,0)), arrow=True).put(0,0, f"{main_lo_in} ")).put(40,8,u"\u2501")
        res.put(0,11, TudiText.line(((0,0),(77,0)), arrow=True).put(0,0, f"{sec_lo_in} ").put(77,0,u"\u2501"))

        return res.__repr__()


class ClockState:

    def __init__(self, state: ClockUpdate):
        self.temp: Optional[float] = state
        self.state: Optional[ClockUpdate] = None

class MotherboardState:

    def __init__(self, state: MotherboardUpdate):
        self.state: Optional[MotherboardUpdate] = state


class OctaveSnapshot:

    def __init__(self, octave: Octave):
        self._client: OctaveClient = octave._client

        self.rf_upconvs: Mapping[int, RfUpconvState] = {}
        self.rf_downconvs: Mapping[int, Dict] = {}
        self.if_downconvs: Mapping[int, Dict] = {}
        self.synths: Mapping[int, Dict] = {}
        self.clock: Optional[ClockState] = None
        self.motherboard: Dict = {}

        self.panel: PanelIdentity = None

        self.update()

    def update(self):
        module: SingleUpdate
        for module in self._client.aquire_modules([]).state.updates:
            if module.rf_up_conv:
                self.rf_upconvs[module.rf_up_conv.index] = RfUpconvState(module.rf_up_conv)

            elif module.rf_down_conv:
                self.rf_downconvs[module.rf_down_conv.index] = RfDownconvState(module.rf_down_conv)

            elif module.if_down_conv:
                self.if_downconvs[module.if_down_conv.index] = IfDownconvState(module.if_down_conv)

            elif module.synth:
                self.synths[module.synth.index] = SynthState(module.synth, self)

            elif module.clock:
                self.clock = ClockState(module.clock)

            elif module.motherboard:
                self.motherboard = MotherboardState(module.motherboard)

        mon = self._client.monitor()
        for ii, data in enumerate(mon.modules[OctaveModule.OCTAVE_MODULE_RF_UPCONVERTER]):
            self.rf_upconvs[ii+1].temp = data.temp

        for ii, data in enumerate(mon.modules[OctaveModule.OCTAVE_MODULE_RF_DOWNCONVERTER]):
            self.rf_downconvs[ii+1].temp = data.temp

        for ii, data in enumerate(mon.modules[OctaveModule.OCTAVE_MODULE_IF_DOWNCONVERTER]):
            self.if_downconvs[ii+1].temp = data.temp

        for ii, data in enumerate(mon.modules[OctaveModule.OCTAVE_MODULE_SYNTHESIZER]):
            if data is None or data.temp == 0:
                continue
            self.synths[ii+1].temp = data.temp

        self.clock.temp = mon.modules[OctaveModule.OCTAVE_MODULE_SOM][0].temp

        connectivity = self._client.identify()
        for c in connectivity.rf_up_converters:
            self.rf_upconvs[c.index].conn = c.connectivity

        for c in connectivity.rf_down_converters:
            self.rf_downconvs[c.index].conn = c.connectivity

        for c in connectivity.if_down_converters:
            self.if_downconvs[c.index].conn = c.connectivity

        for c in connectivity.synthesizers:
            self.synths[c.index].conn = c.connectivity

        self.panel = connectivity.panel_identity

    def export_html(self, file_path: str):


        def _fix_text(text: str):
            return text.replace('&', '&amp;').replace('>', '&gt;').replace('<', '&lt;')

        def _fix_unit(lines: List[str]):
            unit = _fix_text("\n".join(lines))

            for ii in (3,4,5,6):
                unit = unit.replace(f'SYNTH #{ii}', f'<a href="#SYNTH{ii}">SYNTH #{ii}</a>')
                
            for ii in (1,2):
                unit = unit.replace(f'RF DCONV #{ii}', f'<a href="#RF_DCONV{ii}">RF DCONV #{ii}</a>')
                
            for ii in (1,2):
                unit = unit.replace(f'IF DCONV #{ii}', f'<a href="#IF_DCONV{ii}">IF DCONV #{ii}</a>')
                
            for ii in (1,2,3,4,5):
                unit = unit.replace(f'RF UCONV #{ii}', f'<a href="#RF_UCONV{ii}">RF UCONV #{ii}</a>')
                
            unit = "\n".join([
                f'<pre>',
                unit,
                '</pre>\n'
            ])
            return unit

        with open(file_path, "wb") as f:
            f.write( \
'''
<html>
<head>
<style>
body {
  margin: 0;
  font-family: Arial, Helvetica, sans-serif;
}

.topnav {
  overflow: hidden;
  position: fixed;
  background-color: #333;
  bottom: 0;
  width: 100%;
}

.topnav a {
  float: left;
  color: #f2f2f2;
  text-align: center;
  padding: 14px 16px;
  text-decoration: none;
  font-size: 17px;
}

.topnav a:hover {
  background-color: #ddd;
  color: black;
}

.topnav a.active {
  background-color: #04AA6D;
  color: white;
}

.main {
  padding: 16px;
  margin-top: 30px;
  height: 1500px;
}

</style>
</head>
<body>

<div class="topnav">
  <a class="active" href="#RF_UCONVS">RF upconverters</a>
  <a href="#RF_DCONVS">RF downconverters</a>
  <a href="#IF_DCONVS">IF downconverters</a>
  <a href="#SYNTHS">Synthesizers</a>
</div>

<div class="main">
'''.encode())

            f.write(
                f'<h2 id="RF_UCONVS" style="text-align:center;">RF Upconverters</h2>'.encode()
            )
            for ii in (1,2,3,4,5):
                f.write(
                    f'<h4 id="RF_UCONV{ii}">RF upconverter {ii}</h4>'.encode()
                )
                f.write(_fix_unit(
                    TudiText(self.rf_upconvs[ii].__repr__())._lines).encode())

            f.write(
                f'<h2 id="RF_DCONVS" style="text-align:center;">RF Downconverters</h2>'.encode()
            )
            for ii in (1,2):
                f.write(
                    f'<h4 id="RF_DCONV{ii}">RF downconverter {ii}</h4>'.encode()
                )
                f.write(_fix_unit(
                    TudiText(self.rf_downconvs[ii].__repr__())._lines).encode())

            f.write(
                f'<h2 id="IF_DCONVS" style="text-align:center;">IF Downconverters</h2>'.encode()
            )
            for ii in (1,2):
                f.write(
                    f'<h4 id="IF_DCONV{ii}">IF downconverter {ii}</h4>'.encode()
                )
                f.write(_fix_unit(
                    TudiText(self.if_downconvs[ii].__repr__())._lines).encode())

            f.write(
                f'<h2 id="SYNTHS" style="text-align:center;">Synthesizer</h2>'.encode()
            )
            for ii in (3,4,5,6):
                f.write(
                    f'<h4 id="SYNTH{ii}">Synthesizer {ii}</h4>'.encode()
                )
                f.write(_fix_unit(
                    TudiText(self.synths[ii].__repr__())._lines).encode())

            f.write("\n".join([
                '</div>'
                '</html>',
                '</body>\n']).encode())


