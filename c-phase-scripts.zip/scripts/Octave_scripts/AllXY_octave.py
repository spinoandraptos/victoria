""" """
import sys

sys.path.append("C:/Users/admin/Desktop/qcore-yabba/yabba-main/")
from config.experiment_config import FOLDER, N, I, Q, MAG, PHASE, RR, SINGLE_SHOT
from qcore import Experiment, qua, Sweep
from cmath import phase
from qm import qua as qm_qua
from qcore.libs.qua_macros import QuaVariable
from qcore.helpers import logger


class AllXY(Experiment):
    """allXY"""

    ############################# DEFINE PRIMARY DATASETS ##############################
    # these Datasets form the "raw" experimental data and will be streamed by the OPX
    # they must be specified at experiment runtime
    primary_datasets = ["I", "Q"]

    ############################## DEFINE PRIMARY SWEEPS ###############################
    # these Sweeps are uniquely associated with the Experiment subclass
    # these Sweeps must be specified at experiment runtime
    primary_sweeps = ["sequence_index"]

    ############################ DEFINE THE PULSE SEQUENCE #############################
    # ensure that you import 'qua' from 'qcore' and not from 'qm' library
    # attributes accessed via 'self' must be defined in 'if __name__ == "__main__"' code

    def sequence(self):
        self.sequences = [
            ("idle", 0.00, "idle", 0.00, "IdId"),
            (self.qubit_pi_op, 0.00, self.qubit_pi_op, 0.00, "XpXp"),
            (self.qubit_pi_op, 0.25, self.qubit_pi_op, 0.25, "YpYp"),
            (self.qubit_pi_op, 0.00, self.qubit_pi_op, 0.25, "XpYp"),
            (self.qubit_pi_op, 0.25, self.qubit_pi_op, 0.00, "YpXp"),
            (self.qubit_pi2_op, 0.00, "idle", 0.00, "X9Id"),
            (self.qubit_pi2_op, 0.25, "idle", 0.00, "Y9Id"),
            (self.qubit_pi2_op, 0.00, self.qubit_pi2_op, 0.25, "X9Y9"),
            (self.qubit_pi2_op, 0.25, self.qubit_pi2_op, 0.00, "Y9X9"),
            (self.qubit_pi2_op, 0.00, self.qubit_pi_op, 0.25, "X9Yp"),
            (self.qubit_pi2_op, 0.25, self.qubit_pi_op, 0.00, "Y9Xp"),
            (self.qubit_pi_op, 0.00, self.qubit_pi2_op, 0.25, "XpY9"),
            (self.qubit_pi_op, 0.25, self.qubit_pi2_op, 0.00, "YpX9"),
            (self.qubit_pi2_op, 0.00, self.qubit_pi_op, 0.00, "X9Xp"),
            (self.qubit_pi_op, 0.00, self.qubit_pi2_op, 0.00, "XpX9"),
            (self.qubit_pi2_op, 0.25, self.qubit_pi_op, 0.25, "Y9Yp"),
            (self.qubit_pi_op, 0.25, self.qubit_pi2_op, 0.25, "YpY9"),
            (self.qubit_pi_op, 0.00, "idle", 0.00, "XpId"),
            (self.qubit_pi_op, 0.25, "idle", 0.00, "YpId"),
            (self.qubit_pi2_op, 0.00, self.qubit_pi2_op, 0.00, "X9X9"),
            (self.qubit_pi2_op, 0.25, self.qubit_pi2_op, 0.25, "Y9Y9"),
        ]

        qua.reset_frame(self.qubit)

        with qm_qua.switch_(self.sequence_index):
            for i in range(len(self.sequences)):
                with qm_qua.case_(i):
                    if self.sequences[i][0] == "idle":
                        self.qubit.play(self.qubit_pi_op, ampx=0)
                    else:
                        self.qubit.play(
                            self.sequences[i][0], phase=self.sequences[i][1]
                        )
                    if self.sequences[i][2] == "idle":
                        self.qubit.play(self.qubit_pi_op, ampx=0)
                    else:
                        self.qubit.play(
                            self.sequences[i][2], phase=self.sequences[i][3]
                        )

        qua.align(self.qubit, self.resonator)

        self.resonator.measure(
            self.readout_pulse, (self.I, self.Q), ampx=self.ro_ampx, demod_type="dual"
        )
        qua.wait(self.wait_time, self.resonator)


if __name__ == "__main__":
    """ """

    #################################### MODE MAP ######################################
    # key: name of the Mode as defined by the Experiment subclass
    # value: name of the Mode as defined by the user in modes.yml
    modes = {
        "qubit": "qubit",
        "resonator": "rr",
    }

    ################################### PULSE MAP ######################################
    # key: name of the Pulse as defined by the Experiment subclass
    # value: name of the Pulse as defined by the user in modes.yml
    pulses = {
        "qubit_pi_op": "qubit_gaussian_pi_pulse",
        "qubit_pi2_op": "qubit_gaussian_pi2_pulse",
        "readout_pulse": "rr_readout_pulse",
    }

    ############################## CONTROL PARAMETERS ##################################

    parameters = {
        "wait_time": 500_000,
        "ro_ampx": 1,
    }

    ######################## SWEEP (INDEPENDENT) VARIABLES #############################
    # must include an outermost averaging Sweep named "N"
    # must include all primary sweeps defined by the Experiment subclass

    # set number of repetitions for this Experiment run
    N.num = 5000

    # set the qubit frequency sweep for this Experiment run

    SEQ = Sweep(name="sequence_index", start=0, stop=21, step=1, dtype=int)
    sweeps = [N, SEQ]

    ######################## DATASET (DEPENDENT) VARIABLES #############################
    # must include all primary datasets defined by the Experiment subclass
    # I.fitfn = "exp_decay_sine"
    PHASE.datafn_args = {"delay": 2.792e-7, "freq": RR.int_freq}
    PHASE.plot = False
    datasets = [I, Q, MAG, PHASE]

    ######################## INITIALIZE AND RUN EXPERIMENT #############################

    expt = AllXY(FOLDER, modes, pulses, sweeps, datasets, **parameters)
    expt.run()
