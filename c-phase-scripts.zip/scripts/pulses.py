# Script that is used to create the cavity and qubit control pulses
# The pulses are discretized into 1ns time steps.
# It is build upon and inspired from https://github.com/alec-eickbusch/ECD_control/tree/master/ECD_control/ECD_pulse_construction
# For readability, I like to use the greek alphabet. Using the Greek Alphabet Snippets extension in VS Code

import numpy as np
from scipy.integrate import quad
from scipy.interpolate import interp1d


def gaussian_wave(sigma: int, chop: int = 4) -> np.ndarray:
    ts = np.linspace(-chop / 2 * sigma, chop / 2 * sigma, chop * sigma)
    P = np.exp(-(ts**2) / (2.0 * sigma**2))
    ofs = P[0]  # offset incase starting value is non-zero
    return (P - ofs) / (1 - ofs)  # offset the pulse and renormalize


def wait(duration: int) -> np.ndarray:
    return np.zeros(int(duration), dtype=complex)


def disp_gaussian(α: complex, sigma: int, chop: int, dt=1) -> np.ndarray:
    """Returns a gaussian cavity displacement pulse

    Args:
        alpha (complex): Complex coherent state amplitude
        sigma (int): sigma of pulse
        chop (int): chop of pulse
        dt (int, optional): Time step. Defaults to 1.

    Returns:
        np.ndarray: Pulse Array
    """
    wave = gaussian_wave(sigma=sigma, chop=chop)
    energy = np.trapz(wave, dx=dt)
    wave = (1 + 0j) * wave
    return (
        (np.abs(α) / energy)
        * np.exp(1j * (np.pi / 2.0 + np.angle(α)))
        * wave
    )


def rotate(theta: float, phi: float = np.pi / 2, sigma: int = 6, chop: int = 4, dt=1) -> np.ndarray:
    """ Returns a gaussian qubit rotation pulse. The pulse is intendet to be used in a hamiltonian evolution 
    of the form  qΩ(t) + qt conjguate(Ω(t)) 

    Args:
        theta (float): Qubit rotation angle
        phi (flaot): Axis around which the qubit rotates. np.pi/2 for y-axis, 0 for x-axis

    Returns:
        _type_: Pulse Array
    """
    wave = gaussian_wave(sigma=sigma, chop=chop)
    ts = np.arange(len(wave)) * dt
    # to calculate the energy, we interpolate.
    wave_interp = interp1d(x=ts, y=wave, kind="cubic")
    # energy = np.trapz(wave, dx=dt)
    energy, err = quad(wave_interp, a=0, b=(len(wave) - 1) * dt)
    amp = 1 / energy
    wave = (1 + 0j) * wave
    return (theta / (2.0)) * amp * np.exp(1j * phi) * wave


def ecd_sequence(param_dict: dict, β: complex, α: complex = None, ratios=None, dt=1,
                 ) -> tuple[np.ndarray, np.ndarray]:
    """_summary_

    Args:
        param_dict (dict): dictionary that holds chi and pulse parameters
        ratios (_type_, optional): in case we want to scale the individual ecd pulses. If none, the default scaling of the fast control paper is used
        dt (int, optional): _description_. Defaults to 1.

    Returns:
        tuple[np.ndarray, np.ndarray]: cavity_pulse, qubit_pulse
    """

    β_abs = np.abs(β)
    β_phase = np.angle(β)

    χ = param_dict["chi"]  # in GHz
    sigma_q = param_dict["sigma_q"]  # in ns
    sigma_c = param_dict["sigma_c"]  # in n s
    chop = param_dict["chop"]
    tw = param_dict["tw"]  # in ns

    if α is None:
        α = β_abs / (2 * np.sin(χ * tw))
    else:
        α = float(α) if isinstance(α, int) else α

    α = np.abs(α)
    α_phase = β_phase + np.pi / 2.0

    d = disp_gaussian(α, sigma_c, chop, dt)

    # corresponding to sy pi flip
    p = rotate(np.pi, sigma=sigma_q, chop=chop, dt=dt)

    tw
    if ratios is not None:
        r = ratios[0]
        r0 = ratios[1]
        r1 = ratios[2]
        r2 = ratios[3]
    else:
        r = 1.0
        r0 = 1.0
        r1 = np.cos((χ / 2.0) * tw)
        r2 = np.cos(χ * tw)

    def construct_CD(tw, r, r0, r1, r2):
        cavity_pulse = r * np.concatenate(
            [
                r0 * d * np.exp(1j * α_phase),
                np.zeros(tw),
                r1 * d * np.exp(1j * (α_phase + np.pi)),
                np.zeros(len(p)),
                r1 * d * np.exp(1j * (α_phase + np.pi)),
                np.zeros(tw),
                r2 * d * np.exp(1j * α_phase),
            ]
        )
        qubit_pulse = np.concatenate(
            [
                np.zeros(tw + 2 * len(d)),
                p,
                np.zeros(tw + 2 * len(d)),
            ]
        )
        return cavity_pulse, qubit_pulse

    return construct_CD(tw, r, r0, r1, r2)
