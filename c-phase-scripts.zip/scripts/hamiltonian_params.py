import numpy as np

### HOW TO USE THIS SCRIPT ###
# - update all frequencies here.
# - update the chis here.
# - the script calculates the frames and default ratios (as given in fast universal control paper)
# - the frequencies dictionary is used in update_resources octave


# NOTE everything that is 0 will be initalized on the fly based on the saved chis
frequencies = {
    ### Readout ###
    "rr_LO": 7.533333e9, #7.784e9+50e6+150e3+200e6-4.77e6 , # 7761185000.0 - 1.3e6 + 0.57e6,
    "rr_IF":250e6,
    ### Qubit ###
    "qubit_LO": 5.200608000e9,
    "qubit_IF": 120e6, #50e6,
    "qubit_ef_IF": -63.21e6,#-63.025e6,
    "qubit_gf_IF": 29.395e6,
    # ### Alice ###
    # "alice_LO": 6.458576684e9 + 50e6 +2.5e6-20e3 + 1.7e6 -2.44e3-0.72e3,
    # "alice_IF": -50e6,
    # "alice_ge_IF": 0,
    # "alice_e_IF": 0,
    # "alice_uecd1_IF": 0,
    # "alice_uecd2_IF": 0,
    ### Bob ###
    "bob_LO":  5.981889130e9 + 50e6 -267e3 +20e3-193.39e3-18.94e3+25.23e3-839+3e3-200e6, #last 50e3 to be removed
    "bob_IF": 150e6,
    "bob_ge_IF": 0,
    "bob_e_IF": 0,
    "bob_uneven_IF": 0,
    ### Charlie ###
    # "charlie_LO": 6.1981552e9+200e3+50e3+36.2e3-19e3+644+ +3.6e3,
    # "charlie_IF": -50e6,
    # "charlie_ge_IF": 0,
    # "charlie_e_IF": 0,
    # "charlie_uecd1_IF": 0,
}

# Alice = {
#     "chi": (64.6)*1e-6 * 2 * np.pi,  # unit is GHz for this parameter
#     "chi_gf": 108.05e-6 * 2 * np.pi,
#     "kappa": 0,  # 1 / 70e3,
#     "ecd_wait_time_default": 400,
#     "ecd_wait_time_optimized": 316,  ## optimized for alpha = 3
#     "ratios_default": 0,
  
#     "ratios_optimized": (0.9968303747069603, 1.006926713852948, 1.0033507551918568, 0.9906291141273245), ## optimized for alpha = 9
#     "alpha": 1.5,
#     "uecd1_frame": 0,
#     "uecd1_wait_time": 600,
#     "uecd2_wait_time": 400,
#     "uecd1_displacements":
#         [1.0, -0.4378848391445441, 0.9175095343848548, -0.007957516475320999, 0.9175095343848548, -0.007957516475320999, 1.0233567824814445, 0.42367687892859124],
#     "uecd2_displacements":
#         [[4.369/4, -0.11560],
#          [3.218/4, -0.49585],
#          [4.411/4, 0.12250]],
#         #[[6.976/4, -0.06052],
#     #         [5.575/4, -0.49524],
#     #         [5.394/4, 0.09278]], optimized for gaussian, alpha of 1.9
#     "uecd2_total_gate_time": 2232 * 1e-9, # in s #uecd2:1632 char func:2232
# }

Bob = {
    "chi": 114.86e-6 * 2 * np.pi,
    "kappa": 0,  # 1 / 70e3,
    "ecd_wait_time_default": 47,
    "ecd_wait_time_optimized": 416  ,  # optimized for alpha = 6
    "ratios_default": 0,
    "ratios_optimized": (0.9975105274744722, 1.0075971375340518, 0.9837179626937562, 0.914923552718777),  # optimized for alpha = 6
    "char_func_tomo_phase": 0.0,
    "alpha": 4,
}

# Charlie = {
#     "chi":(69.47)*1e-6 * 2 * np.pi,  # 30.722e-6 * 2 * np.pi,  # 30.874e-6 * 2 * np.pi,
#     "chi_gf": (114.27)*1e-6 * 2 * np.pi,
#     "kappa": 0,
#     "ecd_wait_time_optimized": 288,  # for state creation
#     "ecd_wait_time_default": 800, #550 before optimizing
#     "uecd1_delta_chi": 0,
#     "uecd1_frame": 0,
#     # "uecd1_displacements":
#     #    [1, -0.4639, 0.9528, -0.012, 0.9528, -0.012, 1, 0.4389],
#     "uecd1_displacements":
#        [1.0, -0.4546041350032422, 0.95541071392865, -0.006844452052446978, 0.95541071392865, -0.006844452052446978, 1.0166726086776545, 0.4418032436734853],
#     "uecd1_wait_time": 400,
#     "uecd2_displacements":
#       [1.0, -0.09597295370365866, 0.8113846088164457, -0.4934671189543931, 0.8113846088164457, -0.4934671189543931, 1.0188444830781664, 0.10683967693908003]
# ,
#     "uecd2_wait_time": 400,
#     "ratios_default": 0,
#     "ratios_optimized": (0.9938157292614077, 1.010428112427499, 1.005793541116747, 0.9892292945142616),
#     "ratios_cat_test" : (1.0, 1.0, 0.9940724780093684, 0.9763601830713725),
#     "wait_cat_test" : 500,
#     "char_func_tomo_phase": 0,
#     "alpha": 1.5,
# }
# # calculate the default ratios
# Alice["ratios_default"] = (
#     1,
#     1 * np.cos(Alice["ecd_wait_time_default"] * Alice["chi"] / 2),
#     1 * np.cos(Alice["ecd_wait_time_default"] * Alice["chi"] / 2),
#     1 * np.cos(Alice["ecd_wait_time_default"] * Alice["chi"]),
# )

Bob["ratios_default"] = (
    1,
    1 * np.cos(Bob["ecd_wait_time_default"] * Bob["chi"] / 2),
    1 * np.cos(Bob["ecd_wait_time_default"] * Bob["chi"] / 2),
    1 * np.cos(Bob["ecd_wait_time_default"] * Bob["chi"]),
)

# Charlie["ratios_default"] = (
#     1,
#     1 * np.cos(Charlie["ecd_wait_time_default"] * Charlie["chi"] / 2),
#     1 * np.cos(Charlie["ecd_wait_time_default"] * Charlie["chi"] / 2),
#     1 * np.cos(Charlie["ecd_wait_time_default"] * Charlie["chi"]),
# )

# # calculate uneven frame
# Alice["uecd1_frame"] = (Alice["chi"]-(Alice["chi"]+Alice["chi_gf"]))/2
# print(Alice["uecd1_frame"])
# # calcualte the frames
# frequencies["alice_ge_IF"] = (
#     frequencies["alice_IF"] - Alice["chi"] / (2 * np.pi) * 1e9 / 2
# )
# frequencies["alice_e_IF"] = frequencies["alice_IF"] - Alice["chi"] / (2 * np.pi) * 1e9
# frequencies["alice_uecd1_IF"] = frequencies["alice_IF"]-217250

frequencies["bob_ge_IF"] = frequencies["bob_IF"] - Bob["chi"] / (2 * np.pi) * 1e9 / 2
frequencies["bob_e_IF"] = frequencies["bob_IF"] - Bob["chi"] / (2 * np.pi) * 1e9

# frequencies["charlie_ge_IF"] = (
#     frequencies["charlie_IF"] - Charlie["chi"] / (2 * np.pi) * 1e9 / 2
# )
# frequencies["charlie_e_IF"] = (
#     frequencies["charlie_IF"] - Charlie["chi"] / (2 * np.pi) * 1e9
    
# )
# x = frequencies["charlie_IF"]
# a = Charlie["chi"]/ (2 * np.pi) * 1e9 -(Charlie["chi_gf"] -Charlie["chi"])* 1e9 / (2 * np.pi*2)
# #frequencies["charlie_uecd1_IF"] = x-a
# frequencies["charlie_uecd2_IF"] = frequencies["charlie_IF"] - Charlie["chi"]/ (2 * np.pi) * 1e9
# #frequencies["charlie_uecd1_IF"] = x-a
# frequencies["charlie_uecd1_IF"] = frequencies["charlie_IF"]-224599

# print(frequencies["charlie_uecd1_IF"])