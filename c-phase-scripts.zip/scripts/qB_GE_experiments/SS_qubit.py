""" """
from config.experiment_config import FOLDER, N, FREQ, I, Q, MAG, PHASE, RRC, SINGLE_SHOT
from qcore import Experiment, qua, Sweep
from qm import qua as qm_qua

class SSqubit(Experiment):
    """Qubit spectroscopy"""

    ############################# DEFINE PRIMARY DATASETS ##############################
    # these Datasets form the "raw" experimental data and will be streamed by the OPX
    # they must be specified at experiment runtime

    primary_datasets = ["I", "Q", "single_shot"]

    ############################## DEFINE PRIMARY SWEEPS ###############################
    # these Sweeps are uniquely associated with the Experiment subclass
    # these Sweeps must be specified at experiment runtime

    primary_sweeps = ["qubit_frequency"]
    primary_sweeps = ["drive_amp"]

    ############################ DEFINE THE PULSE SEQUENCE #############################
    # ensure that you import 'qua' from 'qcore' and not from 'qm' library
    # attributes accessed via 'self' must be defined in 'if __name__ == "__main__"' code

    def sequence(self):
        """QUA sequence that defines this Experiment subclass"""
        # qua.update_frequency(self.qubit, self.qubit_frequency)
        # self.qubit.play(self.qubit_pulse)
        self.drive.play(self.drive_pulse, ampx=self.drive_amp, duration = 400*4/4)
        qua.align()

        self.resonator.measure(self.readout_pulse, (self.I, self.Q), ampx=self.ro_ampx, demod_type="dual")
        if self.plot_single_shot:  # assign state to G or E
            qm_qua.assign(self.single_shot,qm_qua.Cast.to_fixed(self.I > self.readout_pulse.threshold),)
        qua.wait(self.wait_time, self.resonator)

if __name__ == "__main__":
    """ """

    #################################### MODE MAP ######################################
    # key: name of the Mode as defined by the Experiment subclass
    # value: name of the Mode as defined by the user in modes.yml

    modes = {
        "drive": "drive",
        "qubit": "qB",
        "resonator": "rrB",
    }

    ################################### PULSE MAP ######################################
    # key: name of the Pulse as defined by the Experiment subclass
    # value: name of the Pulse as defined by the user in modes.yml

    pulses = {
        "drive_pulse": "SS_pulse",
        "qubit_pulse": "qB_gaussian_very_sel_pi_pulse",
        "readout_pulse": "rrB_GF_CLEAR_readout_pulse",
    }

    ############################## CONTROL PARAMETERS ##################################

    parameters = {
        "wait_time": 500_000,
        "ro_ampx": 1,
        "plot_single_shot": True,
    }

    ######################## SWEEP (INDEPENDENT) VARIABLES #############################
    # must include an outermost averaging Sweep named "N"
    # must include all primary sweeps defined by the Experiment subclass

    # set number of repetitions for this Experiment run
    N.num = 10000

    # set the qubit frequency sweep for this Experiment run
    FREQ.name = "qubit_frequency"
    FREQ.start = 348e6
    FREQ.stop = 354e6
    FREQ.num = 101

    I_AMPX = Sweep(name="drive_amp", start=0.1, stop=2.0, step=0.02)

    sweeps = [N, I_AMPX]
    
    #sweeps = [N, FREQ]
    ######################## DATASET (DEPENDENT) VARIABLES #############################
    # must include all primary datasets defined by the Experiment subclass

    Q.plot,MAG.plot, PHASE.plot, I.plot = False, False, False, False
    #SINGLE_SHOT.plot = False
    # PHASE.datafn_args = {"delay": 2.792e-7, "freq": RR.int_freq}
    # SINGLE_SHOT.plot_args["plot_type"] = "image"
    SINGLE_SHOT.plot = True

    MAG.fitfn = "lorentzian"

    
    # PHASE.datafn_args = {"delay": 2.792e-7, "freq": RRC.int_freq}
    # SINGLE_SHOT.fitfn = "sine"

    # # PHASE.plot = False
    # Q.plot= True
    
    # I.plot, MAG.plot = True, False
    # SINGLE_SHOT.plot = True

    #datasets = [I, Q, MAG, PHASE]

    datasets = [I, Q, SINGLE_SHOT]

    ######################## INITIALIZE AND RUN EXPERIMENT #############################

    expt = SSqubit(FOLDER, modes, pulses, sweeps, datasets, **parameters)
    expt.run()
