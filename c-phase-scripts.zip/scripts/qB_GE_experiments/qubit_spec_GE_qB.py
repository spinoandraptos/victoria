from config.experiment_config import FOLDER, N, FREQ, I, Q, MAG, PHASE, RRB, SINGLE_SHOT
from qcore import Experiment, qua, Sweep
from qm import qua as qm_qua
from qcore.libs.qua_macros import QuaVariable
from qcore import Dataset


class QubitSpec(Experiment):
    """Qubit spectroscopy"""

    ############################# DEFINE PRIMARY DATASETS ##############################
    # these Datasets form the "raw" experimental data and will be streamed by the OPX
    # they must be specified at experiment runtime
    # primary_datasets = ["I", "Q", "single_shot"]
    primary_datasets = ["I", "Q", "single_shot"]

    ############################## DEFINE PRIMARY SWEEPS ###############################
    # these Sweeps are uniquely associated with the Experiment subclass
    # these Sweeps must be specified at experiment runtime

    primary_sweeps = ["qubit_frequency"]

    ############################ DEFINE THE PULSE SEQUENCE #############################
    # ensure that you import 'qua' from 'qcore' and not from 'qm' library
    # attributes accessed via 'self' must be defined in 'if __name__ == "__main__"' code

    def sequence(self):
        """QUA sequence that defines this Experiment subclass"""
        # qua.reset_phase(self.qubit) # this makes the freuqnecy not to change!!
        qua.reset_frame(self.qubit)

        # qua.align()

        # qua.update_frequency(self.qubit, self.qubit.int_freq) 
        # self.qubit.play(self.qubit_grape)
        # self.cavity.play(self.cavity_grape)
        # qua.align()
        # self.qC.play(self.qC_pulse, ampx = self.pulse_amp)
        # self.cavity.play(self.cavity_coh1, ampx = 1.0)
        # qua.align()

        qua.update_frequency(self.qubit, self.qubit_frequency) 
        self.qubit.play(self.qubit_pulse)
        qua.align(self.qubit, self.qubitEF)

        self.qubitEF.play(self.qubitEF_pulse)
        qua.align()

        self.resonator.measure(self.readout_pulse, (self.I, self.Q), ampx=self.ro_ampx, demod_type="dual")
        qua.align()

        qua.wait(self.wait_time)
        if self.plot_single_shot:  # assign state to G or E
            qm_qua.assign(self.single_shot,qm_qua.Cast.to_fixed(self.I > self.readout_pulse.threshold),)


if __name__ == "__main__":
    """ """

    #################################### MODE MAP ######################################
    # key: name of the Mode as defined by the Experiment subclass
    # value: name of the Mode as defined by the user in modes.yml

    modes = {
        "qubit": "qB",
        "qC":"qC",
        "qubitEF": "qB_EF",
        "cavity": "cavB",
        "resonator": "rrB",
    }

    ################################### PULSE MAP ######################################
    # key: name of the Pulse as defined by the Experiment subclass
    # value: name of the Pulse as defined by the user in modes.yml

    pulses = {
        "qubit_pulse": "qB_gaussian_very_sel_pi_pulse",
        "qubitEF_pulse": "qBEF_gaussian_pi_pulse",
        # "qubit_grape": "qB_grape_fock12",
        # "cavity_grape": "cavB_grape_fock12",
        "cavity_coh1": "cavB_ramp_pulse",
        "readout_pulse": "rrB_GF_CLEAR_readout_pulse",
        "qC_pulse":"qC_gaussian_pi_pulse"
    }

    ############################## CONTROL PARAMETERS ##################################

    parameters = {
        "wait_time": 6e6,
        "ro_ampx": 1.0,
        "qo_ampx": 1.0,
        "plot_single_shot": True,
    }

    ######################## SWEEP (INDEPENDENT) VARIABLES #############################
    # must include an outermost averaging Sweep named "N"
    # must include all primary sweeps defined by the Experiment subclass

    # set number of repetitions for this Experiment run
    N.num = 20_000

    # set the qubit frequency sweep for this Experiment run
    FREQ.name = "qubit_frequency"
    FREQ.start = 348.5e6
    FREQ.stop = 352.5e6
    FREQ.num = 101

    AMP = Sweep(name="pulse_amp", start=0.0, stop=1.0, step = 1.0, save=True)

    sweeps = [N, FREQ]

    ######################## DATASET (DEPENDENT) VARIABLES #############################
    # must include all primary datasets defined by the Experiment subclass

    PHASE.datafn_args = {"delay": 2.792e-7, "freq": RRB.int_freq}
    SINGLE_SHOT.fitfn = "gaussian"

    # PHASE.plot = False
    # Q.plot= False
    
    I.plot, MAG.plot = True, True

   #datasets = [I, Q, MAG, PHASE]
    datasets = [I, Q, SINGLE_SHOT]


    

    ######################## INITIALIZE AND RUN EXPERIMENT #############################

    expt = QubitSpec(FOLDER, modes, pulses, sweeps, datasets, **parameters)
    expt.run()
