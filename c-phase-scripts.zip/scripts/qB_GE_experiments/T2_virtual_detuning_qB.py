""" """

import sys

sys.path.append("C:/Users/admin/Desktop/qcore-yabba/yabba-main/")
from config.experiment_config import FOLDER, N, I, Q, MAG, PHASE, RRB, SINGLE_SHOT
from qcore import Experiment, qua, Sweep
from cmath import phase
from qm import qua as qm_qua
from qcore.libs.qua_macros import QuaVariable
from qcore.helpers import logger

class QubitT2(Experiment):
    """Qubit T2 Virtual Detuning"""

    ############################# DEFINE PRIMARY DATASETS ##############################
    # these Datasets form the "raw" experimental data and will be streamed by the OPX
    # they must be specified at experiment runtime
    primary_datasets = ["I", "Q", "single_shot"]

    ############################## DEFINE PRIMARY SWEEPS ###############################
    # these Sweeps are uniquely associated with the Experiment subclass
    # these Sweeps must be specified at experiment runtime
    primary_sweeps = ["time_delay"]

    ############################ DEFINE THE PULSE SEQUENCE #############################
    # ensure that you import 'qua' from 'qcore' and not from 'qm' library
    # attributes accessed via 'self' must be defined in 'if __name__ == "__main__"' code

    def sequence(self):
        factor = qm_qua.declare(qm_qua.fixed)
        qm_qua.assign(factor, self.detuning * 1e-9)  # formerly with a 4*
        qm_qua.assign(self.phase, qm_qua.Cast.mul_fixed_by_int(factor, self.time_delay))

        qua.reset_frame(self.qubit)


        # self.resonator.measure(self.readout_pulse, (self.I, self.Q), ampx=self.ro_ampx, demod_type="dual")
        # qua.wait(1000, self.resonator)
        # qua.align(self.qubit, self.resonator)
        #qua.update_frequency(self.qubit, self.qubit.int_freq)

        # self.cavityB.play(self.cavB_grape)
        # self.qubit.play(self.qB_grape)
        
        #qua.update_frequency(self.qubit, 173.45e6 - 20e3)


        self.qubit.play(self.qubit_pi2_op)
        qua.wait(self.time_delay, self.qubit)
        self.qubit.play(self.qubit_pi2_op, phase=self.phase)
        qua.align(self.qubit, self.qubitEF)
        self.qubitEF.play(self.qubitEF_pi)
        qua.align(self.qubitEF, self.resonator)
        self.resonator.measure(self.readout_pulse, (self.I, self.Q), ampx=self.ro_ampx, demod_type="dual")
        
        if self.plot_single_shot:  # assign state to G or E
            qm_qua.assign(self.single_shot,qm_qua.Cast.to_fixed(self.I > self.readout_pulse.threshold),)
        qua.align()
        qua.wait(self.wait_time)

if __name__ == "__main__":
    """ """

    #################################### MODE MAP ######################################
    # key: name of the Mode as defined by the Experiment subclass
    # value: name of the Mode as defined by the user in modes.yml
    modes = {"qubit": "qB", 
             "cavityB": "cavB",
             "qubitEF": "qB_EF", 
             "resonator": "rrB",
             }
    ################################### PULSE MAP ######################################
    # key: name of the Pulse as defined by the Experiment subclass
    # value: name of the Pulse as defined by the user in modes.yml
    pulses = {
        # "qB_grape": "qB_grape_fock01_new",
        # "cavB_grape": "cavB_grape_fock01_new",
        "qubit_pi_op": "qB_gaussian_pi_pulse",
        "qubitEF_pi": "qBEF_gaussian_pi_pulse",        
        "qubit_pi2_op": "qB_gaussian_pi2_pulse",
        "readout_pulse":"rrB_GF_CLEAR_readout_pulse",
            }

    ############################## CONTROL PARAMETERS ##################################
    parameters = {
        "wait_time": 6e5,
        "ro_ampx": 1,
        "detuning": 150e3,  # Hz
        "phase": QuaVariable(value=0.0, dtype=qm_qua.fixed, tag="phase", buffer=True, stream=True),
        "plot_single_shot": True,
    }

    ######################## SWEEP (INDEPENDENT) VARIABLES #############################
    # must include an outermost averaging Sweep named "N"
    # must include all primary sweeps defined by the Experiment subclass

    # set number of repetitions for this Experiment run
    N.num = 5000

    # set the qubit frequency sweep for this Experiment run

    DEL = Sweep(name="time_delay", start=16, stop=90_000, step=600, dtype=int)  # ns
    sweeps = [N, DEL]

    ######################## DATASET (DEPENDENT) VARIABLES #############################
    # must include all primary datasets defined by the Experiment subclass
    I.fitfn = "exp_decay_sine"
    Q.fitfn = "exp_decay_sine"
    MAG.fitfn = "exp_decay_sine"
    PHASE.datafn_args = {"delay": 2.792e-7, "freq": RRB.int_freq}
    # PHASE.plot = False
    # Q.plot = False
    I.plot, Q.plot = False, False
    SINGLE_SHOT.plot = True
    SINGLE_SHOT.fitfn = "exp_decay_sine"
    datasets = [I, Q, SINGLE_SHOT]

    ######################## INITIALIZE AND RUN EXPERIMENT #############################
    expt = QubitT2(FOLDER, modes, pulses, sweeps, datasets, **parameters)
    expt.run(simulate=False)
