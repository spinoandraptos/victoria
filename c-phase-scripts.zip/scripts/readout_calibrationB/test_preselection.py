""" """
from config.experiment_config import FOLDER, N, FREQ, I, Q, MAG, PHASE
from qcore import Experiment, qua, Sweep, Dataset
from qm import qua as qm_qua

class RRSpec(Experiment):
    """Readout resonator spectroscopy"""

    ############################# DEFINE PRIMARY DATASETS ##############################
    # these Datasets form the "raw" experimental data and will be streamed by the OPX
    # they must be specified at experiment runtime
    primary_datasets = ["I1", "I2", "Q1", "Q2", "single_shot1", "single_shot2"]
    ############################## DEFINE PRIMARY SWEEPS ###############################
    # these Sweeps are uniquely associated with the Experiment subclass
    # these Sweeps must be specified at experiment runtime
    primary_sweeps = ["resonator_frequency"]


    ############################ DEFINE THE PULSE SEQUENCE #############################
    # ensure that you import 'qua' from 'qcore' and not from 'qm' library
    # attributes accessed via 'self' must be defined in 'if __name__ == "__main__"' code

    def sequence(self):
        #print(self.resonator.tof)
        """QUA sequence that defines this Experiment subclass"""

        self.resonator.measure(self.readout_pulse, (self.I1, self.Q1), ampx=self.ro_ampx, demod_type="dual")
        if self.plot_single_shot:  # assign state to G or E
            qm_qua.assign(self.single_shot1,qm_qua.Cast.to_fixed(self.I1 > self.readout_pulse.threshold),)
       #qua.align()
        qua.wait(1000, self.resonator)
        qua.align()

        self.qubit.play(self.qubit_pulse)
        qua.align()
        self.resonator.measure(self.readout_pulse, (self.I2, self.Q2), ampx=self.ro_ampx, demod_type="dual")
        if self.plot_single_shot:  # assign state to G or E
            qm_qua.assign(self.single_shot2,qm_qua.Cast.to_fixed(self.I2 > self.readout_pulse.threshold),)

        qua.wait(self.wait_time, self.resonator)


I1 = Dataset(
    name="I1",
    save=False,
    plot=True,
    # fitfn="exp_decay",
)

Q1 = Dataset(
    name="Q1",
    save=False,
    plot=True,
)

I2 = Dataset(
    name="I2",
    save=False,
    plot=True,
    # fitfn="exp_decay",
)

Q2 = Dataset(
    name="Q2",
    save=False,
    plot=True,
)

SINGLE_SHOT1 = Dataset(
        name="single_shot1",
        save=True,
        plot=True,
    )

SINGLE_SHOT2 = Dataset(
        name="single_shot2",
        save=True,
        plot=True,
    )




if __name__ == "__main__":
    """ """
    #################################### MODE MAP ######################################
    # key: name of the Mode as defined by the Experiment subclass
    # value: name of the Mode as defined by the user in modes.yml
    modes = {"resonator": "rrB",
             "qubit": "qB",
             }
    ################################### PULSE MAP ######################################
    # key: name of the Pulse as defined by the Experiment subclass
    # value: name of the Pulse as defined by the user in modes.yml
    pulses = {"readout_pulse": "rrB_CLEAR_readout_pulse",
              "qubit_pulse": "qB_gaussian_pi_pulse",
              }
    ############################## CONTROL PARAMETERS ##################################

    parameters = {
        "wait_time": 500_000,
        "ro_ampx": 1,
        "plot_single_shot": True,
    }
    ######################## SWEEP (INDEPENDENT) VARIABLES #############################
    # must include an outermost averaging Sweep named "N"
    # must include all primary sweeps defined by the Experiment subclass

    ################################### 1D SWEEP #######################################

    # set number of repetitions for this Experiment run
    N.num = 20_000
    

    # set the qubit frequency sweep for this Experiment run
    FREQ.name = "resonator_frequency"
    # FREQ.start = -124e6
    # FREQ.stop = -118e6

    FREQ.start = 48e6
    FREQ.stop = 52e6

    FREQ.num = 5

    sweeps = [N, FREQ]
    ################################### 2D SWEEP #######################################
    # RO_AMPX = Sweep(name="ro_ampx", points=[0.8, 1, 1.2])
    # sweeps = [N, RO_AMPX, FREQ]

    ######################## DATASET (DEPENDENT) VARIABLES #############################
    # must include all primary datasets defined by the Experiment subclass

    # PHASE.inputs = ("I", "Q", "resonator_frequency")
    # PHASE.datafn_args = {"delay": 9.7e-6}

    MAG.fitfn = "lorentzian"

    I1.plot, I2.plot, Q1.plot, Q2.plot = False, False, False, False


    datasets = [I1, Q1, I2, Q2, SINGLE_SHOT1, SINGLE_SHOT2]

    ######################## INITIALIZE AND RUN EXPERIMENT #############################

    expt = RRSpec(FOLDER, modes, pulses, sweeps, datasets, **parameters)
    expt.run()
