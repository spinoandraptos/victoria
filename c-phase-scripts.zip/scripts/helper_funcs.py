import logging
from datetime import datetime
import os
import glob

def get_latest_file(base_dir, file_suffix):
    # Get the list of all directories in the base directory
    all_dirs = [
        d for d in os.listdir(base_dir) if os.path.isdir(os.path.join(base_dir, d))
    ]

    # Filter directories to only those that match the YYYY-MM-DD format
    valid_dirs = []
    for d in all_dirs:
        try:
            datetime.strptime(d, "%Y-%m-%d")
            valid_dirs.append(d)
        except ValueError:
            # Skip directories that do not match the format
            continue

    if not valid_dirs:
        raise FileNotFoundError("No valid directories found in base directory")

    # Sort valid directories by date in reverse order
    latest_dir = max(valid_dirs, key=lambda d: datetime.strptime(d, "%Y-%m-%d"))

    # Get the path of the latest directory
    latest_dir_path = os.path.join(base_dir, latest_dir)

    # Get the list of all .hdf5 files in the latest directory with the specific suffix
    pattern = os.path.join(latest_dir_path, f"*{file_suffix}")
    all_files = glob.glob(pattern)

    if not all_files:
        raise FileNotFoundError(
            f"No files ending with {file_suffix} found in the latest directory"
        )

    # Sort files by modification time in reverse order
    latest_file = max(all_files, key=os.path.getmtime)

    return latest_file