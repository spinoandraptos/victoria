""" """

import sys

sys.path.append("C:/Users/admin/Desktop/qcore-yabba/yabba-main/")

from config.experiment_config import FOLDER, N, I, Q, MAG, PHASE, RRB, FREQ, SINGLE_SHOT
from qcore import Experiment, qua, Sweep
from qm import qua as qm_qua
from qcore.libs.qua_macros import QuaVariable
from qcore import Dataset


class CavitySpecB(Experiment):
    """Cavity spectroscopy"""

    ############################# DEFINE PRIMARY DATASETS ##############################
    # these Datasets form the "raw" experimental data and will be streamed by the OPX
    # they must be specified at experiment runtime

    primary_datasets = ["I", "Q", "single_shot"]

    ############################## DEFINE PRIMARY SWEEPS ###############################
    # these Sweeps are uniquely associated with the Experiment subclass
    # these Sweeps must be specified at experiment runtime

    primary_sweeps = ["cavity_frequency"]

    ############################ DEFINE THE PULSE SEQUENCE #############################
    # ensure that you import 'qua' from 'qcore' and not from 'qm' library
    # attributes accessed via 'self' must be defined in 'if __name__ == "__main__"' code

    def sequence(self):
        """QUA sequence that defines this Experiment subclass"""
        qua.update_frequency(self.cavity, self.cavity_frequency)

        self.cavity.play(self.cavity_pulse, ampx = 0.1, duration = 4000/4)
        #self.cavity.play(self.cavity_pulse)
        # self.drive.play(self.drive_pulse, duration = 4000/4, ampx = self.drive_ampx)
        qua.align()

        self.qubit.play(self.qubit_pulse, ampx = 1.0)
        qua.align()
        # self.qubitEF.play(self.qubitEF_pi)
        # qua.align()

        self.resonator.measure(self.readout_pulse, (self.I, self.Q), demod_type="dual")
        if self.plot_single_shot:  # assign state to G or E
            qm_qua.assign(self.single_shot,qm_qua.Cast.to_fixed(self.I > self.readout_pulse.threshold),)
        qua.align()
        qua.wait(self.wait_time)

if __name__ == "__main__":
    """ """

    #################################### MODE MAP ######################################
    # key: name of the Mode as defined by the Experiment subclass
    # value: name of the Mode as defined by the user in modes.yml

    modes = {
        "cavity": "cavB",
        "qubit": "qC",
        "resonator": "rrC",
        "drive": "drive",
        "qubitEF": "qB_EF",
    }

    ################################### PULSE MAP ######################################
    # key: name of the Pulse as defined by the Experiment subclass
    # value: name of the Pulse as defined by the user in modes.yml

    pulses = {        
        "cavity_pulse": "cavB_ramp_long_pulse",
        "drive_pulse": "exchange_pulse",
        "qubit_pulse": "qC_gaussian_sel_pi_pulse",
        "qubitEF_pi": "qBEF_gaussian_pi_pulse",
        "readout_pulse": "rrC_readout_pulse",
    }

    ############################## CONTROL PARAMETERS ##################################

    parameters = {
        "wait_time": 6e6,
        "ro_ampx": 1,
        "fetch_interval": 2,
        "plot_single_shot": True,
    }

    ######################## SWEEP (INDEPENDENT) VARIABLES #############################
    # must include an outermost averaging Sweep named "N"
    # must include all primary sweeps defined by the Experiment subclass

    # set number of repetitions for this Experiment run
    N.num = 5000

    # set the qubit frequency sweep for this Experiment run
    FREQ.name = "cavity_frequency"
    FREQ.start = -190e6
    FREQ.stop = -185e6
    FREQ.num = 101

    DRIVE_AMPX = Sweep(name="drive_ampx", points=[0.0, 1.0])

    sweeps = [N, DRIVE_AMPX, FREQ]

    ######################## DATASET (DEPENDENT) VARIABLES #############################
    # must include all primary datasets defined by the Experiment subclass
    # MAG.fitfn = "gaussian"

    PHASE.datafn_args = {"delay": 2.792e-7, "freq": RRB.int_freq}
    I.plot, Q.plot = True, True
    I.fitfn = "gaussian"
    SINGLE_SHOT.fitfn = "gaussian"
    PHASE.plot = False
    SINGLE_SHOT.plot= True

    datasets = [I, Q, SINGLE_SHOT]

    ######################## INITIALIZE AND RUN EXPERIMENT #############################

    expt = CavitySpecB(FOLDER, modes, pulses, sweeps, datasets, **parameters)
    expt.run()
