from config.experiment_config import FOLDER, N, I, Q, MAG, PHASE, RRC, SINGLE_SHOT, FREQ
from qcore import Experiment, qua, Sweep, Dataset
from qm import qua as qm_qua
from qcore.libs.qua_macros import QuaVariable
from qm.qua import if_

Ipre = Dataset(name="Ipre",save=False,plot=False)
Qpre = Dataset(name="Qpre",save=False,plot=False)
SINGLE_SHOTpre = Dataset(name="single_shotpre",save=True, plot=False)
IApre = Dataset(name="IApre",save=False,plot=False)
QApre = Dataset(name="QApre",save=False,plot=False)
SINGLE_SHOTApre = Dataset(name="single_shotApre",save=True, plot=False)
Ipost = Dataset(name="Ipost",save=False,plot=False)
Qpost = Dataset(name="Qpost",save=False,plot=False)
SINGLE_SHOTpost = Dataset(name="single_shotpost",save=True, plot=True)


class ThreeToneSpec(Experiment):
    """Cavity T2"""

    primary_datasets = ["I", "Q", "single_shot"]

    primary_sweeps = ["qubit_freq"]

    def sequence(self):
        """QUA sequence that defines this Experiment subclass"""
        qua.reset_frame(self.cavityB)
        qua.reset_frame(self.qubitB)
        qua.reset_frame(self.qubitC)

        qua.update_frequency(self.qubitB, self.qubit_freq)
        self.qubitB.play(self.qubitB_sel_pi_pulse)
        qua.align()

        self.cavityB.play(self.coherent1_pulse, ampx = 0.1, duration = 5000/4)
        qua.align() 

        self.qubitC.play(self.qubitC_sel_pi) 
        qua.align(self.qubitC, self.resonator)
                
        self.resonator.measure(self.readout_pulse, (self.I, self.Q), ampx=self.ro_ampx, demod_type="dual")
        qua.align()
        qua.wait(self.wait_time)
        if self.plot_single_shot:  
            qm_qua.assign(self.single_shot, qm_qua.Cast.to_fixed(self.I > self.readout_pulse.threshold),)

if __name__ == "__main__":
    """ """

    #################################### MODE MAP ######################################
    modes = {
        "cavityB": "cavB",
        "cavityA": "cavA",
        "qubitB": "qB",
        "qubitB_EF": "qB_EF",
        "qubitC": "qC",
        "qubitA": "qA",
        "qubitA_EF": "qA_EF",
        "resonator": "rrC",
        "resonatorA": "rrA",
        "drive": "drive"
    }
    ################################### PULSE MAP ######################################
    pulses = {
        "qubitB_sel_pi_pulse": "qB_gaussian_very_sel_pi_pulse",
        "coherent1_pulse": "cavB_ramp_pulse",
        "qubitC_sel_pi": "qC_gaussian_sel_pi_pulse",
        "readout_pulse": "rrC_readout_pulse", 
    }

    ############################## CONTROL PARAMETERS ##################################
    parameters = {
        "wait_time": 6e6,
        "ro_ampx": 1,
        "plot_single_shot": True,
    }

    ######################## SWEEP (INDEPENDENT) VARIABLES #############################

    N.num = 50000
    FREQ.name = "qubit_freq"
    FREQ.start = 350e6
    FREQ.stop = 351e6
    FREQ.num = 101
    sweeps = [N, FREQ]

    ######################## DATASET (DEPENDENT) VARIABLES #############################
    # must include all primary datasets defined by the Experiment subclass
    I.fitfn, SINGLE_SHOT.fitfn, Q.fitfn = "gaussian", "gaussian", "exp_decay_sine"
    PHASE.datafn_args = {"delay": 2.792e-7, "freq": RRC.int_freq}
    Q.plot, MAG.plot = False, False
    SINGLE_SHOT.plot_args = {"plot_err": False}
    I.plot_args = {"plot_err": False}
    datasets = [I, Q, SINGLE_SHOT]

    ######################## INITIALIZE AND RUN EXPERIMENT #############################

    expt = ThreeToneSpec(FOLDER, modes, pulses, sweeps, datasets, **parameters)
    expt.run(simulate=False)