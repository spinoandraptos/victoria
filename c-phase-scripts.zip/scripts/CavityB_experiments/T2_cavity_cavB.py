from config.experiment_config import FOLDER, N, I, Q, MAG, PHASE, RRC, SINGLE_SHOT
from qcore import Experiment, qua, Sweep, Dataset
from qm import qua as qm_qua
from qcore.libs.qua_macros import QuaVariable
from qm.qua import if_

Ipre = Dataset(name="Ipre",save=False,plot=False)
Qpre = Dataset(name="Qpre",save=False,plot=False)
SINGLE_SHOTpre = Dataset(name="single_shotpre",save=True, plot=False)
IApre = Dataset(name="IApre",save=False,plot=False)
QApre = Dataset(name="QApre",save=False,plot=False)
SINGLE_SHOTApre = Dataset(name="single_shotApre",save=True, plot=False)
Ipost = Dataset(name="Ipost",save=False,plot=False)
Qpost = Dataset(name="Qpost",save=False,plot=False)
SINGLE_SHOTpost = Dataset(name="single_shotpost",save=True, plot=True)


class CavityT2_B(Experiment):
    """Cavity T2"""

    primary_datasets = ["I", "Q", "single_shot"]

    primary_sweeps = ["time_delay"]

    def sequence(self):
        """QUA sequence that defines this Experiment subclass"""
        # qua.reset_phase(self.cavityB)
        qua.reset_frame(self.cavityB)
        # qua.reset_phase(self.cavityA)
        # qua.reset_frame(self.cavityA)
        # qua.reset_phase(self.qubitB)
        qua.reset_frame(self.qubitB)
        # qua.reset_phase(self.qubitA)
        qua.reset_frame(self.qubitC)


        factor = qm_qua.declare(qm_qua.fixed)
        qm_qua.assign(factor, self.detuning * 1e-9)
        qm_qua.assign(self.phase, qm_qua.Cast.mul_fixed_by_int(factor, self.time_delay))
        extra_factor = qm_qua.declare(qm_qua.fixed)
        qm_qua.assign(extra_factor, self.drive_detuning * 1e-9)
        qm_qua.assign(self.correcting_phase, qm_qua.Cast.mul_fixed_by_int(extra_factor, self.time_delay))
        total_phase = qm_qua.declare(qm_qua.fixed)
        # qm_qua.assign(total_phase, self.phase + self.correcting_phase + self.extra_phase)


        qua.align()

        # Prepare initial state (|0> - |1>)/sqrt(2)
        #qua.update_frequency(self.qubitA, self.qubitA.int_freq)

        # self.cavityA.play(self.cavityA_grape)
        # self.qubitA.play(self.qubitA_grape)

        self.cavityB.play(self.cavityB_grape)
        self.qubitB.play(self.qubitB_grape)
        qua.align()

        # self.qubitB_EF.play(self.qubitB_EF_pi)  # play selective qubit pulse
        # qua.align(self.qubitB_EF, self.resonator)
        # self.resonator.measure(self.readout_pulse, (self.Ipre, self.Qpre), ampx=self.ro_ampx, demod_type="dual")
        # qm_qua.assign(self.single_shotpre, qm_qua.Cast.to_fixed(self.Ipre > self.readout_pulse.threshold))
        
        # qua.update_frequency(self.qubitA, 350.72e6)
        # self.qubitA.play(self.qubitA_sel_pi)  # play selective qubit pulse
        # self.qubitA.play(self.qubitA_pi)  
        # qua.align(self.qubitA_EF, self.qubitA)
        # self.qubitA_EF.play(self.qubitA_EF_pi)  # play selective qubit pulse
        # qua.align(self.qubitA_EF, self.resonatorA)
        # self.resonatorA.measure(self.readout_pulseA, (self.IApre, self.QApre), ampx=self.ro_ampx, demod_type="dual")
        # qm_qua.assign(self.single_shotApre, qm_qua.Cast.to_fixed(self.IApre > self.readout_pulseA.threshold))

        # self.cavityA.play(self.cavityA_pulse, ampx= 1.14)  # displace by beta = 1.14
        # qua.align(self.qubitA, self.cavityA)  # align pulses
        # self.qubitA.play(self.qubitA_SNAP_pulse, ampx = 2.0)    # SNAP: play pi pulse around X
        # qua.align(self.qubitA, self.cavityA)  # align pulses
        # self.cavityA.play(self.cavityA_pulse, ampx= -0.58)  # displace by beta = -0.58

        # Wait relaxation
        # self.drive.play(self.drive_pulse, ampx = 1.0, duration = self.time_delay/4)

        qm_qua.assign(total_phase, self.phase)

        qua.wait(self.time_delay, self.cavityB)
        qua.align()

        # self.cavityB.play(self.coherent1_pulse, ampx=0.8, phase = total_phase )
        # qua.align(self.cavityB, self.qubitC) 
        # self.qubitC.play(self.qubitC_sel_pi)  # play selective qubit pulse
        # qua.align(self.qubitC, self.resonator)
        
        self.cavityB.play(self.coherent1_pulse, ampx=0.8, phase = total_phase )
        qua.align(self.cavityB, self.qubitB) 
        self.qubitB.play(self.qubit_sel_pi)  # play selective qubit pulse
        qua.align(self.qubitB, self.qubitB_EF)
        self.qubitB_EF.play(self.qubitB_EF_pi)  # play selective qubit pulse
        qua.align(self.qubitB_EF, self.resonator)
        
        self.resonator.measure(self.readout_pulse, (self.I, self.Q), ampx=self.ro_ampx, demod_type="dual")
        qua.align()
        qua.wait(self.wait_time)
        if self.plot_single_shot:  # assign state to G or E
            qm_qua.assign(self.single_shot, qm_qua.Cast.to_fixed(self.I > self.readout_pulse.threshold),)

    


if __name__ == "__main__":
    """ """

    #################################### MODE MAP ######################################
    modes = {
        "cavityB": "cavB",
        "cavityA": "cavA",
        "qubitB": "qB",
        "qubitB_EF": "qB_EF",
        "qubitC": "qC",
        "qubitA": "qA",
        "qubitA_EF": "qA_EF",
        "resonator": "rrB",
        # "resonatorA": "rrA",
        "drive": "drive",
    }
    ################################### PULSE MAP ######################################
    pulses = {
        # "drive_pulse": "exchange_pulse",
        "qubitB_grape": "qB_grape_fock01_new",
        "cavityB_grape": "cavB_grape_fock01_new",
        "qubitA_grape": "qA_grape_fock1",
        "cavityA_grape": "cavA_grape_fock1",
        "qubitB_EF_pi": "qBEF_gaussian_pi_pulse",
        # "qubitA_EF_pi": "qAEF_EF_gaussian_pi_pulse",
        "coherent1_pulse": "cavB_ramp_pulse",
        # "coherent1A_pulse": "cavA_ramp_pulse",
        #"qubit_sel_pi": "qC_gaussian_sel_pi_pulse",
        "qubit_sel_pi": "qB_gaussian_very_sel_pi_pulse",
        # "qubitA_sel_pi": "qA_gaussian_very_sel_pi_pulse",
        # "qubitA_pi": "qA_gaussian_pi_pulse",
        "readout_pulse": "rrB_GF_CLEAR_readout_pulse", 
        # "readout_pulseA": "rrA_GF_CLEAR_readout_pulse", 
        # "cavityA_pulse": "cavA_ramp_pulse",
        # "qubitA_SNAP_pulse": "qA_gaussian_very_sel_pi_pulse",
        # "readout_pulse2": "rrB_pulse_calibrate", 
    }

    ############################## CONTROL PARAMETERS ##################################
    parameters = {
        "extra_phase" : 0, #- 0.374 + 0.07 - 0.227/3.14,
        "wait_time": 6e6,
        "detuning": 100e3,
        "drive_detuning": 0,#-498.5e3 , 
        "phase": QuaVariable(value=0.0, dtype=qm_qua.fixed, tag="phase", buffer=True, stream=True),
        "correcting_phase": QuaVariable(value=0.0, dtype=qm_qua.fixed, tag="correcting_phase", buffer=True, stream=True),
        "ro_ampx": 1,
        "plot_single_shot": True,
    }

    ######################## SWEEP (INDEPENDENT) VARIABLES #############################
    # must include an outermost averaging Sweep named "N"
    # must include all primary sweeps defined by the Experiment subclass

    # set number of repetitions for this Experiment run
    N.num = 50000

    # set the qubit frequency sweep for this Experiment run


    DEL = Sweep(name="time_delay", start=50, stop = 100000, num = 100, dtype=int)
    sweeps = [N, DEL]

    ######################## DATASET (DEPENDENT) VARIABLES #############################
    # must include all primary datasets defined by the Experiment subclass
    I.fitfn, SINGLE_SHOT.fitfn, Q.fitfn = "exp_decay_sine", "exp_decay_sine", "exp_decay_sine"
    PHASE.datafn_args = {"delay": 2.792e-7, "freq": RRC.int_freq}
    Q.plot, MAG.plot = False, False
    SINGLE_SHOT.plot_args = {"plot_err": False}
    I.plot_args = {"plot_err": False}
    SINGLE_SHOT.plot = True
    datasets = [I, Q, SINGLE_SHOT]

    ######################## INITIALIZE AND RUN EXPERIMENT #############################

    expt = CavityT2_B(FOLDER, modes, pulses, sweeps, datasets, **parameters)
    expt.run(simulate=False)