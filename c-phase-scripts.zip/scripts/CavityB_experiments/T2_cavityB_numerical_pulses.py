""" """
import sys

from config.experiment_config import FOLDER, N, FREQ, I, Q, MAG, PHASE, RRB, SINGLE_SHOT
from qcore import Experiment, qua, Sweep, Dataset
from qm import qua as qm_qua
from qcore.libs.qua_macros import QuaVariable

Ipost = Dataset(name="Ipost",save=False,plot=False)
Qpost = Dataset(name="Qpost",save=False,plot=False)
SINGLE_SHOTpost = Dataset(name="single_shotpost",save=True, plot=False)

class Wigner1D_B(Experiment):
    """Wigner_function"""

    ############################# DEFINE PRIMARY DATASETS ##############################
    # these Datasets form the "raw" experimental data and will be streamed by the OPX
    # they must be specified at experiment runtime
    primary_datasets = ["I", "Q", "single_shot", "Ipost", "Qpost", "single_shotpost"]
    #primary_datasets = ["I", "Q", "single_shot"]

    primary_sweeps = ["gate_id"]
    def __init__(self, folder, modes, pulses, sweeps, datasets, **parameters):

        super().__init__(
            folder,
            modes,
            pulses,
            sweeps,
            datasets,
            **parameters,
        )  # Passes other parameters to parent

        self.pulse_list = [f"self.exchange_pulse_cos2_{d}" for d in range (self.time_start, self.time_stop+self.time_step, self.time_step)]


    ############################## DEFINE PRIMARY SWEEPS ###############################
    # these Sweeps are uniquely associated with the Experiment subclass
    # these Sweeps must be specified at experiment runtime

    ############################ DEFINE THE PULSE SEQUENCE #############################
    # ensure that you import 'qua' from 'qcore' and not from 'qm' library
    # attributes accessed via 'self' must be defined in 'if __name__ == "__main__"' code
    def sequence(self):
        """QUA sequence that defines this Experiment subclass"""
        
        qua.reset_frame(self.cavityA)
        qua.reset_frame(self.cavityB)
        qua.reset_frame(self.qubitA)
        qua.reset_frame(self.qubitB)
        qua.reset_frame(self.drive)
        qua.reset_frame(self.resonator)
        qua.update_frequency(self.drive, 334e6)
        #qua.update_frequency(self.qubit, self.qubit.int_freq) 
        factor = qm_qua.declare(qm_qua.fixed)
        qm_qua.assign(factor, self.detuning * 1e-9)
        extra_factor = qm_qua.declare(qm_qua.fixed)
        qm_qua.assign(extra_factor, self.drive_detuning * 1e-9)
        qua.align()

        # PREPARE STATE
        # self.cavity.play(self.cav_op, phase = 0.0)
        # Prepare 1 in A
        self.qubitB.play(self.qubitB_grape)
        self.cavityB.play(self.cavityB_grape) 
        # self.cavityA.play(self.cavityA_grape)
        # self.qubitA.play(self.qubitA_grape)
        qua.align()


        with qm_qua.switch_(self.gate_id):
            for i in range(self.time_start, self.time_stop+self.time_step, self.time_step):
                with qm_qua.case_(i):
                    qm_qua.assign(self.phase, qm_qua.Cast.mul_fixed_by_int(factor, i))
                    qm_qua.assign(self.correcting_phase, qm_qua.Cast.mul_fixed_by_int(extra_factor, i))
                    self.drive.play(getattr(self,f"exchange_pulse_cos2_{i}"))

        total_phase = qm_qua.declare(qm_qua.fixed)
        qm_qua.assign(total_phase, 0.25 + self.phase + self.correcting_phase + self.ramp_phase)

        # qua.wait(self.drive_time, self.cavity)  # wait for state to rotate
        qua.align()

        # MEASURE
        self.cavityB.play(self.cavityB_pulse, ampx=1.0, phase = total_phase)
        qua.align(self.cavityB, self.qubitB) 
        self.qubitB.play(self.qubitB_sel_pi)  # play selective qubit pulse
        qua.align(self.qubitB_EF, self.qubitB)
        self.qubitB_EF.play(self.qubitB_EF_pi)  # play selective qubit pulse
        qua.align(self.qubitB_EF, self.resonator)
        self.resonator.measure(self.readout_pulse, (self.I, self.Q), demod_type="dual")
        qua.align()
        qua.wait(self.wait_time)
        if self.plot_single_shot:  # assign state to G or E
            qm_qua.assign(self.single_shot, qm_qua.Cast.to_fixed(self.I > self.readout_pulse.threshold),)

if __name__ == "__main__":
    """ """

    #################################### MODE MAP ######################################
    # key: name of the Mode as defined by the Experiment subclass
    # value: name of the Mode as defined by the user in modes.yml
    modes = {
        "cavityA": "cavA",
        "cavityB": "cavB",
        "qubitA": "qA",
        "qubitAEF": "qA_EF",
        "qubitB": "qB",
        "qubitB_EF": "qB_EF",
        "qubitC": "qC",
        "resonator": "rrB",
        "drive":"drive",
    }

    ################################### PULSE MAP ######################################
    # key: name of the Pulse as defined by the Experiment subclass
    # value: name of the Pulse as defined by the user in modes.yml
    pulses = {
        "cavityB_pulse": "cavB_ramp_pulse",
        # "qubitA_grape": "qA_grape_fock2",
        # "cavityA_grape": "cavA_grape_fock2",
        "qubitB_grape": "qB_grape_fock02",
        "cavityB_grape": "cavB_grape_fock02",
        # "drive_pulse": "exchange_sg_pulse",
        # "qubit_pi": "qA_gaussian_pi_pulse",
        # "qubit_sel_pi": "qA_gaussian_very_sel_pi_pulse",
        # "qubitEF_pi": "qAEF_EF_gaussian_pi_pulse",

        "qubitB_pi": "qB_gaussian_pi_pulse",
        "qubitB_sel_pi": "qB_gaussian_very_sel_pi_pulse",
        "qubitB_EF_pi": "qBEF_gaussian_pi_pulse",

        "qubitC_sel_pi": "qC_gaussian_sel_pi_pulse",
        "readout_pulse": "rrB_GF_CLEAR_readout_pulse", 
        
    }

    
    time_start = 16
    time_stop = 49_000
    time_step = 1_000
    
    for d in range(time_start,time_stop+time_step,time_step):
        pulses[f"exchange_pulse_cos2_{d}"] = f"exchange_pulse_cos2_{d}"


    ############################## CONTROL PARAMETERS ##################################
    parameters = {
        "ramp_phase":  -0.07/2,
        "drive_detuning":  (-454.3e3)/2,
        "wait_time": 7e6,
        "detuning": 100e3/2,
        "phase": QuaVariable(value=0.0, dtype=qm_qua.fixed, tag="phase", buffer=True, stream=True),
        "correcting_phase": QuaVariable(value=0.0, dtype=qm_qua.fixed, tag="correcting_phase", buffer=True, stream=True),
        "plot_single_shot": True,
        "time_start":  time_start,
        "time_stop":  time_stop,
        "time_step":  time_step,
    }

    ######################## SWEEP (INDEPENDENT) VARIABLES #############################
    # must include an outermost averaging Sweep named "N"
    # must include all primary sweeps defined by the Experiment subclass

    # set number of repetitions for this Experiment run
    N.num = 5000
    # QD_AMPX = Sweep(name="drive_amplitude", start=0, stop=1.0, step=1)
    # TIME = Sweep(name="drive_time", start = 16, stop=60_000, step = 600, dtype = int)
    GATES = Sweep(name="gate_id", start=time_start, stop=time_stop, step=time_step, dtype=int, save=True)
    sweeps = [N, GATES]
    #sweeps = [N, QD_AMPX, TIME]

    ######################## DATASET (DEPENDENT) VARIABLES #############################
    # must include all primary datasets defined by the Experiment subclass
    # I.fitfn = "gaussian"
    PHASE.datafn_args = {"delay": 2.792e-7, "freq": RRB.int_freq}
    I.plot, Q.plot, MAG.plot, PHASE.plot = False, False, False, False
    SINGLE_SHOT.fitfn = 'exp_decay_sine'
    datasets = [I, Q, SINGLE_SHOT, Ipost, Qpost, SINGLE_SHOTpost]
    #datasets = [I, Q, SINGLE_SHOT]
    ######################## INITIALIZE AND RUN EXPERIMENT #############################
    expt = Wigner1D_B(FOLDER, modes, pulses, sweeps, datasets, **parameters)
    expt.run()
