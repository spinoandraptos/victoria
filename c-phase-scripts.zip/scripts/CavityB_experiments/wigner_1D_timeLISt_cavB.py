""" """
import sys

from config.experiment_config import FOLDER, N, FREQ, I, Q, MAG, PHASE, RRB, SINGLE_SHOT
from qcore import Experiment, qua, Sweep, Dataset
from qm import qua as qm_qua
from qcore.libs.qua_macros import QuaVariable

Ipost = Dataset(name="Ipost",save=False,plot=False)
Qpost = Dataset(name="Qpost",save=False,plot=False)
SINGLE_SHOTpost = Dataset(name="single_shotpost",save=True, plot=True)

class Wigner1D(Experiment):
    """Wigner_function"""

    ############################# DEFINE PRIMARY DATASETS ##############################
    # these Datasets form the "raw" experimental data and will be streamed by the OPX
    # they must be specified at experiment runtime
    #primary_datasets = ["I", "Q", "single_shot", "Ipost", "Qpost", "single_shotpost"]
    primary_datasets = ["I", "Q", "single_shot"]


    ############################## DEFINE PRIMARY SWEEPS ###############################
    # these Sweeps are uniquely associated with the Experiment subclass
    # these Sweeps must be specified at experiment runtime
    primary_sweeps = ["gate_id"]
    
    def __init__(self, folder, modes, pulses, sweeps, datasets, **parameters):

        super().__init__(
            folder,
            modes,
            pulses,
            sweeps,
            datasets,
            **parameters,
        )  # Passes other parameters to parent

        self.pulse_list = [f"self.exchange_pulse_{d}" for d in range (16, 10_500, 500)]
        
    
    ############################ DEFINE THE PULSE SEQUENCE #############################
    # ensure that you import 'qua' from 'qcore' and not from 'qm' library
    # attributes accessed via 'self' must be defined in 'if __name__ == "__main__"' code
    def sequence(self):
        """QUA sequence that defines this Experiment subclass"""
        

        factor = qm_qua.declare(qm_qua.fixed)
        qm_qua.assign(factor, self.detuning * 1e-9)  # formerly with a 4*

        # qua.reset_phase(self.cavityB)
        qua.reset_frame(self.cavityB)
        # qua.reset_phase(self.cavityA)
        # qua.reset_frame(self.cavityA)
        # qua.reset_phase(self.qubitB)
        qua.reset_frame(self.qubitB)
        # qua.reset_phase(self.qubitA)
        # qua.reset_frame(self.qubitA)
        qua.align()


        #qua.update_frequency(self.qubitB, self.qubitB.int_freq) 

        # #load fock 1 in cavity A
        # self.cavityA.play(self.cavityA_grape)
        # self.qubitA.play(self.qubitA_grape)
        self.cavityB.play(self.cavityB_grape)
        self.qubitB.play(self.qubitB_grape)
        qua.align()

        
        with qm_qua.switch_(self.gate_id):
            for i in range(16,10_500,500):
                with qm_qua.case_(i):

                    qm_qua.assign(self.phase, qm_qua.Cast.mul_fixed_by_int(factor, i))
                    new_phase = qm_qua.declare(qm_qua.fixed)
                    qm_qua.assign(new_phase, self.phase + 0.25)

                    self.drive.play(getattr(self,f"exchange_pulse_{i}"), ampx = 1.0)
        
        # qua.wait(6000, self.cavityB)  # wait for state to rotate
        qua.align() 

        # WIGNER
        self.cavityB.play(self.cavityB_pulse, ampx=0.4, phase=new_phase)  # displacement in I direction
        qua.align()

        self.qubitB.play(self.qubit_op)  # play pi/2 pulse around X
        qua.wait(self.time_delay, self.qubitB)  # conditional phase gate on even, odd Fock state
        self.qubitB.play(self.qubit_op, phase = 0)  # play pi/2 pulse around X
        qua.align()  # align measurement
        self.qubitB_EF.play(self.qubit_EF_pi)  # play pi/2 pulse around X
        qua.align()
        # Measure cavity state
        self.resonator.measure(self.readout_pulse, (self.I, self.Q), ampx=self.ro_ampx, demod_type= 'dual')  # measure transmitted signal
        if self.plot_single_shot:  # assign state to G or E
            qm_qua.assign(self.single_shot,qm_qua.Cast.to_fixed(self.I > self.readout_pulse.threshold),)
        qua.align()
        qua.wait(self.wait_time)

if __name__ == "__main__":
    """ """

    #################################### MODE MAP ######################################
    # key: name of the Mode as defined by the Experiment subclass
    # value: name of the Mode as defined by the user in modes.yml
    modes = {
       # "qC": "qC",
        "qubitB_EF": "qB_EF",
        "cavityB": "cavB",
        "cavityA": "cavA",
        "drive":"drive",
        "qubitB": "qB",
        "qubitA": "qA",
        "resonator": "rrB",
        #"resonatorC": "rrC",
    }

    ################################### PULSE MAP ######################################
    # key: name of the Pulse as defined by the Experiment subclass
    # value: name of the Pulse as defined by the user in modes.yml
    pulses = {
        "qubitA_grape": "qA_grape_fock1",
        "cavityA_grape": "cavA_grape_fock1",
        "qubit_EF_pi": "qBEF_gaussian_pi_pulse",
        "qubitB_grape": "qB_grape_fock01_new",
        "cavityB_grape": "cavB_grape_fock01_new",
        "cavityB_pulse": "cavB_ramp_pulse",
        #"qubit_sel_pulse": "qB_gaussian_sel_pi_pulse",
        "qubit_op": "qB_gaussian_pi2_pulse",
        "readout_pulse": "rrB_GF_CLEAR_readout_pulse", 
        #"readout_pulseC": "rrC_readout_pulse",
        "drive_pulse": "exchange_pulse",
    }

    for d in range(16,10_500,500):
        pulses[f"exchange_pulse_{d}"] = f"exchange_pulse_{d}"
       

    ############################## CONTROL PARAMETERS ##################################
    parameters = {
        "detuning": -491e3 - 10e3-18e3 , #0.21e5,#-0.38e6 + 0.023e6,
        "phase": QuaVariable(value=0.0, dtype=qm_qua.fixed, tag="phase", buffer=True, stream=True),
        "wait_time": 6e6,
        "ro_ampx": 1,
        "time_delay": 156, # 620,
        "plot_single_shot": True,
        "qubit_drive_ampx": 1.0,
    }

    ######################## SWEEP (INDEPENDENT) VARIABLES #############################
    # must include an outermost averaging Sweep named "N"
    # must include all primary sweeps defined by the Experiment subclass

    # set number of repetitions for this Experiment run
    N.num = 2000
    #QD_AMPX = Sweep(name="cavity_drive_amplitude", start=-2.0, stop=2.0, step=0.05)
    PHASE = Sweep(name="qb_phase", start=0, stop=0.5, step=0.5)

    GATES = Sweep(name="gate_id", start=16, stop=10_000, step=500, dtype=int, save=True) # (0, 1, ..., 19, 20) 
    
    
    sweeps = [N, GATES]
    ######################## DATASET (DEPENDENT) VARIABLES #############################
    # must include all primary datasets defined by the Experiment subclass
    # I.fitfn = "gaussian"
    PHASE.datafn_args = {"delay": 2.792e-7, "freq": RRB.int_freq}
    I.plot, Q.plot, MAG.plot, PHASE.plot = False, False, False, False
    SINGLE_SHOT.fitfn = 'gaussian'
    #datasets = [I, Q, SINGLE_SHOT, Ipost, Qpost, SINGLE_SHOTpost]
    datasets = [I, Q, SINGLE_SHOT]
    ######################## INITIALIZE AND RUN EXPERIMENT #############################
    expt = Wigner1D(FOLDER, modes, pulses, sweeps, datasets, **parameters)
    expt.run()
