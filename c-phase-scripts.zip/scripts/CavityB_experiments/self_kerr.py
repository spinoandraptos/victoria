""" """

from config.experiment_config import FOLDER, N, FREQ, I, Q, MAG, PHASE, RRB, SINGLE_SHOT
from qm import qua as qm_qua
from qcore import Experiment, qua, Sweep
from qcore.libs.qua_macros import QuaVariable

class selfKerr(Experiment):
    """Cavity self Kerr"""

    ############################# DEFINE PRIMARY DATASETS ##############################
    # these Datasets form the "raw" experimental data and will be streamed by the OPX
    # they must be specified at experiment runtime
    primary_datasets = ["I", "Q", "single_shot"]

    ############################## DEFINE PRIMARY SWEEPS ###############################
    # these Sweeps are uniquely associated with the Experiment subclass
    # these Sweeps must be specified at experiment runtime
    primary_sweeps = ["time_delay"]

    ############################ DEFINE THE PULSE SEQUENCE #############################
    # ensure that you import 'qua' from 'qcore' and not from 'qm' library
    # attributes accessed via 'self' must be defined in 'if __name__ == "__main__"' code

    def sequence(self):
        factor = qm_qua.declare(qm_qua.fixed)
        qm_qua.assign(factor, self.detuning * 1e-9)  # formerly with a 4*
        qua.reset_frame(self.cav)
        qua.reset_phase(self.cav)

        #self.cav.play(self.cavity_pulse, ampx = self.cavity_pulse_amplitude) # displace cavity
        self.cav.play(self.cavity_pulse, ampx = self.cavity_pulse_amplitude) # displace cavity
        qua.align()
        #self.drive.play(self.drive_pulse, duration = self.time_delay/4)
        qua.wait(self.time_delay, self.cav)
        qua.align()
       
        qm_qua.assign(self.phase, qm_qua.Cast.mul_fixed_by_int(factor, self.time_delay)+0.5) # virtual phase
        self.cav.play(self.cavity_pulse, ampx = self.cavity_pulse_amplitude, phase = self.phase) # displace cavity back
        qua.align()
        
        self.qubit.play(self.qubit_pulse)
        qua.align(self.qubit, self.qubitEF)  # align all modes
        self.qubitEF.play(self.qubitEF_drive)
        qua.align(self.qubitEF, self.resonator)  # align all modes
        self.resonator.measure(self.readout_pulse, (self.I, self.Q), ampx=self.ro_ampx, demod_type="dual")
        qua.wait(self.wait_time, self.resonator)
        if self.plot_single_shot:  # assign state to G or E
            qm_qua.assign(self.single_shot,qm_qua.Cast.to_fixed(self.I > self.readout_pulse.threshold),)

if __name__ == "__main__":
    """ """
    #################################### MODE MAP ######################################
    # key: name of the Mode as defined by the Experiment subclass
    # value: name of the Mode as defined by the user in modes.yml
    modes = {
    # "qubitAGF": "qubitAGF",
            "drive": "drive",
            "qubit": "qB", 
            "qubitEF":"qB_EF",
            "cav":"cavB",
            "resonator": "rrB"}
    ################################### PULSE MAP ######################################
    # key: name of the Pulse as defined by the Experiment subclass
    # value: name of the Pulse as defined by the user in modes.yml
    pulses = {"qubit_pulse": "qB_gaussian_sel_pi_pulse",
            "cavity_pulse":"cavB_coh2",
            "qubitEF_drive": "qBEF_gaussian_pi_pulse",
            # "qubitA_drive": "qubitAGF_gaussian_pi_pulse",
            "drive_pulse": "exchange_pulse",
            "readout_pulse": "rrB_GF_CLEAR_readout_pulse",}

    ############################## CONTROL PARAMETERS ##################################
    parameters = {
        "wait_time": 5e6,
        "ro_ampx": 1,
        "detuning": 5e6,  # Hz
        "phase": QuaVariable(
            value=0.0,
            dtype=qm_qua.fixed,
            tag="phase",
            buffer=True,
            stream=True,
        ),
        "plot_single_shot": True,
    }

    ######################## SWEEP (INDEPENDENT) VARIABLES #############################
    # must include an outermost averaging Sweep named "N"
    # must include all primary sweeps defined by the Experiment subclass

    # set number of repetitions for this Experiment run
    N.num = 5000

    # set the qubit frequency sweep for this Experiment run

    DEL = Sweep(name="time_delay", start=16, stop=1000, step=4, dtype=int)  # ns
    CAV_AMPX = Sweep(name="cavity_pulse_amplitude", start=0.1, stop=1.8, num=10)

    #CAV_AMPX = Sweep(name="cavity_pulse_amplitude", start=1.118, stop=1.225, num=2)  

    sweeps = [N, CAV_AMPX, DEL]

    ######################## DATASET (DEPENDENT) VARIABLES #############################
    # must include all primary datasets defined by the Experiment subclass
    I.fitfn = "exp_decay_sine"
    Q.fitfn = "exp_decay_sine"
    Q.plot = False
    # SINGLE_SHOT.fitfn = "exp_decay_sine"
    # PHASE.datafn_args = {"delay": 2.792e-7, "freq": RRC.int_freq}
    # PHASE.plot = False
    # I.plot, Q.plot = False, False
    datasets = [I, Q, SINGLE_SHOT]

    ######################## INITIALIZE AND RUN EXPERIMENT #############################

    expt = selfKerr(FOLDER, modes, pulses, sweeps, datasets, **parameters)
    expt.run()
