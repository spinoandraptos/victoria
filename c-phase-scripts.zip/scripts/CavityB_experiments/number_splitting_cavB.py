from config.experiment_config import FOLDER, N, FREQ, I, Q, MAG, PHASE, RRC, SINGLE_SHOT, RRB
from qm import qua as qm_qua
from qcore import Experiment, qua, Sweep


class NumberSplittingB(Experiment):
    """Number splitting"""

    ############################# DEFINE PRIMARY DATASETS ##############################
    primary_datasets = ["I", "Q", "single_shot"]

    ############################## DEFINE PRIMARY SWEEPS ###############################
    primary_sweeps = ["qubit_frequency"]
    #primary_sweeps = ["qubit_amplitude"]

    ############################ DEFINE THE PULSE SEQUENCE #############################
    def sequence(self):
        """QUA sequence that defines this Experiment subclass"""
        qua.reset_frame(self.cavityB)
        qua.reset_frame(self.qubitB)
        qua.align()

        qua.update_frequency(self.qubitB, self.qubitB.int_freq)

        # with qm_qua.switch_(self.orens_id):
        #     with qm_qua.case_(0):
        #         self.cavityB.play(self.cavityB_grape_0)
        #         self.qubitB.play(self.qubitB_grape_0)
        #     with qm_qua.case_(1):
        #         self.cavityB.play(self.cavityB_grape_1)
        #         self.qubitB.play(self.qubitB_grape_1)            
        #     with qm_qua.case_(2):
        #         self.cavityB.play(self.cavityB_grape_2)
        #         self.qubitB.play(self.qubitB_grape_2)            
        #     with qm_qua.case_(3):
        #         self.cavityB.play(self.cavityB_grape_3)
        #         self.qubitB.play(self.qubitB_grape_3)
        #     with qm_qua.case_(4):
        #         self.cavityB.play(self.cavityB_grape_4)
        #         self.qubitB.play(self.qubitB_grape_4)            

        # Flip qubit
        # self.qubitB.play(self.qB_pi)
        qua.align()
        self.cavityB.play(self.cavityB_grape)
        self.qubitB.play(self.qubitB_grape)
        # qua.update_frequency(self.qC, self.qC.int_freq) 
        # self.qC.play(self.qC_pulse)
        qua.align()

        # qua.update_frequency(self.qubitB, self.qubitB.int_freq) #!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
        # self.qubitA.play(self.qubitA_grape, ampx = self.qubit_drive_ampx)
        # self.cavityA.play(self.cavityA_grape, ampx = self.qubit_drive_ampx) 
        # self.qubitB.play(self.qubitB_grape)
        # self.cavityB.play(self.cavityB_grape)
        # qua.align()

        # self.cavity.play(self.cavity_pulse)
        # qua.align()

        #self.drive.play(self.drive_pulse, duration = 6000/4)
        #qua.align()

        #Selective pi pulse
        # qua.update_frequency(self.qC, self.qubit_frequency)
        # # #qua.update_frequency(self.qC, -65.6e6)
        # self.qC.play(self.qC_pulse)
        # qua.align()

        qua.update_frequency(self.qubitB, self.qubit_frequency)
        self.qubitB.play(self.qubit_spec_pulse)
        qua.align(self.qubitB, self.qubitBEF)
        self.qubitBEF.play(self.qubitBEF_drive)
        qua.align(self.qubitBEF, self.resonator)

        self.resonator.measure(self.readout_pulse, (self.I, self.Q), demod_type="dual")
        qua.align()
        qua.wait(self.wait_time)
        if self.plot_single_shot:  # assign state to G or E
            qm_qua.assign(self.single_shot,qm_qua.Cast.to_fixed(self.I > self.readout_pulse.threshold),)

grape_list_B = ["fock01_new", "fock0-1", "fock0i1", "fock0-i1"]

if __name__ == "__main__":
    """ """

    #################################### MODE MAP ######################################
    # key: name of the Mode as defined by the Experiment subclass
    # value: name of the Mode as defined by the user in modes.yml

    modes = {
        # "cavityA": "cavA",
        "cavityB": "cavB",
        "qubitB": "qB",
        # "qubitA": "qA",
        "qubitBEF":"qB_EF",
        "qC": "qB",
        "resonator": "rrB",
        # "drive": "drive",
    }
    ################################### PULSE MAP ######################################
    # key: name of the Pulse as defined by the Experiment subclass
    # value: name of the Pulse as defined by the user in modes.yml

    pulses = {
        # "qubitB_grape": "qB_grape_fock1",
        # "cavityB_grape": "cavB_grape_fock1",
        "qubitB_grape": "qB_grape_fock1",
        "cavityB_grape": "cavB_grape_fock1",
        # "qubitB_grape_1": "qB_grape_fock2_new_new",
        # "cavityB_grape_1": "cavB_grape_fock2_new_new",
        # "qubitB_grape_2": "qB_grape_fock2_new2",
        # "cavityB_grape_2": "cavB_grape_fock2_new2",
        # "qubitB_grape_2": "qB_grape_fock2_1",
        # "cavityB_grape_2": "cavB_grape_fock2_1",
        # "qubitB_grape_3": "qB_grape_fock2_2",
        # "cavityB_grape_3": "cavB_grape_fock2_2",
        # "qubitB_grape_4": "qB_grape_fock2",
        # "cavityB_grape_4": "cavB_grape_fock2",
        # "cavity_pulse": "cavB_ramp_pulse",
        # "drive_pulse": "exchange_pulse",
        #"qC_pulse": "qC_gaussian_sel_pi_pulse",
        "qB_pi":"qB_gaussian_pi2_pulse",
        "qubitBEF_drive": "qBEF_gaussian_pi_pulse",
        "qubit_spec_pulse": "qB_gaussian_very_sel_pi_pulse",
        "readout_pulse": "rrB_GF_CLEAR_readout_pulse",
        #"readout_pulse": "rrC_readout_pulse",
    }
                                       
    ############################## CONTROL PARAMETERS ##################################
    parameters = {
        "wait_time": 6e6,
        "plot_single_shot": True,
    }

    ######################## SWEEP (INDEPENDENT) VARIABLES #############################
    N.num = 10000
    FREQ.name = "qubit_frequency"
    FREQ.start = 344e6
    FREQ.stop = 352e6
    FREQ.num = 101

    ORENS = Sweep(name="orens_id", start=0, stop=4, num=5, dtype=int, save=True)
    # GRAPE = Sweep(name="grape_ampx", start=0.0, stop=1.0, step = 1.0, dtype= float, save=True)

    # sweeps = [N, GRAPE, FREQ]
    sweeps = [N, FREQ]

    # QD_AMPX = Sweep(name="qubit_drive_ampx", points=[0.0, 1.0])
    # QD_AMPX = Sweep(name="qc_ampx", points= [0.0, 1.0]) #needs to be floating point numbers 
    # sweeps = [N, QD_AMPX, FREQ]

    ######################## DATASET (DEPENDENT) VARIABLES #############################
    PHASE.datafn_args = {"delay": 2.792e-7, "freq": RRB.int_freq}
    I.plot, Q.plot, MAG.plot = False, False, False
    SINGLE_SHOT.plot = True
    SINGLE_SHOT.fitfn = "gaussian"
    datasets = [I, Q, SINGLE_SHOT]

    ######################## INITIALIZE AND RUN EXPERIMENT #############################
    expt = NumberSplittingB(FOLDER, modes, pulses, sweeps, datasets, **parameters)
    expt.run()
