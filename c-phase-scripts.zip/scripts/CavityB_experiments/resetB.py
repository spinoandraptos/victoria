from config.experiment_config import FOLDER, N, FREQ, I, Q, MAG, PHASE, RRC, SINGLE_SHOT
from qm import qua as qm_qua
from qcore import Experiment, qua, Sweep


class ResonantExchange1D(Experiment):
    """Resonant exchange"""

    primary_datasets = ["I", "Q", "single_shot"]

    primary_sweeps = ["drive_length"]

    def sequence(self):
        """QUA sequence that defines this Experiment subclass"""

        qua.reset_frame(self.cavB)
        qua.reset_frame(self.qB)
        qua.reset_frame(self.resetB)

        self.cavB.play(self.cavB_grape)
        self.qB.play(self.qB_grape)
        qua.align()

        # Drive resonant exchange
        # qua.update_frequency(self.resetB, self.resetB_freq)

        # qua.update_frequency(self.resetB, -102e6)
        qua.update_frequency(self.resetB, -96.4e6)
        qua.wait(16, self.resetB)
        self.resetB.play(self.resetB_pulse, duration = self.drive_length/4,  ampx = 2.0)
        qua.align()

        self.qB.play(self.qB_sel_pulse)
        qua.align(self.qB, self.qB_EF)
        self.qB_EF.play(self.qubitBEF_pi)
        qua.align(self.qB_EF, self.resonatorB)
        
        self.resonatorB.measure(self.readout_pulseB, (self.I, self.Q), ampx=self.ro_ampx, demod_type="dual")
        qua.align()
        qua.wait(self.wait_time)
        if self.plot_single_shot:  # assign state to G or E
            qm_qua.assign(self.single_shot, qm_qua.Cast.to_fixed(self.I > self.readout_pulseB.threshold))

if __name__ == "__main__":
    """ """

    modes = {
            "resetB":"resetB",
            "cavB": "cavB",
            "qB": "qB",
            "qB_EF": "qB_EF",
            "resonatorB": "rrB",
             }

    pulses = {
        "cavB_grape": "cavB_grape_fock1",
        "qB_grape": "qB_grape_fock1",
        "qB_sel_pulse": "qB_gaussian_very_sel_pi_pulse",
        "qubitBEF_pi":"qBEF_gaussian_pi_pulse",
        "resetB_pulse":"resetB_pulse",
        "readout_pulseB": "rrB_GF_CLEAR_readout_pulse", 
    }
                                       
    parameters = {
        "wait_time": 6e6,
        "ro_ampx": 1,
        "plot_single_shot": True,
        # "drive_length": 80,
    }

    N.num = 50_000
    FREQ.name = "resetB_freq"
    FREQ.start = -120e6
    FREQ.stop = -80e6
    FREQ.num = 201

    LENGTH = Sweep (name="drive_length", dtype=int, units = "ns")
    LENGTH.start = 8
    LENGTH.stop = 2000
    LENGTH.step = 40 ###PREV 2000

    sweeps = [N, LENGTH]

    Q.plot,MAG.plot, PHASE.plot, I.plot = True, False, False, True
    SINGLE_SHOT.plot = True
    datasets = [I, Q, SINGLE_SHOT]

    expt = ResonantExchange1D(FOLDER, modes, pulses, sweeps, datasets, **parameters)
    expt.run(simulate = False)
