""" """

from config.experiment_config import FOLDER, N, FREQ, I, Q, MAG, PHASE, RRB, SINGLE_SHOT
from qm import qua as qm_qua
from qcore import Experiment, qua, Sweep
import numpy as np


class OutAndBackChi(Experiment):
    """Dispersive shift between cavity and qubit"""

    ############################# DEFINE PRIMARY DATASETS ##############################
    # these Datasets form the "raw" experimental data and will be streamed by the OPX
    # they must be specified at experiment runtime

    primary_datasets = ["I", "Q", "single_shot"]

    ############################## DEFINE PRIMARY SWEEPS ###############################
    # these Sweeps are uniquely associated with the Experiment subclass
    # these Sweeps must be specified at experiment runtime

    primary_sweeps = ["time_delay"]

    ############################ DEFINE THE PULSE SEQUENCE #############################
    # ensure that you import 'qua' from 'qcore' and not from 'qm' library
    # attributes accessed via 'self' must be defined in 'if __name__ == "__main__"' code

    def sequence(self):
        """QUA sequence that defines this Experiment subclass"""
        qua.reset_phase(self.cavity)
        qua.reset_frame(self.cavity)
        qua.reset_phase(self.qubit)
        qua.reset_frame(self.qubit)

        # qua.update_frequency(self.qubit, self.qubit.int_freq) 
        # qua.align()
        # qua.initialize_cavity(
        #     rr=self.resonator,
        #     qubit = self.qubit, 
        #     readout_pulse=self.readout_pulse,
        #     qubit_pulse = self.qubit_selective_pi,
        #     demod_type="dual",
        #     threshold_g=self.readout_pulse.threshold,
        #     ro_ampx=self.ro_ampx,
        #     wait_time=50_000,
        #     n_consecutive=3
        # )
        qua.align()

        if self.qubit_in_e:
            self.qubit.play(self.qubit_pi_pulse)
        qua.align()

        self.cavity.play(self.cav_displacement) 
        qua.wait(self.time_delay, self.cavity)  # wait for state to rotate
        self.cavity.play(self.cav_displacement, phase=self.disp_phase) # displace cavity back
        qua.align()  # qubit and cavity
        
        self.qubit.play(self.qubit_selective_pi)  # flip qubit if cav is in vac.
        qua.align()
        self.qubitEF.play(self.qubit_EF_pi)  # flip qubit if cav is in vac.
        qua.align()
        
        self.resonator.measure(self.readout_pulse, (self.I, self.Q), ampx=self.ro_ampx, demod_type="dual")
        if self.plot_single_shot:  # assign state to G or E
            qm_qua.assign(self.single_shot,qm_qua.Cast.to_fixed(self.I > self.readout_pulse.threshold),)
        qua.wait(self.wait_time, self.resonator)


if __name__ == "__main__":
    """ """

    #################################### MODE MAP ######################################
    # key: name of the Mode as defined by the Experiment subclass
    # value: name of the Mode as defined by the user in modes.yml

    modes = {
        "qubit": "qB",
        "qubitEF": "qB_EF",
        "cavity": "cavB",
        # "cavity_e": "alice_e",
        "resonator": "rrB",
    }

    ################################### PULSE MAP ######################################
    # key: name of the Pulse as defined by the Experiment subclass
    # value: name of the Pulse as defined by the user in modes.yml

    pulses = {
        "cav_displacement": "cavB_ramp_pulse",
        "qubit_selective_pi": "qB_gaussian_very_sel_pi_pulse",
        "qubit_EF_pi": "qBEF_gaussian_pi_pulse",
        "readout_pulse": "rrB_GF_CLEAR_readout_pulse",
    }

    ############################## CONTROL PARAMETERS ##################################

    parameters = {
        "wait_time": 5e6,
        "plot_single_shot": True,
        "qubit_in_e": False,
        "ro_ampx": 1,
    }

    ######################## SWEEP (INDEPENDENT) VARIABLES #############################
    # must include an outermost averaging Sweep named "N"
    # must include all primary sweeps defined by the Experiment subclass

    # set number of repetitions for this Experiment run
    N.num = 5000

    # set the delay sweep
    DEL = Sweep(name="time_delay", start=16, stop=20000, step=400, dtype=int)

    DISPL_PHASE = Sweep(name="disp_phase", start=0.0, stop=1.0, step=0.04, dtype=float)
    sweeps = [N, DISPL_PHASE, DEL]

    ######################## DATASET (DEPENDENT) VARIABLES #############################
    # must include all primary datasets defined by the Experiment subclass

    # MAG.axes = sweeps[1:]
    # PHASE.axes = sweeps[1:]
    SINGLE_SHOT.plot_args["plot_type"] = "image"

    PHASE.datafn_args = {"delay": 2.792e-7, "freq": RRB.int_freq}  # 2.792e-7
   
    PHASE.plot = False
    MAG.plot = False
    Q.plot = False
    I.plot = False
    datasets = [I, Q, SINGLE_SHOT]

    ######################## INITIALIZE AND RUN EXPERIMENT #############################

    expt = OutAndBackChi(FOLDER, modes, pulses, sweeps, datasets, **parameters)
    expt.run()



