""" """

# import sys

# sys.path.append("C:/Users/admin/Desktop/qcore-yabba/yabba-main/")
from config.experiment_config import FOLDER, N, I, Q, MAG, PHASE, RRB, SINGLE_SHOT
from qcore import Experiment, qua, Sweep
from qm import qua as qm_qua


class CavityT1_B(Experiment):
    """Cavity T1"""

    ############################# DEFINE PRIMARY DATASETS ##############################
    # these Datasets form the "raw" experimental data and will be streamed by the OPX
    # they must be specified at experiment runtime

    primary_datasets = ["I", "Q", "single_shot"]

    ############################## DEFINE PRIMARY SWEEPS ###############################
    # these Sweeps are uniquely associated with the Experiment subclass
    # these Sweeps must be specified at experiment runtime

    primary_sweeps = ["time_delay"]

    ############################ DEFINE THE PULSE SEQUENCE #############################
    # ensure that you import 'qua' from 'qcore' and not from 'qm' library
    # attributes accessed via 'self' must be defined in 'if __name__ == "__main__"' code

    def sequence(self):
        """QUA sequence that defines this Experiment subclass"""
        qua.reset_frame(self.cavityB)
        qua.reset_frame(self.qubitB)
        qm_qua.reset_global_phase()
        # qua.update_frequency(self.drive, 334e6)
        qua.update_frequency(self.drive, 371e6 - 6e6)

        qua.align()

        self.cavityB.play(self.cavity_grape)
        self.qubitB.play(self.qubit_grape)

        # self.cavityA.play(self.cavityA_grape)
        # self.qubitA.play(self.qubitA_grape)
        # self.cavityB.play(self.cavity_drive)
        # self.cavityB.play(self.cavity_drive)
        # self.cavityB.play(self.cavity_drive)

        qua.align()



        # qua.update_frequency(self.qubit, self.qubit.int_freq)
        # self.cavity.play(self.cavity_grape)
        # self.qubit.play(self.qubit_grape)
        #qua.wait(16, self.cavity, self.drive)
        # qua.align(self.cavity, self.drive)
        #self.cavity.play(self.cavity_drive)

        # self.resetB.play(self.resetB_pulse, ampx = self.reset)

        # qua.wait(self.time_delay, self.cavityB)
        # qua.update_frequency(self.drive, 432e6)
        self.drive.play(self.drive_pulse, duration = self.time_delay/4)
        qua.align()

        self.qubitB.play(self.qubit_pulse)
        qua.align(self.qubitB, self.qubitBEF)
        self.qubitBEF.play(self.qubitBEF_pi)  # play selective qubit pulse
        qua.align(self.qubitBEF, self.resonator)
        self.resonator.measure(self.readout_pulse, (self.I, self.Q), ampx=self.ro_ampx, demod_type="dual")
        qua.align()
        qua.wait(self.wait_time)
    
        if self.plot_single_shot:  # assign state to G or E
            qm_qua.assign(self.single_shot, qm_qua.Cast.to_fixed(self.I > self.readout_pulse.threshold),)

if __name__ == "__main__":
    """ """

    #################################### MODE MAP ######################################
    # key: name of the Mode as defined by the Experiment subclass
    # value: name of the Mode as defined by the user in modes.yml

    modes = {
        "cavityB": "cavB",
        "cavityA": "cavA",
        "qubitB": "qB",
        "qubitA": "qA",
        # "qubitC": "qC",
        "qubitBEF": "qB_EF",
        "qubitA": "qA",
        "resonator": "rrB",
        "drive": "drive",
        # "resetB":"resetB",

    }

    ################################### PULSE MAP ######################################
    # key: name of the Pulse as defined by the Experiment subclass
    # value: name of the Pulse as defined by the user in modes.yml

    pulses = {
        "qubit_grape": "qB_grape_fock1",
        "cavity_grape": "cavB_grape_fock1",
        "qubitA_grape": "qA_grape_fock1",
        "cavityA_grape": "cavA_grape_fock1",
        "cavity_drive": "cavB_ramp_pulse",
        "qubitBEF_pi": "qBEF_gaussian_pi_pulse",
        "qubit_pulse": "qB_gaussian_very_sel_pi_pulse",
        "qubitA_pulse": "qA_gaussian_very_sel_pi_pulse",
        "readout_pulse": "rrB_GF_CLEAR_readout_pulse", 
        # "readout_pulse": "rrC_readout_pulse", 
        "drive_pulse": "very_good_pulse_10000",
        # "resetB_pulse": "resetB_pulse",
    }

    ############################## CONTROL PARAMETERS ##################################

    parameters = {
        "wait_time": 6e6,
        "ro_ampx": 1,
        "plot_single_shot": True,
    }

    ######################## SWEEP (INDEPENDENT) VARIABLES #############################
    # must include an outermost averaging Sweep named "N"
    # must include all primary sweeps defined by the Experiment subclass

    # set number of repetitions for this Experiment run
    N.num = 5000

    # set the qubit frequency sweep for this Experiment run

    DEL = Sweep(name="time_delay", start=10000, stop=3e6, num=50, dtype=int)
    RESET = Sweep (name="reset", dtype=float)
    RESET.start = 0.0
    RESET.stop = 1.0
    RESET.step = 1.0
    sweeps = [N, DEL]

    ######################## DATASET (DEPENDENT) VARIABLES #############################
    # must include all primary datasets defined by the Experiment subclass
    # I.fitfn, SINGLE_SHOT.fitfn, Q.fitfn = "cohstate_decay", "cohstate_decay", "cohstate_decay"
    
    I.fitfn, SINGLE_SHOT.fitfn, Q.fitfn = "exp_decay", "exp_decay", "exp_decay"

    PHASE.datafn_args = {"delay": 2.792e-7, "freq": RRB.int_freq}
    I.plot, Q.plot, MAG.plot = False, False, False
    #SINGLE_SHOT.plot = True
    datasets = [I, Q, SINGLE_SHOT]

    ######################## INITIALIZE AND RUN EXPERIMENT #############################

    expt = CavityT1_B(FOLDER, modes, pulses, sweeps, datasets, **parameters)
    expt.run(simulate = False)
