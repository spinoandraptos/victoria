""" """
import sys

from config.experiment_config import FOLDER, N, FREQ, I, Q, MAG, PHASE, RRB, SINGLE_SHOT
from qcore import Experiment, qua, Sweep, Dataset
from qm import qua as qm_qua
from qcore.libs.qua_macros import QuaVariable

Ipost = Dataset(name="Ipost",save=False,plot=False)
Qpost = Dataset(name="Qpost",save=False,plot=False)
SINGLE_SHOTpost = Dataset(name="single_shotpost",save=True, plot=False)

class Wigner1D_B(Experiment):
    """Wigner_function"""

    ############################# DEFINE PRIMARY DATASETS ##############################
    # these Datasets form the "raw" experimental data and will be streamed by the OPX
    # they must be specified at experiment runtime
    primary_datasets = ["I", "Q", "single_shot", "Ipost", "Qpost", "single_shotpost"]
    #primary_datasets = ["I", "Q", "single_shot"]

    primary_sweeps = ["gate_id"]
    def __init__(self, folder, modes, pulses, sweeps, datasets, **parameters):

        super().__init__(
            folder,
            modes,
            pulses,
            sweeps,
            datasets,
            **parameters,
        )  # Passes other parameters to parent

        self.pulse_list = [f"self.exchange_pulse_cos2_{d}" for d in range (self.time_start, self.time_stop+self.time_step, self.time_step)]

    def sequence(self):
        """QUA sequence that defines this Experiment subclass"""
        qua.align()
        qua.reset_frame(self.cavity)   
        qua.reset_frame(self.qubit)
        qua.reset_frame(self.cavityA)   
        qua.reset_frame(self.qubitA)
        phase = qm_qua.declare(qm_qua.fixed)
        qua.update_frequency(self.drive, 334e6)
        qua.align()

        # PREPARE STATE
        self.qubit.play(self.qubitB_grape)
        self.cavity.play(self.cavityB_grape) 
        self.cavityA.play(self.cavityA_grape, ampx = self.grape_amplitude)
        self.qubitA.play(self.qubitA_grape, ampx = self.grape_amplitude)
        qua.align()

        with qm_qua.switch_(self.gate_id):
            for i in range(self.time_start, self.time_stop+self.time_step, self.time_step):
                with qm_qua.case_(i):
                    qm_qua.assign(phase, qm_qua.Cast.mul_fixed_by_int(self.detuning * 1e-9, i) + 0.25 + self.ramp_phase)
                    self.drive.play(getattr(self,f"exchange_pulse_cos2_{i}"))
        qua.align() 

        # # MEASURE WIGNER
        self.cavity.play(self.cav_op, ampx=0.4, phase = phase)  # displacement in I direction
        qua.align()
        self.qubit.play(self.qubit_op)  # play pi/2 pulse around X
        qua.wait(self.time_delay, self.qubit)  # conditional phase gate on even, odd Fock state
        self.qubit.play(self.qubit_op, phase = 0)  # play pi/2 pulse around X
        qua.align(self.qubit, self.qubitEF)
        self.qubitEF.play(self.qubitEF_pi)
        qua.align()  # align measurement
        self.resonator.measure(self.readout_pulse, (self.I, self.Q), demod_type= 'dual')  # measure transmitted signal
        qua.align()
        qua.wait(self.wait_time)
        if self.plot_single_shot:  # assign state to G or E
            qm_qua.assign(self.single_shot,qm_qua.Cast.to_fixed(self.I > self.readout_pulse.threshold),)
        

if __name__ == "__main__":
    """ """

    #################################### MODE MAP ######################################
    modes = {
       # "qC": "qC",
        "qubitEF": "qB_EF",
        "cavity": "cavB",
        "cavityA": "cavA",
        "drive":"drive",
        "qubit": "qB",
        "qubitA": "qA",
        "resonator": "rrB",
        #"resonatorC": "rrC",
    }

    ################################### PULSE MAP ######################################
    pulses = {
        "qubitB_grape": "qB_grape_fock02",
        "cavityB_grape": "cavB_grape_fock02",
        "qubitEF_pi": "qBEF_gaussian_pi_pulse",
        "qubitA_grape": "qA_grape_fock2",
        "cavityA_grape": "cavA_grape_fock2",
        "cav_op": "cavB_sg_pulse",
        #"qubit_sel_pulse": "qB_gaussian_sel_pi_pulse",
        "qubit_op": "qB_gaussian_pi2_pulse",
        "readout_pulse": "rrB_GF_CLEAR_readout_pulse", 
        # "readout_pulseC": "rrC_readout_pulse",
        # "drive_pulse": "exchange_pulse_ramp",
    }

    time_start = 16
    time_stop = 5000
    time_step = 200
    
    for d in range(time_start, time_stop+time_step, time_step):
        pulses[f"exchange_pulse_cos2_{d}"] = f"exchange_pulse_cos2_{d}"

    ############################## CONTROL PARAMETERS ##################################
    parameters = {
        "ramp_phase":  -0.07/2,
        "detuning":   (-454.3e3)/2,
        "wait_time": 8e6,
        "time_delay": 156, 
        "plot_single_shot": True,
        "qubit_drive_ampx": 1.0,
        "time_start":  time_start,
        "time_stop":  time_stop,
        "time_step":  time_step,
    }

    ######################## SWEEP (INDEPENDENT) VARIABLES #############################
    N.num = 5000
    QD_AMPX = Sweep(name="grape_amplitude", start=0, stop=1.0, step=1)
    TIME = Sweep(name="drive_time", start = 16, stop=60_000, step = 600, dtype = int)
    GATES = Sweep(name="gate_id", start=time_start, stop=time_stop, step=time_step, dtype=int, save=True)
    sweeps = [N, QD_AMPX, GATES]
    #sweeps = [N, GATES]

    ######################## DATASET (DEPENDENT) VARIABLES #############################
    PHASE.datafn_args = {"delay": 2.792e-7, "freq": RRB.int_freq}
    I.plot, Q.plot, MAG.plot, PHASE.plot = False, False, False, False
    SINGLE_SHOT.fitfn = 'exp_decay_sine'
    datasets = [I, Q, SINGLE_SHOT, Ipost, Qpost, SINGLE_SHOTpost]
    #datasets = [I, Q, SINGLE_SHOT]
    
    ######################## INITIALIZE AND RUN EXPERIMENT #############################
    expt = Wigner1D_B(FOLDER, modes, pulses, sweeps, datasets, **parameters)
    expt.run()
