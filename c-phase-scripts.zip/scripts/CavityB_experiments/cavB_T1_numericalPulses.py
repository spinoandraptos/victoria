""" """
import sys

from config.experiment_config import FOLDER, N, FREQ, I, Q, MAG, PHASE, RRB, SINGLE_SHOT
from qcore import Experiment, qua, Sweep, Dataset
from qm import qua as qm_qua
from qcore.libs.qua_macros import QuaVariable

Ipost = Dataset(name="Ipost",save=False,plot=False)
Qpost = Dataset(name="Qpost",save=False,plot=False)
SINGLE_SHOTpost = Dataset(name="single_shotpost",save=True, plot=False)

class cavB_T1_drive(Experiment):
    """Wigner_function"""

    primary_datasets = ["I", "Q", "single_shot", "Ipost", "Qpost", "single_shotpost"]

    primary_sweeps = ["drive_time"]

    def sequence(self):
        """QUA sequence that defines this Experiment subclass"""
        qua.reset_frame(self.cavityA)
        qua.reset_frame(self.cavityB)
        qua.reset_frame(self.qubitA)
        qua.reset_frame(self.qubitB)
        qua.reset_frame(self.drive)
        qua.reset_frame(self.drive_ramp)
        qua.reset_frame(self.resonator)
        qua.update_frequency(self.drive, 372.3e6 - 6e6)
        # qua.update_frequency(self.drive_ramp, 372.3e6 - 6e6)

        qm_qua.reset_global_phase()
        qua.align()

        # PREPARE STATE
        self.qubitB.play(self.qubitB_grape)
        self.cavityB.play(self.cavityB_grape) 
        self.cavityA.play(self.cavityA_grape)
        self.qubitA.play(self.qubitA_grape)
        qua.align()

        self.drive_ramp.play(self.exchange_ramp_up)
        qua.wait(200, self.drive)
        self.drive.play(self.exchange_constant, duration = self.drive_time/4)
        qua.wait(self.drive_time-7, self.drive_ramp)
        self.drive_ramp.play(self.exchange_ramp_down)
        qua.align() 

        # MEASURE
        self.qubitB.play(self.qubit_sel_pi)  # play selective qubit pulse
        qua.align(self.qubitBEF, self.qubitB)
        self.qubitBEF.play(self.qubitEF_pi)  # play selective qubit pulse
        qua.align(self.qubitBEF, self.resonator)
        self.resonator.measure(self.readout_pulse, (self.I, self.Q), demod_type="dual")
        qua.align()
        qua.wait(self.wait_time)
        if self.plot_single_shot:  # assign state to G or E
            qm_qua.assign(self.single_shot, qm_qua.Cast.to_fixed(self.I > self.readout_pulse.threshold),)

if __name__ == "__main__":
    """ """

    #################################### MODE MAP ######################################
    # key: name of the Mode as defined by the Experiment subclass
    # value: name of the Mode as defined by the user in modes.yml
    modes = {
        "cavityA": "cavA",
        "cavityB": "cavB",
        "qubitA": "qA",
        "qubitB": "qB",
        "qubitBEF": "qB_EF",
        "qubitC": "qC",
        "resonator": "rrB",
        "drive":"drive",
        "drive_ramp":"drive_ramp",

    }

    ################################### PULSE MAP ######################################
    # key: name of the Pulse as defined by the Experiment subclass
    # value: name of the Pulse as defined by the user in modes.yml
    pulses = {
        "qubitA_grape": "qA_grape_fock1",
        "cavityA_grape": "cavA_grape_fock1",
        "qubitB_grape": "qB_grape_fock1",
        "cavityB_grape": "cavB_grape_fock1",

        "qubit_sel_pi": "qB_gaussian_very_sel_pi_pulse",
        "qubitEF_pi": "qBEF_gaussian_pi_pulse",

        "qubitB_pi": "qB_gaussian_pi_pulse",
        "qubitB_sel_pi": "qB_gaussian_very_sel_pi_pulse",
        "qubitB_EF_pi": "qBEF_gaussian_pi_pulse",

        "exchange_ramp_up": "exchange_ramp_up",
        "exchange_constant": "exchange_pulse",
        "exchange_ramp_down": "exchange_ramp_down",
        
        "readout_pulse": "rrB_GF_CLEAR_readout_pulse", 
        
    }


    ############################## CONTROL PARAMETERS ##################################
    parameters = {
        "wait_time": 7e6,
        "plot_single_shot": True,        
    }

    ######################## SWEEP (INDEPENDENT) VARIABLES #############################
    # must include an outermost averaging Sweep named "N"
    # must include all primary sweeps defined by the Experiment subclass

    # set number of repetitions for this Experiment run
    N.num = 10_000
    QD_AMPX = Sweep(name="drive_amplitude", start=0, stop=1.0, step=1)
    TIME = Sweep(name="drive_time", start = 416, stop=2_000_000, step = 40_000, dtype = int)
    sweeps = [N, TIME]
    #sweeps = [N, QD_AMPX, TIME]

    ######################## DATASET (DEPENDENT) VARIABLES #############################
    # must include all primary datasets defined by the Experiment subclass
    # I.fitfn = "gaussian"
    PHASE.datafn_args = {"delay": 2.792e-7, "freq": RRB.int_freq}
    I.plot, Q.plot, MAG.plot, PHASE.plot = False, False, False, False
    SINGLE_SHOT.fitfn = 'exp_decay'
    datasets = [I, Q, SINGLE_SHOT, Ipost, Qpost, SINGLE_SHOTpost]
    #datasets = [I, Q, SINGLE_SHOT]
    ######################## INITIALIZE AND RUN EXPERIMENT #############################
    expt = cavB_T1_drive(FOLDER, modes, pulses, sweeps, datasets, **parameters)
    expt.run()
