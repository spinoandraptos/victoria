from config.experiment_config import FOLDER, N, FREQ, I, Q, MAG, PHASE, RRB, SINGLE_SHOT
from qcore import Experiment, qua, Sweep, Dataset
from qm import qua as qm_qua
from qcore.libs.qua_macros import QuaVariable

Ipost = Dataset(name="Ipost",save=False,plot=False)
Qpost = Dataset(name="Qpost",save=False,plot=False)
SINGLE_SHOTpost = Dataset(name="single_shotpost",save=True, plot=False)

class Wigner1D_B(Experiment):
    """Wigner_function"""

    ############################# DEFINE PRIMARY DATASETS ##############################
    primary_datasets = ["I", "Q", "single_shot", "Ipost", "Qpost", "single_shotpost"]

    primary_sweeps = ["ramp_phase"]


    def __init__(self, folder, modes, pulses, sweeps, datasets, **parameters):

        super().__init__(folder,modes,pulses,sweeps,datasets,**parameters,)  # Passes other parameters to parent

    def sequence(self):
        """QUA sequence that defines this Experiment subclass"""
        qua.reset_frame(self.cavityB)
        qua.reset_frame(self.qubitB)
        qua.reset_frame(self.drive)
        qua.reset_frame(self.resonatorB)
        qm_qua.reset_global_phase()
        add_ramp_phase = qm_qua.declare(qm_qua.fixed)
        new_phase = qm_qua.declare(qm_qua.fixed)
        qua.update_frequency(self.drive, 371e6-7e6)
        qua.align()

        # PREPARE STATE
        self.cavityB.play(self.cavityB_grape)
        self.qubitB.play(self.qubitB_grape)
        qua.align()

        self.drive.play(self.just_ramp)

        qm_qua.assign(new_phase, 0.25 + self.ramp_phase + self.add_ramp_phase)
        qua.align() 

        # # MEASURE WIGNER
        self.cavityB.play(self.cav_op, ampx=0.8, phase = new_phase)  # displacement in I direction
        qua.align(self.cavityB, self.qubitB) 
        self.qubitB.play(self.qubit_op)  # play pi/2 pulse around X
        qua.wait(self.time_delay, self.qubitB)  # conditional phase gate on even, odd Fock state
        self.qubitB.play(self.qubit_op)  # play pi/2 pulse around X
        qua.align(self.qubitB, self.qubitBEF)
        self.qubitBEF.play(self.qubitEF_pi)
        qua.align()  # align measurement

        # Measure cavity state
        self.resonatorB.measure(self.readout_pulseB, (self.I, self.Q), demod_type= 'dual')  # measure transmitted signal
        qua.align()
        qua.wait(self.wait_time)
        if self.plot_single_shot:  # assign state to G or E
            qm_qua.assign(self.single_shot,qm_qua.Cast.to_fixed(self.I > self.readout_pulseB.threshold),)

if __name__ == "__main__":
    """ """

    #################################### MODE MAP ######################################
    modes = {
        "qubitBEF": "qB_EF",
        "cavityB": "cavB",
        "drive":"drive",
        "qubitB": "qB",
        "resonatorB": "rrB",
    }

    ################################### PULSE MAP ######################################
    # key: name of the Pulse as defined by the Experiment subclass
    # value: name of the Pulse as defined by the user in modes.yml
    pulses = {
        "qubitEF_pi": "qBEF_gaussian_pi_pulse",
        "qubitB_grape": "qB_grape_fock01_new",
        "cavityB_grape": "cavB_grape_fock01_new",
        "cav_op": "cavB_ramp_pulse",
        "qubit_op": "qB_gaussian_pi2_pulse",
        "readout_pulseB": "rrB_GF_CLEAR_readout_pulse", 
        "just_ramp": "just_ramp",
    }

    
    ############################## CONTROL PARAMETERS ##################################
    parameters = {
        # "detuning": - 804.9e3+0.7e3-11.5e3-19e3+0.9e3,  #-819.8e3/2-680e3/2+9e3/2 -18e3/2 + 13e3/2 + 9e3/2,
        # "phase": QuaVariable(value=0.0, dtype=qm_qua.fixed, tag="phase", buffer=True, stream=True),
        "wait_time": 7e6,
        "time_delay": 156, # 620,
        "plot_single_shot": True,
        "add_ramp_phase": -0.026,
    }

    ######################## SWEEP (INDEPENDENT) VARIABLES #############################
    N.num = 50000
    RAMP = Sweep(name="ramp_phase", start = -0.3, stop=0.3, step = 0.044, dtype = float)
    # QD_AMPX = Sweep(name="grape_amplitude", start = 0.0, stop=1.1, step=1.0, dtype = float)

    sweeps = [N, RAMP]

    ######################## DATASET (DEPENDENT) VARIABLES #############################
    PHASE.datafn_args = {"delay": 2.792e-7, "freq": RRB.int_freq}
    I.plot, Q.plot, MAG.plot, PHASE.plot = False, False, False, False
    SINGLE_SHOT.fitfn = 'gaussian'
    datasets = [I, Q, SINGLE_SHOT, Ipost, Qpost, SINGLE_SHOTpost]
    #datasets = [I, Q, SINGLE_SHOT]

    ######################## INITIALIZE AND RUN EXPERIMENT #############################
    expt = Wigner1D_B(FOLDER, modes, pulses, sweeps, datasets, **parameters)
    expt.run()
