""" """

from config.experiment_config import FOLDER, N, FREQ, I, Q, MAG, PHASE, RRB, SINGLE_SHOT
from qm import qua as qm_qua
from qcore import Experiment, qua, Sweep
import numpy as np
from qcore.libs.qua_macros import QuaVariable


class OutAndBackCrossKerr(Experiment):
    """Dispersive shift between cavity and qubit"""

    ############################# DEFINE PRIMARY DATASETS ##############################
    # these Datasets form the "raw" experimental data and will be streamed by the OPX
    # they must be specified at experiment runtime

    primary_datasets = ["I", "Q", "single_shot"]

    ############################## DEFINE PRIMARY SWEEPS ###############################
    # these Sweeps are uniquely associated with the Experiment subclass
    # these Sweeps must be specified at experiment runtime

    #primary_sweeps = ["time_delay"]
    primary_sweeps = ["disp_phase"]

    ############################ DEFINE THE PULSE SEQUENCE #############################
    # ensure that you import 'qua' from 'qcore' and not from 'qm' library
    # attributes accessed via 'self' must be defined in 'if __name__ == "__main__"' code

    def sequence(self):
        """QUA sequence that defines this Experiment subclass"""
        #factor = qm_qua.declare(qm_qua.fixed)
        # phase = qm_qua.declare(float)
        #qm_qua.assign(factor, self.detuning * 1e-9) 
        qua.reset_frame(self.cavB)
        qua.reset_frame(self.cavA)
        qua.reset_frame(self.qA)
        qua.reset_frame(self.qB)
        qua.align()

        total_disp_phase = qm_qua.declare(qm_qua.fixed)
        qm_qua.assign(total_disp_phase, self.ramp_phase + self.phase + self.disp_phase)

        # # Prepare 1 in A
        # self.cavA.play(self.cavity_grape)
        # self.qA.play(self.qubit_grape)
        # qua.align()

        # # Displace Bob (frequency shifted by cross_kerr but hopefully is ok)
        self.cavB.play(self.cavB_pulse, ampx = 1.5)  # create a coherent state in BOB
        qua.align() 

        self.drive.play(self.drive_pulse)
        # qua.wait(self.time_delay, self.cavB)  # wait for state to rotate
        qua.align() 

        # # Bring Bob back with a certain phase
        self.cavB.play(self.cavB_pulse, ampx = 1.5, phase=total_disp_phase)
        qua.align()  

        self.qB.play(self.qubit_sel_pi)  
        qua.align(self.qB, self.qubitB_EF)
        self.qubitB_EF.play(self.qubitB_EF_pi)  # play selective qubit pulse
        qua.align(self.qubitB_EF, self.resonator)
        self.resonator.measure(self.readout_pulse, (self.I, self.Q), ampx=self.ro_ampx, demod_type="dual")
        
        qua.align()
        qua.wait(self.wait_time)
        if self.plot_single_shot:  # assign state to G or E
            qm_qua.assign(self.single_shot, qm_qua.Cast.to_fixed(self.I > self.readout_pulse.threshold),)


if __name__ == "__main__":
    """ """

    #################################### MODE MAP ######################################
    modes = {
        "drive": "drive",
        "qB": "qB",
        "qA": "qA",
        "cavA": "cavA",
        "cavB": "cavB",
        "resonator": "rrB",
        "qubitB_EF": "qB_EF",
        #"resonatorB": "rrB",
    }

    ################################### PULSE MAP ######################################
    pulses = {        
        "qubit_grape": "qA_grape_fock1",
        "cavity_grape": "cavA_grape_fock1",
        "drive_pulse": "just_ramp", 
        #"cavA_pulse": "cavA_ramp_pulse",
        "cavB_pulse": "cavB_ramp_pulse",
        "qubitB_EF_pi": "qBEF_gaussian_pi_pulse",
        "qubit_sel_pi": "qB_gaussian_very_sel_pi_pulse",
        #"qB_sel_pi": "qB_gaussian_sel_pi_pulse",
        "readout_pulse": "rrB_GF_CLEAR_readout_pulse", 
        # "readout_pulse2": "rrB_pulse_calibrate", 
    }

    ############################## CONTROL PARAMETERS ##################################

    parameters = {
        "ramp_phase": -0.036,
        "detuning":  0.0e6,
        "phase": QuaVariable(value=0.0,dtype=qm_qua.fixed,tag="phase",buffer=True,stream=True),
        "wait_time": 7e6,
        "plot_single_shot": True,
        "qubit_in_e": False,
        "ro_ampx": 1,
    }

    ######################## SWEEP (INDEPENDENT) VARIABLES #############################
    # must include an outermost averaging Sweep named "N"
    # must include all primary sweeps defined by the Experiment subclass

    # set number of repetitions for this Experiment run
    N.num = 5000

    # set the delay sweep
    DEL = Sweep(name="time_delay", start=64, stop=3500, step=51, dtype=int)

    DISPL_PHASE = Sweep(name="disp_phase", start=0.0, stop=1.0, step=0.02, dtype=float)
    #sweeps = [N, DISPL_PHASE, DEL]
    sweeps = [N,  DISPL_PHASE]

    ######################## DATASET (DEPENDENT) VARIABLES #############################
    # must include all primary datasets defined by the Experiment subclass

    # MAG.axes = sweeps[1:]
    # PHASE.axes = sweeps[1:]
    #SINGLE_SHOT.plot_args["plot_type"] = "image"

    PHASE.datafn_args = {"delay": 2.792e-7, "freq": RRB.int_freq}  # 2.792e-7
   
    PHASE.plot = False
    MAG.plot = False
    Q.plot = False
    I.plot = False
    SINGLE_SHOT.plot = True
    SINGLE_SHOT.fitfn = 'gaussian'
    datasets = [I, Q, SINGLE_SHOT]

    ######################## INITIALIZE AND RUN EXPERIMENT #############################

    expt = OutAndBackCrossKerr(FOLDER, modes, pulses, sweeps, datasets, **parameters)
    expt.run()



