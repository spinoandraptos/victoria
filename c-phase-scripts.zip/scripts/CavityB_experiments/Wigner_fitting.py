import numpy as np
import os
import h5py
import matplotlib.pyplot as plt
from scipy.optimize import curve_fit

# Z DATA 
file_fock0 = r"C:\Users\admin\Desktop\yabba-main\yabba-main\data\2024-06-04\12-07-51_Wigner2D.hdf5"
file_fock1 = r"C:\Users\admin\Desktop\yabba-main\yabba-main\data\2024-06-04\20-25-17_Wigner2D.hdf5"
data0 = h5py.File(file_fock0, "r")
data1 = h5py.File(file_fock1, "r")
wigner0 = np.mean(np.array(data0["single_shot"]), axis = 0) * 2 - 1
wigner1 = np.mean(np.array(data1["single_shot"]), axis = 0) * 2 - 1

# XY DATA
drive_length = data0["drive_length"]
I_values = data0['cavity_drive_I']
Q_values = data0['cavity_drive_Q']
x_axis, y_axis = np.meshgrid(I_values, Q_values)

# PLOTTING
fig, axs = plt.subplots(5, 2, figsize=(4, 10))

for i, length in enumerate([0,1,2,3,4]):
    # Plot for Alice in 0
    axs[i, 0].pcolormesh(x_axis, y_axis, wigner0[:,:,length], cmap='bwr', vmin=-1, vmax=1)
    axs[i, 0].set_title('Alice0, Drive: {}'.format(drive_length[length]))
    # axs[i, 0].set_xlabel('I')
    # axs[i, 0].set_ylabel('Q')
    axs[i, 0].set_aspect('equal')
    axs[i, 0].axis('tight')
    
    # Plot for Alice in 1
    axs[i, 1].pcolormesh(x_axis, y_axis, wigner1[:,:,length], cmap='bwr', vmin=-1, vmax=1)
    axs[i, 1].set_title('Alice1, Drive: {}'.format(drive_length[length]))
    # axs[i, 1].set_xlabel('I')
    # axs[i, 1].set_ylabel('Q')
    axs[i, 1].set_aspect('equal')
    axs[i, 1].axis('tight')

plt.tight_layout()
plt.show()