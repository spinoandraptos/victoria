from config.experiment_config import FOLDER, N, FREQ, I, Q, MAG, PHASE, RRB, SINGLE_SHOT
from qcore import Experiment, qua, Sweep
from qm import qua as qm_qua
from qcore.libs.qua_macros import QuaVariable
from qcore import Dataset


class DisplacementCal_B(Experiment):
    """Cavity spectroscopy"""

    primary_datasets = ["I", "Q", "single_shot"]

    primary_sweeps = ["cavity_drive_amplitude"]

    def sequence(self):
        """QUA sequence that defines this Experiment subclass"""
        qua.reset_frame(self.cavity)
        # qua.reset_phase(self.cavity)

        self.cavity.play(self.cavity_drive, ampx = self.cavity_drive_amplitude)  # play displacement to cavity
        self.cavity.play(self.cavity_drive, ampx = self.cavity_drive_amplitude)  # play displacement to cavity
        self.cavity.play(self.cavity_drive, ampx = self.cavity_drive_amplitude)  # play displacement to cavity

        qua.align(self.cavity, self.qubit)  # align all modes
        
        self.qubit.play(self.qubit_drive)  # play qubit pulse
        qua.align(self.qubit, self.qubit_EF)  # align all modes
        self.qubit_EF.play(self.qubit_EF_drive)
        qua.align(self.qubit_EF, self.resonator)  # align all modes
        self.resonator.measure(self.readout_pulse, (self.I, self.Q), ampx=self.ro_ampx, demod_type="dual")
        
        qua.align()
        qua.wait(self.wait_time)
        if self.plot_single_shot:  # assign state to G or E
            qm_qua.assign(self.single_shot,qm_qua.Cast.to_fixed(self.I > self.readout_pulse.threshold),)

if __name__ == "__main__":
    """ """

    #################################### MODE MAP ######################################
    modes = {
        "cavity": "cavB",
        "qubit": "qB",
        "qubit_EF": "qB_EF",
        "resonator": "rrB",
    }

    ################################### PULSE MAP ######################################
    pulses = {
        # "cavity_drive": "cavB_grape_coherent",
        # "cavity_drive2": "cavB_ramp_pulse",
        "cavity_drive": "cavB_sg_pulse",
        "qubit_drive": "qB_gaussian_very_sel_pi_pulse",
        "qubit_EF_drive": "qBEF_gaussian_pi_pulse",
        "readout_pulse": "rrB_GF_CLEAR_readout_pulse",
    }

    ############################## CONTROL PARAMETERS ##################################
    parameters = {
        "wait_time": 7e6,
        "ro_ampx": 1,
        "plot_single_shot": True,
    }
# 
    ######################## SWEEP (INDEPENDENT) VARIABLES #############################
    N.num = 2000
    QD_AMPX = Sweep(name="cavity_drive_amplitude", start=0.0, stop=1.0,  step=0.04)
    sweeps = [N, QD_AMPX]

    ######################## DATASET (DEPENDENT) VARIABLES #############################
    I.fitfn = "displacement_cal"
    Q.fitfn = "displacement_cal"
    I.plot = False
    Q.plot = False
    SINGLE_SHOT.fitfn = "displacement_cal"
    PHASE.datafn_args = {"delay": 2.792e-7, "freq": RRB.int_freq}
    # I.plot, Q.plot, MAG.plot = False, False, False
    datasets = [I, Q, SINGLE_SHOT]

    ######################## INITIALIZE AND RUN EXPERIMENT #############################
    expt = DisplacementCal_B(FOLDER, modes, pulses, sweeps, datasets, **parameters)
    expt.run()
