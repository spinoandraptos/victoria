from config.experiment_config import FOLDER, N, FREQ, RRB, I, Q, SINGLE_SHOT
from qcore import Experiment, qua, Sweep, Dataset
from qm import qua as qm_qua
from qcore.libs.qua_macros import QuaVariable
import shutil
import os
from datetime import datetime
from scripts.qB_GE_experiments.T2_virtual_detuning_qB import QubitT2
from scripts.qB_GE_experiments.AllXY_qB import ALLXY
from qm.qua import *
import numpy as np 

# SCREENSHOT FILE 
current_script_path = os.path.realpath(__file__) # Get the path to the current script
script_name = os.path.basename(current_script_path)[:-3] # Get filename only (e.g., 'my_script.py')
date, time = datetime.now().strftime("%Y-%m-%d %H-%M-%S").split()
destination_path = os.path.join(FOLDER + "data/" + str(date) + '/', f"{script_name}_screenhsot_{time}.py") # Define destination path
shutil.copy(current_script_path, destination_path) # Copy the script


SINGLE_SHOT_B = Dataset(
    name="single_shotB",
    save=True,
    plot=False, 
)
SINGLE_SHOT_B_BEFORE = Dataset(
    name="single_shotB_before",
    save=True,
    plot=False, 
)
IB = Dataset(
    name="IB",
    save=False,
    plot=False, 
)
IB_BEFORE = Dataset(
    name="IB_before",
    save=False,
    plot=False, 
)
QB = Dataset(
    name="QB",
    save=False,
    plot=False, 
)
QB_BEFORE= Dataset(
    name="QB_before",
    save=False,
    plot=False, 
)


class WignersAB(Experiment):
    """Wigner_function"""

    primary_datasets = ["IB", "IB_before", "QB", "QB_before", "single_shotB", "single_shotB_before"]

    primary_sweeps = ["gate_id"]

    def __init__(self, folder, modes, pulses, sweeps, datasets, **parameters):

        super().__init__(
            folder,
            modes,
            pulses,
            sweeps,
            datasets,
            **parameters,
        )  # Passes other parameters to parent

        self.wigner_points = [[-0.6, -0.6],
                            [-0.3, -0.6],
                            [0.0, -0.6],
                            [0.3, -0.6],
                            [0.6, -0.6],
                            [-0.6, -0.3],
                            [-0.3, -0.3],
                            [0.0, -0.3],
                            [0.3, -0.3],
                            [0.6, -0.3],
                            [-0.6, 0.0],
                            [-0.3, 0.0],
                            [0.0, 0.0],
                            [0.3, 0.0],
                            [0.6, 0.0],
                            [-0.6, 0.3],
                            [-0.3, 0.3],
                            [0.0, 0.3],
                            [0.3, 0.3],
                            [0.6, 0.3],
                            [-0.6, 0.6],
                            [-0.3, 0.6],
                            [0.0, 0.6],
                            [0.3, 0.6],
                            [0.6, 0.6]]

    def sequence(self):
        factorB = qm_qua.declare(qm_qua.fixed)
        qm_qua.assign(factorB, self.detuningB * 1e-9)  
        qm_qua.assign(self.phaseB, qm_qua.Cast.mul_fixed_by_int(factorB, self.drive_length))
        total_phaseB = qm_qua.declare(qm_qua.fixed)
        qm_qua.assign(total_phaseB, self.phaseB + 0.25)

        qua.reset_frame(self.cavityB)
        qua.reset_phase(self.cavityB)
        qua.reset_frame(self.qubitB)
        qua.reset_phase(self.qubitB)
        qua.reset_frame(self.qubitB_EF)
        qua.reset_phase(self.qubitB_EF)

        # GRAPE B
        self.cavityB.play(self.cavB_grape)
        self.qubitB.play(self.qB_grape)
        qua.align()

        with switch_(self.gate_id):
            for i in range(len(self.wigner_points)):
                with case_(i):
                    dispB_I, dispB_Q = self.wigner_points[i]
                    self.cavityB.play(self.cavB_op, ampx=(dispB_I, -dispB_Q, dispB_Q, dispB_I), phase= total_phaseB)  # displacement

        qua.align(self.cavityB, self.qubitB)
        self.qubitB.play(self.qubitB_pi2)  # play pi/2 pulse around X
        qua.wait(int(self.time_delayB), self.qubitB)  # conditional phase gate on even, odd Fock state
        self.qubitB.play(self.qubitB_pi2, phase = self.qb_phase)  # play pi/2 pulse around X
        qua.align(self.qubitB, self.qubitB_EF)  
        self.qubitB_EF.play(self.qubitB_EF_drive)  # play pi/2 pulse around X
        qua.align(self.qubitB_EF, self.rrB)  
        self.rrB.measure(self.readout_pulseB, (self.IB, self.QB), ampx=self.ro_ampx, demod_type = 'dual')  # measure transmitted signal
        
        qua.align()
        qua.wait(self.wait_time)

        if self.plot_single_shot:  # assign state to G or E
            qm_qua.assign(self.single_shotB, qm_qua.Cast.to_fixed(self.IB > self.readout_pulseB.threshold),)


 
if __name__ == "__main__":
    """ """

    modes = {
        "cavityB": "cavB",
        "qubitB": "qB",
        "qubitB_EF": "qB_EF",
        "rrB": "rrB",
    }

    pulses = {
        "qB_grape": "qB_grape_fock01_new",
        "cavB_grape": "cavB_grape_fock01_new",
        "cavB_op": "cavB_ramp_pulse",
        "qubitB_pi2": "qB_gaussian_pi2_pulse",
        "qubitB_EF_drive": "qB_EF_gaussian_pi_pulse",
        "readout_pulseB": "rrB_GF_CLEAR_readout_pulse",
        "qB_selective": "qB_gaussian_very_sel_pi_pulse",
        "qB_unselective": "qB_gaussian_pi_pulse",
    }

    ############################## CONTROL PARAMETERS ##################################
    parameters = {
        "detuningB": 0, #181.8e3, #133.2e3, 
        "phaseB": QuaVariable(value=0.0, dtype=qm_qua.fixed, tag="phaseB", buffer=True, stream=True),
        "wait_time": 6e6,
        "ro_ampx": 1,
        "time_delayB": 160, 
        # "qb_phase":0,
        "plot_single_shot": True,
        "qubit_drive_ampx": 1.0,
        "drive_length":0,
    }

    N.num = 10000

    # LENGTH = Sweep (name="drive_length", dtype=int, units = "ns")
    # LENGTH.start = 16
    # LENGTH.stop = 12000
    # LENGTH.step = 16 ###PREV 2000
    
    GATES = Sweep(name="gate_id", start=0, stop=24, step = 1, dtype=int, save=True)
        
    PARITY = Sweep (name="qb_phase", dtype=float)
    PARITY.start = 0.0
    PARITY.stop = 0.5
    PARITY.step = 0.5

    # DRIVE_AMPX = Sweep(name="drive_amp", start=1.798, stop=1.808, step = 0.002) ###PREV 0.2
    
    # sweeps = [N, LENGTH]
    sweeps = [N, GATES, PARITY]

    SINGLE_SHOT_B.plot_args["plot_type"] = "image"
    SINGLE_SHOT_B.plot = True
    datasets = [IB, IB_BEFORE,  
                QB, QB_BEFORE, 
                SINGLE_SHOT_B, SINGLE_SHOT_B_BEFORE]

    expt = WignersAB(FOLDER, modes, pulses, sweeps, datasets, **parameters)
    expt.run(simulate=False, filename_suffix="entanglement")
