""" """
import sys

from config.experiment_config import FOLDER, N, FREQ, I, Q, MAG, PHASE, RRB, SINGLE_SHOT
from qcore import Experiment, qua, Sweep, Dataset
from qm import qua as qm_qua


I_grape = Dataset(
    name="I_grape",
    save=False,
    plot=False, 
)
Q_grape= Dataset(
    name="Q_grape",
    save=False,
    plot=False, 
)
SINGLE_SHOT_grape= Dataset(
    name="single_shot_grape",
    save=True,
    plot=False, 
)

class Wigner1D(Experiment):
    """Wigner_function"""

    ############################# DEFINE PRIMARY DATASETS ##############################
    # these Datasets form the "raw" experimental data and will be streamed by the OPX
    # they must be specified at experiment runtime
    primary_datasets = ["I", "Q", "single_shot", "I_grape", "Q_grape", "single_shot_grape"]

    ############################## DEFINE PRIMARY SWEEPS ###############################
    # these Sweeps are uniquely associated with the Experiment subclass
    # these Sweeps must be specified at experiment runtime
    primary_sweeps = ["cavity_drive_amplitude"]

    ############################ DEFINE THE PULSE SEQUENCE #############################
    # ensure that you import 'qua' from 'qcore' and not from 'qm' library
    # attributes accessed via 'self' must be defined in 'if __name__ == "__main__"' code
    def sequence(self):
        """QUA sequence that defines this Experiment subclass"""
        
        qua.reset_frame(self.cavity)   
        qua.reset_phase(self.cavity)
        qua.reset_phase(self.qubit)
        qua.reset_frame(self.qubit)



        self.cavity.play(self.cavity_grape)  # displace by beta = 1.14
        self.qubit.play(self.qubit_grape)    # SNAP: play pi pulse around X
        qua.align()  # align pulses


        self.cavity.play(self.cav_op, ampx=self.cavity_drive_amplitude, phase=0.5)  # displacement in I direction
        qua.align()

        self.qubit.play(self.qubit_op)  # play pi/2 pulse around X
        qua.wait(self.time_delay, self.qubit)  # conditional phase gate on even, odd Fock state
        self.qubit.play(self.qubit_op, phase = self.qb_phase)  # play pi/2 pulse around X
        qua.align()  # align measurement

        self.qubitB_EF.play(self.qubitEF_drive)
        qua.align()

        # Measure cavity state
        self.resonator.measure(self.readout_pulse, (self.I, self.Q), ampx=self.ro_ampx, demod_type= 'dual')  # measure transmitted signal
        if self.plot_single_shot:  # assign state to G or E
            qm_qua.assign(self.single_shot,qm_qua.Cast.to_fixed(self.I > self.readout_pulse.threshold),)
        qua.align()
        qua.wait(self.wait_time)

if __name__ == "__main__":
    """ """

    #################################### MODE MAP ######################################
    # key: name of the Mode as defined by the Experiment subclass
    # value: name of the Mode as defined by the user in modes.yml
    modes = {
        "qubitB_EF": "qB_EF",
        # "driveA": "driveA",
        "cavity": "cavB",
        "qubit": "qB",
        "resonator": "rrB",
    }

    ################################### PULSE MAP ######################################
    # key: name of the Pulse as defined by the Experiment subclass
    # value: name of the Pulse as defined by the user in modes.yml
    pulses = {
        "qubitEF_drive": "qB_EF_gaussian_pi_pulse",
        # "cavity_drive": "cavity_grape_fock1_1000ns",
        # "qubitA_drive": "qubitAGF_gaussian_pi_pulse",
        # "driveA_pulse": "driveA_constant_ramp_pulse_short",
        "qubit_grape": "qB_grape_fock2_new2",
        "cavity_grape": "cavB_grape_fock2_new2",
        "cav_op": "cavB_ramp_pulse",
        "qubit_op": "qB_gaussian_pi2_pulse",
        "readout_pulse": "rrB_GF_readout_pulse",
    }

    ############################## CONTROL PARAMETERS ##################################
    parameters = {
        "wait_time": 6e6,
        "ro_ampx": 1,
        "time_delay": 172,
        "plot_single_shot": True,
        "qubit_drive_ampx": 1.0,
    }

    ######################## SWEEP (INDEPENDENT) VARIABLES #############################
    # must include an outermost averaging Sweep named "N"
    # must include all primary sweeps defined by the Experiment subclass

    # set number of repetitions for this Experiment run
    N.num = 2000
    QD_AMPX = Sweep(name="cavity_drive_amplitude", start=-1.8, stop=1.8, step=0.05)
    # WAIT = Sweep(name="waiting_time", start=1058, stop=1074, step=4)
    PHASE = Sweep(name="qb_phase", start=0.0, stop=0.5, step=0.5)

    sweeps = [N,  PHASE, QD_AMPX]

    ######################## DATASET (DEPENDENT) VARIABLES #############################
    # must include all primary datasets defined by the Experiment subclass
    # I.fitfn = "gaussian"
    PHASE.datafn_args = {"delay": 2.792e-7, "freq": RRB.int_freq}
    I.plot, Q.plot, MAG.plot, PHASE.plot = False, False, False, False
    SINGLE_SHOT.fitfn = 'gaussian'
    datasets = [I, Q, SINGLE_SHOT, I_grape, Q_grape, SINGLE_SHOT_grape]
    ######################## INITIALIZE AND RUN EXPERIMENT #############################
    expt = Wigner1D(FOLDER, modes, pulses, sweeps, datasets, **parameters)
    expt.run()
