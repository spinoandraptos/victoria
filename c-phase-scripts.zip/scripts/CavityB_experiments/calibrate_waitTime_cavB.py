""" """
import sys

from config.experiment_config import FOLDER, N, FREQ, I, Q, MAG, PHASE, RRB, SINGLE_SHOT
from qcore import Experiment, qua, Sweep
from qm import qua as qm_qua

class WaitTime(Experiment):
    """Wigner_function"""

    ############################# DEFINE PRIMARY DATASETS ##############################
    # these Datasets form the "raw" experimental data and will be streamed by the OPX
    # they must be specified at experiment runtime
    primary_datasets = ["I", "Q", "single_shot"]

    ############################## DEFINE PRIMARY SWEEPS ###############################
    # these Sweeps are uniquely associated with the Experiment subclass
    # these Sweeps must be specified at experiment runtime
    primary_sweeps = ["time_delay"]

    ############################ DEFINE THE PULSE SEQUENCE #############################
    # ensure that you import 'qua' from 'qcore' and not from 'qm' library
    # attributes accessed via 'self' must be defined in 'if __name__ == "__main__"' code
    def sequence(self):
        """QUA sequence that defines this Experiment subclass"""
        
        qua.reset_frame(self.cavity)   
        qua.reset_phase(self.cavity)
        qua.reset_phase(self.qubit)
        qua.reset_frame(self.qubit)

        #qua.update_frequency(self.qubit, self.qubit.int_freq) 
        # qua.align()
        # qua.initialize_cavity_AND_qubit(
        #     rr=self.resonator,
        #     qubit = self.qubit, 
        #     readout_pulse=self.readout_pulse,
        #     qubit_pulse = self.qubit_drive,
        #     demod_type="dual",
        #     threshold_g=self.readout_pulse.threshold,
        #     ro_ampx=self.ro_ampx,
        #     wait_time=50_000,
        #     n_consecutive=3
        # )
        # qua.align()

        self.qubit.play(self.qubit_grape)
        self.cavity.play(self.cavity_grape) 
        qua.align()

        self.qubit.play(self.qubit_op)  # play pi/2 pulse around X
        qua.wait(self.time_delay, self.qubit)  # conditional phase gate on even, odd Fock state
        self.qubit.play(self.qubit_op)  # play pi/2 pulse around X
        qua.align()  # align measurement
        self.qubit_EF.play(self.qubitEF_pi)  
        qua.align()

        # Measure cavity state
        self.resonator.measure(self.readout_pulse, (self.I, self.Q), ampx=self.ro_ampx, demod_type= 'dual')  # measure transmitted signal
        if self.plot_single_shot:  # assign state to G or E
            qm_qua.assign(self.single_shot,qm_qua.Cast.to_fixed(self.I > self.readout_pulse.threshold),)
        
        qua.align()
        qua.wait(self.wait_time)

if __name__ == "__main__":
    """ """

    #################################### MODE MAP ######################################
    # key: name of the Mode as defined by the Experiment subclass
    # value: name of the Mode as defined by the user in modes.yml
    modes = {
        # "qubitAGF": "qubitAGF",
        # "driveA": "driveA",
        "cavity": "cavB",
        "qubit": "qB",
        "qubit_EF": "qB_EF",
        "resonator": "rrB",
    }

    ################################### PULSE MAP ######################################
    # key: name of the Pulse as defined by the Experiment subclass
    # value: name of the Pulse as defined by the user in modes.yml
    pulses = {
        "qubit_grape": "qB_grape_fock1",
        "cavity_grape": "cavB_grape_fock1",
        "qubit_op": "qB_gaussian_pi2_pulse",
        "qubitEF_pi": "qBEF_gaussian_pi_pulse",
        "readout_pulse": "rrB_GF_CLEAR_readout_pulse",
    }

    ############################## CONTROL PARAMETERS ##################################
    parameters = {
        "wait_time": 6e6,
        "ro_ampx": 1,
        "plot_single_shot": True,
        "qubit_drive_ampx": 1.0,
    }

    ######################## SWEEP (INDEPENDENT) VARIABLES #############################
    # must include an outermost averaging Sweep named "N"
    # must include all primary sweeps defined by the Experiment subclass

    # set number of repetitions for this Experiment run
    N.num = 2000
    DEL = Sweep(name= "time_delay", start= 16, stop=350, step=4, dtype = int)
    # WAIT = Sweep(name="time_delay", start=572, stop=620, step=48)
    sweeps = [N, DEL]

    ######################## DATASET (DEPENDENT) VARIABLES #############################
    # must include all primary datasets defined by the Experiment subclass
    # I.fitfn = "gaussian"
    PHASE.datafn_args = {"delay": 2.792e-7, "freq": RRB.int_freq}
    I.plot, Q.plot, MAG.plot, PHASE.plot = False, False, False, False
    SINGLE_SHOT.fitfn = 'gaussian'
    datasets = [I, Q, SINGLE_SHOT]
    ######################## INITIALIZE AND RUN EXPERIMENT #############################
    expt = WaitTime(FOLDER, modes, pulses, sweeps, datasets, **parameters)
    expt.run()
