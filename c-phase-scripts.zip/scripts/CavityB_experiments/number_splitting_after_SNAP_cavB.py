from config.experiment_config import FOLDER, N, FREQ, I, Q, MAG, SINGLE_SHOT
from qm import qua as qm_qua
from qcore import Experiment, qua, Dataset


IB_PARITY = Dataset(name="IB_parity",save=True,plot=False)
QB_PARITY = Dataset(name="QB_parity",save=False,plot=False)
SINGLE_SHOT_B_PARITY = Dataset(name="single_shotB_parity",save=True,plot=False)



class NumberSplittingB_SNAP(Experiment):
    """Number splitting"""

    primary_datasets = ["I", "Q", "single_shot", "IB_parity", "QB_parity", "single_shotB_parity"]
    primary_sweeps = ["qubit_frequency"]

    def sequence(self):
        """QUA sequence that defines this Experiment subclass"""
        qua.reset_frame(self.cavityB)
        qua.reset_frame(self.qubitB)
        qua.reset_frame(self.qubitB_fock1)
        qua.reset_frame(self.qubitBEF)
        qm_qua.reset_global_phase()
        phase1 = qm_qua.declare(qm_qua.fixed)
        phase2 = qm_qua.declare(qm_qua.fixed)
        qm_qua.assign(phase1, 0.25+0.5)
        qm_qua.assign(phase2, 0.25+0.0)
        qua.update_frequency(self.qubitB, self.qubitB.int_freq)
        qua.align()

        # GRAPE 
        self.cavityB.play(self.cavityB_grape02)
        self.qubitB.play(self.qubitB_grape02)
        qua.align()
        
        self.qubitB.play(self.qubitB_pi2)
        qua.wait(int(self.time_delayB), self.qubitB)  
        self.qubitB.play(self.qubitB_pi2, phase = 0.5) 
        qua.align(self.qubitB, self.resonator)  
        self.resonator.measure(self.readout_pulse, (self.IB_parity, self.QB_parity), demod_type = 'dual')
        qua.wait(1000, self.resonator)
        qua.align()
        
        # self.cavityB.play(self.cavityB_disp, ampx = 0.353, phase = phase1)
        # qua.align()
        # self.qubitB.play(self.qubitB_very_sel_pi, ampx = 2.0)
        # self.qubitB_fock1.play(self.qubitB_fock1_very_sel_pi, ampx = 2.0)
        # qua.align()
        # self.cavityB.play(self.cavityB_disp, ampx = 1.037, phase = phase2)
        # qua.align()


        # SPECTROSCOPY
        qua.update_frequency(self.qubitB, self.qubit_frequency)
        self.qubitB.play(self.qubitB_very_sel_pi)
        qua.align(self.qubitB, self.qubitBEF)
        self.qubitBEF.play(self.qubitBEF_drive)
        qua.align(self.qubitBEF, self.resonator)
        self.resonator.measure(self.readout_pulse, (self.I, self.Q), demod_type="dual")
        qua.align()
        qua.wait(self.wait_time)
        if self.plot_single_shot:  # assign state to G or E
            qm_qua.assign(self.single_shotB_parity,qm_qua.Cast.to_fixed(self.IB_parity > -2.5E-5))
            qm_qua.assign(self.single_shot,qm_qua.Cast.to_fixed(self.I > self.readout_pulse.threshold))


if __name__ == "__main__":
    """ """

    modes = {
        "cavityB": "cavB",
        "qubitB": "qB",
        "qubitB_fock1": "qB_fock1",
        "qubitBEF":"qB_EF",
        "resonator": "rrB",
    }

    pulses = {
        "qubitB_grape02": "qB_grape_fock02",
        "cavityB_grape02": "cavB_grape_fock02",
        "qubitB_grape0m2": "qB_grape_fock0-2",
        "cavityB_grape0m2": "cavB_grape_fock0-2",
        "cavityB_disp": "cavB_sg_pulse",
        "qubitB_pi2":"qB_gaussian_pi2_pulse",
        "qubitB_fock1_sel_pi": "qB_f1_gaussian_sel_pi_pulse",
        "qubitB_fock1_very_sel_pi": "qB_f1_gaussian_very_sel_pi_pulse",
        "qubitB_sel_pi": "qB_gaussian_sel_pi_pulse",
        "qubitB_very_sel_pi": "qB_gaussian_very_sel_pi_pulse",
        "qubitBEF_drive": "qBEF_gaussian_pi_pulse",
        "readout_pulse": "rrB_GF_CLEAR_readout_pulse",
    }
                                       
    parameters = {
        "wait_time": 7e6,
        "plot_single_shot": True,
        "time_delayB": 156,
    }

    ######################## SWEEP (INDEPENDENT) VARIABLES #############################
    N.num = 500
    FREQ.name = "qubit_frequency"
    FREQ.start = 344e6
    FREQ.stop = 352e6
    FREQ.num = 101
    sweeps = [N, FREQ]

    I.plot, Q.plot, MAG.plot = False, False, False
    SINGLE_SHOT.plot = True
    SINGLE_SHOT.fitfn = "gaussian"
    datasets = [I, Q, SINGLE_SHOT, IB_PARITY, QB_PARITY, SINGLE_SHOT_B_PARITY]

    expt = NumberSplittingB_SNAP(FOLDER, modes, pulses, sweeps, datasets, **parameters)
    expt.run()
