""" """
import sys

# sys.path.append("C:/Users/admin/Desktop/qcore-yabba/yabba-main/")
from config.experiment_config import FOLDER, N, FREQ, I, Q, MAG, PHASE, RRC, SINGLE_SHOT
from qcore import Experiment, qua, Sweep
from qm import qua as qm_qua

class SSqubit(Experiment):
    """Qubit spectroscopy"""

    ############################# DEFINE PRIMARY DATASETS ##############################
    # these Datasets form the "raw" experimental data and will be streamed by the OPX
    # they must be specified at experiment runtime

    primary_datasets = ["I", "Q", "single_shot"]

    ############################## DEFINE PRIMARY SWEEPS ###############################
    # these Sweeps are uniquely associated with the Experiment subclass
    # these Sweeps must be specified at experiment runtime

    primary_sweeps = ["cavity_frequency"]

    ############################ DEFINE THE PULSE SEQUENCE #############################
    # ensure that you import 'qua' from 'qcore' and not from 'qm' library
    # attributes accessed via 'self' must be defined in 'if __name__ == "__main__"' code

    def sequence(self):
        """QUA sequence that defines this Experiment subclass"""
        # self.cavityB.play(self.cavityB_pulse, ampx= 1.14)  # displace by beta = 1.14
        # qua.align()
        # self.qB.play(self.qB_pulse, ampx = 2.0)    # SNAP: play pi pulse around X
        # qua.align()  # align pulses
        # self.cavityB.play(self.cavityB_pulse, ampx= -0.58)  # displace by beta = -0.58
        # qua.align()


        qua.update_frequency(self.cavityA, self.cavity_frequency)
        qua.update_frequency(self.drive, self.drive_frequency)

        self.cavityA.play(self.cavity_pulse)
        self.drive.play(self.drive_pulse, duration = 3232/4)
        qua.align()

        # self.cavityB.play(self.cavityB_pulse, ampx= 0.58)  # displace by beta = 1.14
        # qua.align()
        # self.qB.play(self.qB_pulse, ampx = 2.0)    # SNAP: play pi pulse around X
        # qua.align()  # align pulses
        # self.cavityB.play(self.cavityB_pulse, ampx= -1.14)  # displace by beta = -0.58
        # qua.align()

        # qua.update_frequency(self.qC, -165.75e6) # Sample qC when cavB is in 1 and cavA in vacuum
        self.qC.play(self.qubit_pulse, ampx = 1.0)
        qua.align()

        self.resonator.measure(self.readout_pulse, (self.I, self.Q), ampx=self.ro_ampx, demod_type="dual")
        if self.plot_single_shot:  # assign state to G or E
            qm_qua.assign(self.single_shot,qm_qua.Cast.to_fixed(self.I > self.readout_pulse.threshold),)
        qua.wait(self.wait_time, self.resonator)

if __name__ == "__main__":
    """ """

    #################################### MODE MAP ######################################
    # key: name of the Mode as defined by the Experiment subclass
    # value: name of the Mode as defined by the user in modes.yml

    modes = {
        "cavityA": "cavA",
        "cavityB": "cavB",
        "qB": "qB",
        "qC": "qC",
        "resonator": "rrC",
        "drive": "drive",
    }

    ################################### PULSE MAP ######################################
    # key: name of the Pulse as defined by the Experiment subclass
    # value: name of the Pulse as defined by the user in modes.yml

    pulses = {        
        "cavity_pulse": "cavA_ramp_long_pulse",
        "cavityB_pulse": "cavB_ramp_pulse",
        "drive_pulse": "SS_pulse",
        "qB_pulse": "qB_gaussian_very_sel_pi_pulse",
        "qubit_pulse": "qC_gaussian_sel_pi_pulse",
        "readout_pulse": "rrC_readout_pulse",
    }


    ############################## CONTROL PARAMETERS ##################################

    parameters = {
        "wait_time": 7e6,
        "ro_ampx": 1,
        "plot_single_shot": True,
    }

    ######################## SWEEP (INDEPENDENT) VARIABLES #############################
    # must include an outermost averaging Sweep named "N"
    # must include all primary sweeps defined by the Experiment subclass

    # set number of repetitions for this Experiment run
    N.num = 10000

    # set the qubit frequency sweep for this Experiment run
    FREQ.name = "cavity_frequency"
    FREQ.start = -180e6
    FREQ.stop = -164e6
    FREQ.num = 101

    FREQ2 = Sweep(
    name="freq",
    dtype=int,
    units="Hz",
    )
    
    FREQ2.name = "drive_frequency"
    FREQ2.start = -200e6
    FREQ2.stop = 200e6
    FREQ2.step= 0.5e6

    #I_AMPX = Sweep(name="drive_amp", start=0.0, stop=2.0, step=0.05)

    sweeps = [N, FREQ, FREQ2]
    
    #sweeps = [N, FREQ]
    ######################## DATASET (DEPENDENT) VARIABLES #############################
    # must include all primary datasets defined by the Experiment subclass

    Q.plot,MAG.plot, PHASE.plot, I.plot = False, False, False, False
    #SINGLE_SHOT.plot = False
    # PHASE.datafn_args = {"delay": 2.792e-7, "freq": RR.int_freq}
    SINGLE_SHOT.plot_args["plot_type"] = "image"
    SINGLE_SHOT.plot = True

    MAG.fitfn = "lorentzian"

    
    # PHASE.datafn_args = {"delay": 2.792e-7, "freq": RRC.int_freq}
    # SINGLE_SHOT.fitfn = "sine"

    # # PHASE.plot = False
    # Q.plot= True
    
    # I.plot, MAG.plot = True, False
    # SINGLE_SHOT.plot = True

    #datasets = [I, Q, MAG, PHASE]

    datasets = [I, Q, SINGLE_SHOT]

    ######################## INITIALIZE AND RUN EXPERIMENT #############################

    expt = SSqubit(FOLDER, modes, pulses, sweeps, datasets, **parameters)
    expt.run()
