import numpy as np

from qcore.vna_experiment import VNAExperiment, VNAExperiment_with_yoko
from qcore.helpers.logger import logger
from qcore import Stage

from config.experiment_config import MODES_CONFIG, FOLDER

# NOTE Need enable current sweep without power sweep

if __name__ == "__main__":

    with Stage(configpath=MODES_CONFIG, remote=True) as stage:
        # connect to VNA
        vna = stage.get("VNA")[0]
        vna.connect()
        yoko = stage.get("yoko")[0]
        yoko.ramp(0, step=0.5e-4)
        yoko.output = True

        currents_list = np.linspace(
            start=-5e-3, stop=10e-3, num=151
        )  # np.linspace(start=0.00175, stop=10e-3, num=121) #AMP
        power_list = [-28, 8] #np.linspace(start=-28, stop=0, num=8)
        for idx_current in range(len(currents_list)):
            for idx_power in range(len(power_list)):
                power_target = power_list[idx_power]
                current_target = currents_list[idx_current]
                print("current_target", current_target)  # A
                print("power_target", power_target)
                yoko.ramp(current_target, step=0.5e-4)
                # these parameters are set on VNA and do not change during a measurement run
                vna_parameters = {
                    # frequency sweep center (Hz)
                    "fcenter": 7.168e9,  # fcenterlist[0],
                    # frequency sweep span (Hz)
                    "fspan": 3e6,
                    # frequency sweep start value (Hz)
                    # "fstart": 4e9,
                    # frequency sweep stop value (Hz)
                    # "fstop": 8e9,
                    # IF bandwidth (Hz), [1, 500000]
                    "bandwidth": 300,  # 300 #1e3,
                    # number of frequency sweep points, [2, 200001]
                    "sweep_points": 1_001,
                    # delay (s) between successive sweep points, [0.0, 100.0]
                    "sweep_delay": 1e-4,
                    # trace data to be displayed and acquired, max traces = 16
                    # each tuple in the list is (<S parameter>, <trace format>)
                    # valid S parameter keys = ("s11", "s12", "s21", "s22")
                    # see VNA.VALID_TRACE_FORMATS for full list of trace format keys
                    "traces": [
                        ("s21", "mlog"),
                        ("s21", "phase"),
                    ],
                    # if true, VNA will display averaged traces on the Shockline app
                    # if false, VNA will display the trace of the current run
                    "is_averaging": True,
                    # if set to "point" will set the averaging type to point by point
                    # "sweep" will set averaging type tp sweep by sweep (note if you do this you should set the avg_count to be the same as the repetition count in measurement parameters)
                    "avg_type": "sweep",
                    "avg_count": 45,  # 15,
                }
                vna.configure(**vna_parameters)
                # these parameters are looped over during the measurement
                measurement_parameters = {
                    # Number of sweep averages, must be an integer > 0
                    "repetitions": 45,  # 15,
                    # Input powers at (<port1>, <port2>) (dBm), range [-30.0, 15.0]
                    # <portX> (X=1,2) can be a set {a, b,...}, tuple (st, stop, step), or constant x
                    # use set for discrete sweep points a, b, ...
                    # use tuple for linear sweep given by np.arange(start, stop + step/2,   step)
                    # use constant to not sweep power for that port
                    # if both <port1> and <port2> are not constant, sweep points will be the cartesian product of <port1> and <port2>
                    # eg 1: powers = ((-30, 15, 5), 0) will sweep port 1 power from -30dBm to 15dBm inclusive in steps of 5dBm with port 2 power remaining constant at 0 dBm
                    # eg 2: powers = ({-15, 0, 15}, {-5, 0}) will result in sweep points (-15, -5), (-15, 0), (0, -5), (0, 0), (15, -5), (15, 0)
                    # eg 3: powers = (0, 0) will set both port powers to 0, no power sweep happens
                    "powers": (power_target, -30),
                    # "powers": ({-25, -15}, -30),  # powerspeclist[idx],
                    # "currents": np.linspace(start=-2e-3, stop=3e-3, num=22),
                    # "currents": {0e-3, 0.69e-3},
                    # total physical attenuation added to VNA ports, if any
                    # (port_1_attenuation, port_2_attenuation) in dB
                    "attenuation": (40, 0),
                }

                # create measurement instance with instruments and measurement_parameters
                # measurement = VNAExperiment(
                #     folder=FOLDER + f"{idx_current}", vna=vna, **measurement_parameters
                # )

                measurement = VNAExperiment(
                    folder=FOLDER,
                    vna=vna,
                    current_index=idx_current,
                    **measurement_parameters,
                )
                measurement_parameters["powers"] = measurement.powers
                # measurement = VNAExperiment_with_yoko(
                #     folder=FOLDER, vna=vna, yoko=yoko, **measurement_parameters
                # )
                # measurement_parameters["powers"] = measurement.powers
                # measurement_parameters["currents"] = measurement.currents

                metadata = {**vna_parameters, **measurement_parameters}
                measurement.run(metadata=metadata)
                vna.hold()
        logger.info("Done vnasweep!")
        yoko.ramp(0, step=0.5e-4)
        # yoko.output=False
