""" Calibrate DC offset for optimized readout """

import sys

sys.path.append("C:/Users/admin/Desktop/qcore-yabba/yabba-main/")

from qcore import Stage
from qcore.instruments import QM
from qm import qua
import numpy as np

from config.experiment_config import MODES_CONFIG


def get_qua_program(rr, dc_offset_op):

    with qua.program() as cal_dc:
        adc_st = qua.declare_stream(adc_trace=True)
        qua.reset_phase(rr.name)
        qua.measure(dc_offset_op, rr.name, adc_st)

        with qua.stream_processing():
            adc_st.input1().average().save("adc1")
            adc_st.input2().average().save("adc2")
    return cal_dc


if __name__ == "__main__":
    """ """

    with Stage(configpath=MODES_CONFIG, remote=True) as stage:

        (rr,) = stage.get("rrA")
        (octave, opx_plus) = stage.get("oct1", "opx_plus")
        qm = QM(modes=(rr,), oscillators=(octave,), opx_plus=opx_plus)

        mode_lo = octave.settings["RF_outputs"][2]
        dc_offset_pulse_name = "rrA_readout_pulse"

        # Reset DC offset of readout mode to be calibrated
        to_update = {"out1": 0.0, "out2": 0.0}
        rr.mixer_offsets = {**rr.mixer_offsets, **to_update}

        # Execute script
        job = qm.execute(get_qua_program(rr, dc_offset_pulse_name))
        # Creates a result handle to fetch data from the OPX
        handle = job.result_handles
        # Waits (blocks the Python console) until all results have been acquired
        handle.wait_for_all_values()
        # Fetch the raw ADC traces and derive the average values
        adc1_mean = np.mean(handle.get("adc1").fetch_all())
        adc2_mean = np.mean(handle.get("adc2").fetch_all())

        dc_offset1 = -adc1_mean * (2**-12)
        dc_offset2 = -adc2_mean * (2**-12)

        # Update DC offset of readout mode to be calibrated
        to_update = {"out1": dc_offset1, "out2": dc_offset2}

        rr.mixer_offsets = {**rr.mixer_offsets, **to_update}

        print(to_update)
