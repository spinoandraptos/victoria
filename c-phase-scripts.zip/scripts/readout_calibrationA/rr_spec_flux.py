""" """
import time
import sys
from datetime import datetime
sys.path.append("C:/Users/admin/Desktop/qcore-yabba/yabba-main/")
from config.experiment_config import FOLDER, N, FREQ, I, Q, MAG, PHASE, MODES_CONFIG
from qcore import Experiment, qua, Sweep, Dataset
from qcore.helpers import Stage
import numpy as np


class RRSpec(Experiment):
    """Readout resonator spectroscopy"""

    ############################# DEFINE PRIMARY DATASETS ##############################
    # these Datasets form the "raw" experimental data and will be streamed by the OPX
    # they must be specified at experiment runtime
    primary_datasets = ["I", "Q"]
    ############################## DEFINE PRIMARY SWEEPS ###############################
    # these Sweeps are uniquely associated with the Experiment subclass
    # these Sweeps must be specified at experiment runtime
    primary_sweeps = ["resonator_frequency"]


    ############################ DEFINE THE PULSE SEQUENCE #############################
    # ensure that you import 'qua' from 'qcore' and not from 'qm' library
    # attributes accessed via 'self' must be defined in 'if __name__ == "__main__"' code

    def sequence(self):
        #print(self.resonator.tof)
        """QUA sequence that defines this Experiment subclass"""
        qua.update_frequency(self.resonator, self.resonator_frequency)
        # self.drive.play(self.drive_pulse, ampx=self.drive_amp)
        # qua.align(self.drive, self.resonator)
        self.resonator.measure(
            self.readout_pulse, (self.I, self.Q), ampx=self.ro_ampx, demod_type="dual"
        )
        qua.wait(self.wait_time, self.resonator)




if __name__ == "__main__":
    """ """
    #################################### MODE MAP ######################################
    # key: name of the Mode as defined by the Experiment subclass
    # value: name of the Mode as defined by the user in modes.yml
    modes = {"resonator": "rrC",
             }
    ################################### PULSE MAP ######################################
    # key: name of the Pulse as defined by the Experiment subclass
    # value: name of the Pulse as defined by the user in modes.yml
    pulses = {"readout_pulse": "rrC_readout_pulse",
              }
    ############################## CONTROL PARAMETERS ##################################

    parameters = {
        "wait_time": 20_000,
        "ro_ampx": 1,
    }
    ######################## SWEEP (INDEPENDENT) VARIABLES #############################
    # must include an outermost averaging Sweep named "N"
    # must include all primary sweeps defined by the Experiment subclass

    ################################### 1D SWEEP #######################################

    # set number of repetitions for this Experiment run
    N.num = 10_000
    

    # set the qubit frequency sweep for this Experiment run
    FREQ.name = "resonator_frequency"
    FREQ.start = 40e6
    FREQ.stop = 60e6
    FREQ.num = 401

    sweeps = [N, FREQ]
    ################################### 2D SWEEP #######################################
    # RO_AMPX = Sweep(name="ro_ampx", points=[0.8, 1, 1.2])
    # sweeps = [N, RO_AMPX, FREQ]

    ######################## DATASET (DEPENDENT) VARIABLES #############################
    # must include all primary datasets defined by the Experiment subclass

    PHASE.inputs = ("I", "Q", "resonator_frequency")
    PHASE.datafn_args = {"delay": 0.04e-9}

    MAG.fitfn = "lorentzian"
    MAG.plot, PHASE.plot, I.plot, Q.plot = False, False, False, False
    MAG.save, PHASE.save, I.save, Q.save = True, True, True, True
    datasets = [I, Q, MAG, PHASE]

    ######################## INITIALIZE AND RUN EXPERIMENT #############################
    
    flux_points = np.arange(0e-3,60e-3,1e-3)
    
    for flux in flux_points:
        
        print(f"Starting rr spec for flux = {flux*1e3:.2f} mA")
        
        with Stage(configpath=MODES_CONFIG, remote=True) as stage:
            yoko = stage.get("yoko")[0]
            yoko.ramp(flux, step=0.05e-3) # step is 0.05 mA
            yoko.output = True
        time.sleep(5)
        
        expt = RRSpec(FOLDER, modes, pulses, sweeps, datasets, **parameters)
        date, hour = datetime.now().strftime("%Y-%m-%d %H-%M-%S").split()
        expt._filepath = expt._folder / "data"/ date / f"{hour}_flux_{flux}{Experiment.DATAFILE_SUFFIX}"
        try: 
            expt.run()
        except Exception:
            yoko.ramp(0, step=0.05e-3) # step is 0.05 mA
        print("Done")

    with Stage(configpath=MODES_CONFIG, remote=True) as stage:
        yoko = stage.get("yoko")[0]
        yoko.ramp(0, step=0.05e-3) # step is 0.05 mA
        yoko.output = True

    print("Done with all sweeps. Current set back to 0 mA.")
