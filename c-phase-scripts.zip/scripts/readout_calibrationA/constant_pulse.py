""" """

import sys
sys.path.append("C:/Users/admin/Desktop/qcore-yabba/yabba-main/")
from config.experiment_config import FOLDER, N, FREQ, I, Q, MAG, PHASE
from qcore import Experiment, qua, Sweep


class cw(Experiment):
    """Readout resonator spectroscopy"""
    primary_datasets = ["I", "Q"]
    primary_sweeps = ["resonator_frequency"]
    def sequence(self):
        #print(self.resonator.tof)
        """QUA sequence that defines this Experiment subclass"""
        self.drive.play(self.drive_pulse, duration = 10000, ampx = 1)
        qua.align()
        qua.wait(self.wait_time, self.resonator)


if __name__ == "__main__":
    modes = {"resonator": "rr", "drive":"qubit"}
    pulses = {"readout_pulse": "rr_readout_pulse", "drive_pulse":"drive_cw"}
    parameters = {
        "wait_time": 1e5,
        "ro_ampx": 1.0,
    }
    N.num = 1000
    FREQ.name = "resonator_frequency"
    FREQ.start = 49e6
    FREQ.stop = 51e6
    FREQ.num = 201
    sweeps = [N, FREQ]
    PHASE.inputs = ("I", "Q", "resonator_frequency")
    PHASE.datafn_args = {"delay": 0.002e-9}
    MAG.fitfn = "lorentzian"
    datasets = [I, Q, MAG, PHASE]
    expt = cw(FOLDER, modes, pulses, sweeps, datasets, **parameters)
    expt.run()
    print(expt._get_qm()._config)