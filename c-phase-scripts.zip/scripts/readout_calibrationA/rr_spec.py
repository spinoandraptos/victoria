""" """
from config.experiment_config import FOLDER, N, FREQ, I, Q, MAG, PHASE
from qcore import Experiment, qua, Sweep


class RRSpec(Experiment):
    """Readout resonator spectroscopy"""

    ############################# DEFINE PRIMARY DATASETS ##############################
    # these Datasets form the "raw" experimental data and will be streamed by the OPX
    # they must be specified at experiment runtime
    primary_datasets = ["I", "Q"]
    ############################## DEFINE PRIMARY SWEEPS ###############################
    # these Sweeps are uniquely associated with the Experiment subclass
    # these Sweeps must be specified at experiment runtime
    primary_sweeps = ["resonator_frequency"]


    ############################ DEFINE THE PULSE SEQUENCE #############################
    # ensure that you import 'qua' from 'qcore' and not from 'qm' library
    # attributes accessed via 'self' must be defined in 'if __name__ == "__main__"' code

    def sequence(self):
        #print(self.resonator.tof)
        """QUA sequence that defines this Experiment subclass"""
        qua.update_frequency(self.resonator, self.resonator_frequency)
        self.resonator.measure(self.readout_pulse, (self.I, self.Q), demod_type="dual")
        qua.wait(self.wait_time, self.resonator)


if __name__ == "__main__":
    """ """
    #################################### MODE MAP ######################################
    modes = {"resonator": "rrA"}

    ################################### PULSE MAP ######################################
    pulses = {"readout_pulse": "rrA_readout_pulse"}

    ############################## CONTROL PARAMETERS ##################################
    parameters = {
        "wait_time": 10_000,
        "ro_ampx": 1.0,
    }

    N.num = 20_000
    
    FREQ.name = "resonator_frequency"
    FREQ.start = 45e6
    FREQ.stop = 55e6
    FREQ.num = 201

    sweeps = [N, FREQ]

    ######################## DATASET (DEPENDENT) VARIABLES #############################
    PHASE.inputs = ("I", "Q", "resonator_frequency")
    PHASE.datafn_args = {"delay": 9.7e-6}
    MAG.fitfn = "lorentzian"

    datasets = [I, Q, MAG, PHASE]

    ######################## INITIALIZE AND RUN EXPERIMENT #############################

    expt = RRSpec(FOLDER, modes, pulses, sweeps, datasets, **parameters)
    expt.run()
