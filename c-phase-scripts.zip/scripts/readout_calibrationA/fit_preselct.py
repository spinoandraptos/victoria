import numpy as np
import os
import h5py
import matplotlib.pyplot as plt
from scipy.optimize import curve_fit

import numpy as np
from scipy.optimize import curve_fit
import matplotlib.pyplot as plt



file =  r"C:\Users\admin\Desktop\cphase\data\2025-07-16\14-54-50_RRSpec.hdf5" # MEASURE - 0us wait time - MEASURE (CLEAR)
file =  r"C:\Users\admin\Desktop\cphase\data\2025-07-16\14-59-39_RRSpec.hdf5" # MEASURE - 1us wait time - MEASURE (CLEAR)
file =  r"C:\Users\admin\Desktop\cphase\data\2025-07-16\15-03-37_RRSpec.hdf5" # MEASURE - 0us wait time - PI PULSE- MEASURE (CLEAR)


file =  r"C:\Users\admin\Desktop\cphase\data\2025-07-16\15-34-06_RRSpec.hdf5" # MEASURE - 0us wait time - MEASURE (NORMAL)
file =  r"C:\Users\admin\Desktop\cphase\data\2025-07-16\15-35-35_RRSpec.hdf5" # MEASURE - 0us wait time - PI PULSE- MEASURE (NORMAL)


data = h5py.File(file, "r")
# data1 = h5py.File(file_fock1, "r")
meas1 = np.average(np.array(data["single_shot1"]), axis=1)
meas2 = np.average(np.array(data["single_shot2"]), axis=1)

print("P1(e)=",np.average(meas1))
print("P2(e)=",np.average(meas2))

mask = (meas1 == 0)

print("P1(e|g)=",np.average(meas1[mask]))
print("P2(e|g)=",np.average(meas2[mask]))

