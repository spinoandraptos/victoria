""" """

from config.experiment_config import FOLDER, N, FREQ, I, Q, MAG, PHASE

from qcore import Experiment, qua, Sweep
from qcore.helpers import Stage
from config.experiment_config import MODES_CONFIG
import numpy as np
import sys
import time
sys.path.append("C:/Users/admin/Desktop/qcore-yabba/yabba-main/")


class RRSpec_with_DC(Experiment):
    """Readout resonator spectroscopy with DC current sweep"""

    ############################# DEFINE PRIMARY DATASETS ##############################
    # these Datasets form the "raw" experimental data and will be streamed by the OPX
    # they must be specified at experiment runtime

    primary_datasets = ["I", "Q"]

    ############################## DEFINE PRIMARY SWEEPS ###############################
    # these Sweeps are uniquely associated with the Experiment subclass
    # these Sweeps must be specified at experiment runtime

    primary_sweeps = ["resonator_frequency"]

    ############################ DEFINE THE PULSE SEQUENCE #############################
    # ensure that you import 'qua' from 'qcore' and not from 'qm' library
    # attributes accessed via 'self' must be defined in 'if __name__ == "__main__"' code

    def sequence(self):
        """QUA sequence that defines this Experiment subclass"""
        # yoko.ramp(self.DC_current / 1e3)
        qua.update_frequency(self.resonator, self.resonator_frequency)
        self.resonator.measure(
            self.readout_pulse, (self.I, self.Q), ampx=self.ro_ampx, demod_type="dual"
        )
        qua.wait(self.wait_time, self.resonator)


if __name__ == "__main__":
    """ """

    #################################### MODE MAP ######################################
    # key: name of the Mode as defined by the Experiment subclass
    # value: name of the Mode as defined by the user in modes.yml

    modes = {"resonator": "rr"}
    with Stage(configpath=MODES_CONFIG, remote=True) as stage:
        (yoko,) = stage.get("yoko",)
    yoko.ramp(0, step=1e-4)
    yoko.output = True

    ################################### PULSE MAP ######################################
    # key: name of the Pulse as defined by the Experiment subclass
    # value: name of the Pulse as defined by the user in modes.yml

    pulses = {"readout_pulse": "rr_readout_pulse"}

    ############################## CONTROL PARAMETERS ##################################

    parameters = {
        "wait_time": 20_000,
        "ro_ampx": 0.6,
    }

    ######################## SWEEP (INDEPENDENT) VARIABLES #############################
    # must include an outermost averaging Sweep named "N"
    # must include all primary sweeps defined by the Experiment subclass

    ################################### 1D SWEEP #######################################

    # set number of repetitions for this Experiment run
    N.num = 3_000

    # set the qubit frequency sweep for this Experiment run
    FREQ.name = "resonator_frequency"
    FREQ.start = -52e6
    FREQ.stop = -48.5e6
    FREQ.num = 121
    DC_currents = np.arange(start=-10e-3, stop=10e-3, step=0.5e-3)

    ################################### 2D SWEEP #######################################

    # RO_AMPX = Sweep(
    #     name="ro_ampx",
    #     points=[0.1, 0.15],
    # )
    # sweeps = [N, RO_AMPX, FREQ]
    sweeps = [N, FREQ]

    ######################## DATASET (DEPENDENT) VARIABLES #############################
    # must include all primary datasets defined by the Experiment subclass

    PHASE.inputs = ("I", "Q", "resonator_frequency")
    PHASE.datafn_args = {"delay": 2.792e-7}

    I.plot = False
    Q.plot = False
    PHASE.plot = False
    MAG.plot = False

    datasets = [I, Q, MAG, PHASE]

    ######################## INITIALIZE AND RUN EXPERIMENT #############################
    for DC_current in DC_currents:
      yoko.ramp(DC_current, step=0.5e-4)
      expt = RRSpec_with_DC(FOLDER, modes, pulses, sweeps, datasets, current_value=DC_current, **parameters)
      expt.run()
    yoko.ramp(0, step=0.5e-4)
    yoko.output = False
