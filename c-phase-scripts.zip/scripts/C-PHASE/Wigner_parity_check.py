from config.experiment_config import FOLDER, N, FREQ, RRB, I, Q, SINGLE_SHOT
from qcore import Experiment, qua, Sweep, Dataset
from qm import qua as qm_qua
from qcore.libs.qua_macros import QuaVariable
import shutil
import os
from datetime import datetime
from scripts.qB_GE_experiments.T2_virtual_detuning_qB import QubitT2
from scripts.qB_GE_experiments.AllXY_qB import ALLXY

# SCREENSHOT FILE 
current_script_path = os.path.realpath(__file__) # Get the path to the current script
script_name = os.path.basename(current_script_path)[:-3] # Get filename only (e.g., 'my_script.py')
date, time = datetime.now().strftime("%Y-%m-%d %H-%M-%S").split()
destination_path = os.path.join(FOLDER + "data/" + str(date) + '/', f"{script_name}_screenhsot_{time}.py") # Define destination path
shutil.copy(current_script_path, destination_path) # Copy the script

IA_PARITY= Dataset(name="IA_parity",save=False,plot=False)
QA_PARITY = Dataset(name="QA_parity",save=False,plot=False)
SINGLE_SHOT_A_PARITY = Dataset(name="single_shotA_parity",save=True,plot=False)

IA = Dataset(name="IA",save=False,plot=False)
QA = Dataset(name="QA",save=False,plot=False)
SINGLE_SHOT_A = Dataset(name="single_shotA",save=True,plot=False)
SINGLE_SHOT_A_AFTER = Dataset(name="single_shotA_after",save=True,plot=False)

IB_PARITY = Dataset(name="IB_parity",save=False,plot=False)
QB_PARITY = Dataset(name="QB_parity",save=False,plot=False)
SINGLE_SHOT_B_PARITY = Dataset(name="single_shotB_parity",save=True,plot=False)

IB = Dataset(name="IB",save=False,plot=False)
QB = Dataset(name="QB",save=False,plot=False)
SINGLE_SHOT_B = Dataset(name="single_shotB",save=True,plot=False)
SINGLE_SHOT_B_AFTER = Dataset(name="single_shotB_after",save=True,plot=False)

SINGLE_SHOT_C = Dataset(
    name="single_shotC",
    save=True,
    plot=False, 
)
SINGLE_SHOT_C_BEFORE = Dataset(
    name="single_shotC_before",
    save=True,
    plot=False, 
)
IC = Dataset(
    name="IC",
    save=False,
    plot=False, 
)
IC_BEFORE = Dataset(
    name="IC_before",
    save=False,
    plot=False, 
)
QC = Dataset(
    name="QC",
    save=False,
    plot=False, 
)
QC_BEFORE = Dataset(
    name="QC_before",
    save=False,
    plot=False, 
)


class WignersAB(Experiment):
    """Wigner_function"""

    ############################# DEFINE PRIMARY DATASETS ##############################
    primary_datasets = ["IA_parity", "QA_parity", "single_shotA_parity",
                        "IA", "QA", "single_shotA",
                        "IB_parity", "QB_parity", "single_shotB_parity",
                        "IB", "QB", "single_shotB",]

    ############################## DEFINE PRIMARY SWEEPS ###############################
    primary_sweeps = ["cavity_drive_I"]

    ############################ DEFINE THE PULSE SEQUENCE #############################
    def sequence(self):
        total_phaseA = qm_qua.declare(qm_qua.fixed)
        total_phaseB = qm_qua.declare(qm_qua.fixed)
        qua.reset_frame(self.cavityA)
        qua.reset_frame(self.qubitA)
        qua.reset_frame(self.qubitA_EF)
        qua.reset_frame(self.cavityB)
        qua.reset_frame(self.qubitB)
        qua.reset_frame(self.qubitB_EF)
        qua.reset_frame(self.drive)
        qm_qua.reset_global_phase()
        qua.update_frequency(self.drive, 334e6)
        qua.align()

        ###########################
        #STATE PREPARATION 
        ###########################
        self.cavityA.play(self.cavA_grape)
        self.qubitA.play(self.qA_grape)
        self.cavityB.play(self.cavB_grape)
        self.qubitB.play(self.qB_grape)
        qua.align()

        #############################
        #DRIVE
        ############################
        qm_qua.assign(total_phaseA,  0.25 + qm_qua.Cast.mul_fixed_by_int(self.ramp_phaseA, self.gate_num) + qm_qua.Cast.mul_fixed_by_int(self.detuningA * 1e-9 * self.gate_num, self.pulse_length))
        qm_qua.assign(total_phaseB,  0.25 + qm_qua.Cast.mul_fixed_by_int(self.ramp_phaseB, self.gate_num) + qm_qua.Cast.mul_fixed_by_int(self.detuningB * 1e-9 * self.gate_num, self.pulse_length))

        for i in range (0, self.gate_num, 1):
            self.drive.play(self.drive_pulse)
        qua.align()

        self.qubitA.play(self.qubitA_pi2)
        qua.wait(int(self.time_delayA), self.qubitA)  
        self.qubitA.play(self.qubitA_pi2, phase = 0.5) 
        qua.align(self.qubitA, self.rrA)  
        self.rrA.measure(self.readout_pulseA, (self.IA_parity, self.QA_parity), demod_type = 'dual')

        self.qubitB.play(self.qubitB_pi2)
        qua.wait(int(self.time_delayB), self.qubitB)  
        self.qubitB.play(self.qubitB_pi2, phase = 0.5) 
        qua.align(self.qubitB, self.rrB)  
        self.rrB.measure(self.readout_pulseB, (self.IB_parity, self.QB_parity), demod_type = 'dual')
        
        qua.wait(1500, self.rrA, self.rrB)
        qua.align()

        qm_qua.assign(self.single_shotA_parity, qm_qua.Cast.to_fixed(self.IA_parity > self.readout_pulseA.threshold))
        qm_qua.assign(self.single_shotB_parity, qm_qua.Cast.to_fixed(self.IB_parity > self.readout_pulseB.threshold))
        

        ##############################
        #WIGNER A
        ##############################
        self.cavityA.play(self.cavA_op, ampx=(self.cavity_drive_I, -self.cavity_drive_Q, self.cavity_drive_Q, self.cavity_drive_I), phase= total_phaseA)  # displacement
        qua.align(self.cavityA, self.qubitA)
        self.qubitA.play(self.qubitA_pi2)  # play pi/2 pulse around X
        qua.wait(int(self.time_delayA), self.qubitA)  # conditional phase gate on even, odd Fock state
        self.qubitA.play(self.qubitA_pi2, phase = self.qb_phase)  # play pi/2 pulse around X
        qua.align(self.qubitA, self.qubitA_EF)  
        self.qubitA_EF.play(self.qubitA_EF_pi) 
        qua.align(self.qubitA_EF, self.rrA)  
        self.rrA.measure(self.readout_pulseA, (self.IA, self.QA), demod_type = 'dual')  # measure transmitted signal

        ############################
        #WIGNER B
        ############################
        self.cavityB.play(self.cavB_op, ampx=(self.cavity_drive_I, -self.cavity_drive_Q, self.cavity_drive_Q, self.cavity_drive_I), phase= total_phaseB)  # displacement
        qua.align(self.cavityB, self.qubitB)
        self.qubitB.play(self.qubitB_pi2)  # play pi/2 pulse around X
        qua.wait(int(self.time_delayB), self.qubitB)  # conditional phase gate on even, odd Fock state
        self.qubitB.play(self.qubitB_pi2, phase = self.qb_phase)  # play pi/2 pulse around X
        qua.align(self.qubitB, self.qubitB_EF)  
        self.qubitB_EF.play(self.qubitB_EF_pi) 
        qua.align(self.qubitB, self.rrB)  
        self.rrB.measure(self.readout_pulseB, (self.IB, self.QB), demod_type = 'dual')  # measure transmitted signal
        
        qua.align()
        qua.wait(self.wait_time)

        qm_qua.assign(self.single_shotA, qm_qua.Cast.to_fixed(self.IA > self.readout_pulseA.threshold))
        qm_qua.assign(self.single_shotB, qm_qua.Cast.to_fixed(self.IB > self.readout_pulseB.threshold))

if __name__ == "__main__":
    """ """

    modes = {
        "cavityA": "cavA",
        "cavityB": "cavB",
        "qubitA": "qA",
        "qubitB": "qB",
        "qubitA_EF": "qA_EF",
        "qubitB_EF": "qB_EF",
        "drive": "drive",
        "rrA": "rrA",
        "rrB": "rrB",
    }

    pulses = {
        "qA_grape": "qA_grape_fock02",
        "cavA_grape": "cavA_grape_fock02",
        "qB_grape": "qB_grape_fock2",
        "cavB_grape": "cavB_grape_fock2",

        "cavA_op": "cavA_ramp_pulse",
        "cavB_op": "cavB_ramp_pulse",

        "drive_pulse": "very_good_pulse_standard",

        "qubitA_pi2": "qA_gaussian_pi2_pulse",
        "qubitB_pi2": "qB_gaussian_pi2_pulse",
        "qubitB_EF_pi": "qBEF_gaussian_pi_pulse",
        "qubitA_EF_pi": "qAEF_EF_gaussian_pi_pulse",

        "readout_pulseA": "rrA_GF_CLEAR_readout_pulse",
        "readout_pulseB": "rrB_GF_CLEAR_readout_pulse",
    }

    ############################## CONTROL PARAMETERS ##################################

    parameters = {
        "ramp_phaseA": -0.154/2 -0.22,
        "detuningA": -1518e3/2, 
        "ramp_phaseB": -0.056/2 -0.42,
        "detuningB": -452e3/2,
        "wait_time": 7e6,
        "plot_single_shot": True,
        "pulse_length": 1900,
        "gate_num": 1,
        "time_delayA": 520,
        "time_delayB": 156, 
        # "drive_length": 1940,
        "qb_phase":0,
        "gate_num": 1,
    }
    N.num = 10_000
    QD_AMPX_I = Sweep(name="cavity_drive_I", start=-2.0, stop=2.0, num = 21) ###PREV 0.2
    QD_AMPX_Q = Sweep(name="cavity_drive_Q", start=-2.0, stop=2.0, num = 21) ###PREV 0.2
    
    # LENGTH = Sweep (name="drive_length", dtype=int, units = "ns")
    # LENGTH.start = 1300
    # LENGTH.stop = 5200
    # LENGTH.step = 1300 ###PREV 2000

    GATE = Sweep(name="gate_id", start=0, stop=2, num = 3, dtype = int)

    PARITY = Sweep (name="qb_phase", dtype=float)
    PARITY.start = 0.0
    PARITY.stop = 0.5
    PARITY.step = 0.5

    # sweeps = [N, QD_AMPX_Q, QD_AMPX_I]
    sweeps = [N, QD_AMPX_Q, QD_AMPX_I]

    SINGLE_SHOT_A.plot_args["plot_type"] = "image"
    SINGLE_SHOT_B.plot_args["plot_type"] = "image"

    datasets = [IA, QA, SINGLE_SHOT_A,  
                IA_PARITY, QA_PARITY, SINGLE_SHOT_A_PARITY, 
                IB, QB, SINGLE_SHOT_B,
                IB_PARITY, QB_PARITY, SINGLE_SHOT_B_PARITY]

    SINGLE_SHOT_A.plot = True
    SINGLE_SHOT_B.plot = True

    expt = WignersAB(FOLDER, modes, pulses, sweeps, datasets, **parameters)
    #expt.run(simulate=False, filename_suffix=grape_A + "fock01")
    expt.run(simulate=False)

