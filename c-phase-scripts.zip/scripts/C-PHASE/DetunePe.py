from config.experiment_config import FOLDER, N, FREQ, I, Q, MAG, PHASE, RRC, SINGLE_SHOT
from qm import qua as qm_qua
from qcore import Experiment, qua, Sweep

class ResonantExchange1D(Experiment):
    """Resonant exchange"""

    ############################# DEFINE PRIMARY DATASETS ##############################
    # these Datasets form the "raw" experimental data and will be streamed by the OPX
    # they must be specified at experiment runtime
    primary_datasets = ["I", "Q"]
    ############################## DEFINE PRIMARY SWEEPS ###############################
    # these Sweeps are uniquely associated with the Experiment subclass
    # these Sweeps must be specified at experiment runtime
    primary_sweeps = ["drive_freq"]
    ############################ DEFINE THE PULSE SEQUENCE #############################
    # ensure that you import 'qua' from 'qcore' and not from 'qm' library
    # attributes accessed via 'self' must be defined in 'if __name__ == "__main__"' code

    def sequence(self):
        """QUA sequence that defines this Experiment subclass"""
        # Prepare 1 in Alice
        self.qubit.play(self.qubit_drive)
        self.cav.play(self.cavity_drive)
        qua.align()
        # Drive resonant exchange
        qua.update_frequency(self.drive, self.drive_freq)
        self.drive.play(self.exchange_drive)
        qua.align()
        # Readout state of qubibt
        self.resonator.measure(self.readout_pulse, (self.I, self.Q), ampx=self.ro_ampx, demod_type="dual")
        qua.align()
        qua.wait(self.wait_time)
        if self.plot_single_shot:  # assign state to G or E
            qm_qua.assign(self.single_shot,qm_qua.Cast.to_fixed(self.I > self.readout_pulse.threshold))


if __name__ == "__main__":
    """ """

    #################################### MODE MAP ######################################
    # key: name of the Mode as defined by the Experiment subclass
    # value: name of the Mode as defined by the user in modes.yml

    modes = {"qubit": "qA",
             "drive": "drive",
             "resonator": "rrC",
             "cav": "cavA"}

    ################################### PULSE MAP ######################################
    # key: name of the Pulse as defined by the Experiment subclass
    # value: name of the Pulse as defined by the user in modes.yml

    pulses = {
        "cavity_drive": "cavA_grape_fock1",
        "qubit_drive": "qA_grape_fock1",
        "exchange_drive": "exchange_pulse",
        "readout_pulse": "rrC_readout_pulse",
    }

    ############################## CONTROL PARAMETERS ##################################
    parameters = {
        "wait_time": 7e6,
        "ro_ampx": 1,
        "plot_single_shot": False,
    }

    ######################## SWEEP (INDEPENDENT) VARIABLES #############################
    # must include an outermost averaging Sweep named "N"
    # must include all primary sweeps defined by the Experiment subclass

    # set number of repetitions for this Experiment run
    N.num = 5000

    FREQ.name = "drive_freq"
    FREQ.start = -100e6
    FREQ.stop = 200e6
    FREQ.num = 201

    sweeps = [N, FREQ]

    ######################## DATASET (DEPENDENT) VARIABLES #############################
    # must include all primary datasets defined by the Experiment subclass

    PHASE.datafn_args = {"delay": 2.792e-7, "freq": RRC.int_freq}
    I.plot, Q.plot, PHASE.plot, MAG.plot = True, True, False, False
    # SINGLE_SHOT.plot_args["plot_type"] = "image"
    # I.plot_args["plot_type"] = "image"
    # Q.plot_args["plot_type"] = "image"


    datasets = [I, Q]
    # SINGLE_SHOT.fitfn = 'double_gaussian'
    # SINGLE_SHOT.plot_args = {"plot_err": False}
    ######################## INITIALIZE AND RUN EXPERIMENT #############################

    expt = ResonantExchange1D(FOLDER, modes, pulses, sweeps, datasets, **parameters)
    expt.run()
