""" """
import sys

from config.experiment_config import FOLDER, N, FREQ, I, Q, MAG, PHASE, RRB, SINGLE_SHOT
from qcore import Experiment, qua, Sweep, Dataset
from qm import qua as qm_qua
from qcore.libs.qua_macros import QuaVariable

SINGLE_SHOT_A_pre = Dataset(
    name="single_shotApre",
    save=True,
    plot=False, 
)

SINGLE_SHOT_A = Dataset(
    name="single_shotA",
    save=True,
    plot=False, 
)

SINGLE_SHOT_B = Dataset(
    name="single_shotB",
    save=True,
    plot=False, 
)

SINGLE_SHOT_C = Dataset(
    name="single_shotC",
    save=True,
    plot=False, 
)

IApre = Dataset(
    name="IApre",
    save=False,
    plot=False,
    # fitfn="exp_decay",
)

QApre = Dataset(
    name="QApre",
    save=False,
    plot=False,
)

IA = Dataset(
    name="IA",
    save=False,
    plot=False,
)

QA= Dataset(
    name="QA",
    save=False,
    plot=False,
)

IB = Dataset(
    name="IB",
    save=False,
    plot=False,
)

QB = Dataset(
    name="QB",
    save=False,
    plot=False,
)

IC = Dataset(
    name="IC",
    save=False,
    plot=False,
)

QC= Dataset(
    name="QC",
    save=False,
    plot=False,
)

class Wigner1D_A(Experiment):
    """Wigner_function"""

    ############################# DEFINE PRIMARY DATASETS ##############################
    # these Datasets form the "raw" experimental data and will be streamed by the OPX
    # they must be specified at experiment runtime
    primary_datasets = ["IApre", "QApre", "single_shotApre","IA", "QA", "single_shotA","IB", "QB", "single_shotB","IC", "QC", "single_shotC",]
    #primary_datasets = ["I", "Q", "single_shot"]

    primary_sweeps = ["gate_id"]
    def __init__(self, folder, modes, pulses, sweeps, datasets, **parameters):

        super().__init__(
            folder,
            modes,
            pulses,
            sweeps,
            datasets,
            **parameters,
        )  # Passes other parameters to parent

        self.pulse_list = [f"self.exchange_pulse_cos2_{d}" for d in range (16,1_020, 20)]


    ############################## DEFINE PRIMARY SWEEPS ###############################
    # these Sweeps are uniquely associated with the Experiment subclass
    # these Sweeps must be specified at experiment runtime

    ############################ DEFINE THE PULSE SEQUENCE #############################
    # ensure that you import 'qua' from 'qcore' and not from 'qm' library
    # attributes accessed via 'self' must be defined in 'if __name__ == "__main__"' code
    def sequence(self):
        """QUA sequence that defines this Experiment subclass"""
        qua.reset_frame(self.cavA)
        qua.reset_frame(self.cavB)
        qua.reset_frame(self.drive)
        qua.reset_frame(self.qC)
        qua.reset_frame(self.qA)
        qua.reset_frame(self.qB)






        # PREPARE STATE
        # self.cavity.play(self.cav_op, phase = 0.0)
        # Prepare 1 in A
        # self.cavB.play(self.cavityB_grape)
        # self.qB.play(self.qubitB_grape)
        self.cavA.play(self.cavityA_grape)
        self.qA.play(self.qubitA_grape)
        qua.align()  

        qua.update_frequency(self.drive, 345e6)

        with qm_qua.switch_(self.gate_id):
            for i in range(16,1_020, 20):
                with qm_qua.case_(i):
                    self.drive.play(getattr(self,f"exchange_pulse_cos2_{i}"), ampx = 1.0)


        #qua.wait(self.drive_time, self.cavity)  # wait for state to rotate
        qua.align() 

        # # Check if cavA in 0 or 1
        # self.qA.play(self.qA_pulse)
        # qua.align(self.qubitEF, self.qA)
        # self.qubitEF.play(self.qubitEF_pi)
        # qua.align(self.qubitEF, self.rrA)
        # self.rrA.measure(self.readout_pulseA, (self.IA, self.QA), ampx=self.ro_ampx, demod_type="dual")

        # Check if cavB in 0 or 1
        # self.qB.play(self.qB_pulse)
        # qua.align(self.qB_EF, self.qB)
        # self.qB_EF.play(self.qB_EF_pi)        
        # qua.align(self.rrB, self.qB_EF)
        # self.rrB.measure(self.readoutB_pulse, (self.IB, self.QB), ampx=self.ro_ampx, demod_type="dual")
        
        # Check if rrC in g or e
        self.rrC.measure(self.readoutC_pulse, (self.IC, self.QC), ampx=self.ro_ampx, demod_type="dual")
        qua.align()

        qua.wait(self.wait_time)
        if self.plot_single_shot:  # assign state to G or E
            #qm_qua.assign(self.single_shotA, qm_qua.Cast.to_fixed(self.IA > self.readout_pulseA.threshold),)
            #qm_qua.assign(self.single_shotB, qm_qua.Cast.to_fixed(self.IB > self.readoutB_pulse.threshold),)
            qm_qua.assign(self.single_shotC, qm_qua.Cast.to_fixed(self.IC > self.readoutC_pulse.threshold),)

if __name__ == "__main__":
    """ """

    #################################### MODE MAP ######################################
    # key: name of the Mode as defined by the Experiment subclass
    # value: name of the Mode as defined by the user in modes.yml
    modes = {"qA": "qA",
             "qB": "qB",
             "qB_EF": "qB_EF",
             "qC": "qC",
             "drive": "drive",
             "rrA": "rrA",
             "qubitEF": "qA_EF",
             "rrB": "rrB",
             "rrC": "rrC",
             "cavA": "cavA",
             "cavB": "cavB"
             }

    ################################### PULSE MAP ######################################
    # key: name of the Pulse as defined by the Experiment subclass
    # value: name of the Pulse as defined by the user in modes.yml
    pulses = {
        "qubitA_grape": "qA_grape_fock1",
        "cavityA_grape": "cavA_grape_fock1",
        "qubitB_grape": "qB_grape_fock01_new",
        "cavityB_grape": "cavB_grape_fock01_new",
        "qA_pulse": "qA_gaussian_very_sel_pi_pulse",
        "qB_pulse": "qB_gaussian_very_sel_pi_pulse",
        "qC_pulse": "qC_gaussian_pi_pulse",
        "qubit_spec_pulse": "qC_gaussian_sel_pi_pulse",
        # "qB_pulse": "qB_gaussian_pi_pulse",
        # "qB_pulse": "qB_gaussian_pi_pulse",
        "exchange_drive": "exchange_sg_pulse",
        #"readoutB_pulse": "rrB_GF_CLEAR_readout_pulse",
        "readoutB_pulse": "rrB_readout_pulse",
        "readoutC_pulse": "rrC_readout_pulse",
        "readout_pulseA": "rrA_GF_CLEAR_readout_pulse", 
        "qubitEF_pi": "qAEF_EF_gaussian_pi_pulse",        
        "qB_EF_pi": "qBEF_gaussian_pi_pulse",
    }

    
    for d in range(16,1_020, 20):
        pulses[f"exchange_pulse_cos2_{d}"] = f"exchange_pulse_cos2_{d}"


    ############################## CONTROL PARAMETERS ##################################
    parameters = {
        "wait_time": 6e6,
        "ro_ampx": 1,
        "plot_single_shot": True,
        "qubit_drive_ampx": 1.0,
    }

    ######################## SWEEP (INDEPENDENT) VARIABLES #############################
    # must include an outermost averaging Sweep named "N"
    # must include all primary sweeps defined by the Experiment subclass

    # set number of repetitions for this Experiment run
    N.num = 5000
    #QD_AMPX = Sweep(name="drive_amplitude", start=0, stop=1.0, step=1)
    GATES = Sweep(name="gate_id", start=16, stop=1020, step=20, dtype=int, save=True)
    sweeps = [N, GATES]
    #sweeps = [N, QD_AMPX, TIME]

    ######################## DATASET (DEPENDENT) VARIABLES #############################
    # must include all primary datasets defined by the Experiment subclass
    IC.plot = False
    QC.plot = False
    #SINGLE_SHOT_C.plot = True
    SINGLE_SHOT_C.plot = True
    SINGLE_SHOT.fitfn = 'exp_decay_sine'
    datasets = [IApre, QApre, SINGLE_SHOT_A_pre, IA, QA, SINGLE_SHOT_A, IB, QB, SINGLE_SHOT_B, IC, QC, SINGLE_SHOT_C]
    #datasets = [I, Q, SINGLE_SHOT]
    ######################## INITIALIZE AND RUN EXPERIMENT #############################
    expt = Wigner1D_A(FOLDER, modes, pulses, sweeps, datasets, **parameters)
    expt.run()
