from config.experiment_config import FOLDER, N, FREQ, RRB, I, Q, SINGLE_SHOT
from qcore import Experiment, qua, Sweep, Dataset
from qm import qua as qm_qua
from qcore.libs.qua_macros import QuaVariable
import shutil
import os
from datetime import datetime
from scripts.qB_GE_experiments.T2_virtual_detuning_qB import QubitT2
from scripts.qB_GE_experiments.AllXY_qB import ALLXY
from qm.qua import *

# SCREENSHOT FILE 
current_script_path = os.path.realpath(__file__) # Get the path to the current script
script_name = os.path.basename(current_script_path)[:-3] # Get filename only (e.g., 'my_script.py')
date, time = datetime.now().strftime("%Y-%m-%d %H-%M-%S").split()
destination_path = os.path.join(FOLDER + "data/" + str(date) + '/', f"{script_name}_screenhsot_{time}.py") # Define destination path
shutil.copy(current_script_path, destination_path) # Copy the script

IA = Dataset(name="IA",save=False,plot=False)
QA = Dataset(name="QA",save=False,plot=False)
SINGLE_SHOT_A = Dataset(name="single_shotA",save=True,plot=False)
IB = Dataset(name="IB",save=False,plot=False)
QB = Dataset(name="QB",save=False,plot=False)
SINGLE_SHOT_B = Dataset(name="single_shotB",save=True,plot=False)

class DriveDetuning(Experiment):
    """Wigner_function"""

    primary_datasets = ["IA",
                        "QA",
                        "single_shotA", 
                        "IB",
                        "QB",
                        "single_shotB",
                        ]

    primary_sweeps = ["detuningA"]

    def __init__(self, folder, modes, pulses, sweeps, datasets, **parameters):

        super().__init__(folder,modes,pulses,sweeps,datasets, **parameters,)  # Passes other parameters to parent

        self.pulse_list = [f"self.exchange_pulse_cos2_5200"]

    def sequence(self):
        """QUA sequence that defines this Experiment subclass"""
        qua.reset_frame(self.cavityA)
        qua.reset_frame(self.qubitA)
        qua.reset_frame(self.qubitAEF)
        qua.reset_frame(self.drive)
        qm_qua.reset_global_phase()

        total_phase_A = qm_qua.declare(qm_qua.fixed)
        factor = qm_qua.declare(qm_qua.fixed)

        qua.update_frequency(self.drive, 345e6 - 6e6)
        qua.update_frequency(self.qubitA, self.qubitA.int_freq)

        # GRAPE A and B
        self.cavityA.play(self.cavA_grape)
        self.qubitA.play(self.qA_grape)
        qua.align()

        # DRIVE

        qm_qua.assign(factor, 1e-9 * 5200 * 6)  # formerly with a 4*
        qm_qua.assign(total_phase_A,  0.25 + qm_qua.Cast.mul_fixed_by_int(self.ramp_phaseA, 6) + qm_qua.Cast.mul_fixed_by_int(factor, self.detuningA))
        for p in range (0,6,1):
            self.drive.play(getattr(self,f"exchange_pulse_cos2_5200"))

        qua.align()

        self.cavityA.play(self.cavityA_pulse, ampx= -0.4, phase = total_phase_A)
        qua.align(self.cavityA, self.qubitA) 
        self.qubitA.play(self.qA_selective)  # play selective qubit pulse
        qua.align(self.qubitAEF, self.qubitA)
        self.qubitAEF.play(self.qubitA_EF_pi)  # play selective qubit pulse
        qua.align(self.qubitAEF, self.rrA)
        self.rrA.measure(self.readout_pulseA, (self.IA, self.QA), demod_type = 'dual')  # measure transmitted signal
        
        if self.plot_single_shot:  # assign state to G or E
            qm_qua.assign(self.single_shotA, qm_qua.Cast.to_fixed(self.IA > self.readout_pulseA.threshold))
        qua.align()
        qua.wait(self.wait_time)


grape_list_A = ["fock01_test"]

for i in range (len(grape_list_A)):
    qA_grape = "qA_grape_" + grape_list_A[i]
    cavA_grape =  "cavA_grape_" + grape_list_A[i]

    if __name__ == "__main__":
        """ """

        modes = {
            "cavityA": "cavA",
            "cavityB": "cavB",
            "qubitA": "qA",
            "qubitAEF":"qA_EF",
            "qubitB": "qB", 
            "qubitB_EF":"qB_EF",
            "drive": "drive",           
            "rrA": "rrA",
            "rrB": "rrB"
        }

        pulses = {
            "qA_grape": qA_grape,
            "cavA_grape": cavA_grape,
            "cavityA_pulse": "cavA_ramp_pulse",
            "qubitA_pi2": "qA_gaussian_pi2_pulse",
            "qA_selective": "qA_gaussian_very_sel_pi_pulse",
            "qubitA_EF_pi": "qAEF_EF_gaussian_pi_pulse",
            "qA_unselective": "qA_gaussian_pi_pulse",
            "exchange_pulse_cos2_5200": "exchange_pulse_cos2_5200",
            "readout_pulseA": "rrA_GF_CLEAR_readout_pulse",
        }


        ############################## CONTROL PARAMETERS ##################################
        parameters = {
            "ramp_phaseA": -0.1+0.007, 
            # "detuningA": - 812.83e3, 
            "wait_time": 6e6,
            "plot_single_shot": True,
        }

        N.num = 100_000

                        
        DET = Sweep(name = "detuningA", start = - 812.83e3 - 10e3, stop =  - 812.83e3 + 10e3, step = 1e3, dtype = int, units="Hz", save = True)

        sweeps = [N, DET]

        SINGLE_SHOT_A.plot = True
        SINGLE_SHOT_B.plot = True
        # SINGLE_SHOT_A.plot_args["plot_type"] = "image"
        # SINGLE_SHOT_B.plot_args["plot_type"] = "image"
        datasets = [IA, QA, SINGLE_SHOT_A, 
                    IB, QB, SINGLE_SHOT_B,
                    ]

        expt = DriveDetuning(FOLDER, modes, pulses, sweeps, datasets, **parameters)
        
        expt.run(simulate=False)