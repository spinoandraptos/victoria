from config.experiment_config import FOLDER, N, FREQ, RRB, I, Q, SINGLE_SHOT
from qcore import Experiment, qua, Sweep, Dataset
from qm import qua as qm_qua
from qcore.libs.qua_macros import QuaVariable
import shutil
import os
from datetime import datetime
from scripts.qB_GE_experiments.T2_virtual_detuning_qB import QubitT2
from scripts.qB_GE_experiments.AllXY_qB import ALLXY
from qm.qua import *

# SCREENSHOT FILE 
current_script_path = os.path.realpath(__file__) # Get the path to the current script
script_name = os.path.basename(current_script_path)[:-3] # Get filename only (e.g., 'my_script.py')
date, time = datetime.now().strftime("%Y-%m-%d %H-%M-%S").split()
destination_path = os.path.join(FOLDER + "data/" + str(date) + '/', f"{script_name}_screenhsot_{time}.py") # Define destination path
shutil.copy(current_script_path, destination_path) # Copy the script

IB_AFTER = Dataset(name="IB_after", save=False, plot=False)
QB_AFTER = Dataset(name="QB_after", save=False, plot=False)
SINGLE_SHOT_B_AFTER = Dataset(name="single_shotB_after",save=True,plot=False)

IA_AFTER = Dataset(name="IA_after",save=False,plot=False, )
QA_AFTER = Dataset(name="QA_after",save=False,plot=False, )
SINGLE_SHOT_A_AFTER = Dataset(name="single_shotA_after",save=True,plot=False)

IA = Dataset(name="IA",save=False, plot=False)
QA = Dataset(name="QA",save=False, plot=False)
SINGLE_SHOT_A = Dataset(name="single_shotA", save=True, plot=False)

IB = Dataset(name="IB",save=False, plot=False)
QB = Dataset(name="QB",save=False, plot=False)
SINGLE_SHOT_B = Dataset(name="single_shotB", save=True, plot=False)

class WignersAB(Experiment):
    """Wigner_function"""

    primary_datasets = ["IA", "QA", "single_shotA",
                        "IB", "QB", "single_shotB",]

    primary_sweeps = ["orens_id"]

    def __init__(self, folder, modes, pulses, sweeps, datasets, **parameters):

        super().__init__(
            folder,
            modes,
            pulses,
            sweeps,
            datasets,
            **parameters,
        )  # Passes other parameters to parent

        # self.orens_points = [[-0.67152985, -0.34296374],
        #                     [0.4261962, 0.29391114],
        #                     [0.97668197, -0.76566442],
        #                     [-0.30305089, 0.2026751],
        #                     [0.03902931, -0.43510274]]

        self.orens_points = [
                            [ 0.21841281, 0.40857803],
                            [ 1.27526808, -0.03944858],
                            [ 0.78701447, 1.30379379],
                            [ -0.24961871, 0.75413147],
                            [ -1.41136609, 0.57889231],
                            [ -0.90260273, 0.21038691],
                            [ -1.08786047, -0.8881262],
                            [ -0.65582081, 1.10398337],
                            [ -0.61667827, -0.46690001],
                            [ 0.24196665, -0.39232866],
                            [ 0.58342168, 0.66363423],
                            [ 0.16148649, -1.47437816],
                            [ -0.46327263, -0.0140931],
                            [ 0.41139432, -0.76836481],
                            [ 0.75615557, 0.13199463]
                            ]


        self.grape_list = [[self.qB_grape_fock0, self.cavB_grape_fock0],
                    [self.qB_grape_fock2, self.cavB_grape_fock2]]
        
        self.pulse_list = [f"self.exchange_pulse_cos2_{d}" for d in range (self.time_start, self.time_stop+self.time_step, self.time_step)]

    def sequence(self):

        disp_I = qm_qua.declare(qm_qua.fixed)
        disp_Q = qm_qua.declare(qm_qua.fixed)
        total_phase_A = qm_qua.declare(qm_qua.fixed)
        total_phase_B = qm_qua.declare(qm_qua.fixed)
        # qm_qua.assign(total_phase_A, 0.25 + qm_qua.Cast.mul_fixed_by_int(self.detuningA * 1e-9, self.drive_length) + self.ramp_phaseA)
        # qm_qua.assign(total_phase_B, 0.25 + qm_qua.Cast.mul_fixed_by_int(self.detuningB * 1e-9, self.drive_length) + self.ramp_phaseB)

        qua.reset_frame(self.cavityA)
        qua.reset_frame(self.qubitA)
        qua.reset_frame(self.cavityB)
        qua.reset_frame(self.qubitB)
        qua.reset_frame(self.drive)
        qua.reset_frame(self.drive_ramp)
        qm_qua.reset_global_phase()
        qua.update_frequency(self.qubitA, self.qubitA.int_freq)
        qua.update_frequency(self.qubitB, self.qubitB.int_freq)
        qua.align()

        with switch_(self.orens_id):
            for i in range(len(self.orens_points)):
                with case_(i):
                    qm_qua.assign(disp_I, self.orens_points[i][0])
                    qm_qua.assign(disp_Q, self.orens_points[i][1])

        with switch_(self.grape_id):
            for j in range(len(self.grape_list)):
                with case_(j):
                    self.qubitA.play(self.qA_grape)
                    self.cavityA.play(self.cavA_grape)
                    self.qubitB.play( self.grape_list[j][0])
                    self.cavityB.play(self.grape_list[j][1])
        qua.align()

        with switch_(self.gate_id):
            for i in range(self.time_start, self.time_stop+self.time_step, self.time_step):
                with qm_qua.case_(i):
                    qm_qua.assign(total_phase_A, 0.25 + qm_qua.Cast.mul_fixed_by_int(self.detuningA * 1e-9, i) + self.ramp_phaseA)
                    qm_qua.assign(total_phase_B, 0.25 + qm_qua.Cast.mul_fixed_by_int(self.detuningB * 1e-9, i) + self.ramp_phaseB)
                    self.drive.play(getattr(self,f"exchange_pulse_cos2_{i}"))
  
        # self.drive_ramp.play(self.exchange_ramp_up)
        # qua.align(self.drive, self.drive_ramp)
        # self.drive.play(self.exchange_constant, duration = self.drive_length/4)
        # qua.wait(self.drive_length-7, self.drive_ramp)
        # self.drive_ramp.play(self.exchange_ramp_down)
        # self.sec_drive.play(self.sec_drive_pulse, duration =  (self.drive_length+400)/4, ampx = 0.01)
        qua.align() 

        # ORENS A
        self.cavityA.play(self.cavA_op, ampx=(disp_I, -disp_Q, disp_Q, disp_I), phase = total_phase_A)  # displacement
        qua.align(self.cavityA, self.qubitA)
        #qua.update_frequency(self.qubitA, 223.76e6) # fock1 frequency
        qua.update_frequency(self.qubitA, 223e6) # fock2 frequency
        self.qubitA.play(self.qA_selective)
        qua.align(self.qubitA, self.qubitA_EF)
        self.qubitA_EF.play(self.qA_EF_pi)  # play pi/2 pulse around X
        qua.align(self.qubitA_EF, self.rrA) 
        self.rrA.measure(self.readout_pulseA, (self.IA, self.QA), demod_type = 'dual')  # measure transmitted signal
        
        # ORENS B
        self.cavityB.play(self.cavB_op, ampx=(disp_I, -disp_Q, disp_Q, disp_I), phase = total_phase_B)  # displacement
        qua.align(self.cavityB, self.qubitB)
        #qua.update_frequency(self.qubitB, 348.29e6) # fock1 frequency
        qua.update_frequency(self.qubitB, 346.096e6) # fock2 frequency
        self.qubitB.play(self.qB_selective)
        qua.align(self.qubitB, self.qubitB_EF)
        self.qubitB_EF.play(self.qB_EF_pi)  # play pi/2 pulse around X
        qua.align(self.qubitB_EF, self.rrB) 
        self.rrB.measure(self.readout_pulseB, (self.IB, self.QB), demod_type = 'dual')  # measure transmitted signal
        
        if self.plot_single_shot:  # assign state to G or E
            qm_qua.assign(self.single_shotA, qm_qua.Cast.to_fixed(self.IA > self.readout_pulseA.threshold),)
            qm_qua.assign(self.single_shotB, qm_qua.Cast.to_fixed(self.IB > self.readout_pulseB.threshold),)

        qua.align()
        qua.wait(self.wait_time)


if __name__ == "__main__":
    """ """
    modes = {
        "cavityA": "cavA",
        "cavityB": "cavB",
        "qubitA": "qA",
        "qubitB": "qB",    
        "qubitA_EF": "qA_EF",
        "qubitB_EF": "qB_EF",    
        "drive": "drive", 
        "drive_ramp": "drive_ramp", 
        "sec_drive":"secondary_drive",
        "rrA": "rrA",
        "rrB": "rrB",
        # "rrC": "rrC",
    }

    pulses = {
        "qA_grape": "qA_grape_fock02",
        "cavA_grape": "cavA_grape_fock02",
        "qB_grape_fock0": "qB_grape_fock0",
        "qB_grape_fock1": "qB_grape_fock1",
        "qB_grape_fock2": "qB_grape_fock2",
        "cavB_grape_fock0": "cavB_grape_fock0",
        "cavB_grape_fock1": "cavB_grape_fock1",
        "cavB_grape_fock2": "cavB_grape_fock2",
        "cavA_op": "cavA_ramp_pulse",
        "cavB_op": "cavB_ramp_pulse",
        # "qubitA_pi2": "qA_gaussian_pi2_pulse",
        # "qubitB_pi2": "qB_gaussian_pi2_pulse",
        #"exchange_ramp_up": "exchange_ramp_up",
        #"exchange_constant": "exchange_pulse",
        #"exchange_ramp_down": "exchange_ramp_down",
        #"sec_drive_pulse": "sec_drive_ramp",
        "qA_selective": "qA_gaussian_very_sel_pi_pulse",
        "qB_selective": "qB_gaussian_very_sel_pi_pulse",
        "qA_EF_pi": "qAEF_EF_gaussian_pi_pulse",
        "qB_EF_pi": "qBEF_gaussian_pi_pulse",
        "readout_pulseA": "rrA_GF_CLEAR_readout_pulse",
        "readout_pulseB": "rrB_GF_CLEAR_readout_pulse",
        # "readout_pulseC": "rrC_readout_pulse"
    }

    time_start = 16
    time_stop = 6000
    time_step = 200

        
    for d in range(time_start, time_stop+time_step, time_step):
        pulses[f"exchange_pulse_cos2_{d}"] = f"exchange_pulse_cos2_{d}"

    parameters = {
        "ramp_phaseA": -0.098, 
        "ramp_phaseB": -0.036, 
        "detuningA": -819.8e3/2-680e3/2+9e3/2-18e3/2, 
        "detuningB": -466e3/2 + 14e3/2 + 7e3/2, 
        "wait_time": 6e6,
        "plot_single_shot": True,
        "time_start":  time_start,
        "time_stop":  time_stop,
        "time_step":  time_step,
    }

    N.num = 100_000


    # LENGTH = Sweep (name="drive_length", dtype=int, units = "ns")
    # LENGTH.start = 16
    # LENGTH.stop = 5200
    # LENGTH.step = 200
    
    ORENS = Sweep(name="orens_id", start=0, stop=14, num = 15, dtype=int, save=True)

    STATES = Sweep(name="grape_id", start=0, stop=1, num = 2, dtype=int, save=True)
    GATES = Sweep(name="gate_id", start=time_start, stop=time_stop, step=time_step, dtype=int, save=True)

    #sweeps = [N, LENGTH, STATES, ORENS]
    sweeps = [N, GATES, STATES, ORENS]

    SINGLE_SHOT_A.plot = True
    SINGLE_SHOT_B.plot = True

    datasets = [IA,QA,SINGLE_SHOT_A,  
                IB,QB,SINGLE_SHOT_B,]

    expt = WignersAB(FOLDER, modes, pulses, sweeps, datasets, **parameters)
    
    expt.run(simulate=False)

