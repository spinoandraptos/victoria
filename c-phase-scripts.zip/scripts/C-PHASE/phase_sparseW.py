from config.experiment_config import FOLDER, N, FREQ, RRB, I, Q, SINGLE_SHOT
from qcore import Experiment, qua, Sweep, Dataset
from qm import qua as qm_qua
from qcore.libs.qua_macros import QuaVariable
import shutil
import os
from datetime import datetime
from scripts.qB_GE_experiments.T2_virtual_detuning_qB import QubitT2
from scripts.qB_GE_experiments.AllXY_qB import ALLXY
from qm.qua import *

# SCREENSHOT FILE 
current_script_path = os.path.realpath(__file__) # Get the path to the current script
script_name = os.path.basename(current_script_path)[:-3] # Get filename only (e.g., 'my_script.py')
date, time = datetime.now().strftime("%Y-%m-%d %H-%M-%S").split()
destination_path = os.path.join(FOLDER + "data/" + str(date) + '/', f"{script_name}_screenhsot_{time}.py") # Define destination path
shutil.copy(current_script_path, destination_path) # Copy the script


IB_AFTER = Dataset(name="IB_after", save=False, plot=False)
QB_AFTER = Dataset(name="QB_after", save=False, plot=False)
SINGLE_SHOT_B_AFTER = Dataset(name="single_shotB_after",save=True,plot=False)

IA_AFTER = Dataset(name="IA_after",save=False,plot=False, )
QA_AFTER = Dataset(name="QA_after",save=False,plot=False, )
SINGLE_SHOT_A_AFTER = Dataset(name="single_shotA_after",save=True,plot=False)

IA = Dataset(name="IA",save=False, plot=False)
QA = Dataset(name="QA",save=False, plot=False)
SINGLE_SHOT_A = Dataset(name="single_shotA", save=True, plot=False)

IB = Dataset(name="IB",save=False, plot=False)
QB = Dataset(name="QB",save=False, plot=False)
SINGLE_SHOT_B = Dataset(name="single_shotB", save=True, plot=False)

IC = Dataset(name="IC",save=False, plot=False)
QC = Dataset(name="QC",save=False, plot=False)
SINGLE_SHOT_C = Dataset(name="single_shotC", save=True, plot=False)

class WignersAB(Experiment):
    """Wigner_function"""

    primary_datasets = ["IA", "QA", "single_shotA",
                        "IB", "QB", "single_shotB",
                        "IC", "QC", "single_shotC",
                        "IA_after", "QA_after", "single_shotA_after",
                        "IB_after", "QB_after", "single_shotB_after",
                        ]

    primary_sweeps = ["gate_id"]

    def __init__(self, folder, modes, pulses, sweeps, datasets, **parameters):

        super().__init__(
            folder,
            modes,
            pulses,
            sweeps,
            datasets,
            **parameters,
        )  # Passes other parameters to parent

        self._gate_list = [
        -0.23147611-4.46301092e-01j, -0.94715811-1.88288489e-01j,
        1.25964143+1.20165020e-03j, -0.33728887+2.34464982e-01j,
        0.64679664-3.26556897e-01j, -0.36765613+9.86028805e-01j,
       -2.00070781+1.05340005e+00j,  1.20291328+2.06819825e-01j,
        0.20164076-1.19496794e-02j,  0.01427361-1.05863997e+00j,
       -0.85478561-1.70145013e+00j,  0.44946502+5.32985404e-01j]

    def sequence(self):
        factorA = qm_qua.declare(qm_qua.fixed)
        factorB = qm_qua.declare(qm_qua.fixed)
        qm_qua.assign(factorA, self.detuningA * 1e-9)  
        qm_qua.assign(factorB, self.detuningB * 1e-9)  

        """QUA sequence that defines this Experiment subclass"""
        qua.reset_frame(self.cavityA)
        qua.reset_phase(self.cavityA)
        qua.reset_frame(self.qubitA)
        qua.reset_phase(self.qubitA)
        qua.reset_frame(self.cavityB)
        qua.reset_phase(self.cavityB)
        qua.reset_frame(self.qubitB)
        qua.reset_phase(self.qubitB)
        qua.reset_frame(self.drive)
        qua.reset_phase(self.drive)

        qm_qua.assign(self.phaseA, qm_qua.Cast.mul_fixed_by_int(factorA, self.drive_length))
        qm_qua.assign(self.phaseB, qm_qua.Cast.mul_fixed_by_int(factorB, self.drive_length))
        total_phaseA = qm_qua.declare(qm_qua.fixed)
        total_phaseB = qm_qua.declare(qm_qua.fixed)
        qm_qua.assign(total_phaseA, self.phaseA + 0.25)
        qm_qua.assign(total_phaseB, self.phaseB + 0.25)

        # GRAPEs
        self.cavityA.play(self.cavA_grape)
        self.qubitA.play(self.qA_grape)
        self.cavityB.play(self.cavB_grape)
        self.qubitB.play(self.qB_grape)

        # qua.align(self.cavityB, self.qubitB, self.rrB, self.cavityA, self.qubitA, self.rrA)

        # self.rrA.measure(self.readout_pulseA, (self.IA_after, self.QA_after), demod_type = 'dual')  # measure transmitted signal
        # self.rrB.measure(self.readout_pulseB, (self.IB_after, self.QB_after), demod_type = 'dual')  # measure transmitted signal

        # if self.plot_single_shot:  # assign state to G or E
        #     qm_qua.assign(self.single_shotA_after, qm_qua.Cast.to_fixed(self.IA_after > self.readout_pulseA.threshold),)
        #     qm_qua.assign(self.single_shotB_after, qm_qua.Cast.to_fixed(self.IB_after > self.readout_pulseB.threshold),)

        with switch_(self.gate_id):
            for i in range(len(self._gate_list)):
                with case_(i):
                    
                    disp_I, disp_Q = (self._gate_list[i]).real, (self._gate_list[i]).imag
                    
                    # qua.wait(2000, self.rrA, self.rrB)
                    # qua.align(self.rrA, self.rrB, self.drive)
                    qua.align()
                    self.drive.play(self.drive_pulse, ampx=2.0, duration = self.drive_length/4)
                    qua.align(self.drive, self.cavityB, self.cavityA) 

                    # WIGNERs
                    self.cavityA.play(self.cavA_op, ampx= (disp_I, disp_Q, -disp_Q, disp_I), phase= total_phaseA)  # displacement
                    qua.align(self.cavityA, self.qubitA)
                    self.qubitA.play(self.qubitA_pi2)  # play pi/2 pulse around X
                    qua.wait(int(self.time_delayA), self.qubitA)  # conditional phase gate on even, odd Fock state
                    self.qubitA.play(self.qubitA_pi2, phase = self.qubit_phase)  # play pi/2 pulse around X

                    self.cavityB.play(self.cavB_op, ampx= (disp_I, disp_Q, -disp_Q, disp_I), phase= total_phaseB)  # displacement
                    qua.align(self.cavityB, self.qubitB)
                    self.qubitB.play(self.qubitB_pi2)  # play pi/2 pulse around X
                    qua.wait(int(self.time_delayB), self.qubitB)  # conditional phase gate on even, odd Fock state
                    self.qubitB.play(self.qubitB_pi2, phase = self.qubit_phase)  # play pi/2 pulse around X

                    qua.align()
                    self.rrA.measure(self.readout_pulseA, (self.IA, self.QA), ampx=self.ro_ampx, demod_type = 'dual')  # measure transmitted signal
                    self.rrB.measure(self.readout_pulseB, (self.IB, self.QB), ampx=self.ro_ampx, demod_type = 'dual')  # measure transmitted signal
                    self.rrC.measure(self.readout_pulseC, (self.IC, self.QC), ampx=self.ro_ampx, demod_type = 'dual')  # measure transmitted signal

        if self.plot_single_shot:  # assign state to G or E
            qm_qua.assign(self.single_shotA, qm_qua.Cast.to_fixed(self.IA > self.readout_pulseA.threshold),)
            qm_qua.assign(self.single_shotB, qm_qua.Cast.to_fixed(self.IB > self.readout_pulseB.threshold),)
            qm_qua.assign(self.single_shotC, qm_qua.Cast.to_fixed(self.IC > self.readout_pulseC.threshold),)

        qua.align()
        qua.wait(self.wait_time)


grape_list = [
("fock0", "fock01"),
("fock1", "fock01"),
("fock2", "fock01"),
("fock01", "fock0"),                            
("fock01", "fock1"),                            
("fock01", "fock2"),
]

# grape_list = [("fock2", "fock01")]


for entry in grape_list:

    qA_grape = "qA_grape_" + entry[0]
    cavA_grape =  "cavA_grape_" + entry[0]
    qB_grape = "qB_grape_"+ entry[1]
    cavB_grape =  "cavB_grape_"+ entry[1]

    if __name__ == "__main__":
        """ """
        modes = {
            "cavityA": "cavA",
            "cavityB": "cavB",
            "qubitA": "qA",
            "qubitB": "qB",    
            "drive": "drive",           
            "rrA": "rrA",
            "rrB": "rrB",
            "rrC": "rrC",
        }

        pulses = {
            "qA_grape": qA_grape,
            "cavA_grape": cavA_grape,
            "qB_grape": qB_grape,
            "cavB_grape": cavB_grape,
            "cavA_op": "cavA_ramp_pulse",
            "cavB_op": "cavB_ramp_pulse",
            "qubitA_pi2": "qA_gaussian_pi2_pulse",
            "qubitB_pi2": "qB_gaussian_pi2_pulse",
            "drive_pulse": "exchange_pulse",
            "readout_pulseA": "rrA_CLEAR_readout_pulse",
            "readout_pulseB": "rrB_GF_CLEAR_readout_pulse",
            "readout_pulseC": "rrC_readout_pulse",
            # "qA_selective": "qA_gaussian_very_sel_pi_pulse",
            # "qB_selective": "qB_gaussian_very_sel_pi_pulse",
            # "qA_unselective": "qA_gaussian_pi_pulse",
            # "qB_unselective": "qB_gaussian_pi_pulse",
        }

        parameters = {
            "detuningA":  -496.5e3, #-466.8e3, 
            "detuningB": 198.3e3, #133.2e3, 
            "phaseA": QuaVariable(value=0.0,dtype=qm_qua.fixed,tag="phaseA",buffer=True,stream=True,),
            "phaseB": QuaVariable(value=0.0,dtype=qm_qua.fixed,tag="phaseB",buffer=True,stream=True,),
            "wait_time": 7e6,
            "ro_ampx": 1,
            "time_delayA": 564,
            "time_delayB": 160, 
            "plot_single_shot": True,
            "qubit_drive_ampx": 1.0,
            # "qubit_phase":0,
        }

        N.num = 1_000

        LENGTH = Sweep (name="drive_length", dtype=int, units = "ns")
        LENGTH.start = 16
        LENGTH.stop = 24_000
        LENGTH.step = 500 ###PREV 2000
        
        GATES = Sweep(name="gate_id", start=0, stop=11, step = 1, dtype=int, save=True)
        
        PARITY = Sweep(name="qubit_phase", start=0, stop=0.5, step=0.5)

        # sweeps = [N, LENGTH, GATES, PARITY]
        sweeps = [N, LENGTH, GATES, PARITY]

        datasets = [IA,  
                    IA_AFTER, 
                    QA, 
                    QA_AFTER, 
                    SINGLE_SHOT_A,  
                    SINGLE_SHOT_A_AFTER,
                    IB,
                    QB,
                    SINGLE_SHOT_B,
                    IB_AFTER, 
                    QB_AFTER, 
                    SINGLE_SHOT_B_AFTER,
                    IC,
                    QC,
                    SINGLE_SHOT_C]

        expt = WignersAB(FOLDER, modes, pulses, sweeps, datasets, **parameters)
        expt.run(simulate=False, filename_suffix=cavA_grape+cavB_grape)

print("DONEEEEEE")