import numpy as np
import os
import h5py
import matplotlib.pyplot as plt
from scipy.optimize import curve_fit

file = r"C:\Users\admin\Desktop\cphase\data\2025-07-24\18-33-35_WignersAB_cavA_grape_fock0cavB_grape_fock01.hdf5"

data =  h5py.File(file, "r")

data_A = np.array(data["single_shotA"])
print(np.shape(data_A))

grape_list = [("fock1", "fock01"),
              ("fock2", "fock01"),
              ("fock01", "fock0"),                            
              ("fock01", "fock1"),                            
              ("fock01", "fock2")]

for entry in grape_list:
    print(entry[0], entry[1])