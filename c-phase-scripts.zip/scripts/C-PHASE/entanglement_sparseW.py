from config.experiment_config import FOLDER, N, FREQ, RRB, I, Q, SINGLE_SHOT
from qcore import Experiment, qua, Sweep, Dataset
from qm import qua as qm_qua
from qcore.libs.qua_macros import QuaVariable
import shutil
import os
from datetime import datetime
from scripts.qB_GE_experiments.T2_virtual_detuning_qB import QubitT2
from scripts.qB_GE_experiments.AllXY_qB import ALLXY
from qm.qua import *

# SCREENSHOT FILE 
# current_script_path = os.path.realpath(__file__) # Get the path to the current script
# script_name = os.path.basename(current_script_path)[:-3] # Get filename only (e.g., 'my_script.py')
# date, time = datetime.now().strftime("%Y-%m-%d %H-%M-%S").split()
# destination_path = os.path.join(FOLDER + "data/" + str(date) + '/', f"{script_name}_screenhsot_{time}.py") # Define destination path
# shutil.copy(current_script_path, destination_path) # Copy the script

SINGLE_SHOT_A = Dataset(
    name="single_shotA",
    save=True,
    plot=False, 
)
SINGLE_SHOT_A_BEFORE = Dataset(
    name="single_shotA_before",
    save=True,
    plot=False, 
)
SINGLE_SHOT_A_AFTER = Dataset(
    name="single_shotA_after",
    save=True,
    plot=False, 
)

SINGLE_SHOT_B = Dataset(
    name="single_shotB",
    save=True,
    plot=False, 
)
SINGLE_SHOT_B_BEFORE = Dataset(
    name="single_shotB_before",
    save=True,
    plot=False, 
)
SINGLE_SHOT_B_AFTER = Dataset(
    name="single_shotB_after",
    save=True,
    plot=False, 
)

IA = Dataset(
    name="IA",
    save=False,
    plot=False, 
)
IA_BEFORE = Dataset(
    name="IA_before",
    save=False,
    plot=False, 
)
IA_AFTER = Dataset(
    name="IA_after",
    save=False,
    plot=False, 
)

QA = Dataset(
    name="QA",
    save=False,
    plot=False, 
)
QA_BEFORE = Dataset(
    name="QA_before",
    save=False,
    plot=False, 
)
QA_AFTER = Dataset(
    name="QA_after",
    save=False,
    plot=False, 
)

IB = Dataset(
    name="IB",
    save=False,
    plot=False, 
)
IB_BEFORE = Dataset(
    name="IB_before",
    save=False,
    plot=False, 
)
IB_AFTER = Dataset(
    name="IB_after",
    save=False,
    plot=False, 
)

QB = Dataset(
    name="QB",
    save=False,
    plot=False, 
)
QB_BEFORE= Dataset(
    name="QB_before",
    save=False,
    plot=False, 
)
QB_AFTER = Dataset(
    name="QB_after",
    save=False,
    plot=False, 
)

class WignersAB(Experiment):
    """Wigner_function"""

    # primary_datasets = ["IA","IA_before", "IA_after", 
    #                     "QA", "QA_before", "QA_after", 
    #                     "single_shotA", "single_shotA_before", "single_shotA_after",
    #                     "IB", "IB_before", "IB_after",
    #                     "QB","QB_before", "QB_after", 
    #                     "single_shotB", "single_shotB_before", "single_shotB_after",
    #                     ]

    primary_datasets = ["IA", "QA", "single_shotA",
                    "IB", "QB", "single_shotB"]

    primary_sweeps = ["gate_id"]

    def __init__(self, folder, modes, pulses, sweeps, datasets, **parameters):

        super().__init__(
            folder,
            modes,
            pulses,
            sweeps,
            datasets,
            **parameters,
        )  # Passes other parameters to parent

        self.wigner_points = [[-0.23916340636121503,
  -0.005759099620915109,
  -0.23916340636121503,
  -0.005759099620915109],
 [-0.23916340636121503,
  -0.005759099620915109,
  0.7527302880248496,
  -0.5929459349336413],
 [-0.23916340636121503,
  -0.005759099620915109,
  -0.6518195898504391,
  -0.9061446383355495],
 [-0.23916340636121503,
  -0.005759099620915109,
  -0.06886481428066807,
  0.5808686209299183],
 [-0.23916340636121503,
  -0.005759099620915109,
  0.34448334860823226,
  0.018346532038072925],
 [-0.23916340636121503,
  -0.005759099620915109,
  -0.04609078813848337,
  -0.5870517136908409],
 [-0.23916340636121503,
  -0.005759099620915109,
  -0.833451025638746,
  0.786695741712128],
 [-0.23916340636121503,
  -0.005759099620915109,
  -0.30428149527314713,
  -1.1962704715014338],
 [-0.23916340636121503,
  -0.005759099620915109,
  -0.3361490495317264,
  1.1559561171943085],
 [-0.23916340636121503,
  -0.005759099620915109,
  0.7560176958354424,
  0.6034859693614035],
 [-0.23916340636121503,
  -0.005759099620915109,
  -0.7767249936491234,
  -0.023992106336685064],
 [-0.23916340636121503,
  -0.005759099620915109,
  -1.4894295274088054,
  -0.29593700218561586],
 [0.7527302880248496,
  -0.5929459349336413,
  -0.23916340636121503,
  -0.005759099620915109],
 [0.7527302880248496,
  -0.5929459349336413,
  0.7527302880248496,
  -0.5929459349336413],
 [0.7527302880248496,
  -0.5929459349336413,
  -0.6518195898504391,
  -0.9061446383355495],
 [0.7527302880248496,
  -0.5929459349336413,
  -0.06886481428066807,
  0.5808686209299183],
 [0.7527302880248496,
  -0.5929459349336413,
  0.34448334860823226,
  0.018346532038072925],
 [0.7527302880248496,
  -0.5929459349336413,
  -0.04609078813848337,
  -0.5870517136908409],
 [0.7527302880248496,
  -0.5929459349336413,
  -0.833451025638746,
  0.786695741712128],
 [0.7527302880248496,
  -0.5929459349336413,
  -0.30428149527314713,
  -1.1962704715014338],
 [0.7527302880248496,
  -0.5929459349336413,
  -0.3361490495317264,
  1.1559561171943085],
 [0.7527302880248496,
  -0.5929459349336413,
  0.7560176958354424,
  0.6034859693614035],
 [0.7527302880248496,
  -0.5929459349336413,
  -0.7767249936491234,
  -0.023992106336685064],
 [0.7527302880248496,
  -0.5929459349336413,
  -1.4894295274088054,
  -0.29593700218561586],
 [-0.6518195898504391,
  -0.9061446383355495,
  -0.23916340636121503,
  -0.005759099620915109],
 [-0.6518195898504391,
  -0.9061446383355495,
  0.7527302880248496,
  -0.5929459349336413],
 [-0.6518195898504391,
  -0.9061446383355495,
  -0.6518195898504391,
  -0.9061446383355495],
 [-0.6518195898504391,
  -0.9061446383355495,
  -0.06886481428066807,
  0.5808686209299183],
 [-0.6518195898504391,
  -0.9061446383355495,
  0.34448334860823226,
  0.018346532038072925],
 [-0.6518195898504391,
  -0.9061446383355495,
  -0.04609078813848337,
  -0.5870517136908409],
 [-0.6518195898504391,
  -0.9061446383355495,
  -0.833451025638746,
  0.786695741712128],
 [-0.6518195898504391,
  -0.9061446383355495,
  -0.30428149527314713,
  -1.1962704715014338],
 [-0.6518195898504391,
  -0.9061446383355495,
  -0.3361490495317264,
  1.1559561171943085],
 [-0.6518195898504391,
  -0.9061446383355495,
  0.7560176958354424,
  0.6034859693614035],
 [-0.6518195898504391,
  -0.9061446383355495,
  -0.7767249936491234,
  -0.023992106336685064],
 [-0.6518195898504391,
  -0.9061446383355495,
  -1.4894295274088054,
  -0.29593700218561586],
 [-0.06886481428066807,
  0.5808686209299183,
  -0.23916340636121503,
  -0.005759099620915109],
 [-0.06886481428066807,
  0.5808686209299183,
  0.7527302880248496,
  -0.5929459349336413],
 [-0.06886481428066807,
  0.5808686209299183,
  -0.6518195898504391,
  -0.9061446383355495],
 [-0.06886481428066807,
  0.5808686209299183,
  -0.06886481428066807,
  0.5808686209299183],
 [-0.06886481428066807,
  0.5808686209299183,
  0.34448334860823226,
  0.018346532038072925],
 [-0.06886481428066807,
  0.5808686209299183,
  -0.04609078813848337,
  -0.5870517136908409],
 [-0.06886481428066807,
  0.5808686209299183,
  -0.833451025638746,
  0.786695741712128],
 [-0.06886481428066807,
  0.5808686209299183,
  -0.30428149527314713,
  -1.1962704715014338],
 [-0.06886481428066807,
  0.5808686209299183,
  -0.3361490495317264,
  1.1559561171943085],
 [-0.06886481428066807,
  0.5808686209299183,
  0.7560176958354424,
  0.6034859693614035],
 [-0.06886481428066807,
  0.5808686209299183,
  -0.7767249936491234,
  -0.023992106336685064],
 [-0.06886481428066807,
  0.5808686209299183,
  -1.4894295274088054,
  -0.29593700218561586],
 [0.34448334860823226,
  0.018346532038072925,
  -0.23916340636121503,
  -0.005759099620915109],
 [0.34448334860823226,
  0.018346532038072925,
  0.7527302880248496,
  -0.5929459349336413],
 [0.34448334860823226,
  0.018346532038072925,
  -0.6518195898504391,
  -0.9061446383355495],
 [0.34448334860823226,
  0.018346532038072925,
  -0.06886481428066807,
  0.5808686209299183],
 [0.34448334860823226,
  0.018346532038072925,
  0.34448334860823226,
  0.018346532038072925],
 [0.34448334860823226,
  0.018346532038072925,
  -0.04609078813848337,
  -0.5870517136908409],
 [0.34448334860823226,
  0.018346532038072925,
  -0.833451025638746,
  0.786695741712128],
 [0.34448334860823226,
  0.018346532038072925,
  -0.30428149527314713,
  -1.1962704715014338],
 [0.34448334860823226,
  0.018346532038072925,
  -0.3361490495317264,
  1.1559561171943085],
 [0.34448334860823226,
  0.018346532038072925,
  0.7560176958354424,
  0.6034859693614035],
 [0.34448334860823226,
  0.018346532038072925,
  -0.7767249936491234,
  -0.023992106336685064],
 [0.34448334860823226,
  0.018346532038072925,
  -1.4894295274088054,
  -0.29593700218561586],
 [-0.04609078813848337,
  -0.5870517136908409,
  -0.23916340636121503,
  -0.005759099620915109],
 [-0.04609078813848337,
  -0.5870517136908409,
  0.7527302880248496,
  -0.5929459349336413],
 [-0.04609078813848337,
  -0.5870517136908409,
  -0.6518195898504391,
  -0.9061446383355495],
 [-0.04609078813848337,
  -0.5870517136908409,
  -0.06886481428066807,
  0.5808686209299183],
 [-0.04609078813848337,
  -0.5870517136908409,
  0.34448334860823226,
  0.018346532038072925],
 [-0.04609078813848337,
  -0.5870517136908409,
  -0.04609078813848337,
  -0.5870517136908409],
 [-0.04609078813848337,
  -0.5870517136908409,
  -0.833451025638746,
  0.786695741712128],
 [-0.04609078813848337,
  -0.5870517136908409,
  -0.30428149527314713,
  -1.1962704715014338],
 [-0.04609078813848337,
  -0.5870517136908409,
  -0.3361490495317264,
  1.1559561171943085],
 [-0.04609078813848337,
  -0.5870517136908409,
  0.7560176958354424,
  0.6034859693614035],
 [-0.04609078813848337,
  -0.5870517136908409,
  -0.7767249936491234,
  -0.023992106336685064],
 [-0.04609078813848337,
  -0.5870517136908409,
  -1.4894295274088054,
  -0.29593700218561586],
 [-0.833451025638746,
  0.786695741712128,
  -0.23916340636121503,
  -0.005759099620915109],
 [-0.833451025638746,
  0.786695741712128,
  0.7527302880248496,
  -0.5929459349336413],
 [-0.833451025638746,
  0.786695741712128,
  -0.6518195898504391,
  -0.9061446383355495],
 [-0.833451025638746,
  0.786695741712128,
  -0.06886481428066807,
  0.5808686209299183],
 [-0.833451025638746,
  0.786695741712128,
  0.34448334860823226,
  0.018346532038072925],
 [-0.833451025638746,
  0.786695741712128,
  -0.04609078813848337,
  -0.5870517136908409],
 [-0.833451025638746,
  0.786695741712128,
  -0.833451025638746,
  0.786695741712128],
 [-0.833451025638746,
  0.786695741712128,
  -0.30428149527314713,
  -1.1962704715014338],
 [-0.833451025638746,
  0.786695741712128,
  -0.3361490495317264,
  1.1559561171943085],
 [-0.833451025638746,
  0.786695741712128,
  0.7560176958354424,
  0.6034859693614035],
 [-0.833451025638746,
  0.786695741712128,
  -0.7767249936491234,
  -0.023992106336685064],
 [-0.833451025638746,
  0.786695741712128,
  -1.4894295274088054,
  -0.29593700218561586],
 [-0.30428149527314713,
  -1.1962704715014338,
  -0.23916340636121503,
  -0.005759099620915109],
 [-0.30428149527314713,
  -1.1962704715014338,
  0.7527302880248496,
  -0.5929459349336413],
 [-0.30428149527314713,
  -1.1962704715014338,
  -0.6518195898504391,
  -0.9061446383355495],
 [-0.30428149527314713,
  -1.1962704715014338,
  -0.06886481428066807,
  0.5808686209299183],
 [-0.30428149527314713,
  -1.1962704715014338,
  0.34448334860823226,
  0.018346532038072925],
 [-0.30428149527314713,
  -1.1962704715014338,
  -0.04609078813848337,
  -0.5870517136908409],
 [-0.30428149527314713,
  -1.1962704715014338,
  -0.833451025638746,
  0.786695741712128],
 [-0.30428149527314713,
  -1.1962704715014338,
  -0.30428149527314713,
  -1.1962704715014338],
 [-0.30428149527314713,
  -1.1962704715014338,
  -0.3361490495317264,
  1.1559561171943085],
 [-0.30428149527314713,
  -1.1962704715014338,
  0.7560176958354424,
  0.6034859693614035],
 [-0.30428149527314713,
  -1.1962704715014338,
  -0.7767249936491234,
  -0.023992106336685064],
 [-0.30428149527314713,
  -1.1962704715014338,
  -1.4894295274088054,
  -0.29593700218561586],
 [-0.3361490495317264,
  1.1559561171943085,
  -0.23916340636121503,
  -0.005759099620915109],
 [-0.3361490495317264,
  1.1559561171943085,
  0.7527302880248496,
  -0.5929459349336413],
 [-0.3361490495317264,
  1.1559561171943085,
  -0.6518195898504391,
  -0.9061446383355495],
 [-0.3361490495317264,
  1.1559561171943085,
  -0.06886481428066807,
  0.5808686209299183],
 [-0.3361490495317264,
  1.1559561171943085,
  0.34448334860823226,
  0.018346532038072925],
 [-0.3361490495317264,
  1.1559561171943085,
  -0.04609078813848337,
  -0.5870517136908409],
 [-0.3361490495317264,
  1.1559561171943085,
  -0.833451025638746,
  0.786695741712128],
 [-0.3361490495317264,
  1.1559561171943085,
  -0.30428149527314713,
  -1.1962704715014338],
 [-0.3361490495317264,
  1.1559561171943085,
  -0.3361490495317264,
  1.1559561171943085],
 [-0.3361490495317264,
  1.1559561171943085,
  0.7560176958354424,
  0.6034859693614035],
 [-0.3361490495317264,
  1.1559561171943085,
  -0.7767249936491234,
  -0.023992106336685064],
 [-0.3361490495317264,
  1.1559561171943085,
  -1.4894295274088054,
  -0.29593700218561586],
 [0.7560176958354424,
  0.6034859693614035,
  -0.23916340636121503,
  -0.005759099620915109],
 [0.7560176958354424,
  0.6034859693614035,
  0.7527302880248496,
  -0.5929459349336413],
 [0.7560176958354424,
  0.6034859693614035,
  -0.6518195898504391,
  -0.9061446383355495],
 [0.7560176958354424,
  0.6034859693614035,
  -0.06886481428066807,
  0.5808686209299183],
 [0.7560176958354424,
  0.6034859693614035,
  0.34448334860823226,
  0.018346532038072925],
 [0.7560176958354424,
  0.6034859693614035,
  -0.04609078813848337,
  -0.5870517136908409],
 [0.7560176958354424,
  0.6034859693614035,
  -0.833451025638746,
  0.786695741712128],
 [0.7560176958354424,
  0.6034859693614035,
  -0.30428149527314713,
  -1.1962704715014338],
 [0.7560176958354424,
  0.6034859693614035,
  -0.3361490495317264,
  1.1559561171943085],
 [0.7560176958354424,
  0.6034859693614035,
  0.7560176958354424,
  0.6034859693614035],
 [0.7560176958354424,
  0.6034859693614035,
  -0.7767249936491234,
  -0.023992106336685064],
 [0.7560176958354424,
  0.6034859693614035,
  -1.4894295274088054,
  -0.29593700218561586],
 [-0.7767249936491234,
  -0.023992106336685064,
  -0.23916340636121503,
  -0.005759099620915109],
 [-0.7767249936491234,
  -0.023992106336685064,
  0.7527302880248496,
  -0.5929459349336413],
 [-0.7767249936491234,
  -0.023992106336685064,
  -0.6518195898504391,
  -0.9061446383355495],
 [-0.7767249936491234,
  -0.023992106336685064,
  -0.06886481428066807,
  0.5808686209299183],
 [-0.7767249936491234,
  -0.023992106336685064,
  0.34448334860823226,
  0.018346532038072925],
 [-0.7767249936491234,
  -0.023992106336685064,
  -0.04609078813848337,
  -0.5870517136908409],
 [-0.7767249936491234,
  -0.023992106336685064,
  -0.833451025638746,
  0.786695741712128],
 [-0.7767249936491234,
  -0.023992106336685064,
  -0.30428149527314713,
  -1.1962704715014338],
 [-0.7767249936491234,
  -0.023992106336685064,
  -0.3361490495317264,
  1.1559561171943085],
 [-0.7767249936491234,
  -0.023992106336685064,
  0.7560176958354424,
  0.6034859693614035],
 [-0.7767249936491234,
  -0.023992106336685064,
  -0.7767249936491234,
  -0.023992106336685064],
 [-0.7767249936491234,
  -0.023992106336685064,
  -1.4894295274088054,
  -0.29593700218561586],
 [-1.4894295274088054,
  -0.29593700218561586,
  -0.23916340636121503,
  -0.005759099620915109],
 [-1.4894295274088054,
  -0.29593700218561586,
  0.7527302880248496,
  -0.5929459349336413],
 [-1.4894295274088054,
  -0.29593700218561586,
  -0.6518195898504391,
  -0.9061446383355495],
 [-1.4894295274088054,
  -0.29593700218561586,
  -0.06886481428066807,
  0.5808686209299183],
 [-1.4894295274088054,
  -0.29593700218561586,
  0.34448334860823226,
  0.018346532038072925],
 [-1.4894295274088054,
  -0.29593700218561586,
  -0.04609078813848337,
  -0.5870517136908409],
 [-1.4894295274088054,
  -0.29593700218561586,
  -0.833451025638746,
  0.786695741712128],
 [-1.4894295274088054,
  -0.29593700218561586,
  -0.30428149527314713,
  -1.1962704715014338],
 [-1.4894295274088054,
  -0.29593700218561586,
  -0.3361490495317264,
  1.1559561171943085],
 [-1.4894295274088054,
  -0.29593700218561586,
  0.7560176958354424,
  0.6034859693614035],
 [-1.4894295274088054,
  -0.29593700218561586,
  -0.7767249936491234,
  -0.023992106336685064],
 [-1.4894295274088054,
  -0.29593700218561586,
  -1.4894295274088054,
  -0.29593700218561586]]

    def sequence(self):
        factorA = qm_qua.declare(qm_qua.fixed)
        factorB = qm_qua.declare(qm_qua.fixed)
        qm_qua.assign(factorA, self.detuningA * 1e-9)  
        qm_qua.assign(factorB, self.detuningB * 1e-9)  

        """QUA sequence that defines this Experiment subclass"""
        qua.reset_frame(self.cavityA)
        qua.reset_phase(self.cavityA)
        qua.reset_frame(self.qubitA)
        qua.reset_phase(self.qubitA)
        qua.reset_frame(self.cavityB)
        qua.reset_phase(self.cavityB)
        qua.reset_frame(self.qubitB)
        qua.reset_phase(self.qubitB)
        qua.reset_frame(self.drive)
        qua.reset_phase(self.drive)

        qm_qua.assign(self.phaseA, qm_qua.Cast.mul_fixed_by_int(factorA, self.drive_length))
        qm_qua.assign(self.phaseB, qm_qua.Cast.mul_fixed_by_int(factorB, self.drive_length))
        total_phaseA = qm_qua.declare(qm_qua.fixed)
        total_phaseB = qm_qua.declare(qm_qua.fixed)
        qm_qua.assign(total_phaseA, self.phaseA + 0.25)
        qm_qua.assign(total_phaseB, self.phaseB + 0.25)

        dispA_I = qm_qua.declare(qm_qua.fixed)
        dispA_Q = qm_qua.declare(qm_qua.fixed)
        dispB_I = qm_qua.declare(qm_qua.fixed)
        dispB_Q = qm_qua.declare(qm_qua.fixed)

        #qua.update_frequency(self.qubitA, self.qubitA.int_freq)

        with switch_(self.gate_id):
            for i in range(len(self.wigner_points)):
                with case_(i):
                    qm_qua.assign(dispA_I, self.wigner_points[i][0])
                    qm_qua.assign(dispA_Q, self.wigner_points[i][1])
                    qm_qua.assign(dispB_I, self.wigner_points[i][2])
                    qm_qua.assign(dispB_Q, self.wigner_points[i][3])


        # # INITIALIZE A 
        # self.qubitA.play(self.qA_selective)
        # self.qubitA.play(self.qA_unselective)
        # qua.update_frequency(self.qubitA, self.qubitA_EF_freq)
        # self.qubitA.play(self.qubitA_EF_pi)  # play pi/2 pulse around X
        # qua.align(self.qubitA, self.rrA)    
        # self.rrA.measure(self.readout_pulseA, (self.IA_before, self.QA_before), ampx=self.ro_ampx, demod_type = 'dual')  # measure transmitted signal

        # # INITIALIZE B
        # self.qubitB.play(self.qB_selective)
        # self.qubitB.play(self.qB_unselective)
        # qua.align(self.qubitB, self.qubitB_EF)  
        # self.qubitB_EF.play(self.qubitB_EF_pi)  # play pi/2 pulse around X
        # qua.align(self.qubitB_EF, self.rrB)  
        # self.rrB.measure(self.readout_pulseB, (self.IB_before, self.QB_before), ampx=self.ro_ampx, demod_type = 'dual')  # measure transmitted signal
        
        # if self.plot_single_shot:  # assign state to G or E
        #         qm_qua.assign(self.single_shotA_before, qm_qua.Cast.to_fixed(self.IA_before > self.readout_pulseA.threshold),)
        #         qm_qua.assign(self.single_shotB_before, qm_qua.Cast.to_fixed(self.IB_before > self.readout_pulseB.threshold),)


        # qua.wait(2000, self.rrA, self.rrB)
        #qua.update_frequency(self.qubitA, self.qubitA.int_freq)
        qua.align()

        # GRAPE A and B
        self.cavityA.play(self.cavA_grape)
        self.qubitA.play(self.qA_grape)
        self.cavityB.play(self.cavB_grape)
        self.qubitB.play(self.qB_grape)
        qua.align()

        self.drive.play(self.drive_pulse, ampx = 2.0, duration = self.drive_length / 4)
        qua.align()

        self.cavityA.play(self.cavA_op, ampx=(dispA_I, -dispA_Q, dispA_Q, dispA_I), phase= total_phaseA)  # displacement
        qua.align(self.cavityA, self.qubitA)
        self.qubitA.play(self.qubitA_pi2)  # play pi/2 pulse around X
        qua.wait(int(self.time_delayA), self.qubitA)  # conditional phase gate on even, odd Fock state
        self.qubitA.play(self.qubitA_pi2, phase = self.qb_phase)  # play pi/2 pulse around X
        #qua.update_frequency(self.qubitA,  self.qubitA_EF_freq)
        #self.qubitA.play(self.qubitA_EF_pi)  # play pi/2 pulse around X
        qua.align(self.qubitA, self.rrA) 
        self.rrA.measure(self.readout_pulseA, (self.IA, self.QA), ampx=self.ro_ampx, demod_type = 'dual')  # measure transmitted signal
        
        # WIGNER B
        self.cavityB.play(self.cavB_op, ampx=(dispB_I, -dispB_Q, dispB_Q, dispB_I), phase= total_phaseB)  # displacement
        qua.align(self.cavityB, self.qubitB)
        self.qubitB.play(self.qubitB_pi2)  # play pi/2 pulse around X
        qua.wait(int(self.time_delayB), self.qubitB)  # conditional phase gate on even, odd Fock state
        self.qubitB.play(self.qubitB_pi2, phase = self.qb_phase)  # play pi/2 pulse around X
        qua.align(self.qubitB, self.qubitB_EF)
        self.qubitB_EF.play(self.qubitB_EF_pi)  # play pi/2 pulse around X
        qua.align(self.qubitB_EF, self.rrB)  
        self.rrB.measure(self.readout_pulseB, (self.IB, self.QB), ampx=self.ro_ampx, demod_type = 'dual')  # measure transmitted signal
                    
        if self.plot_single_shot:  # assign state to G or E
            qm_qua.assign(self.single_shotA, qm_qua.Cast.to_fixed(self.IA > self.readout_pulseA.threshold))
            qm_qua.assign(self.single_shotB, qm_qua.Cast.to_fixed(self.IB > self.readout_pulseB.threshold))

        qua.align()
        qua.wait(self.wait_time)



grape_list_A = ["fock01"]
grape_list_B = ["fock01_new"]

for i in range (len(grape_list_A)):
    qA_grape = "qA_grape_" + grape_list_A[i]
    cavA_grape =  "cavA_grape_" + grape_list_A[i]
    for j in range(len(grape_list_B)):
        qB_grape = "qB_grape_" + grape_list_B[j]
        cavB_grape =  "cavB_grape_" + grape_list_B[j] 
        print(f"Starting {grape_list_A[i]}_A x {grape_list_B[j]}_B experiment")

        if __name__ == "__main__":
            """ """

            modes = {
                "cavityA": "cavA",
                "cavityB": "cavB",
                "qubitA": "qA",
                # "qubitA_EF":"qA_EF",
                "qubitB": "qB", 
                "qubitB_EF":"qB_EF",
                "drive": "drive",           
                "rrA": "rrA",
                "rrB": "rrB"
            }

            pulses = {
                "qA_grape": qA_grape,
                "cavA_grape": cavA_grape,
                "qB_grape": qB_grape,
                "cavB_grape": cavB_grape,
                "cavA_op": "cavA_ramp_pulse",
                "cavB_op": "cavB_ramp_pulse",
                "qubitA_pi2": "qA_gaussian_pi2_pulse",
                "qubitB_pi2": "qB_gaussian_pi2_pulse",
                "drive_pulse": "exchange_pulse",
                "readout_pulseA": "rrA_readout_pulse",
                "readout_pulseB": "rrB_GF_CLEAR_readout_pulse",
                "qA_selective": "qA_gaussian_very_sel_pi_pulse",
                "qB_selective": "qB_gaussian_very_sel_pi_pulse",
                "qubitA_EF_pi": "qA_EF_gaussian_pi_pulse",
                "qubitB_EF_pi": "qBEF_gaussian_pi_pulse",
                "qA_unselective": "qA_gaussian_pi_pulse",
                "qB_unselective": "qB_gaussian_pi_pulse",
            }

            ############################## CONTROL PARAMETERS ##################################
            parameters = {
                "detuningA": -541.6e3, 
                "detuningB": -1.248e6 - 20e3, 
                "phaseA": QuaVariable(value=0.0,dtype=qm_qua.fixed,tag="phaseA",buffer=True,stream=True,),
                "phaseB": QuaVariable(value=0.0,dtype=qm_qua.fixed,tag="phaseB",buffer=True,stream=True,),
                "wait_time": 6e6,
                "ro_ampx": 1,
                "time_delayA": 520,
                "time_delayB": 156, 
                "plot_single_shot": True,
                "qubit_drive_ampx": 1.0,
                #"qubitA_EF_freq": 133.62e6,
                #"drive_length":0,
            }

            N.num = 5000



            LENGTH = Sweep (name="drive_length", dtype=int, units = "ns")
            LENGTH.start = 2800
            LENGTH.stop = 3100
            LENGTH.step = 30 ###PREV 2000

            PARITY  = Sweep(name="qb_phase", start=0, stop=0.5, num = 2, dtype=float, save=True)

            GATES = Sweep(name="gate_id", start=0, stop=143, num = 144, dtype=int, save=True)
        
            sweeps = [N, LENGTH, PARITY, GATES]

            #sweeps = [N, PARITY, GATES]

            SINGLE_SHOT_A.plot = True
            SINGLE_SHOT_B.plot = True

            # SINGLE_SHOT_A.plot_args["plot_type"] = "image"
            # SINGLE_SHOT_B.plot_args["plot_type"] = "image"

            # datasets = [IA, IA_BEFORE, IA_AFTER, 
            #             QA, QA_BEFORE, QA_AFTER, 
            #             SINGLE_SHOT_A, SINGLE_SHOT_A_BEFORE, SINGLE_SHOT_A_AFTER,
            #             IB, IB_BEFORE, IB_AFTER, 
            #             QB, QB_BEFORE, QB_AFTER, 
            #             SINGLE_SHOT_B, SINGLE_SHOT_B_BEFORE, SINGLE_SHOT_B_AFTER,
            #             ]

            
            datasets = [IA, QA, SINGLE_SHOT_A,
                        IB, QB, SINGLE_SHOT_B]

            expt = WignersAB(FOLDER, modes, pulses, sweeps, datasets, **parameters)
            expt.run(simulate=False, filename_suffix=cavA_grape + cavB_grape)