from config.experiment_config import FOLDER, N, I, Q, MAG, PHASE, RRC, SINGLE_SHOT
from qcore import Experiment, qua, Sweep
from qm import qua as qm_qua
from qcore.libs.qua_macros import QuaVariable


class qA_heating(Experiment):
    """qA heating due to qC drive"""

    primary_datasets = ["I", "Q", "single_shot"]

    primary_sweeps = ["time_delay"]


    def sequence(self):
        """QUA sequence that defines this Experiment subclass"""
        qua.align()

        # Prepare initial state (|0> - |1>)/sqrt(2)
        # self.cavity.play(self.cavity_grape)
        # self.qubit.play(self.qubit_grape)

        # qua.align(self.drive, self.qubit, self.drive)

        self.drive.play(self.drive_pulse, ampx = 2.0, duration = self.time_delay/4)
        qua.align(self.drive, self.qubitEF)
        
        self.qubitEF.play(self.qubitEF_pi)  # play selective qubit pulse
        qua.align()

        self.resonator.measure(self.readout_pulse, (self.I, self.Q), ampx=self.ro_ampx, demod_type="dual")
        qua.align()
        qua.wait(self.wait_time)
        if self.plot_single_shot:  # assign state to G or E
            qm_qua.assign(self.single_shot, qm_qua.Cast.to_fixed(self.I > self.readout_pulse.threshold),)


if __name__ == "__main__":
    """ """

    modes = {
        "cavity": "cavA",
        "qubit": "qA",
        "qubitEF": "qA_EF",
        "resonator": "rrA",
        "drive":"drive",
    }

    pulses = {
        "qubit_grape": "qA_grape_fock01",
        "cavity_grape": "cavA_grape_fock01",
        "qubitEF_pi": "qAEF_EF_gaussian_pi_pulse",
        "coherent1_pulse": "cavA_ramp_pulse",
        "qubit_sel_pi": "qA_gaussian_very_sel_pi_pulse",
        "readout_pulse": "rrA_GF_CLEAR_readout_pulse", 
        "drive_pulse": "exchange_pulse",

    }

    parameters = {
        "wait_time": 5e5,
        "ro_ampx": 1,
        "plot_single_shot": True,
    }


    N.num = 5000

    DEL = Sweep(name="time_delay", start=16, stop=400_000, step=400, dtype=int)
    sweeps = [N, DEL]

    # I.fitfn, SINGLE_SHOT.fitfn, Q.fitfn = "exp_decay_sine", "exp_decay_sine", "exp_decay_sine"
    PHASE.datafn_args = {"delay": 2.792e-7, "freq": RRC.int_freq}
    Q.plot, MAG.plot = False, False
    SINGLE_SHOT.plot_args = {"plot_err": False}
    I.plot_args = {"plot_err": False}
    # SINGLE_SHOT.plot = False
    datasets = [I, Q, SINGLE_SHOT]

    expt = qA_heating(FOLDER, modes, pulses, sweeps, datasets, **parameters)
    expt.run(simulate=False)
