import sys
from config.experiment_config import FOLDER, N, FREQ, I, Q, MAG, PHASE, RRC, SINGLE_SHOT
from qm import qua as qm_qua
from qcore import Experiment, qua, Sweep, Dataset
import shutil
import os
from datetime import datetime

# SCREENSHOT FILE 
current_script_path = os.path.realpath(__file__) # Get the path to the current script
script_name = os.path.basename(current_script_path)[:-3] # Get filename only (e.g., 'my_script.py')
date, time = datetime.now().strftime("%Y-%m-%d %H-%M-%S").split()
destination_path = os.path.join(FOLDER + "data/" + str(date) + '/', f"{script_name}_screenhsot_{time}.py") # Define destination path
shutil.copy(current_script_path, destination_path) # Copy the script



SINGLE_SHOT_A_pre = Dataset(
    name="single_shotApre",
    save=True,
    plot=False, 
)

SINGLE_SHOT_A = Dataset(
    name="single_shotA",
    save=True,
    plot=False, 
)

SINGLE_SHOT_B = Dataset(
    name="single_shotB",
    save=True,
    plot=False, 
)

SINGLE_SHOT_C = Dataset(
    name="single_shotC",
    save=True,
    plot=True, 
)

IApre = Dataset(
    name="IApre",
    save=False,
    plot=False,
    # fitfn="exp_decay",
)

QApre = Dataset(
    name="QApre",
    save=False,
    plot=False,
)

IA = Dataset(
    name="IA",
    save=False,
    plot=False,
)

QA= Dataset(
    name="QA",
    save=False,
    plot=False,
)

IB = Dataset(
    name="IB",
    save=False,
    plot=False,
)

QB = Dataset(
    name="QB",
    save=False,
    plot=False,
)

IC = Dataset(
    name="IC",
    save=False,
    plot=False,
)

QC= Dataset(
    name="QC",
    save=False,
    plot=False,
)


class ResonantExchange1D(Experiment):
    """Resonant exchange"""

    primary_datasets = ["IA", "QA", "single_shotA"]

    primary_sweeps = ["gate_id"]
    def __init__(self, folder, modes, pulses, sweeps, datasets, **parameters):

        super().__init__(
            folder,
            modes,
            pulses,
            sweeps,
            datasets,
            **parameters,
        )  # Passes other parameters to parent

        self.pulse_list = [f"self.exchange_pulse_{d}" for d in range (20, 1020, 20)]
        
    
    def sequence(self):
        """QUA sequence that defines this Experiment subclass"""
        
        qua.reset_frame(self.cavB)
        qua.reset_frame(self.drive)
        qua.reset_frame(self.qC)
        qua.reset_frame(self.qA)
        qua.align()

        # self.cavB.play(self.cavityB_grape)
        # self.qB.play(self.qubitB_grape)
        self.cavA.play(self.cavityA_grape)
        self.qA.play(self.qubitA_grape)
        qua.align()  
              
        qua.update_frequency(self.drive, 114.2e6)

        with qm_qua.switch_(self.gate_id):
            for i in range(20,1020,20):
                with qm_qua.case_(i):
                    self.drive.play(getattr(self,f"exchange_pulse_{i}"), ampx = 2.0)
        
        qua.align()
        # qua.update_frequency(self.qA, 350.71e6)
        self.qA.play(self.qA_pulse)
        qua.align(self.qubitEF, self.qA)
        self.qubitEF.play(self.qubitEF_pi)
        qua.align(self.qubitEF, self.rrA)
        self.rrA.measure(self.readout_pulseA, (self.IA, self.QA), ampx=self.ro_ampx, demod_type="dual")

        if self.plot_single_shot:  # assign state to G or E
            qm_qua.assign(self.single_shotA, qm_qua.Cast.to_fixed(self.IA > self.readout_pulseA.threshold),)

        qua.align()
        qua.wait(self.wait_time)

if __name__ == "__main__":
    """ """

    modes = {"qA": "qA",
             "qB": "qB",
             "qB_EF": "qB_EF",
             "qC": "qC",
             "drive": "drive",
             "rrA": "rrA",
             "qubitEF": "qA_EF",
             "rrB": "rrB",
             "rrC": "rrC",
             "cavA": "cavA",
             "cavB": "cavB"
             }

    pulses = {
        "qubitA_grape": "qA_grape_fock1",
        "cavityA_grape": "cavA_grape_fock1",
        "qubitB_grape": "qB_grape_fock1",
        "cavityB_grape": "cavB_grape_fock1",
        "qA_pulse": "qA_gaussian_very_sel_pi_pulse",
        "qB_pulse": "qB_gaussian_pi_pulse",
        "qC_pulse": "qC_gaussian_pi_pulse",
        "qubit_spec_pulse": "qC_gaussian_sel_pi_pulse",
        # "qB_pulse": "qB_gaussian_pi_pulse",
        # "qB_pulse": "qB_gaussian_pi_pulse",
        #"readoutB_pulse": "rrB_GF_CLEAR_readout_pulse",
        "readoutB_pulse": "rrB_readout_pulse",
        "readoutC_pulse": "rrC_readout_pulse",
        "readout_pulseA": "rrA_GF_CLEAR_readout_pulse", 
        "qubitEF_pi": "qAEF_EF_gaussian_pi_pulse",        
        "qB_EF_pi": "qBEF_gaussian_pi_pulse",
    }

    for d in range(20,1020,20):
        pulses[f"exchange_pulse_{d}"] = f"exchange_pulse_{d}"
                  
    parameters = {
        "wait_time": 5e6,
        "ro_ampx": 1,
        "plot_single_shot": True,
        # "drive_ampx": 1.6,
    }

    N.num = 50000
    GATES = Sweep(name="gate_id", start=20, stop=1000, step=20, dtype=int, save=True) # (0, 1, ..., 19, 20) 
    sweeps = [N, GATES]

    IA.plot = True
    QA.plot = True
    SINGLE_SHOT_A.plot = True
    SINGLE_SHOT_A.fitfn = "exp_decay_sine"
    datasets = [IA, QA, SINGLE_SHOT_A]

    expt = ResonantExchange1D(FOLDER, modes, pulses, sweeps, datasets, **parameters)
    expt.run(simulate=False)
