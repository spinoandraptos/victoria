import sys
from config.experiment_config import FOLDER, N, FREQ, I, Q, MAG, PHASE, RRC, SINGLE_SHOT
from qm import qua as qm_qua
from qm.qua import for_, for_each_, declare, assign
from qcore import Experiment, qua, Sweep, Dataset
import shutil
import os
from datetime import datetime

# SCREENSHOT FILE 
# current_script_path = os.path.realpath(__file__) # Get the path to the current script
# script_name = os.path.basename(current_script_path)[:-3] # Get filename only (e.g., 'my_script.py')
# date, time = datetime.now().strftime("%Y-%m-%d %H-%M-%S").split()
# destination_path = os.path.join(FOLDER + "data/" + str(date) + '/', f"{script_name}_screenhsot_{time}.py") # Define destination path
# shutil.copy(current_script_path, destination_path) # Copy the script

SINGLE_SHOT_A = Dataset(name="single_shotA", save=True, plot=False)
SINGLE_SHOT_B = Dataset(name="single_shotB", save=True, plot=False)
SINGLE_SHOT_C = Dataset(name="single_shotC", save=True, plot=False)

IA = Dataset(name="IA", save=False, plot=False)
QA= Dataset( name="QA", save=False, plot=False)
IB = Dataset(name="IB", save=False, plot=False)
QB = Dataset(name="QB", save=False, plot=False)
IC = Dataset(name="IC", save=True, plot=False)
QC= Dataset(name="QC", save=True, plot=False)

class ResonantExchange1D(Experiment):
    """Resonant exchange"""

    ############################# DEFINE PRIMARY DATASETS ##############################
    primary_datasets = ["IA", "QA", "single_shotA","IB", "QB", "single_shotB","IC", "QC", "single_shotC",]

    ############################## DEFINE PRIMARY SWEEPS ###############################
    primary_sweeps = ["gate_id"]

    def __init__(self, folder, modes, pulses, sweeps, datasets, **parameters):
        super().__init__(folder,modes,pulses,sweeps,datasets,**parameters,)  # Passes other parameters to parent
        self.pulse_list = [f"self.exchange_pulse_cos2_{d}" for d in range (self.time_start, self.time_stop+self.time_step, self.time_step)]


    ############################ DEFINE THE PULSE SEQUENCE #############################
    def sequence(self):
        """QUA sequence that defines this Experiment subclass"""
        # qua.reset_frame(self.cavA)
        # qua.reset_frame(self.drive)
        # qua.reset_frame(self.qC)
        # qua.reset_frame(self.qA)
        # qua.reset_frame(self.qC_EF)
        qm_qua.reset_global_phase()
        qua.update_frequency(self.drive, 200.7e6-0e6) #-6 and -2
        qua.update_frequency(self.qA, self.qA.int_freq) # fock 1
        qua.align()

        self.cavA.play(self.cavityA_grape)
        self.qA.play(self.qubitA_grape)
        # self.cavB.play(self.cavityB_grape, ampx = self.grape_B)
        # self.qB.play(self.qubitB_grape, ampx = self.grape_B)
        qua.align()

        with qm_qua.switch_(self.gate_id):
            for i in range(self.time_start, self.time_stop+self.time_step, self.time_step):
                with qm_qua.case_(i):
                    self.drive.play(getattr(self,f"exchange_pulse_cos2_{i}"))
        qua.align() 

        # Check if cavA in 0 or 1
        # qua.update_frequency(self.qA, 350.76e6) # fock1 frequency
        # self.qA.play(self.qA_pulse)
        # qua.align(self.qubitEF, self.qA)
        # self.qubitEF.play(self.qubitEF_pi)
        # qua.align(self.qubitEF, self.rrA)
        # self.rrA.measure(self.readout_pulseA, (self.IA, self.QA), demod_type="dual")

        # # Check if cavB in 0 or 1
        # self.qB.play(self.qB_pulse)
        # qua.align(self.qB_EF, self.qB)
        # self.qB_EF.play(self.qB_EF_pi)        
        # qua.align(self.rrB, self.qB_EF)
        # self.rrB.measure(self.readoutB_pulse, (self.IB, self.QB), demod_type="dual")
        
        # Check if rrC in g or e
        self.qC_EF.play(self.qubitCEF_pi)
        qua.align(self.qC_EF, self.rrC)
        self.rrC.measure(self.readoutC_pulse, (self.IC, self.QC), demod_type="dual")
        qua.align()
        qua.wait(self.wait_time)
        if self.plot_single_shot:  # assign state to G or E
        #    qm_qua.assign(self.single_shotA, qm_qua.Cast.to_fixed(self.IA > self.readout_pulseA.threshold),)
        #    qm_qua.assign(self.single_shotB, qm_qua.Cast.to_fixed(self.IB > self.readoutB_pulse.threshold),)
           qm_qua.assign(self.single_shotC, qm_qua.Cast.to_fixed(self.IC > self.readoutC_pulse.threshold),)


if __name__ == "__main__":
    """ """
    #################################### MODE MAP ######################################
    # key: name of the Mode as defined by the Experiment subclass
    # value: name of the Mode as defined by the user in modes.yml
    modes = {"qA": "qA",
             "qB": "qB",
            #  "qB_EF": "qB_EF",
             "qC": "qC",
             "qC_EF": "qC_EF",
             "drive": "drive",
            #  "rrA": "rrA",
            #  "qubitEF": "qA_EF",
            #  "rrB": "rrB",
             "rrC": "rrC",
             "cavA": "cavA",
             "cavB": "cavB"
             }

    ################################### PULSE MAP ######################################
    # key: name of the Pulse as defined by the Experiment subclass
    # value: name of the Pulse as defined by the user in modes.yml

    pulses = {
        "qubitA_grape": "qA_grape_fock1",
        "cavityA_grape": "cavA_grape_fock1",
        "qubitB_grape": "qB_grape_fock1",
        "cavityB_grape": "cavB_grape_fock1",
        "qA_pulse": "qA_gaussian_very_sel_pi_pulse",
        "qB_pulse": "qB_gaussian_very_sel_pi_pulse",
        "qC_pulse": "qC_gaussian_pi_pulse",
        "qubitCEF_pi":"qC_EF_gaussian_pi_pulse",

        "readoutC_pulse": "rrC_GF_readout_pulse",
        "readout_pulseA": "rrA_GF_CLEAR_readout_pulse", 
        "readoutB_pulse": "rrB_GF_CLEAR_readout_pulse",
        "qubitEF_pi": "qAEF_EF_gaussian_pi_pulse",        
        "qB_EF_pi": "qBEF_gaussian_pi_pulse",
    }
                   
    time_start = 16
    time_stop = 5000
    time_step = 100
    
    for d in range(time_start, time_stop+time_step, time_step):
        pulses[f"exchange_pulse_cos2_{d}"] = f"exchange_pulse_cos2_{d}"
               
                                
    ############################## CONTROL PARAMETERS ##################################
    parameters = {
        "wait_time": 7e6,
        "ro_ampx": 1,
        "plot_single_shot": True,
        # "drive_ampx": 1.6,
        "time_start":  time_start,
        "time_stop":  time_stop,
        "time_step":  time_step,
    }


    ######################## SWEEP (INDEPENDENT) VARIABLES #############################
    N.num = 5000

    # LENGTH = Sweep (name="drive_length", dtype=int, units = "ns")
    # LENGTH.start = 16
    # LENGTH.stop = 4000
    # LENGTH.step = 20

    # GATES = Sweep(name="gate_id", start=time_start, stop=time_stop, step=time_step, dtype=int, save=True)
    # SINGLE_SHOT_C.fitfn = "exp_decay_sine"
    # SINGLE_SHOT_B.fitfn = "exp_decay_sine"
    # SINGLE_SHOT_A.fitfn = "exp_decay_sine"
    # SINGLE_SHOT_A.plot_args["plot_type"] = "image"
    # FREQ = Sweep(name = 'drive_freq', start = 182.7e6, stop = 184.7e6, step = 2e6, dtype=int)
    AMPX =  Sweep(name="grape_B", points=[0.0, 1.0])
    # sweeps = [N, AMPX, LENGTH]

    # AMPX =  Sweep(name="drive_ampx", points=[0.0, 0.2, 0.4, 0.6, 0.8, 1.0, 1.2, 1.4, 1.6, 1.8, 2.0])
    # GRAPE = Sweep(name = "grape_id", start = 0, stop = 2, num = 3, dtype = int)
    #sweeps = [N, GRAPE, LENGTH]
    GATES = Sweep(name="gate_id", start=time_start, stop=time_stop, step=time_step, dtype=int, save=True)

    sweeps = [N, GATES]

    SINGLE_SHOT_C.plot = True
    SINGLE_SHOT_A.plot = False
    SINGLE_SHOT_B.plot = False

    ######################## DATASET (DEPENDENT) VARIABLES #############################
    # must include all primary datasets defined by the Experiment subclass
    # datasets = [IA, QA, SINGLE_SHOT_A]
    datasets = [IA, QA, SINGLE_SHOT_A, IB, QB, SINGLE_SHOT_B, IC, QC, SINGLE_SHOT_C]
    ######################## INITIALIZE AND RU NEXPERIMENT #############################
    expt = ResonantExchange1D(FOLDER, modes, pulses, sweeps, datasets, **parameters)
    expt.run()
