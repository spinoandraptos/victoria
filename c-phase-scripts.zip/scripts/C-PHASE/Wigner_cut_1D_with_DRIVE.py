from config.experiment_config import FOLDER, N, FREQ, RRB, I, Q, SINGLE_SHOT
from qcore import Experiment, qua, Sweep, Dataset
from qm import qua as qm_qua
from qcore.libs.qua_macros import QuaVariable
import shutil
import os
from datetime import datetime
from scripts.qB_GE_experiments.T2_virtual_detuning_qB import QubitT2
from scripts.qB_GE_experiments.AllXY_qB import ALLXY


# SCREENSHOT FILE 
current_script_path = os.path.realpath(__file__) # Get the path to the current script
script_name = os.path.basename(current_script_path)[:-3] # Get filename only (e.g., 'my_script.py')
date, time = datetime.now().strftime("%Y-%m-%d %H-%M-%S").split()
destination_path = os.path.join(FOLDER + "data/" + str(date) + '/', f"{script_name}_screenhsot_{time}.py") # Define destination path
shutil.copy(current_script_path, destination_path) # Copy the script

SINGLE_SHOT_A = Dataset(
    name="single_shotA",
    save=True,
    plot=False, 
)
SINGLE_SHOT_A_BEFORE = Dataset(
    name="single_shotA_before",
    save=True,
    plot=False, 
)
SINGLE_SHOT_B = Dataset(
    name="single_shotB",
    save=True,
    plot=False, 
)
SINGLE_SHOT_B_BEFORE = Dataset(
    name="single_shotB_before",
    save=True,
    plot=False, 
)
SINGLE_SHOT_C = Dataset(
    name="single_shotC",
    save=True,
    plot=False, 
)
SINGLE_SHOT_C_BEFORE = Dataset(
    name="single_shotC_before",
    save=True,
    plot=False, 
)
IC = Dataset(
    name="IC",
    save=False,
    plot=False, 
)
IC_BEFORE = Dataset(
    name="IC_before",
    save=False,
    plot=False, 
)
QC = Dataset(
    name="QC",
    save=False,
    plot=False, 
)
QC_BEFORE = Dataset(
    name="QC_before",
    save=False,
    plot=False, 
)
IA = Dataset(
    name="IA",
    save=False,
    plot=False, 
)
IA_BEFORE = Dataset(
    name="IA_before",
    save=False,
    plot=False, 
)
QA = Dataset(
    name="QA",
    save=False,
    plot=False, 
)
QA_BEFORE = Dataset(
    name="QA_before",
    save=False,
    plot=False, 
)
IB = Dataset(
    name="IB",
    save=False,
    plot=False, 
)
IB_BEFORE = Dataset(
    name="IB_before",
    save=False,
    plot=False, 
)
QB = Dataset(
    name="QB",
    save=False,
    plot=False, 
)
QB_BEFORE= Dataset(
    name="QB_before",
    save=False,
    plot=False, 
)


class WignersAB(Experiment):
    """Wigner_function"""

    ############################# DEFINE PRIMARY DATASETS ##############################
    # these Datasets form the "raw" experimental data and will be streamed by the OPX
    # they must be specified at experiment runtime
    # primary_datasets = ["IA", "IA_before", "QA", "QA_before", "single_shotA", "single_shotA_before", 
    #                     "IB", "IB_before", "QB", "QB_before", "single_shotB", "single_shotB_before", 
    #                     "IC", "IC_before", "QC", "QC_before", "single_shotC", "single_shotC_before"]

    primary_datasets = ["IA", "QA", "single_shotA",
                        "IB", "QB", "single_shotB"]

    ############################## DEFINE PRIMARY SWEEPS ###############################
    # these Sweeps are uniquely associated with the Experiment subclass
    # these Sweeps must be specified at experiment runtime
    primary_sweeps = ["cavity_drive_I"]

    ############################ DEFINE THE PULSE SEQUENCE #############################
    # ensure that you import 'qua' from 'qcore' and not from 'qm' library
    # attributes accessed via 'self' must be defined in 'if __name__ == "__main__"' code
    
    def sequence(self):
        factorA = qm_qua.declare(qm_qua.fixed)
        factorB = qm_qua.declare(qm_qua.fixed)
        qm_qua.assign(factorA, self.detuningA * 1e-9)  
        qm_qua.assign(factorB, self.detuningB * 1e-9)  
        qm_qua.assign(self.phaseA, qm_qua.Cast.mul_fixed_by_int(factorA, self.drive_length))
        qm_qua.assign(self.phaseB, qm_qua.Cast.mul_fixed_by_int(factorB, self.drive_length))
        total_phaseA = qm_qua.declare(qm_qua.fixed)
        total_phaseB = qm_qua.declare(qm_qua.fixed)
        qua.reset_frame(self.cavityA)
        qua.reset_frame(self.qubitA)
        qua.reset_frame(self.cavityB)
        qua.reset_frame(self.qubitB)
        qua.reset_frame(self.drive)
        qm_qua.reset_global_phase()
        qua.update_frequency(self.drive, 371e6-7e6)


        # GRAPE A
        self.cavityA.play(self.cavA_grape)
        self.qubitA.play(self.qA_grape)
        # GRAPE B
        self.cavityB.play(self.cavB_grape)
        self.qubitB.play(self.qB_grape)
        qua.align()

        self.drive.play(self.drive_pulse)
        self.drive.play(self.drive_pulse)
        self.drive.play(self.drive_pulse)
        qm_qua.assign(total_phaseA, 3*self.phaseA + 0.25 + 3*self.ramp_phaseA)
        qm_qua.assign(total_phaseB, 3*self.phaseB + 0.25 + 3*self.ramp_phaseB)
        qua.align() 

        # WIGNER A
        self.cavityA.play(self.cavA_op, ampx=(self.cavity_drive_I, 0, 0, self.cavity_drive_I), phase= total_phaseA)  # displacement
        qua.align(self.cavityA, self.qubitA)
        self.qubitA.play(self.qubitA_pi2)  # play pi/2 pulse around X
        qua.wait(int(self.time_delayA), self.qubitA)  # conditional phase gate on even, odd Fock state
        self.qubitA.play(self.qubitA_pi2, phase = self.qb_phase)  # play pi/2 pulse around X
        #qua.align(self.qubitA)  
        #qua.update_frequency(self.qubitA,  233.19e6)
        #self.qubitA.play(self.qubitA_EF_drive) 
        qua.align(self.qubitA, self.rrA)  
        self.rrA.measure(self.readout_pulseA, (self.IA, self.QA), ampx=self.ro_ampx, demod_type = 'dual')  # measure transmitted signal

        # WIGNER B
        self.cavityB.play(self.cavB_op, ampx=(self.cavity_drive_I, 0, 0, self.cavity_drive_I), phase= total_phaseB)  # displacement
        qua.align(self.cavityB, self.qubitB)
        self.qubitB.play(self.qubitB_pi2)  # play pi/2 pulse around X
        qua.wait(int(self.time_delayB), self.qubitB)  # conditional phase gate on even, odd Fock state
        self.qubitB.play(self.qubitB_pi2, phase = self.qb_phase)  # play pi/2 pulse around X
        qua.align(self.qubitB, self.qubitB_EF)  
        self.qubitB_EF.play(self.qubitB_EF_drive)  # play pi/2 pulse around X
        qua.align(self.qubitB_EF, self.rrB)  
        self.rrB.measure(self.readout_pulseB, (self.IB, self.QB), ampx=self.ro_ampx, demod_type = 'dual')  # measure transmitted signal
        
        #qua.align()
        #self.rrC.measure(self.readout_pulseC, (self.IC, self.QC), ampx=self.ro_ampx, demod_type = 'dual')  # measure transmitted signal

        if self.plot_single_shot:  # assign state to G or E
            qm_qua.assign(self.single_shotA, qm_qua.Cast.to_fixed(self.IA > self.readout_pulseA.threshold),)
            qm_qua.assign(self.single_shotB, qm_qua.Cast.to_fixed(self.IB > self.readout_pulseB.threshold),)
            #qm_qua.assign(self.single_shotC, qm_qua.Cast.to_fixed(self.IC > self.readout_pulseC.threshold),)

        qua.align()
        qua.wait(self.wait_time)

grape_A = "fock01"
       
if __name__ == "__main__":
    """ """

    modes = {
        "cavityA": "cavA",
        "cavityB": "cavB",
        "qubitA": "qA",
        "qubitB": "qB",
        "qubitB_EF": "qB_EF",
        "drive": "drive",           
        "rrA": "rrA",
        "rrB": "rrB",
        #"rrC": "rrC",
    }

    pulses = {
        "qA_grape": "qA_grape_fock1",
        "cavA_grape": "cavA_grape_fock1",
        "qB_grape": "qB_grape_fock01_new",
        "cavB_grape": "cavB_grape_fock01_new",
        "cavA_op": "cavA_ramp_pulse",
        "cavB_op": "cavB_ramp_pulse",
        "qubitA_pi2": "qA_gaussian_pi2_pulse",
        "qubitB_pi2": "qB_gaussian_pi2_pulse",
        "qubitB_EF_drive": "qBEF_gaussian_pi_pulse",
        "qubitA_EF_drive": "qA_EF_gaussian_pi_pulse",
        "drive_pulse": "very_good_pulse_standard",
        "readout_pulseA": "rrA_GF_CLEAR_readout_pulse",
        "readout_pulseB": "rrB_GF_CLEAR_readout_pulse",
        # "readout_pulseC": "rrC_readout_pulse",
        "qA_selective": "qA_gaussian_very_sel_pi_pulse",
        "qB_selective": "qB_gaussian_very_sel_pi_pulse",
        "qA_unselective": "qA_gaussian_pi_pulse",
        "qB_unselective": "qB_gaussian_pi_pulse",
    }

    ############################## CONTROL PARAMETERS ##################################
    parameters = {
        "ramp_phaseA": -0.076,  
        "ramp_phaseB": -0.026-0.018,
        "detuningA": -768e3,
        "detuningB":  -202e3,
        "phaseA": QuaVariable(value=0.0,dtype=qm_qua.fixed,tag="phaseA",buffer=True,stream=True,),
        "phaseB": QuaVariable(value=0.0,dtype=qm_qua.fixed,tag="phaseB",buffer=True,stream=True,),
        "wait_time": 7e6,
        "ro_ampx": 1,
        "time_delayA": 520,
        "time_delayB": 156, 
        "drive_length": 4000,
        "qb_phase": 0,
        "plot_single_shot": True,
        "qubit_drive_ampx": 1.0,
        #"drive_amp": 1.0,
    }

    N.num = 5000
    QD_AMPX_I = Sweep(name="cavity_drive_I", start=-1.8, stop=1.8, step = 0.05) ###PREV 0.2
    #QD_AMPX_Q = Sweep(name="cavity_drive_Q", start=-1.8, stop=1.8, num = 41) ###PREV 0.2
    
    LENGTH = Sweep (name="drive_length", dtype=int, units = "ns")
    LENGTH.start = 4800
    LENGTH.stop = 5200
    LENGTH.step = 50 ###PREV 2000

    # PARITY = Sweep (name="qb_phase", dtype=float)
    # PARITY.start = 0.0
    # PARITY.stop = 0.5
    # PARITY.step = 0.5

    # DRIVE_AMPX = Sweep(name="drive_amp", start=1.798, stop=1.808, step = 0.002) ###PREV 0.2
    
    # sweeps = [N, QD_AMPX_I]
    sweeps = [N, QD_AMPX_Q, QD_AMPX_I]


    # datasets = [IA, IA_BEFORE,  
    #             QA, QA_BEFORE, 
    #             SINGLE_SHOT_A, SINGLE_SHOT_A_BEFORE, 
    #             IB, IB_BEFORE,  
    #             QB, QB_BEFORE, 
    #             SINGLE_SHOT_B, SINGLE_SHOT_B_BEFORE, 
    #             IC, QC, SINGLE_SHOT_C,
    #             IC_BEFORE, QC_BEFORE, SINGLE_SHOT_C_BEFORE]

    datasets = [IA, QA, SINGLE_SHOT_A, 
                IB, QB, SINGLE_SHOT_B]

    SINGLE_SHOT_A.plot = True
    SINGLE_SHOT_B.plot = True
    expt = WignersAB(FOLDER, modes, pulses, sweeps, datasets, **parameters)
    expt.run()
