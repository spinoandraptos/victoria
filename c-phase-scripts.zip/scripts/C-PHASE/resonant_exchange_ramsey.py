""" """

import sys

sys.path.append("C:/Users/admin/Desktop/qcore-yabba/yabba-main/")
from config.experiment_config import FOLDER, N, I, Q, MAG, PHASE, RRB, SINGLE_SHOT
from qcore import Experiment, qua, Sweep
from cmath import phase
from qm import qua as qm_qua
from qcore.libs.qua_macros import QuaVariable
from qcore.helpers import logger


class RamseyExchange(Experiment):
    """Qubit T2 Virtual Detuning"""

    primary_datasets = ["I", "Q", "single_shot"]

    primary_sweeps = ["time_delay"]

    def sequence(self):
        qua.reset_phase(self.cavityA)
        qua.reset_frame(self.cavityA)
        qua.reset_phase(self.qubit)
        qua.reset_frame(self.qubit)
        qua.reset_phase(self.qubitA)
        qua.reset_frame(self.qubitA)

        qua.reset_phase(self.drive)
        qua.reset_frame(self.drive)



        factor = qm_qua.declare(qm_qua.fixed)
        qm_qua.assign(factor, self.detuning * 1e-9)  # formerly with a 4*

        self.cavityA.play(self.cavity_grape)
        self.qubitA.play(self.qubit_grape)
        qua.align()

        self.drive.play(self.exchange_drive, ampx = 2.0, duration = 248/2/4)
        qua.wait(self.time_delay, self.drive)
        qm_qua.assign(self.phase, qm_qua.Cast.mul_fixed_by_int(factor, self.time_delay))
        self.drive.play(self.exchange_drive, ampx = 2.0, duration = 248/2/4, phase = self.phase)
        qua.align()

        self.resonator.measure(self.readout_pulse, (self.I, self.Q), ampx=self.ro_ampx, demod_type="dual")
        qua.align()
        qua.wait(self.wait_time)
        if self.plot_single_shot:  # assign state to G or E
            qm_qua.assign(self.single_shot, qm_qua.Cast.to_fixed(self.I > self.readout_pulse.threshold),)

if __name__ == "__main__":
    """ """

    modes = {"qubit": "qC",
             "qubitA": "qA",
             "drive": "drive",
             "resonator": "rrC",
             "cavityA": "cavA"}

    pulses = {
        "qubit_grape": "qA_grape_fock1",
        "cavity_grape": "cavA_grape_fock1",
        #"qC_pulse": "qC_gaussian_pi_pulse",
        "qubit_pulse": "qC_gaussian_sel_pi_pulse",
        "exchange_drive": "exchange_pulse",
        "readout_pulse": "rrC_readout_pulse",
    }
                                       
    parameters = {
        "detuning": 0e6,  # Hz
        "wait_time": 6e6,
        "ro_ampx": 1,
        "plot_single_shot": True,
        "qubit_drive_ampx": 1.0,
        "phase": QuaVariable(
            value=0.0,
            dtype=qm_qua.fixed,
            tag="phase",
            buffer=True,
            stream=True,
        ),
    }

    N.num = 5000
    DEL = Sweep(name="time_delay", start=16, stop=400, step=4, dtype=int)  # ns
    sweeps = [N, DEL]

    I.fitfn = "exp_decay_sine"
    Q.fitfn = "exp_decay_sine"
    MAG.fitfn = "exp_decay_sine"
    PHASE.datafn_args = {"delay": 2.792e-7, "freq": RRB.int_freq}
    # PHASE.plot = False
    Q.plot = True
    SINGLE_SHOT.fitfn = "exp_decay_sine"
    datasets = [I, Q, SINGLE_SHOT]

    ######################## INITIALIZE AND RUN EXPERIMENT #############################
    expt = RamseyExchange(FOLDER, modes, pulses, sweeps, datasets, **parameters)
    expt.run(simulate=False)
