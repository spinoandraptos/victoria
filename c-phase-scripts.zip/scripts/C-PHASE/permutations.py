import numpy as np
from itertools import product

wa = 4.59
wb = 6.13
wq = 5.71
wd = 4.17

def permutations_with_repetitions(arr, length):
    indices = list(range(len(arr)))
    permuted_indices = list(product(indices, repeat=length))
    permuted_elements = [np.sum([arr[i] for i in perm]) for perm in permuted_indices]
    return list(zip(permuted_elements, permuted_indices))

exponentials= [wa, -wa, wb, -wb, wq, -wq, wd, -wd]
exponentials= [wa, wb, -wb, wq, wd, -wd]

#              0    1   2    3   4    5   6    7
order = 6
result = permutations_with_repetitions(exponentials, order)



def replace_with_letters(arr, mapping):
    return [mapping[num] for num in arr]

mapping = {
    0: 'a*',
    1: 'b*',
    2: 'b',
    3: 'q*',
    4: 'd*',
    5: 'd'
}
# mapping = {
#     0: 'a*',
#     1: 'a',
#     2: 'b*',
#     3: 'b',
#     4: 'q*',
#     5: 'q',
#     6: 'd*',
#     7: 'd'
# }
for exponent, indices in result:
    if  abs(exponent) < 0.4:
        print(f"Exponent: {exponent}, Modes: {list(replace_with_letters(np.array(indices), mapping))}")

   