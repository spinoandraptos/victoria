from config.experiment_config import FOLDER, N, FREQ, RRB, I, Q, SINGLE_SHOT
from qcore import Experiment, qua, Sweep, Dataset
from qm import qua as qm_qua
from qcore.libs.qua_macros import QuaVariable
import shutil
import os
from datetime import datetime
from scripts.qB_GE_experiments.T2_virtual_detuning_qB import QubitT2
from scripts.qB_GE_experiments.AllXY_qB import ALLXY
from qm.qua import *

# SCREENSHOT FILE 
current_script_path = os.path.realpath(__file__) # Get the path to the current script
script_name = os.path.basename(current_script_path)[:-3] # Get filename only (e.g., 'my_script.py')
date, time = datetime.now().strftime("%Y-%m-%d %H-%M-%S").split()
destination_path = os.path.join(FOLDER + "data/" + str(date) + '/', f"{script_name}_screenhsot_{time}.py") # Define destination path
shutil.copy(current_script_path, destination_path) # Copy the script

IA_PARITY= Dataset(name="IA_parity",save=True,plot=False)
QA_PARITY = Dataset(name="QA_parity",save=False,plot=False)
SINGLE_SHOT_A_PARITY = Dataset(name="single_shotA_parity",save=True,plot=False)

IA = Dataset(name="IA",save=False,plot=False)
QA = Dataset(name="QA",save=False,plot=False)
SINGLE_SHOT_A = Dataset(name="single_shotA",save=True,plot=False)
SINGLE_SHOT_A_AFTER = Dataset(name="single_shotA_after",save=True,plot=False)

IB_PARITY = Dataset(name="IB_parity",save=True,plot=False)
QB_PARITY = Dataset(name="QB_parity",save=False,plot=False)
SINGLE_SHOT_B_PARITY = Dataset(name="single_shotB_parity",save=True,plot=False)

IB = Dataset(name="IB",save=False,plot=False)
QB = Dataset(name="QB",save=False,plot=False)
SINGLE_SHOT_B = Dataset(name="single_shotB",save=True,plot=False)
SINGLE_SHOT_B_AFTER = Dataset(name="single_shotB_after",save=True,plot=False)


class photon_loss(Experiment):
    """"""

    primary_datasets = ["IA_parity", "QA_parity", "single_shotA_parity",
                        "IA", "QA", "single_shotA",
                        "IB_parity", "QB_parity", "single_shotB_parity",
                        "IB", "QB", "single_shotB",]

    primary_sweeps = ["delay"]


    def __init__(self, folder, modes, pulses, sweeps, datasets, **parameters):

        super().__init__(folder,modes,pulses,sweeps,datasets, **parameters,)  # Passes other parameters to parent
        
        self.orens_points = [[0.17810928, -1.32101934],
                            [-0.21121299, -0.41773907],
                            [0.73130212, 1.11075067],
                            [-0.39162883, 0.77796174],
                            [-1.03344266, 0.98572183],
                            [0.48593934, 0.03767621],
                            [-1.3205937, -0.20939208],
                            [-0.44173141, -0.69979338],
                            [0.86497711, -0.02507866],
                            [-0.2604925, 0.39819938]]

    def sequence(self):
        """QUA sequence that defines this Experiment subclass"""
        qua.reset_frame(self.cavityA)
        qua.reset_frame(self.qubitA)
        qua.reset_frame(self.qubitA_EF)
        qua.reset_frame(self.cavityB)
        qua.reset_frame(self.qubitB)
        qua.reset_frame(self.qubitB_fock1)
        qua.reset_frame(self.qubitB_EF)
        qua.reset_frame(self.drive)
        total_phase_A = qm_qua.declare(qm_qua.fixed)
        total_phase_B = qm_qua.declare(qm_qua.fixed)
        disp_I = qm_qua.declare(qm_qua.fixed)
        disp_Q = qm_qua.declare(qm_qua.fixed)
        SNAP_phase1 = qm_qua.declare(qm_qua.fixed)
        SNAP_phase2 = qm_qua.declare(qm_qua.fixed)
        qm_qua.reset_global_phase()

        with switch_(self.orens_id):
            for i in range(len(self.orens_points)):
                with case_(i):
                    qm_qua.assign(disp_I, self.orens_points[i][0])
                    qm_qua.assign(disp_Q, self.orens_points[i][1])

        qua.update_frequency(self.qubitA, self.qubitA.int_freq)
        qua.update_frequency(self.qubitB, self.qubitB.int_freq)
        qua.update_frequency(self.drive, 334e6)
        qua.align()

        # PREPARE DATA CAVITY AND WAIT
        self.cavityA.play(self.cavA_grape2)
        self.qubitA.play(self.qA_grape2)
        # PREPARE ANCILLA CAVITY
        qua.wait(self.delay, self.cavityB, self.qubitB)
        self.cavityB.play(self.cavB_grape02)
        self.qubitB.play(self.qB_grape02)
        qua.align()

        # DRIVE 2xCZ OR WAIT 4us
        with qm_qua.switch_(self.gate_id):
            with qm_qua.case_(0):
                qm_qua.assign(total_phase_A, 0.25)
                qm_qua.assign(total_phase_B, 0.25)
                qm_qua.assign(SNAP_phase1, 0.5 + 0.25)
                qm_qua.assign(SNAP_phase2, 0.0 + 0.25)
                qua.wait(4000, self.drive)
            with qm_qua.case_(1):
                qm_qua.assign(total_phase_A,  0.25 + self.ramp_phaseA + qm_qua.Cast.mul_fixed_by_int(self.detuningA * 1e-9, self.pulse_length))
                qm_qua.assign(total_phase_B,  0.25 + self.ramp_phaseB + qm_qua.Cast.mul_fixed_by_int(self.detuningB * 1e-9, self.pulse_length))
                qm_qua.assign(SNAP_phase1,  0.5 + 0.25 + self.ramp_phaseA + qm_qua.Cast.mul_fixed_by_int(self.detuningA * 1e-9, self.pulse_length))
                qm_qua.assign(SNAP_phase2,  0.0 + 0.25 + self.ramp_phaseB + qm_qua.Cast.mul_fixed_by_int(self.detuningB * 1e-9, self.pulse_length))
                self.drive.play(self.identity_gate)
        qua.align()

        # CHECK PARITY ANCILLA WITH SNAP
        self.cavityB.play(self.cavB_op, ampx = 0.353, phase = SNAP_phase1)
        qua.align(self.cavityB, self.qubitB, self.qubitB_fock1)
        self.qubitB.play(self.qB_selective, ampx = 2.0)
        self.qubitB_fock1.play(self.qB_f1_selective, ampx = 2.0)
        qua.align(self.cavityB, self.qubitB, self.qubitB_fock1)
        self.cavityB.play(self.cavB_op, ampx = 1.037, phase = SNAP_phase2)
        qua.align(self.cavityB, self.qubitB)
        self.qubitB.play(self.qB_selective)
        qua.align(self.qubitB, self.qubitB_EF)
        self.qubitB_EF.play(self.qubitB_EF_pi)
        qua.align(self.qubitB_EF, self.rrB)
        self.rrB.measure(self.readout_pulseB, (self.IB, self.QB), demod_type = 'dual')  # measure transmitted signal

        # MEASURE ORENS OF DATA CAVITY
        self.cavityA.play(self.cavA_op, ampx=(disp_I, -disp_Q, disp_Q, disp_I), phase = total_phase_A)  # displacement
        qua.align(self.cavityA, self.qubitA)
        qua.update_frequency(self.qubitA, 350.0e6) # fock2 frequency
        self.qubitA.play(self.qA_selective)
        qua.align(self.qubitA, self.qubitA_EF)
        self.qubitA_EF.play(self.qubitA_EF_pi)  # play pi/2 pulse around X
        qua.align(self.qubitA_EF, self.rrA) 
        self.rrA.measure(self.readout_pulseA, (self.IA, self.QA), demod_type = 'dual')  # measure transmitted signal
        
        if self.plot_single_shot:  # assign state to G or E
            qm_qua.assign(self.single_shotA, qm_qua.Cast.to_fixed(self.IA > self.readout_pulseA.threshold))
            qm_qua.assign(self.single_shotB, qm_qua.Cast.to_fixed(self.IB > self.readout_pulseB.threshold))

        qua.align()
        qua.wait(self.wait_time)


if __name__ == "__main__":
    
    modes = {
        "cavityA": "cavA",
        "cavityB": "cavB",
        "qubitA": "qA",
        "qubitA_EF":"qA_EF",
        "qubitB": "qB", 
        "qubitB_fock1": "qB_fock1", 
        "qubitB_EF":"qB_EF",
        "drive": "drive",           
        "rrA": "rrA",
        "rrB": "rrB"
    }

    pulses = {
        "cavA_grape2": "cavA_grape_fock2",
        "qA_grape2": "qA_grape_fock2",
        "cavB_grape02": "cavB_grape_fock02",
        "qB_grape02": "qB_grape_fock02",
        "identity_gate": "very_good_pulse_standard",
        "cavA_op": "cavA_ramp_pulse",
        "cavB_op": "cavB_sg_pulse",
        "qubitA_pi2": "qA_gaussian_pi2_pulse",
        "qubitB_pi2": "qB_gaussian_pi2_pulse",
        "qA_unselective": "qA_gaussian_pi_pulse",
        "qB_unselective": "qB_gaussian_pi_pulse",
        "qA_selective": "qA_gaussian_very_sel_pi_pulse",
        "qB_selective": "qB_gaussian_very_sel_pi_pulse",
        "qB_f1_selective": "qB_f1_gaussian_very_sel_pi_pulse",
        "qubitA_EF_pi": "qAEF_EF_gaussian_pi_pulse",
        "qubitB_EF_pi": "qBEF_gaussian_pi_pulse",
        "readout_pulseA": "rrA_GF_CLEAR_readout_pulse",
        "readout_pulseB": "rrB_GF_CLEAR_readout_pulse",
    }

    parameters = {
        "ramp_phaseA": -0.159/2,  
        "ramp_phaseB":  -0.07/2,
        "detuningA": (-1528.5e3)/2,
        "detuningB":   (-454.3e3)/2,
        "wait_time": 8e6,
        "plot_single_shot": True,
        "pulse_length": 3600,
        # "gate_id":1,
    }

    N.num = 100_000

    ORENS = Sweep(name = "orens_id", start = 0, stop = 9, num = 10, dtype = int, save = True)
    DELAY = Sweep(name = "delay", start = 16, stop = 800e3, step = 20e3, dtype = int, save = True)
    # DRIVES = Sweep(name = "drive_length", start = time_start, stop = time_stop, step = time_step, dtype = int, save = True)
    GATES = Sweep(name = "gate_id", start = 0, stop = 1, num = 2, dtype = int, save = True)

    sweeps = [N, GATES, ORENS, DELAY]

    SINGLE_SHOT_A.plot = True
    SINGLE_SHOT_B.plot = True

    datasets = [IA, QA, SINGLE_SHOT_A,  
                IA_PARITY, QA_PARITY, SINGLE_SHOT_A_PARITY, 
                IB, QB, SINGLE_SHOT_B,
                IB_PARITY, QB_PARITY, SINGLE_SHOT_B_PARITY]


    expt = photon_loss(FOLDER, modes, pulses, sweeps, datasets, **parameters)
    
    expt.run(simulate=False)