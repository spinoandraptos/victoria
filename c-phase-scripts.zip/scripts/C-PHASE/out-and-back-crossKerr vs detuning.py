""" """

from config.experiment_config import FOLDER, N, FREQ, I, Q, MAG, PHASE, RRA, SINGLE_SHOT
from qm import qua as qm_qua
from qcore import Experiment, qua, Sweep
import numpy as np


class OutAndBackCrossKerr(Experiment):
    """Dispersive shift between cavity and qubit"""

    ############################# DEFINE PRIMARY DATASETS ##############################
    # these Datasets form the "raw" experimental data and will be streamed by the OPX
    # they must be specified at experiment runtime

    primary_datasets = ["I", "Q", "single_shot"]

    ############################## DEFINE PRIMARY SWEEPS ###############################
    # these Sweeps are uniquely associated with the Experiment subclass
    # these Sweeps must be specified at experiment runtime

    primary_sweeps = ["drive_frequency"]

    ############################ DEFINE THE PULSE SEQUENCE #############################
    # ensure that you import 'qua' from 'qcore' and not from 'qm' library
    # attributes accessed via 'self' must be defined in 'if __name__ == "__main__"' code

    def sequence(self):
        """QUA sequence that defines this Experiment subclass"""
        qua.reset_phase(self.cavB)
        qua.reset_frame(self.cavB)
        qua.reset_phase(self.cavA)
        qua.reset_frame(self.cavA)
        qua.reset_phase(self.qA)
        qua.reset_frame(self.qA)
        qua.reset_phase(self.qB)
        qua.reset_frame(self.qB)
        qua.reset_phase(self.drive)
        qua.reset_frame(self.drive)

        qua.align()
        # qua.initialize_cavity_AND_qubit(
        #     rr=self.resonatorB,
        #     qubit = self.qB, 
        #     readout_pulse=self.readout_pulseB,
        #     qubit_pulse = self.qB_pulse,
        #     demod_type="dual",
        #     threshold_g=self.readout_pulseB.threshold,
        #     ro_ampx=self.ro_ampx,
        #     wait_time=50_000,
        #     n_consecutive=3
        # )
        # qua.align()

        # # U2: 0 -> 1 in cavB
        # qua.update_frequency(self.qubit, self.qubit.int_freq) #!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
        self.qB.play(self.qubitB_grape)
        self.cavB.play(self.cavityB_grape) 
        qua.align()

        # Displace Bob (frequency shifted by cross_kerr but hopefully is ok)
        self.cavA.play(self.cavA_pulse, ampx=1.0)  # create a coherent state in ali
        qua.align() 

        qua.update_frequency(self.drive, self.drive_frequency)

        self.drive.play(self.drive_pulse, duration = 1500/4)
        #qua.wait(1500, self.cavA)  # wait for state to rotate
        qua.align() 

        # Bring Bob back with a certain phase
        self.cavA.play(self.cavA_pulse, ampx=1.0, phase=self.disp_phase)
        qua.align()  

        self.qA.play(self.qubit_sel_pi)  
        qua.align()


        # Measure and wait
        self.resonator.measure(self.readout_pulse, (self.I, self.Q), ampx=self.ro_ampx, demod_type="dual")
        if self.plot_single_shot:  
            qm_qua.assign(self.single_shot,qm_qua.Cast.to_fixed(self.I > self.readout_pulse.threshold),)
        qua.wait(self.wait_time, self.resonator)


if __name__ == "__main__":
    """ """

    #################################### MODE MAP ######################################
    # key: name of the Mode as defined by the Experiment subclass
    # value: name of the Mode as defined by the user in modes.yml

    modes = {
        "drive": "drive",
        "qA": "qA",
        "qB": "qB",
        "cavA": "cavA",
        "cavB": "cavB",
        "resonator": "rrA",
        "resonatorB": "rrB",
    }

    ################################### PULSE MAP ######################################
    # key: name of the Pulse as defined by the Experiment subclass
    # value: name of the Pulse as defined by the user in modes.yml

    pulses = {
        "qubitB_grape": "qB_grape_fock1",
        "cavityB_grape": "cavB_grape_fock1",
        "drive_pulse": "exchange_pulse", 
        "cavA_pulse": "cavA_ramp_pulse",
        "cavB_pulse": "cavB_ramp_pulse",
        "qubit_sel_pi": "qA_gaussian_sel_pi_pulse",
        "qB_pulse": "qB_gaussian_sel_pi_pulse",
        "readout_pulse": "rrA_readout_pulse",
        "readout_pulseB": "rrB_readout_pulse",
    }

    ############################## CONTROL PARAMETERS ##################################

    parameters = {
        "wait_time": 5e6,
        "plot_single_shot": True,
        "qubit_in_e": False,
        "ro_ampx": 1,
    }

    ######################## SWEEP (INDEPENDENT) VARIABLES #############################
    # must include an outermost averaging Sweep named "N"
    # must include all primary sweeps defined by the Experiment subclass

    # set number of repetitions for this Experiment run
    N.num = 5000

    # set the delay sweep
    FREQ.name = "drive_frequency"
    FREQ.start = 57.675e6 - 200e6
    FREQ.stop = 57.675e6 + 240e6
    FREQ.num = 101
    DISPL_PHASE = Sweep(name="disp_phase", start=0.0, stop=1.0, step=0.05, dtype=float)
    sweeps = [N, DISPL_PHASE, FREQ]

    ######################## DATASET (DEPENDENT) VARIABLES #############################
    # must include all primary datasets defined by the Experiment subclass

    # MAG.axes = sweeps[1:]
    # PHASE.axes = sweeps[1:]
    SINGLE_SHOT.plot_args["plot_type"] = "image"

    PHASE.datafn_args = {"delay": 2.792e-7, "freq": RRA.int_freq}  # 2.792e-7
   
    PHASE.plot = False
    MAG.plot = False
    Q.plot = False
    I.plot = False
    datasets = [I, Q, SINGLE_SHOT]

    ######################## INITIALIZE AND RUN EXPERIMENT #############################

    expt = OutAndBackCrossKerr(FOLDER, modes, pulses, sweeps, datasets, **parameters)
    expt.run()



