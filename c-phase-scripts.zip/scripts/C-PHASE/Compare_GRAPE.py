from config.experiment_config import FOLDER, N, MAG, PHASE, SINGLE_SHOT, FREQ
from qcore import Experiment, qua, Sweep, Dataset
from qm.qua import *
from qm import qua as qm_qua

I = Dataset(name="I", save=True, plot=True)
Q = Dataset(name="Q", save=True, plot=True)
SINGLE_SHOT = Dataset(name="single_shot", save=True, plot=True)

class GRAPE(Experiment):
    """Compare several GRAPE pulses"""

    primary_datasets = ["I", "Q", "single_shot"]

    primary_sweeps = ["qubit_frequency"]

    def __init__(self, folder, modes, pulses, sweeps, datasets, **parameters):

        super().__init__(folder,modes,pulses,sweeps,datasets,**parameters,)  # Passes other parameters to parent


        self.grape_list = [
            (self.op1, self.op2),
            (self.op3, self.op4),
            # (self.op5, self.op6),
            # (self.op7, self.op8),
            # (self.op9, self.op10),
        ]


    def sequence(self):
        """QUA sequence that defines this Experiment subclass"""

        with switch_(self.gate_id):
            for i in range(len(self.grape_list)):
                with case_(i):
                    cav_grape, qb_grape = self.grape_list[i]
                    qua.update_frequency(self.qubit, self.qubit.int_freq)
                    self.cavity.play(cav_grape)
                    self.qubit.play(qb_grape)
                    qua.align(self.cavity, self.qubit)
                    qua.update_frequency(self.qubit, self.qubit_frequency)
                    self.qubit.play(self.selective)
                    qua.align(self.qubit, self.resonator)
                    self.resonator.measure(self.readout_pulse,(self.I, self.Q),ampx=self.ro_ampx,demod_type="dual",)
        qua.align()
        qua.wait(self.wait_time)
        if self.plot_single_shot:  # assign state to G or E
            qm_qua.assign(self.single_shot,qm_qua.Cast.to_fixed(self.I > self.readout_pulse.threshold),)


if __name__ == "__main__":
    """ """
    modes = {
        "qubit": "qB",
        "cavity": "cavB",
        "resonator": "rrB",
    }

    pulses = {
        "selective": "qB_gaussian_very_sel_pi_pulse",
        "readout_pulse": "rrB_CLEAR_readout_pulse",
        "op1":"cavB_grape_fock01", 
        "op2":"qB_grape_fock01",
        "op3":"cavB_grape_fock01_new", 
        "op4":"qB_grape_fock01_new",
        # "op5":"cavA_grape_fock04_2500",
        # "op6":"qA_grape_fock04_2500",
    }

    parameters = {
        "wait_time": 5e6,
        "ro_ampx": 1,
        "plot_single_shot": True,
    }

    N.num = 50000
    GATES = Sweep(name="gate_id", start=0, stop=1, step=1, dtype=int, save=True)
    
    FREQ.name = "qubit_frequency"
    FREQ.start = 248e6 
    FREQ.stop = 252e6
    FREQ.num = 101

    FREQ.start = 272e6 
    FREQ.stop = 277e6
    FREQ.num = 101

    sweeps = [N, GATES, FREQ]

    datasets = [I, Q, SINGLE_SHOT]

    GRAPE(FOLDER, modes, pulses, sweeps, datasets, **parameters).run()