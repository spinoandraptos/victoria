from config.experiment_config import FOLDER, N, FREQ, RRB, I, Q, SINGLE_SHOT
from qcore import Experiment, qua, Sweep, Dataset
from qm import qua as qm_qua
from qcore.libs.qua_macros import QuaVariable
import shutil
import os
from datetime import datetime
from scripts.qB_GE_experiments.T2_virtual_detuning_qB import QubitT2
from scripts.qB_GE_experiments.AllXY_qB import ALLXY


# SCREENSHOT FILE 
current_script_path = os.path.realpath(__file__) # Get the path to the current script
script_name = os.path.basename(current_script_path)[:-3] # Get filename only (e.g., 'my_script.py')
date, time = datetime.now().strftime("%Y-%m-%d %H-%M-%S").split()
destination_path = os.path.join(FOLDER + "data/" + str(date) + '/', f"{script_name}_screenhsot_{time}.py") # Define destination path
shutil.copy(current_script_path, destination_path) # Copy the script

SINGLE_SHOT_A = Dataset(
    name="single_shotA",
    save=True,
    plot=False, 
)
SINGLE_SHOT_A_BEFORE = Dataset(
    name="single_shotA_before",
    save=True,
    plot=False, 
)
SINGLE_SHOT_A_AFTER = Dataset(
    name="single_shotA_after",
    save=True,
    plot=False, 
)

SINGLE_SHOT_B = Dataset(
    name="single_shotB",
    save=True,
    plot=False, 
)
SINGLE_SHOT_B_BEFORE = Dataset(
    name="single_shotB_before",
    save=True,
    plot=False, 
)
SINGLE_SHOT_B_AFTER = Dataset(
    name="single_shotB_after",
    save=True,
    plot=False, 
)

SINGLE_SHOT_C_BEFORE = Dataset(
    name="single_shotC_before",
    save=True,
    plot=False, 
)
IC_BEFORE = Dataset(
    name="IC_before",
    save=False,
    plot=False, 
)
QC_BEFORE = Dataset(
    name="QC_before",
    save=False,
    plot=False, 
)

IA = Dataset(
    name="IA",
    save=False,
    plot=False, 
)
IA_BEFORE = Dataset(
    name="IA_before",
    save=False,
    plot=False, 
)
IA_AFTER = Dataset(
    name="IA_after",
    save=False,
    plot=False, 
)

QA = Dataset(
    name="QA",
    save=False,
    plot=False, 
)
QA_BEFORE = Dataset(
    name="QA_before",
    save=False,
    plot=False, 
)
QA_AFTER = Dataset(
    name="QA_after",
    save=False,
    plot=False, 
)

IB = Dataset(
    name="IB",
    save=False,
    plot=False, 
)
IB_BEFORE = Dataset(
    name="IB_before",
    save=False,
    plot=False, 
)
IB_AFTER = Dataset(
    name="IB_after",
    save=False,
    plot=False, 
)

QB = Dataset(
    name="QB",
    save=False,
    plot=False, 
)
QB_BEFORE= Dataset(
    name="QB_before",
    save=False,
    plot=False, 
)
QB_AFTER = Dataset(
    name="QB_after",
    save=False,
    plot=False, 
)

class WignersAB(Experiment):
    """Wigner_function"""

    ############################# DEFINE PRIMARY DATASETS ##############################
    # these Datasets form the "raw" experimental data and will be streamed by the OPX
    # they must be specified at experiment runtime
    primary_datasets = ["IA","IA_before", "IA_after", "QA", "QA_before", "QA_after", "single_shotA", "single_shotA_before", "single_shotA_after",
                        "IB","IB_before", "IB_after",  "QB","QB_before", "QB_after",  "single_shotB", "single_shotB_before", "single_shotB_after",
                        "IC_before", "QC_before", "single_shotC_before"]

    ############################## DEFINE PRIMARY SWEEPS ###############################
    # these Sweeps are uniquely associated with the Experiment subclass
    # these Sweeps must be specified at experiment runtime
    primary_sweeps = ["qb_phase"]

    ############################ DEFINE THE PULSE SEQUENCE #############################
    # ensure that you import 'qua' from 'qcore' and not from 'qm' library
    # attributes accessed via 'self' must be defined in 'if __name__ == "__main__"' code
    
    def sequence(self):
        factorA = qm_qua.declare(qm_qua.fixed)
        factorB = qm_qua.declare(qm_qua.fixed)
        qm_qua.assign(factorA, self.detuningA * 1e-9)  
        qm_qua.assign(factorB, self.detuningB * 1e-9)  
        total_phaseA = qm_qua.declare(qm_qua.fixed)
        total_phaseB = qm_qua.declare(qm_qua.fixed)

        qua.reset_frame(self.cavityA)
        qua.reset_frame(self.qubitA)
        qua.reset_frame(self.qubitA_EF)
        qua.reset_frame(self.cavityB)
        qua.reset_frame(self.qubitB)
        qua.reset_frame(self.drive)
        qua.reset_frame(self.drive_ramp)
        qm_qua.reset_global_phase()
        qua.align()

        # qm_qua.assign(self.phaseA, qm_qua.Cast.mul_fixed_by_int(factorA, self.drive_length))
        # qm_qua.assign(self.phaseB, qm_qua.Cast.mul_fixed_by_int(factorB, self.drive_length))
        # qm_qua.assign(total_phaseA, self.phaseA + 0.25 + self.ramp_phaseA)
        # qm_qua.assign(total_phaseB, self.phaseB + 0.25 + self.ramp_phaseB)

        # qua.update_frequency(self.drive, 345e6 - 6e6)
        # qua.update_frequency(self.drive_ramp, 345e6 - 6e6)

        qm_qua.assign(total_phaseA, 0.25 )
        qm_qua.assign(total_phaseB, 0.25 )


        # INITIALIZE
        # self.qubitA.play(self.qA_selective)
        # self.qubitA.play(self.qA_unselective)
        # qua.align(self.qubitA, self.rrA)
        # self.rrA.measure(self.readout_pulseA, (self.IA_before, self.QA_before), ampx=self.ro_ampx, demod_type = 'dual')  # measure transmitted signal

        # self.qubitB.play(self.qB_selective)
        # self.qubitB.play(self.qB_unselective)
        # qua.align(self.qubitB, self.rrB)
        # self.rrB.measure(self.readout_pulseB, (self.IB_before, self.QB_before), ampx=self.ro_ampx, demod_type = 'dual')  # measure transmitted signal

        # self.rrC.measure(self.readout_pulseC, (self.IC_before, self.QC_before), ampx=self.ro_ampx, demod_type = 'dual')  # measure transmitted signal
        
        # if self.plot_single_shot:  # assign state to G or E
        #         qm_qua.assign(self.single_shotA_before, qm_qua.Cast.to_fixed(self.IA_before > self.readout_pulseA.threshold),)
        #         qm_qua.assign(self.single_shotB_before, qm_qua.Cast.to_fixed(self.IB_before > self.readout_pulseB.threshold),)
        #         qm_qua.assign(self.single_shotC_before, qm_qua.Cast.to_fixed(self.IC_before > self.readout_pulseC.threshold),)

        # qua.wait(2000, self.rrA, self.rrB, self.rrC)
        
        # qua.align()
        # qua.update_frequency(self.drive, 225e6)
        # qua.update_frequency(self.qubitA,  self.qubitA.int_freq)

        # GRAPE 
        self.cavityA.play(self.cavA_grape)
        self.qubitA.play(self.qA_grape)
        self.cavityB.play(self.cavB_grape)
        self.qubitB.play(self.qB_grape)
        qua.align()



        #############################
        #DRIVE
        ############################
        # self.drive_ramp.play(self.exchange_ramp_up)
        # qua.align(self.drive, self.drive_ramp)
        # self.drive.play(self.exchange_constant, duration = self.drive_length/4)
        # qua.wait(self.drive_length-7, self.drive_ramp)
        # self.drive_ramp.play(self.exchange_ramp_down)
        # qua.align()

        ##############################
        #WIGNER A
        ##############################
        self.cavityA.play(self.cavA_op, ampx=(self.cavity_drive_I, -self.cavity_drive_Q, self.cavity_drive_Q, self.cavity_drive_I), phase= total_phaseA)  # displacement
        qua.align(self.cavityA, self.qubitA)
        self.qubitA.play(self.qubitA_pi2)  # play pi/2 pulse around X
        qua.wait(int(self.time_delayA), self.qubitA)  # conditional phase gate on even, odd Fock state
        self.qubitA.play(self.qubitA_pi2, phase = self.qb_phase)  # play pi/2 pulse around X
        qua.align(self.qubitA, self.qubitA_EF)  
        self.qubitA_EF.play(self.qubitA_EF_pi) 
        qua.align(self.qubitA_EF, self.rrA)  
        self.rrA.measure(self.readout_pulseA, (self.IA, self.QA), demod_type = 'dual')  # measure transmitted signal

        ############################
        #WIGNER B
        ############################
        self.cavityB.play(self.cavB_op, ampx=(self.cavity_drive_I, -self.cavity_drive_Q, self.cavity_drive_Q, self.cavity_drive_I), phase= total_phaseB)  # displacement
        qua.align(self.cavityB, self.qubitB)
        self.qubitB.play(self.qubitB_pi2)  # play pi/2 pulse around X
        qua.wait(int(self.time_delayB), self.qubitB)  # conditional phase gate on even, odd Fock state
        self.qubitB.play(self.qubitB_pi2, phase = self.qb_phase)  # play pi/2 pulse around X
        qua.align(self.qubitB, self.qubitB_EF)  
        self.qubitB_EF.play(self.qubitB_EF_pi) 
        qua.align(self.qubitB, self.rrB)  
        self.rrB.measure(self.readout_pulseB, (self.IB, self.QB), demod_type = 'dual')  # measure transmitted signal
        
        #self.rrC.measure(self.readout_pulseC, (self.IC, self.QC), ampx=self.ro_ampx, demod_type = 'dual')  # measure transmitted signal
        qua.align()
        qua.wait(self.wait_time)
        if self.plot_single_shot:  # assign state to G or E
            qm_qua.assign(self.single_shotA, qm_qua.Cast.to_fixed(self.IA > self.readout_pulseA.threshold),)
            qm_qua.assign(self.single_shotB, qm_qua.Cast.to_fixed(self.IB > self.readout_pulseB.threshold),)
            #qm_qua.assign(self.single_shotC, qm_qua.Cast.to_fixed(self.IC > self.readout_pulseC.threshold),)

grape_list_A = [
        "fock01_test",
    ]

grape_list_B = [
        "fock1",
    ]

for i in range (len(grape_list_A)):
    qA_grape = "qA_grape_" + grape_list_A[i]
    cavA_grape =  "cavA_grape_" + grape_list_A[i]
    for j in range(len(grape_list_B)):
        qB_grape = "qB_grape_" + grape_list_B[j]
        cavB_grape =  "cavB_grape_" + grape_list_B[j] 
        print(f"Starting {grape_list_A[i]}_A x 0_B experiment")

        if __name__ == "__main__":
            """ """

            modes = {
                "cavityA": "cavA",
                "cavityB": "cavB",
                "qubitA": "qA",
                "qubitB": "qB", 
                "qubitA_EF":"qA_EF",
                "qubitB_EF":"qB_EF",
                "drive": "drive", 
                "drive_ramp": "drive_ramp", 
                "rrA": "rrA",
                "rrB": "rrB",
                "rrC": "rrC",
            }

            pulses = {
                "qA_grape": qA_grape,
                "cavA_grape": cavA_grape,
                "qB_grape": qB_grape,
                "cavB_grape": cavB_grape,
                "cavA_op": "cavA_ramp_pulse",
                "cavB_op": "cavB_ramp_pulse",
                "qubitA_pi2": "qA_gaussian_pi2_pulse",
                "qubitB_pi2": "qB_gaussian_pi2_pulse",
                "exchange_ramp_up": "exchange_ramp_up",
                "exchange_constant": "exchange_pulse",
                "exchange_ramp_down": "exchange_ramp_down",
                "readout_pulseA": "rrA_GF_CLEAR_readout_pulse",
                "readout_pulseB": "rrB_GF_CLEAR_readout_pulse",
                "readout_pulseC": "rrC_readout_pulse",
                "qA_selective": "qA_gaussian_very_sel_pi_pulse",
                "qB_selective": "qB_gaussian_very_sel_pi_pulse",
                "qubitA_EF_pi": "qAEF_EF_gaussian_pi_pulse",
                "qubitB_EF_pi": "qBEF_gaussian_pi_pulse",
                "qA_unselective": "qA_gaussian_pi_pulse",
                "qB_unselective": "qB_gaussian_pi_pulse",
            }

            ############################## CONTROL PARAMETERS ##################################
            parameters = {
                "ramp_phaseA": -0.1+0.007, 
                "ramp_phaseB": -0.036, 
                "detuningA": -818e3, 
                "detuningB": -233e3+3.5e3-1.4e3, 
                "phaseA": QuaVariable(value=0.0,dtype=qm_qua.fixed,tag="phaseA",buffer=True,stream=True,),
                "phaseB": QuaVariable(value=0.0,dtype=qm_qua.fixed,tag="phaseB",buffer=True,stream=True,),
                "wait_time": 7e6,
                "time_delayA": 520,
                "time_delayB": 156, 
                # "qb_phase": 0,
                "plot_single_shot": True,
            }

            N.num = 10000
            QD_AMPX_I = Sweep(name="cavity_drive_I", start=-1.8, stop=1.8, num = 41) ###PREV 0.2
            QD_AMPX_Q = Sweep(name="cavity_drive_Q", start=-1.8, stop=1.8, num = 41) ###PREV 0.2
            
            LENGTH = Sweep (name="drive_length", dtype=int, units = "ns")
            LENGTH.start = 0
            LENGTH.stop = 5200
            LENGTH.step = 60 ###PREV 2000

            PARITY = Sweep (name="qb_phase", dtype=float)
            PARITY.start = 0.0
            PARITY.stop = 0.5
            PARITY.step = 0.5

            sweeps = [N, QD_AMPX_Q, QD_AMPX_I, PARITY]
            # sweeps = [N, QD_AMPX_Q, QD_AMPX_I]
            # sweeps = [N, PARITY, QD_AMPX_I]

            SINGLE_SHOT_A.plot = True
            SINGLE_SHOT_B.plot = True

            SINGLE_SHOT_A.plot_args["plot_type"] = "image"
            SINGLE_SHOT_B.plot_args["plot_type"] = "image"

            datasets = [IA, IA_BEFORE, IA_AFTER, 
                        QA, QA_BEFORE, QA_AFTER, 
                        SINGLE_SHOT_A, SINGLE_SHOT_A_BEFORE, SINGLE_SHOT_A_AFTER,
                        IB, IB_BEFORE, IB_AFTER, 
                        QB, QB_BEFORE, QB_AFTER, 
                        SINGLE_SHOT_B, SINGLE_SHOT_B_BEFORE, SINGLE_SHOT_B_AFTER,
                        IC_BEFORE, QC_BEFORE, SINGLE_SHOT_C_BEFORE]

            expt = WignersAB(FOLDER, modes, pulses, sweeps, datasets, **parameters)
            expt.run(simulate=False, filename_suffix=cavA_grape + cavB_grape)
   



        # modes_B = {
        #     "qubit": "qB",
        #     "resonator": "rrB",
        # }
        # modes_A = {
        #     "qubit": "qA",
        #     "resonator": "rrA",
        # }
        # pulses_B = {
        #     "qubit_pi_op": "qB_gaussian_pi_pulse",
        #     "qubit_pi2_op": "qB_gaussian_pi2_pulse",
        #     "readout_pulse": "rrB_CLEAR_readout_pulse",
        # }
        # pulses_A = {
        #     "qubit_pi_op": "qA_gaussian_pi_pulse",
        #     "qubit_pi2_op": "qA_gaussian_pi2_pulse",
        #     "readout_pulse": "rrA_CLEAR_readout_pulse",
        # }
        
        # #### ALLXY check
        # N.num = 10000
        # GATES = Sweep(name="gate_id", start=0, stop=21, num=22, dtype=int, save=True)
        # sweeps_ALLXY = [N, GATES]
        # datasets_ALLXY = [I, Q, SINGLE_SHOT]
        # I.plot , Q.plot, SINGLE_SHOT.plot = False, False, False
        # parameters_ALLXY = {
        #     "wait_time": 500_000,
        #     "ro_ampx": 1,
        #     "plot_single_shot": True,

        # }
        # ALLXY(FOLDER, modes_B, pulses_B, sweeps_ALLXY, datasets_ALLXY, **parameters_ALLXY).run()
        # ALLXY(FOLDER, modes_A, pulses_A, sweeps_ALLXY, datasets_ALLXY, **parameters_ALLXY).run()
        
        # #### T2 check
        # N.num = 5000
        # DEL = Sweep(name="time_delay", start=16, stop=200_000, step=800, dtype=int)  # ns
        # sweeps_T2 = [N, DEL]
        # datasets_T2 = [I, Q, SINGLE_SHOT]
        # I.plot , Q.plot, SINGLE_SHOT.plot = False, False, False
        # parameters_T2 = {
        #     "wait_time": 500_000,
        #     "ro_ampx": 1,
        #     "detuning": 0.1e6,  # Hz
        #     "phase": QuaVariable(
        #         value=0.0,
        #         dtype=qm_qua.fixed,
        #         tag="phase",
        #         buffer=True,
        #         stream=True,
        #     ),
        #     "plot_single_shot": True,
        # }
        # QubitT2(FOLDER, modes_B, pulses_B, sweeps_T2, datasets_T2, **parameters_T2).run()
        # QubitT2(FOLDER, modes_A, pulses_A, sweeps_T2, datasets_T2, **parameters_T2).run()


print("DONE!!!")