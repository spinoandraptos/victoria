import numpy as np
import os
import h5py
import matplotlib.pyplot as plt
from scipy.optimize import curve_fit

file = r"C:\Users\admin\Desktop\cphase\data\2025-10-18\00-34-26_WignersAB.hdf5"

data =  h5py.File(file, "r")

data_A = np.average(np.array(data["single_shotA"]), axis=0)*2-1

data_B = np.average(np.array(data["single_shotB"]), axis=0)*2-1

print(np.shape(data_A))


# XY DATA
drive_length = data["drive_length"]
I_values = data['cavity_drive_I']
Q_values = data['cavity_drive_Q']


x_axis, y_axis = np.meshgrid(I_values, Q_values)

# PLOTTING
fig, axs = plt.subplots(len(drive_length), 2, figsize=(4, 20))

for i, length in enumerate(drive_length):
    # Wigner Alice
    mesh_A = axs[i, 0].pcolormesh(x_axis, y_axis, data_A[:, :, i], cmap='bwr', vmin=-1, vmax=1)
    axs[i, 0].set_title('Alice, Drive: {}'.format(length))
    axs[i, 0].set_aspect('equal')
    axs[i, 0].axis('tight')
    plt.colorbar(mesh_A, ax=axs[i, 0])

    # Wigner Bob
    mesh_B = axs[i, 1].pcolormesh(x_axis, y_axis, data_B[:, :, i], cmap='bwr', vmin=-1, vmax=1)
    axs[i, 1].set_title('Bob, Drive: {}'.format(length))
    axs[i, 1].set_aspect('equal')
    axs[i, 1].axis('tight')
    plt.colorbar(mesh_B, ax=axs[i, 1])

plt.tight_layout()
plt.show()

# plt.plot(np.transpose(I_values, data_A[:,10,0]))
# plt.show()
# # print(np.shape(? data_A[:,10,0]))
