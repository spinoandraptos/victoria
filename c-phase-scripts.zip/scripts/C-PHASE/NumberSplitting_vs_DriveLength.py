from config.experiment_config import FOLDER, N, FREQ, I, Q, MAG, PHASE, RRC, SINGLE_SHOT, RRA
from qm import qua as qm_qua
from qcore import Experiment, qua, Sweep, Dataset


SINGLE_SHOT_A = Dataset(
    name="single_shotA",
    save=True,
    plot=False, 
)
SINGLE_SHOT_A_BEFORE = Dataset(
    name="single_shotA_before",
    save=True,
    plot=False, 
)
SINGLE_SHOT_A_AFTER = Dataset(
    name="single_shotA_after",
    save=True,
    plot=False, 
)

SINGLE_SHOT_B = Dataset(
    name="single_shotB",
    save=True,
    plot=False, 
)
SINGLE_SHOT_B_BEFORE = Dataset(
    name="single_shotB_before",
    save=True,
    plot=False, 
)
SINGLE_SHOT_B_AFTER = Dataset(
    name="single_shotB_after",
    save=True,
    plot=False, 
)

SINGLE_SHOT_C = Dataset(
    name="single_shotC",
    save=True,
    plot=False, 
)
IC = Dataset(
    name="IC",
    save=False,
    plot=False, 
)
QC = Dataset(
    name="QC",
    save=False,
    plot=False, 
)

IA = Dataset(
    name="IA",
    save=False,
    plot=False, 
)
IA_BEFORE = Dataset(
    name="IA_before",
    save=False,
    plot=False, 
)
IA_AFTER = Dataset(
    name="IA_after",
    save=False,
    plot=False, 
)

QA = Dataset(
    name="QA",
    save=False,
    plot=False, 
)
QA_BEFORE = Dataset(
    name="QA_before",
    save=False,
    plot=False, 
)
QA_AFTER = Dataset(
    name="QA_after",
    save=False,
    plot=False, 
)

IB = Dataset(
    name="IB",
    save=False,
    plot=False, 
)
IB_BEFORE = Dataset(
    name="IB_before",
    save=False,
    plot=False, 
)
IB_AFTER = Dataset(
    name="IB_after",
    save=False,
    plot=False, 
)

QB = Dataset(
    name="QB",
    save=False,
    plot=False, 
)
QB_BEFORE= Dataset(
    name="QB_before",
    save=False,
    plot=False, 
)
QB_AFTER = Dataset(
    name="QB_after",
    save=False,
    plot=False, 
)

class NumberSplitting(Experiment):
    """Number splitting"""

    primary_datasets = ["IA", "QA", "single_shotA",
                        "IB", "QB", "single_shotB",
                        "IC", "QC", "single_shotC"]

    primary_sweeps = ["qubit_frequency"]

    def sequence(self):
        """QUA sequence that defines this Experiment subclass"""
        qua.reset_frame(self.cavityA)
        qua.reset_frame(self.cavityB)
        qua.reset_frame(self.qubitA)
        qua.reset_frame(self.qubitB)

        qua.update_frequency(self.qubitA, self.qubitA.int_freq)
        qua.update_frequency(self.qubitB, self.qubitB.int_freq)
        qua.align()

        # self.cavityA.play(self.cavityA_grape)
        # self.qubitA.play(self.qubitA_grape)
        self.cavityB.play(self.cavityB_grape)
        self.qubitB.play(self.qubitB_grape)
        qua.align()

        self.drive.play(self.exchange_pulse, ampx = 1.9, duration = self.drive_length/4)
        qua.align()

        # qua.update_frequency(self.qubitA, self.qubit_frequency)
        # self.qubitA.play(self.qubitA_spec_pulse)
        # qua.update_frequency(self.qubitA, 133.62e6)
        # self.qubitA.play(self.qubitA_EF_pi)

        # qua.update_frequency(self.qubitB, self.qubit_frequency)
        # self.qubitB.play(self.qubitB_spec_pulse)
        # qua.update_frequency(self.qubitB, 37.71e6)
        # self.qubitB.play(self.qubitB_EF_pi)
        
        # qua.update_frequency(self.qubitC, self.qubit_frequency)
        # self.qubitC.play(self.qubitC_spec_pulse)
        # qua.align()

        # Measurement
        self.rrA.measure(self.readout_pulseA, (self.IA, self.QA), ampx=self.ro_ampx, demod_type="dual")
        self.rrB.measure(self.readout_pulseB, (self.IB, self.QB), ampx=self.ro_ampx, demod_type = 'dual')  # measure transmitted signal
        self.rrC.measure(self.readout_pulseC, (self.IC, self.QC), ampx=self.ro_ampx, demod_type = 'dual')  # measure transmitted signal

        qua.align()
        qua.wait(self.wait_time)

        if self.plot_single_shot:  # assign state to G or E
            qm_qua.assign(self.single_shotA,qm_qua.Cast.to_fixed(self.IA > self.readout_pulseA.threshold),)
            qm_qua.assign(self.single_shotB,qm_qua.Cast.to_fixed(self.IB > self.readout_pulseB.threshold),)


if __name__ == "__main__":
    """ """

    modes = {
        "cavityA": "cavA",
        "cavityB": "cavB",
        "qubitA":"qA",
        "qubitB":"qB",
        "qubitC":"qC",
        "drive":"drive",
        "rrA": "rrA",
        "rrB": "rrB",
        "rrC": "rrC", 
    }

    pulses = {
        "cavity_pulse": "cavA_ramp_pulse",
        "cavityA_grape":"cavA_grape_fock01",
        "qubitA_grape":"qA_grape_fock01", 
        "cavityB_grape":"cavB_grape_fock1",
        "qubitB_grape":"qB_grape_fock1", 
        "qubitA_spec_pulse": "qA_gaussian_very_sel_pi_pulse",
        "qubitA_EF_pi": "qA_EF_gaussian_pi_pulse",
        "qubitB_spec_pulse": "qB_gaussian_very_sel_pi_pulse",
        "qubitB_EF_pi": "qB_EF_gaussian_pi_pulse",
        "qubitC_spec_pulse": "qC_gaussian_sel_pi_pulse",
        "exchange_pulse": "exchange_pulse",
        "readout_pulseA": "rrA_GF_CLEAR_readout_pulse",
        "readout_pulseB": "rrB_GF_CLEAR_readout_pulse",
        "readout_pulseC": "rrC_readout_pulse",
    }
                                       
    parameters = {
        "wait_time": 5e6,
        "ro_ampx": 1,
        "plot_single_shot": True,
        "drive_length": 164,
    }

    N.num = 10000

    FREQ.name = "qubit_frequency"
    FREQ.start = 50e6 
    FREQ.stop = 60e6
    FREQ.num = 101

    # QD_AMPX = Sweep(name="drive_amp", dtype = float, start= 0.0, stop = 2.0, step = 0.2) #needs to be floating point numbers 
    
    sweeps = [N, FREQ]
    # sweeps = [N, QD_AMPX, FREQ]
    
    SINGLE_SHOT_A.plot = True
    SINGLE_SHOT_B.plot = True
    QC.plot = True 

    SINGLE_SHOT_A.fitfn = "gaussian"
    SINGLE_SHOT_B.fitfn = "gaussian"
    QC.fitfn = "gaussian"

    # SINGLE_SHOT.plot_args["plot_type"] = "image"

    datasets = [IA, QA, SINGLE_SHOT_A, 
                IB, QB, SINGLE_SHOT_B,
                IC, QC, SINGLE_SHOT_C]

    expt = NumberSplitting(FOLDER, modes, pulses, sweeps, datasets, **parameters)
    expt.run(simulate = False)
