from config.experiment_config import FOLDER, N, FREQ, RRB, I, Q, SINGLE_SHOT
from qcore import Experiment, qua, Sweep, Dataset
from qm import qua as qm_qua
from qcore.libs.qua_macros import QuaVariable
import shutil
import os
from datetime import datetime
from scripts.qB_GE_experiments.T2_virtual_detuning_qB import QubitT2
from scripts.qB_GE_experiments.AllXY_qB import ALLXY


# SCREENSHOT FILE 
current_script_path = os.path.realpath(__file__) # Get the path to the current script
script_name = os.path.basename(current_script_path)[:-3] # Get filename only (e.g., 'my_script.py')
date, time = datetime.now().strftime("%Y-%m-%d %H-%M-%S").split()
destination_path = os.path.join(FOLDER + "data/" + str(date) + '/', f"{script_name}_screenhsot_{time}.py") # Define destination path
shutil.copy(current_script_path, destination_path) # Copy the script

SINGLE_SHOT_A = Dataset(
    name="single_shotA",
    save=True,
    plot=False, 
)
SINGLE_SHOT_A_BEFORE = Dataset(
    name="single_shotA_before",
    save=True,
    plot=False, 
)
SINGLE_SHOT_B = Dataset(
    name="single_shotB",
    save=True,
    plot=False, 
)
SINGLE_SHOT_B_BEFORE = Dataset(
    name="single_shotB_before",
    save=True,
    plot=False, 
)
SINGLE_SHOT_C = Dataset(
    name="single_shotC",
    save=True,
    plot=False, 
)
SINGLE_SHOT_C_BEFORE = Dataset(
    name="single_shotC_before",
    save=True,
    plot=False, 
)
IC = Dataset(
    name="IC",
    save=False,
    plot=False, 
)
IC_BEFORE = Dataset(
    name="IC_before",
    save=False,
    plot=False, 
)
QC = Dataset(
    name="QC",
    save=False,
    plot=False, 
)
QC_BEFORE = Dataset(
    name="QC_before",
    save=False,
    plot=False, 
)
IA = Dataset(
    name="IA",
    save=False,
    plot=False, 
)
IA_BEFORE = Dataset(
    name="IA_before",
    save=False,
    plot=False, 
)
QA = Dataset(
    name="QA",
    save=False,
    plot=False, 
)
QA_BEFORE = Dataset(
    name="QA_before",
    save=False,
    plot=False, 
)
IB = Dataset(
    name="IB",
    save=False,
    plot=False, 
)
IB_BEFORE = Dataset(
    name="IB_before",
    save=False,
    plot=False, 
)
QB = Dataset(
    name="QB",
    save=False,
    plot=False, 
)
QB_BEFORE= Dataset(
    name="QB_before",
    save=False,
    plot=False, 
)


class WignersAB(Experiment):
    """Wigner_function"""

    ############################# DEFINE PRIMARY DATASETS ##############################
    # these Datasets form the "raw" experimental data and will be streamed by the OPX
    # they must be specified at experiment runtime
    primary_datasets = ["IA", "IA_before", "QA", "QA_before", "single_shotA", "single_shotA_before", 
                        "IB", "IB_before", "QB", "QB_before", "single_shotB", "single_shotB_before", 
                        "IC", "IC_before", "QC", "QC_before", "single_shotC", "single_shotC_before"]

    ############################## DEFINE PRIMARY SWEEPS ###############################
    # these Sweeps are uniquely associated with the Experiment subclass
    # these Sweeps must be specified at experiment runtime
    primary_sweeps = ["drive_length"]

    ############################ DEFINE THE PULSE SEQUENCE #############################
    # ensure that you import 'qua' from 'qcore' and not from 'qm' library
    # attributes accessed via 'self' must be defined in 'if __name__ == "__main__"' code
    
    def sequence(self):
        factorA = qm_qua.declare(qm_qua.fixed)
        factorB = qm_qua.declare(qm_qua.fixed)
        qm_qua.assign(factorA, self.detuningA * 1e-9)  
        qm_qua.assign(factorB, self.detuningB * 1e-9)  
        qm_qua.assign(self.phaseA, qm_qua.Cast.mul_fixed_by_int(factorA, self.drive_length))
        qm_qua.assign(self.phaseB, qm_qua.Cast.mul_fixed_by_int(factorB, self.drive_length))
        total_phaseA = qm_qua.declare(qm_qua.fixed)
        total_phaseB = qm_qua.declare(qm_qua.fixed)
        qm_qua.assign(total_phaseA, self.phaseA + 0.25)
        qm_qua.assign(total_phaseB, self.phaseB + 0.25)

        qua.reset_frame(self.cavityA)
        # qua.reset_phase(self.cavityA)
        qua.reset_frame(self.qubitA)
        # qua.reset_phase(self.qubitA)
        qua.reset_frame(self.cavityB)
        # qua.reset_phase(self.cavityB)
        qua.reset_frame(self.qubitB)
        qua.reset_phase(self.qubitB)
        qua.reset_frame(self.qubitB_EF)
        # qua.reset_phase(self.qubitB_EF)
        qua.reset_frame(self.drive)
        # qua.reset_phase(self.drive)

        # INITIALIZE A 
        # self.qubitA.play(self.qA_selective)
        # self.qubitA.play(self.qA_unselective)
        # qua.align(self.qubitA, self.rrA)
        # self.rrA.measure(self.readout_pulseA, (self.IA_before, self.QA_before), ampx=self.ro_ampx, demod_type = 'dual')  # measure transmitted signal
        # # INITIALIZE B
        # self.qubitB.play(self.qB_selective)
        # self.qubitB.play(self.qB_unselective)
        # qua.align(self.qubitB, self.qubitB_EF)  
        # self.qubitB_EF.play(self.qubitB_EF_drive)  # play pi/2 pulse around X
        # qua.align(self.qubitB_EF, self.rrB)  
        # self.rrB.measure(self.readout_pulseB, (self.IB_before, self.QB_before), ampx=self.ro_ampx, demod_type = 'dual')  # measure transmitted signal
        # # INITIALIZE C
        # self.rrC.measure(self.readout_pulseC, (self.IC_before, self.QC_before), ampx=self.ro_ampx, demod_type = 'dual')  # measure transmitted signal
        
        # if self.plot_single_shot:  # assign state to G or E
        #         qm_qua.assign(self.single_shotA_before, qm_qua.Cast.to_fixed(self.IA_before > self.readout_pulseA.threshold),)
        #         qm_qua.assign(self.single_shotB_before, qm_qua.Cast.to_fixed(self.IB_before > self.readout_pulseB.threshold),)
        #         qm_qua.assign(self.single_shotC_before, qm_qua.Cast.to_fixed(self.IC_before > self.readout_pulseC.threshold),)

        # qua.wait(2000, self.rrA, self.rrB, self.rrC)
        
        qua.align()

        # GRAPE A & B
        self.cavityA.play(self.cavA_grape)
        self.qubitA.play(self.qA_grape)
        self.cavityB.play(self.cavB_grape)
        self.qubitB.play(self.qB_grape)
        qua.align()
        
        self.drive.play(self.drive_pulse, ampx= 2.0, duration = self.drive_length/4)
        qua.align() 

        self.cavityA.play(self.cavA_op, ampx=(0.5, -0.0, 0.0, 0.5), phase= total_phaseA)  # displacement
        qua.align(self.cavityA, self.qubitA)
        qua.update_frequency(self.qubitA, 250.22e6) # fock2 frequency
        self.qubitA.play(self.qA_selective)
        qua.update_frequency(self.qubitA,  self.qubitA_EF_freq)
        self.qubitA.play(self.qubitA_EF_pi)  # play pi/2 pulse around X
        qua.align(self.qubitA, self.rrA) 
        self.rrA.measure(self.readout_pulseA, (self.IA, self.QA), ampx=self.ro_ampx, demod_type = 'dual')  # measure transmitted signal
        
        # WIGNER B
        self.cavityB.play(self.cavB_op, ampx=(0.5, -0.0, 0.0, 0.5), phase= total_phaseB)  # displacement
        qua.align(self.cavityB, self.qubitB)
        qua.update_frequency(self.qubitB, 271.26e6) # fock2 frequency
        self.qubitB.play(self.qB_selective_2)
        qua.align(self.qubitB, self.qubitB_EF)
        self.qubitB_EF.play(self.qubitB_EF_pi)  # play pi/2 pulse around X
        qua.align(self.qubitB_EF, self.rrB)  
        self.rrB.measure(self.readout_pulseB, (self.IB, self.QB), ampx=self.ro_ampx, demod_type = 'dual')  # measure transmitted signal
                    
        if self.plot_single_shot:  # assign state to G or E
            qm_qua.assign(self.single_shotA, qm_qua.Cast.to_fixed(self.IA > self.readout_pulseA.threshold))
            qm_qua.assign(self.single_shotB, qm_qua.Cast.to_fixed(self.IB > self.readout_pulseB.threshold))

        qua.align()
        qua.wait(self.wait_time)

 
if __name__ == "__main__":
    """ """

    modes = {
            "cavityA": "cavA",
            "cavityB": "cavB",
            "qubitA": "qA",
            # "qubitA_EF":"qA_EF",
            "qubitB": "qB", 
            "qubitB_EF":"qB_EF",
            "drive": "drive",           
            "rrA": "rrA",
            "rrB": "rrB"
    }

    pulses = {
        "qA_grape": "qA_grape_fock01",
        "cavA_grape": "cavA_grape_fock01",
        "qB_grape": "qB_grape_fock01",
        "cavB_grape": "cavB_grape_fock01",
        "cavA_op": "cavA_ramp_pulse",
        "cavB_op": "cavB_ramp_pulse",
        "qubitA_pi2": "qA_gaussian_pi2_pulse",
        "qubitB_pi2": "qB_gaussian_pi2_pulse",
        "drive_pulse": "exchange_pulse",
        "readout_pulseA": "rrA_GF_CLEAR_readout_pulse",
        "readout_pulseB": "rrB_GF_CLEAR_readout_pulse",
        "qA_selective": "qA_gaussian_very_sel_pi_pulse",
        "qB_selective": "qB_gaussian_very_sel_pi_pulse",
        "qB_selective_2": "qB_gaussian_very_sel_pi_pulse_fock2",
        "qubitA_EF_pi": "qA_EF_gaussian_pi_pulse",
        "qubitB_EF_pi": "qB_EF_gaussian_pi_pulse",
        "qA_unselective": "qA_gaussian_pi_pulse",
        "qB_unselective": "qB_gaussian_pi_pulse",
            }

    ############################## CONTROL PARAMETERS ##################################
    parameters = {
        "detuningA": -444.3e3,
        "detuningB": 181.8e3,
        "phaseA": QuaVariable(value=0.0,dtype=qm_qua.fixed,tag="phaseA",buffer=True,stream=True,),
        "phaseB": QuaVariable(value=0.0,dtype=qm_qua.fixed,tag="phaseB",buffer=True,stream=True,),
        "wait_time": 6e6,
        "ro_ampx": 1,
        "time_delayA": 564,
        "time_delayB": 172, 
        "qb_phase":0,
        "plot_single_shot": True,
        "qubit_drive_ampx": 1.0,
        "qubitA_EF_freq": 133.62e6,
    }

    N.num = 5000
    QD_AMPX_I = Sweep(name="cavity_drive_I", start=-1.8, stop=1.8, num = 41) ###PREV 0.2
    QD_AMPX_Q = Sweep(name="cavity_drive_Q", start=-1.8, stop=1.8, num = 41) ###PREV 0.2
    
    LENGTH = Sweep (name="drive_length", dtype=int, units = "ns")
    LENGTH.start = 16
    LENGTH.stop = 12000
    LENGTH.step = 16 ###PREV 2000

    PARITY = Sweep (name="qb_phase", dtype=float)
    PARITY.start = 0.0
    PARITY.stop = 0.5
    PARITY.step = 0.5

    # DRIVE_AMPX = Sweep(name="drive_amp", start=1.798, stop=1.808, step = 0.002) ###PREV 0.2
    
    sweeps = [N, LENGTH]
    # sweeps = [N, QD_AMPX_Q, QD_AMPX_I, LENGTH, PARITY]

    # SINGLE_SHOT_A.plot_args["plot_type"] = "image"
    # SINGLE_SHOT_B.plot_args["plot_type"] = "image"

    datasets = [IA, IA_BEFORE,  
                QA, QA_BEFORE, 
                SINGLE_SHOT_A, SINGLE_SHOT_A_BEFORE, 
                IB, IB_BEFORE,  
                QB, QB_BEFORE, 
                SINGLE_SHOT_B, SINGLE_SHOT_B_BEFORE, 
                IC, QC, SINGLE_SHOT_C,
                IC_BEFORE, QC_BEFORE, SINGLE_SHOT_C_BEFORE]

    SINGLE_SHOT_A.plot = True
    expt = WignersAB(FOLDER, modes, pulses, sweeps, datasets, **parameters)
    expt.run(simulate=False, filename_suffix="entanglement")
