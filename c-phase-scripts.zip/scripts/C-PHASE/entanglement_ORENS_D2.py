from config.experiment_config import FOLDER, N, FREQ, RRB, I, Q, SINGLE_SHOT
from qcore import Experiment, qua, Sweep, Dataset
from qm import qua as qm_qua
from qcore.libs.qua_macros import QuaVariable
import shutil
import os
from datetime import datetime
from scripts.qB_GE_experiments.T2_virtual_detuning_qB import QubitT2
from scripts.qB_GE_experiments.AllXY_qB import ALLXY
from qm.qua import *

# SCREENSHOT FILE 
current_script_path = os.path.realpath(__file__) # Get the path to the current script
script_name = os.path.basename(current_script_path)[:-3] # Get filename only (e.g., 'my_script.py')
date, time = datetime.now().strftime("%Y-%m-%d %H-%M-%S").split()
destination_path = os.path.join(FOLDER + "data/" + str(date) + '/', f"{script_name}_screenhsot_{time}.py") # Define destination path
shutil.copy(current_script_path, destination_path) # Copy the script

IA_PARITY= Dataset(name="IA_parity",save=True,plot=False)
QA_PARITY = Dataset(name="QA_parity",save=False,plot=False)
SINGLE_SHOT_A_PARITY = Dataset(name="single_shotA_parity",save=True,plot=False)

IA = Dataset(name="IA",save=False,plot=False)
QA = Dataset(name="QA",save=False,plot=False)
SINGLE_SHOT_A = Dataset(name="single_shotA",save=True,plot=False)
SINGLE_SHOT_A_AFTER = Dataset(name="single_shotA_after",save=True,plot=False)

IB_PARITY = Dataset(name="IB_parity",save=True,plot=False)
QB_PARITY = Dataset(name="QB_parity",save=False,plot=False)
SINGLE_SHOT_B_PARITY = Dataset(name="single_shotB_parity",save=True,plot=False)

IB = Dataset(name="IB",save=False,plot=False)
QB = Dataset(name="QB",save=False,plot=False)
SINGLE_SHOT_B = Dataset(name="single_shotB",save=True,plot=False)
SINGLE_SHOT_B_AFTER = Dataset(name="single_shotB_after",save=True,plot=False)


class ORENS_AB(Experiment):
    """Wigner_function"""

    primary_datasets = ["IA_parity", "QA_parity", "single_shotA_parity",
                        "IA", "QA", "single_shotA",
                        "IB_parity", "QB_parity", "single_shotB_parity",
                        "IB", "QB", "single_shotB",]

    primary_sweeps = ["orens_id"]


    def __init__(self, folder, modes, pulses, sweeps, datasets, **parameters):

        super().__init__(folder,modes,pulses,sweeps,datasets, **parameters,)  # Passes other parameters to parent

        #self.pulse_list = [f"self.exchange_pulse_cos2_{d}" for d in range (self.time_start, self.time_stop+self.time_step, self.time_step)]

        self.orens_points = [
            [-0.67152985, -0.34296374, -0.67152985, -0.34296374],
            [-0.67152985, -0.34296374, 0.4261962, 0.29391114],
            [-0.67152985, -0.34296374, 0.97668197, -0.76566442],
            [-0.67152985, -0.34296374, -0.30305089, 0.2026751],
            [-0.67152985, -0.34296374, 0.03902931, -0.43510274],
            [0.4261962, 0.29391114, -0.67152985, -0.34296374],
            [0.4261962, 0.29391114, 0.4261962, 0.29391114],
            [0.4261962, 0.29391114, 0.97668197, -0.76566442],
            [0.4261962, 0.29391114, -0.30305089, 0.2026751],
            [0.4261962, 0.29391114, 0.03902931, -0.43510274],
            [0.97668197, -0.76566442, -0.67152985, -0.34296374],
            [0.97668197, -0.76566442, 0.4261962, 0.29391114],
            [0.97668197, -0.76566442, 0.97668197, -0.76566442],
            [0.97668197, -0.76566442, -0.30305089, 0.2026751],
            [0.97668197, -0.76566442, 0.03902931, -0.43510274],
            [-0.30305089, 0.2026751, -0.67152985, -0.34296374],
            [-0.30305089, 0.2026751, 0.4261962, 0.29391114],
            [-0.30305089, 0.2026751, 0.97668197, -0.76566442],
            [-0.30305089, 0.2026751, -0.30305089, 0.2026751],
            [-0.30305089, 0.2026751, 0.03902931, -0.43510274],
            [0.03902931, -0.43510274, -0.67152985, -0.34296374],
            [0.03902931, -0.43510274, 0.4261962, 0.29391114],
            [0.03902931, -0.43510274, 0.97668197, -0.76566442],
            [0.03902931, -0.43510274, -0.30305089, 0.2026751],
            [0.03902931, -0.43510274, 0.03902931, -0.43510274]
             ]  

    def sequence(self):
        """QUA sequence that defines this Experiment subclass"""
        qua.reset_frame(self.cavityA)
        qua.reset_frame(self.qubitA)
        qua.reset_frame(self.qubitA_EF)
        qua.reset_frame(self.cavityB)
        qua.reset_frame(self.qubitB)
        qua.reset_frame(self.qubitB_EF)
        qua.reset_frame(self.drive)
        qm_qua.reset_global_phase()
        total_phase_A = qm_qua.declare(qm_qua.fixed)
        total_phase_B = qm_qua.declare(qm_qua.fixed)
        dispA_I = qm_qua.declare(qm_qua.fixed)
        dispA_Q = qm_qua.declare(qm_qua.fixed)
        dispB_I = qm_qua.declare(qm_qua.fixed)
        dispB_Q = qm_qua.declare(qm_qua.fixed)

        with switch_(self.orens_id):
            for i in range(len(self.orens_points)):
                with case_(i):
                    qm_qua.assign(dispA_I, self.orens_points[i][0])
                    qm_qua.assign(dispA_Q, self.orens_points[i][1])
                    qm_qua.assign(dispB_I, self.orens_points[i][2])
                    qm_qua.assign(dispB_Q, self.orens_points[i][3])

        qua.update_frequency(self.drive, 371e6 - 7e6)
        qua.update_frequency(self.qubitA, self.qubitA.int_freq)
        qua.update_frequency(self.qubitB, self.qubitB.int_freq)
        qua.align()

        self.cavityA.play(self.cavA_grape01)
        self.qubitA.play(self.qA_grape01)
        self.cavityB.play(self.cavB_grape01)
        self.qubitB.play(self.qB_grape01)
        qua.align()

        qm_qua.assign(total_phase_A,  0.25 + qm_qua.Cast.mul_fixed_by_int(self.ramp_phaseA, self.gate_num) + qm_qua.Cast.mul_fixed_by_int(self.detuningA * 1e-9 * self.gate_num, self.pulse_length))
        qm_qua.assign(total_phase_B,  0.25 + qm_qua.Cast.mul_fixed_by_int(self.ramp_phaseB, self.gate_num) + qm_qua.Cast.mul_fixed_by_int(self.detuningB * 1e-9 * self.gate_num, self.pulse_length))
        for i in range(0, self.gate_num, 1):
            self.drive.play(self.very_good_pulse_standard)

        qua.align()

        # ORENS A
        self.cavityA.play(self.cavA_op, ampx=(dispA_I, -dispA_Q, dispA_Q, dispA_I), phase = total_phase_A)  # displacement
        qua.align(self.cavityA, self.qubitA)
        # qua.update_frequency(self.qubitA, 350.0e6) # fock2 frequency
        qua.update_frequency(self.qubitA, 350.76e6) # fock1 frequency
        self.qubitA.play(self.qA_selective)
        qua.align(self.qubitA, self.qubitA_EF)
        self.qubitA_EF.play(self.qubitA_EF_pi)  # play pi/2 pulse around X
        qua.align(self.qubitA_EF, self.rrA) 
        self.rrA.measure(self.readout_pulseA, (self.IA, self.QA), demod_type = 'dual')  # measure transmitted signal
        
        # ORENS B
        self.cavityB.play(self.cavB_op, ampx=(dispB_I, -dispB_Q, dispB_Q, dispB_I), phase = total_phase_B)  # displacement
        qua.align(self.cavityB, self.qubitB)
        # qua.update_frequency(self.qubitB, 346.076e6) #fock2
        qua.update_frequency(self.qubitB, 348.27e6) # fock1 frequency
        self.qubitB.play(self.qB_selective)
        qua.align(self.qubitB, self.qubitB_EF)
        self.qubitB_EF.play(self.qubitB_EF_pi)  # play pi/2 pulse around X
        qua.align(self.qubitB_EF, self.rrB)  
        self.rrB.measure(self.readout_pulseB, (self.IB, self.QB), demod_type = 'dual')  # measure transmitted signal

        if self.plot_single_shot:  # assign state to G or E
            qm_qua.assign(self.single_shotA, qm_qua.Cast.to_fixed(self.IA > self.readout_pulseA.threshold))
            qm_qua.assign(self.single_shotB, qm_qua.Cast.to_fixed(self.IB > self.readout_pulseB.threshold))

        qua.align()
        qua.wait(self.wait_time)



if __name__ == "__main__":
    modes = {
        "cavityA": "cavA",
        "cavityB": "cavB",
        "qubitA": "qA",
        "qubitA_EF":"qA_EF",
        "qubitB": "qB", 
        "qubitB_EF":"qB_EF",
        "drive": "drive",           
        "rrA": "rrA",
        "rrB": "rrB"
    }

    pulses = {
        "qA_grape1": "qA_grape_fock1",
        "cavA_grape1": "cavA_grape_fock1",

        "qA_grape01": "qA_grape_fock01_test",
        "cavA_grape01": "cavA_grape_fock01_test",

        "qB_grape01": "qB_grape_fock01_new",
        "cavB_grape01": "cavB_grape_fock01_new",

        "qB_grape1": "qB_grape_fock1",
        "cavB_grape1": "cavB_grape_fock1",
        "very_good_pulse_standard": "very_good_pulse_standard",
        "cavA_op": "cavA_ramp_pulse",
        "cavB_op": "cavB_ramp_pulse",
        "qubitA_pi2": "qA_gaussian_pi2_pulse",
        "qubitB_pi2": "qB_gaussian_pi2_pulse",
        "qA_unselective": "qA_gaussian_pi_pulse",
        "qB_unselective": "qB_gaussian_pi_pulse",
        "qA_selective": "qA_gaussian_very_sel_pi_pulse",
        "qB_selective": "qB_gaussian_very_sel_pi_pulse",
        "qubitA_EF_pi": "qAEF_EF_gaussian_pi_pulse",
        "qubitB_EF_pi": "qBEF_gaussian_pi_pulse",
        "readout_pulseA": "rrA_GF_CLEAR_readout_pulse",
        "readout_pulseB": "rrB_GF_CLEAR_readout_pulse",
    }

    parameters = {
        "ramp_phaseA": -0.08,  
        "ramp_phaseB": -0.026,
        "detuningA": - 730e3,
        "detuningB":  - 198.4e3, 
        "wait_time": 7e6,
        "plot_single_shot": True,
        "time_delayA": 520,
        "time_delayB": 156,
        "pulse_length": 3800,
        "gate_num": 3, 
    }

    N.num = 4_000

    ORENS = Sweep(name = "orens_id", start = 0, stop = 24, num = 25, dtype = int, save = True)

    # DRIVES = Sweep(name = "drive_length", start = time_start, stop = time_stop, step = time_step, dtype = int, save = True)
    # GATES = Sweep(name = "gate_num", start = 0, stop = 1, num = 2, dtype = int, save = True)

    #sweeps = [N, GATES, ORENS]
    sweeps = [N, ORENS]

    SINGLE_SHOT_A.plot = True
    SINGLE_SHOT_B.plot = True
    # SINGLE_SHOT_A.plot_args["plot_type"] = "image"
    # SINGLE_SHOT_B.plot_args["plot_type"] = "image"

    datasets = [IA, QA, SINGLE_SHOT_A,  
                IA_PARITY, QA_PARITY, SINGLE_SHOT_A_PARITY, 
                IB, QB, SINGLE_SHOT_B,
                IB_PARITY, QB_PARITY, SINGLE_SHOT_B_PARITY]


    expt = ORENS_AB(FOLDER, modes, pulses, sweeps, datasets, **parameters)
    
    expt.run(simulate=False, filename_suffix = "++_3gates")