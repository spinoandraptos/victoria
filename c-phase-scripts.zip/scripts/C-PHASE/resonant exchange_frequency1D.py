from config.experiment_config import FOLDER, N, FREQ, I, Q, MAG, PHASE, RRC, SINGLE_SHOT
from qm import qua as qm_qua
from qcore import Experiment, qua, Sweep, Dataset

IA = Dataset(name="IA",save=False,plot=False)
QA = Dataset(name="QA",save=False,plot=False)
SINGLE_SHOTA = Dataset(name="single_shotA",save=True, plot=True)

IB = Dataset(name="IB",save=False,plot=False)
QB = Dataset(name="QB",save=False,plot=False)
SINGLE_SHOTB = Dataset(name="single_shotB",save=True, plot=True)

IC = Dataset(name="IC",save=False,plot=False)
QC = Dataset(name="QC",save=False,plot=False)
SINGLE_SHOTC = Dataset(name="single_shotC",save=True, plot=True)


class ResonantExchange1D(Experiment):
    """Resonant exchange"""

    primary_datasets = ["IA", "QA", "single_shotA", "IB", "QB", "single_shotB", "IC", "QC", "single_shotC"]

    primary_sweeps = ["drive_freq"]

    def sequence(self):
        """QUA sequence that defines this Experiment subclass"""

        # qua.reset_frame(self.cavA)
        # qua.reset_frame(self.cavB)
        # qua.reset_frame(self.qA)
        # qua.reset_frame(self.qB)
        # qua.reset_frame(self.qC)
        # qua.reset_frame(self.drive)
        # qua.reset_frame(self.drive_ramp)
        qm_qua.reset_global_phase()
        qua.update_frequency(self.drive, self.drive_freq)
        qua.update_frequency(self.qA, self.qA.int_freq)
        qua.update_frequency(self.qB, self.qB.int_freq)
        qua.align()


        self.cavA.play(self.cavA_grape)
        self.qA.play(self.qA_grape)
        # self.cavB.play(self.cavB_grape)
        # self.qB.play(self.qB_grape)
        qua.align()

        # Drive resonant exchange

        self.drive.play(self.exchange_pulse)
        qua.align()

        #self.qC.play(self.qubit_sel_pulse)
        # qua.align(self.qubitEF, self.qubit)
        # self.qubitEF.play(self.qubitEF_pi)
        # qua.align(self.qC, self.resonatorC)
        # self.resonatorC.measure(self.readout_pulseC, (self.I, self.Q), ampx=self.ro_ampx, demod_type="dual")
        
        # qua.update_frequency(self.qA, 350.76e6) # fock1 frequency
        # qua.update_frequency(self.qA, 223e6) # fock 2
        self.qA.play(self.qA_sel_pulse)
        qua.align(self.qA, self.qA_EF)
        self.qA_EF.play(self.qubitAEF_pi)
        qua.align(self.qA_EF, self.resonatorA)
        self.resonatorA.measure(self.readout_pulseA, (self.IA, self.QA), demod_type="dual")
        
        self.qB.play(self.qB_sel_pulse)
        qua.align(self.qB, self.qB_EF)
        self.qB_EF.play(self.qubitBEF_pi)
        qua.align(self.qB_EF, self.resonatorB)
        self.resonatorB.measure(self.readout_pulseB, (self.IB, self.QB), demod_type="dual")
        
        # self.qC_EF.play(self.qubitCEF_pi)
        # qua.align(self.qC_EF, self.resonatorC)
        self.resonatorC.measure(self.readout_pulseC, (self.IC, self.QC), demod_type="dual")

        qua.align()
        qua.wait(self.wait_time)
        if self.plot_single_shot:  # assign state to G or E
            qm_qua.assign(self.single_shotA, qm_qua.Cast.to_fixed(self.IA > self.readout_pulseA.threshold))
            qm_qua.assign(self.single_shotB, qm_qua.Cast.to_fixed(self.IB > self.readout_pulseB.threshold))
            qm_qua.assign(self.single_shotC, qm_qua.Cast.to_fixed(self.IC > self.readout_pulseC.threshold))

if __name__ == "__main__":
    """ """

    modes = {
            "cavA": "cavA",
            "cavB":"cavB",
            "qA": "qA",
            "qA_EF": "qA_EF",
            "qB":"qB",
            "qB_EF": "qB_EF",
            "qC": "qC",
            "qC_EF": "qC_EF",
            "drive": "drive",
            "drive_ramp": "drive_ramp",
            "resonatorA": "rrA",
            "resonatorB": "rrB",
            "resonatorC": "rrC",
             }

    pulses = {
        "cavA_grape": "cavA_grape_fock1",
        "qA_grape": "qA_grape_fock1",
        "cavB_grape": "cavB_grape_fock1",
        "qB_grape": "qB_grape_fock1",

        "qC_pulse": "qC_gaussian_pi_pulse",
        "qA_sel_pulse": "qA_gaussian_very_sel_pi_pulse",
        "qB_sel_pulse": "qB_gaussian_very_sel_pi_pulse",
        # "qC_sel_pulse": "qC_gaussian_sel_pi_pulse",

        # "exchange_ramp_up": "exchange_ramp_up",
        # "exchange_constant": "exchange_pulse",
        # "exchange_ramp_down": "exchange_ramp_down",

        "exchange_pulse": "very_good_pulse_800",
        "qubitBEF_pi": "qBEF_gaussian_pi_pulse",
        "qubitAEF_pi": "qAEF_EF_gaussian_pi_pulse",
        "qubitCEF_pi": "qC_EF_gaussian_pi_pulse",

        "readout_pulseC": "rrC_GF_readout_pulse",
        "readout_pulseA": "rrA_GF_CLEAR_readout_pulse", 
        "readout_pulseB": "rrB_GF_CLEAR_readout_pulse", 

    }
                                       
    parameters = {
        "wait_time": 6e6,
        "plot_single_shot": True,
        "grape_id": 0,
        # "ampx": 2.0, 
    }


    N.num = 50_000
    FREQ.name = "drive_freq"
    FREQ.start = 198e6
    FREQ.stop = 202e6
    FREQ.num = 101
    sweeps = [N, FREQ]    
    AMP = Sweep(name="ampx", start=0.0, stop=2.0, step = 0.2, dtype = float)
    # GRAPE = Sweep(name="grape_id", start=0, stop=2, num = 3, dtype = int)
    # sweeps = [N, AMP, FREQ]


    # PHASE.datafn_args = {"delay": 2.792e-7, "freq": RRC.int_freq}
    # SINGLE_SHOTA.plot_args["plot_type"] = "image"
    # SINGLE_SHOTC.plot_args["plot_type"] = "image"
    Q.plot,MAG.plot, PHASE.plot, I.plot = False, False, False, False
    #SINGLE_SHOT.plot_args["plot_type"] = "image"
    SINGLE_SHOTA.plot = True# False
    SINGLE_SHOTB.plot = True #False
    QC.plot = True

    # I.fitfn = 'gaussian'
    # Q.fitfn = 'gaussian'

    datasets = [IA, QA, SINGLE_SHOTA, IB, QB, SINGLE_SHOTB, IC, QC, SINGLE_SHOTC]
    # SINGLE_SHOT.fitfn = 'gaussian'
    expt = ResonantExchange1D(FOLDER, modes, pulses, sweeps, datasets, **parameters)
    expt.run()
