from config.experiment_config import FOLDER, N, FREQ, I, Q, MAG, PHASE, RRC, SINGLE_SHOT
from qm import qua as qm_qua
from qcore import Experiment, qua, Sweep


class NumberSplitting(Experiment):
    """Number splitting"""

    ############################# DEFINE PRIMARY DATASETS ##############################
    primary_datasets = ["I", "Q", "single_shot"]

    ############################## DEFINE PRIMARY SWEEPS ###############################
    primary_sweeps = ["qubit_frequency"]

    ############################ DEFINE THE PULSE SEQUENCE #############################
    def sequence(self):
        """QUA sequence that defines this Experiment subclass"""
        qua.reset_frame(self.cavityA)
        qua.reset_frame(self.qubitA)
        qua.reset_frame(self.cavityB)
        qua.reset_frame(self.qubitB)

        qua.update_frequency(self.qubitA, self.qubitA.int_freq)
        qua.update_frequency(self.qubitB, self.qubitB.int_freq)
        qua.update_frequency(self.drive, self.drive_frequency)
        qua.align()

        # with qm_qua.switch_(self.grape_id): # 0: B in vacuum, 1: B populated
        #         with qm_qua.case_(0):
        #             self.cavityB.play(self.cavB_grape)
        #             self.qubitB.play(self.qB_grape)
                
        #         with qm_qua.case_(1):
        #             self.cavityA.play(self.cavA_grape)
        #             self.qubitA.play(self.qA_grape)
        #             self.cavityB.play(self.cavB_grape)
        #             self.qubitB.play(self.qB_grape)
        
        # qua.align()
        self.cavityA.play(self.cavA_grape)
        self.qubitA.play(self.qA_grape)
        self.cavityB.play(self.cavB_grape)
        self.qubitB.play(self.qB_grape)
        qua.align()

        self.drive.play(self.drive_pulse)
        qua.align()

        qua.update_frequency(self.qubitB, self.qubit_frequency) # fock1 frequency
        self.qubitB.play(self.qB_selective)
        qua.align(self.qubitB, self.qubitB_EF)
        self.qubitB_EF.play(self.qB_EF_pi)  # play pi/2 pulse around X
        qua.align(self.qubitB_EF, self.resonator) 

        # qua.update_frequency(self.qubitA, self.qubit_frequency) # fock1 frequency
        # self.qubitA.play(self.qA_selective)
        # qua.align(self.qubitA, self.qubitA_EF)
        # self.qubitA_EF.play(self.qA_EF_pi)  # play pi/2 pulse around X
        # qua.align(self.qubitA_EF, self.resonator) 




        self.resonator.measure(self.readout_pulse, (self.I, self.Q), demod_type = 'dual')  # measure transmitted signal
        qua.align()
        qua.wait(self.wait_time)
        if self.plot_single_shot:  # assign state to G or E
            qm_qua.assign(self.single_shot,qm_qua.Cast.to_fixed(self.I > self.readout_pulse.threshold))


if __name__ == "__main__":
    """ """

    #################################### MODE MAP ######################################
    # key: name of the Mode as defined by the Experiment subclass
    # value: name of the Mode as defined by the user in modes.yml

    modes = {
        "cavityA": "cavA",
        "cavityB": "cavB",
        "qubitA": "qA",
        "qubitB": "qB",
        "qubitA_EF": "qA_EF",
        "qubitB_EF": "qB_EF",
        "drive": "drive",
        "resonator": "rrB",

    }
    ################################### PULSE MAP ######################################
    # key: name of the Pulse as defined by the Experiment subclass
    # value: name of the Pulse as defined by the user in modes.yml

    pulses = {
        "qA_grape": "qA_grape_fock1",
        "cavA_grape": "cavA_grape_fock1",
        "qB_grape": "qB_grape_fock01_new",
        "cavB_grape": "cavB_grape_fock01_new",

        "drive_pulse": "exchange_pulse_cos2_4000",

        "qA_selective": "qA_gaussian_very_sel_pi_pulse",
        "qA_EF_pi": "qAEF_EF_gaussian_pi_pulse",

        "qB_selective": "qB_gaussian_very_sel_pi_pulse",
        "qB_EF_pi": "qBEF_gaussian_pi_pulse",

        "readout_pulse": "rrB_GF_CLEAR_readout_pulse",
    }
                                       
    ############################## CONTROL PARAMETERS ##################################
    parameters = {
        "wait_time": 6e6,
        "ro_ampx": 1,
        "plot_single_shot": True,
    }

    ######################## SWEEP (INDEPENDENT) VARIABLES #############################
    N.num = 10000

    FREQ.name = "qubit_frequency"
    # FREQ.start = 222e6  # A
    # FREQ.stop = 225.4e6 # A
    FREQ.start = 345.5e6 
    FREQ.stop = 346.5e6
    FREQ.num = 51

    DRIVE =  Sweep(name = "drive_frequency", start = 345e6-6.5e6, stop = 345e6-5e6,  num = 5, dtype = int, save = True)

    # QD_AMPX = Sweep(name="drive_ampx", points=[0.0, 1.6])
           
    GRAPE = Sweep(name = "grape_id", start = 0, stop = 1,  num = 2, dtype = int, save = True)

    # sweeps = [N, FREQ]
    sweeps = [N, DRIVE, FREQ]

    ######################## DATASET (DEPENDENT) VARIABLES #############################

    PHASE.datafn_args = {"delay": 2.792e-7, "freq": RRC.int_freq}

    Q.plot= False
    SINGLE_SHOT.plot = True
    I.plot, MAG.plot = False, False
    SINGLE_SHOT.fitfn = "gaussian"

    datasets = [I, Q, SINGLE_SHOT]

    ######################## INITIALIZE AND RUN EXPERIMENT #############################

    expt = NumberSplitting(FOLDER, modes, pulses, sweeps, datasets, **parameters)
    expt.run(simulate=False)
