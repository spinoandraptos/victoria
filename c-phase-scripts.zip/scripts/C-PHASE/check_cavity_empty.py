""" """
from config.experiment_config import FOLDER, N, FREQ, I, Q, MAG, PHASE, RRC, SINGLE_SHOT
from qm import qua as qm_qua
from qcore import Experiment, qua, Sweep


class cavity_depopulated(Experiment):
    """cavity depopulated"""
    
    primary_datasets = ["I", "Q", "single_shot"]
   
    primary_sweeps = ["qubit_frequency"]

    def sequence(self):
        """QUA sequence that defines this Experiment subclass"""

        # Prepare 1 in Bob
        self.cavity.play(self.cavity_pulse, ampx= 1.14)  # displace by beta = 1.14
        qua.align()
        self.qB.play(self.qubitB_pulse, ampx = 2.0)    # SNAP: play pi pulse around X
        qua.align()  # align pulses
        self.cavity.play(self.cavity_pulse, ampx=-0.58)  # displace by beta = -0.58
        qua.align()

        # Flip qC
        qua.update_frequency(self.qC, self.qC.int_freq) # bare qC frequency (short pulse so cavB in 1 does not matter!)
        self.qC.play(self.qC_pulse) 
        qua.align()

        self.drive.play(self.exchange_drive, duration = 400/4, ampx = self.drive_amp) # transfer population to Alice
        qua.align()

        qua.update_frequency(self.qC, self.qubit_frequency) # qC should be in ground, so we can use it for spectroscopy
        self.qC.play(self.qubit_sel_pulse)
        qua.align()

        self.resonator.measure(self.readout_pulse, (self.I, self.Q), ampx=self.ro_ampx, demod_type="dual")
        if self.plot_single_shot:  # assign state to G or E
            qm_qua.assign(self.single_shot,qm_qua.Cast.to_fixed(self.I > self.readout_pulse.threshold),)
        qua.wait(self.wait_time)


if __name__ == "__main__":
    """ """

    #################################### MODE MAP ######################################
    modes = {"qB": "qB",
             "qC": "qC",
             "drive": "drive",
             "resonator": "rrC",
             "cavity": "cavB",
             }

    ################################### PULSE MAP ######################################
    pulses = {
        "cavity_pulse": "cavB_ramp_pulse", # displace Bob
        "qubitB_pulse": "qB_gaussian_very_sel_pi_pulse", # SNAP on qB
        "qC_pulse": "qC_gaussian_pi_pulse", # flip qC
        "exchange_drive": "exchange_pulse", # exchange drive
        "qubit_sel_pulse": "qC_gaussian_sel_pi_pulse", # qC spectrscopy pulse
        "readout_pulse": "rrC_readout_pulse", # RO qC
    }
                                       
    ############################## CONTROL PARAMETERS ##################################
    parameters = {
        "wait_time": 7e6,
        "ro_ampx": 1,
        "plot_single_shot": True,
    }

    ######################## SWEEP (INDEPENDENT) VARIABLES #############################
    N.num = 10000

    FREQ.name = "qubit_frequency"
    FREQ.start = 32e6
    FREQ.stop = 36e6
    FREQ.num = 201

    DRIVE_AMPX = Sweep(name="drive_amp", start=0.0, stop=1.0, step=1)

    sweeps = [N, DRIVE_AMPX, FREQ]

    ######################## DATASET (DEPENDENT) VARIABLES #############################
    PHASE.datafn_args = {"delay": 2.792e-7, "freq": RRC.int_freq}
    Q.plot, PHASE.plot, MAG.plot = False, False, False
    datasets = [I, Q, SINGLE_SHOT]
    SINGLE_SHOT.plot_args = {"plot_err": False}

    ######################## INITIALIZE AND RUN EXPERIMENT #############################
    expt = cavity_depopulated(FOLDER, modes, pulses, sweeps, datasets, **parameters)
    expt.run()
