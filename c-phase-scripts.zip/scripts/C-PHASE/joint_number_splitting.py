""" """
from config.experiment_config import FOLDER, N, FREQ, I, Q, MAG, PHASE, RRC, SINGLE_SHOT, RRB
from qm import qua as qm_qua
from qcore import Experiment, qua, Sweep, Dataset
from qm.qua._dsl.scope_functions import if_

SINGLE_SHOTA = Dataset(name="single_shotA",save=True, plot=True)
SINGLE_SHOTB = Dataset(name="single_shotB",save=True, plot=True)

IA = Dataset(name="IA",save=False,plot=False)
QA = Dataset(name="QA",save=False,plot=False)

IB = Dataset(name="IB",save=False,plot=False)
QB = Dataset(name="QB",save=False,plot=False)


class NumberSplitting_AB(Experiment):
    """Number splitting"""

    ############################# DEFINE PRIMARY DATASETS ##############################
    # these Datasets form the "raw" experimental data and will be streamed by the OPX
    # they must be specified at experiment runtime

    primary_datasets = ["IA", "QA", "single_shotA", "IB", "QB", "single_shotB"]

    ############################## DEFINE PRIMARY SWEEPS ###############################
    # these Sweeps are uniquely associated with the Experiment subclass
    # these Sweeps must be specified at experiment runtime

    primary_sweeps = ["qubit_frequency"]
    ############################ DEFINE THE PULSE SEQUENCE #############################
    # ensure that you import 'qua' from 'qcore' and not from 'qm' library
    # attributes accessed via 'self' must be defined in 'if __name__ == "__main__"' code

    def sequence(self):
        """QUA sequence that defines this Experiment subclass"""
        qua.reset_frame(self.cavityA)
        qua.reset_frame(self.qubitA)
        qua.reset_frame(self.cavityB)
        qua.reset_frame(self.qubitB)
        qm_qua.reset_global_phase()
        qua.align()
  
        qua.update_frequency(self.qubitA, self.qubitA.int_freq) #!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
        qua.update_frequency(self.qubitB, self.qubitB.int_freq) #!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
        # self.qubitB.play(self.qubitB_grape)
        # self.cavityB.play(self.cavityB_grape) 
        # self.qubitA.play(self.qubitA_grape)
        # self.cavityA.play(self.cavityA_grape) 
        # qua.align()

        # qua.update_frequency(self.drive, 334e6)
        # self.drive.play(self.drive_pulse, ampx = self.drive_ampx)
        # qua.align()

        # Measure A
        qua.update_frequency(self.qubitA, self.qubit_frequency)
        self.qubitA.play(self.qubitA_spec_pulse)
        qua.align(self.qubitA, self.qubitA_EF)
        self.qubitA_EF.play(self.qA_EF_pi)
        qua.align(self.qubitA_EF, self.resonatorA)
        self.resonatorA.measure(self.readout_pulseA, (self.IA, self.QA), demod_type="dual")
        
        # Measure B
        qua.update_frequency(self.qubitB, self.qubit_frequency)
        self.qubitB.play(self.qubitB_spec_pulse)
        qua.align(self.qubitB, self.qubitB_EF)
        self.qubitB_EF.play(self.qB_EF_pi)
        qua.align(self.qubitB_EF, self.resonatorB)
        self.resonatorB.measure(self.readout_pulseB, (self.IB, self.QB), demod_type="dual")

        qua.align()
        qua.wait(self.wait_time)

        if self.plot_single_shot:  # assign state to G or E
            qm_qua.assign(self.single_shotA,qm_qua.Cast.to_fixed(self.IA > self.readout_pulseA.threshold))
            qm_qua.assign(self.single_shotB,qm_qua.Cast.to_fixed(self.IB > self.readout_pulseB.threshold))



if __name__ == "__main__":
    """ """

    #################################### MODE MAP ######################################
    modes = {
        "cavityA": "cavA",
        "qubitA": "qA",
        "cavityB": "cavB",
        "qubitB": "qB",
        "qubitA_EF":"qA_EF",
        "qubitB_EF":"qB_EF",
        "resonatorA": "rrA",
        "resonatorB": "rrB",
        "drive": "drive",
    }
    
    ################################### PULSE MAP ######################################
    pulses = {
        # "qubitA_grape": "qA_grape_fock02",
        # "cavityA_grape": "cavA_grape_fock02",
        # "qubitB_grape": "qB_grape_fock2",
        # "cavityB_grape": "cavB_grape_fock2",

        # "drive_pulse": "very_good_pulse_standard",

        "qubitA_spec_pulse": "qA_gaussian_very_sel_pi_pulse",
        "qubitB_spec_pulse": "qB_gaussian_very_sel_pi_pulse",

        "qA_EF_pi":"qAEF_EF_gaussian_pi_pulse",
        "qB_EF_pi":"qBEF_gaussian_pi_pulse",
        "readout_pulseA": "rrA_GF_CLEAR_readout_pulse",
        "readout_pulseB": "rrB_GF_CLEAR_readout_pulse",
    }
                                       
    ############################## CONTROL PARAMETERS ##################################
    parameters = {
        "wait_time": 7e6,
        "plot_single_shot": True,
    }

    ######################## SWEEP (INDEPENDENT) VARIABLES #############################
    N.num = 10000

    FREQ.name = "qubit_frequency"
    FREQ.start = 349e6
    FREQ.stop = 353e6
    FREQ.num = 101

    # LENGTH = Sweep (name="drive_length", dtype=int, units = "ns")
    # LENGTH.start = 16
    # LENGTH.stop = 1000
    # LENGTH.step = 200
    # sweeps = [N, LENGTH, FREQ]

    SINGLE_SHOTA.fitfn = 'gaussian'
    SINGLE_SHOTB.fitfn = 'gaussian'

    AMPX = Sweep(name="drive_ampx", points= [0.0, 1.0]) #needs to be floating point numbers 
    sweeps = [N, FREQ]

    ######################## DATASET (DEPENDENT) VARIABLES #############################
    PHASE.datafn_args = {"delay": 2.792e-7, "freq": RRB.int_freq}
    datasets = [IA, QA, SINGLE_SHOTA, IB, QB, SINGLE_SHOTB]

    ######################## INITIALIZE AND RUN EXPERIMENT #############################
    expt = NumberSplitting_AB(FOLDER, modes, pulses, sweeps, datasets, **parameters)
    expt.run()
