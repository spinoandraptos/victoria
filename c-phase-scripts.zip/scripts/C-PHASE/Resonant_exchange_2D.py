from config.experiment_config import FOLDER, N, FREQ, RRC
from qm import qua as qm_qua
from qcore import Experiment, qua, Sweep, Dataset


class ResonantExchange(Experiment):
    """Resonant exchange"""

    ############################# DEFINE PRIMARY DATASETS ##############################
    primary_datasets = ["IA", "QA", "single_shot_A",
                        "IB", "QB", "single_shot_B",
                        "IC", "QC", "single_shot_C",]
    
    ############################## DEFINE PRIMARY SWEEPS ###############################
    primary_sweeps = ["drive_length"]
    
    ############################ DEFINE THE PULSE SEQUENCE #############################
    def sequence(self):
        """QUA sequence that defines this Experiment subclass"""
        # Prepare 1 
        qua.update_frequency(self.qB, self.qB.int_freq) # fock 1
        qua.update_frequency(self.qA, self.qA.int_freq) # fock 1
        self.cavA.play(self.cavA_grape)
        self.qA.play(self.qA_grape)
        # self.cavB.play(self.cavB_grape)
        # self.qB.play(self.qB_grape)
        qua.align()

        # self.qC.play(self.qC_pulse)
        # qua.align(self.qC, self.drive)


        # Drive resonant exchange
        qua.update_frequency(self.drive, self.drive_frequency)
        # self.drive.play(self.exchange_drive_up, ampx = 2.0)
        self.drive.play(self.exchange_drive, duration = self.drive_length/4)
        # self.drive.play(self.exchange_drive_down, ampx = 2.0)
        qua.align()

        # RO cavity A
        # self.qA.play(self.qA_selective)
        # self.qB.play(self.qB_selective)
        # qua.align()

        # qua.update_frequency(self.qA, 223.76e6) # fock 1
        # self.qA.play(self.qA_sel_pulse)
        # qua.align(self.qA, self.qA_EF)
        # self.qA_EF.play(self.qubitAEF_pi)
        # qua.align(self.qA_EF, self.resonatorA)
        # self.resonatorA.measure(self.readoutA_pulse, (self.IA, self.QA), demod_type="dual")

        # qua.update_frequency(self.qB, 348.29e6) 
        # self.qB.play(self.qB_sel_pulse)
        # qua.align(self.qB, self.qB_EF)
        # self.qB_EF.play(self.qubitBEF_pi)
        # qua.align(self.qB_EF, self.resonatorB)
        # self.resonatorB.measure(self.readoutB_pulse, (self.IB, self.QB), demod_type="dual")

        self.qC_EF.play(self.qubitCEF_pi)
        qua.align(self.qC_EF, self.resonatorC)
        self.resonatorC.measure(self.readoutC_pulse, (self.IC, self.QC), demod_type="dual")

        if self.plot_single_shot:  # assign state to G or E
            qm_qua.assign(self.single_shot_A, qm_qua.Cast.to_fixed(self.IA > self.readoutA_pulse.threshold))
            qm_qua.assign(self.single_shot_B, qm_qua.Cast.to_fixed(self.IB > self.readoutB_pulse.threshold))
            qm_qua.assign(self.single_shot_C, qm_qua.Cast.to_fixed(self.IC > self.readoutC_pulse.threshold))

        qua.align()
        qua.wait(self.wait_time)

if __name__ == "__main__":
    """ """

    #################################### MODE MAP ######################################
    # key: name of the Mode as defined by the Experiment subclass
    # value: name of the Mode as defined by the user in modes.yml

    modes = {
             "qA":"qA",
             "qA_EF":"qA_EF",
             "qB": "qB",
             "qB_EF":"qB_EF",
             "qC": "qC",
             "qC_EF": "qC_EF",
             "drive": "drive",
             "resonatorA": "rrA", 
             "resonatorB": "rrB", 
             "resonatorC": "rrC", 
             "cavA": "cavA",
             "cavB": "cavB"}

    ################################### PULSE MAP ######################################
    # key: name of the Pulse as defined by the Experiment subclass
    # value: name of the Pulse as defined by the user in modes.yml

    pulses = {
        "cavA_grape": "cavA_grape_fock1",
        "qA_grape": "qA_grape_fock1",
        "cavB_grape": "cavB_grape_fock2",
        "qB_grape": "qB_grape_fock2",
        # "exchange_drive_up": "exchange_ramp_up",
        # "exchange_drive": "exchange_pulse_cos2_special",
        "exchange_drive": "vanilla_ramp",
        # "qC_pulse": "qC_gaussian_pi_pulse",
        # "exchange_drive_down": "exchange_ramp_down",
        "qA_sel_pulse": "qA_gaussian_very_sel_pi_pulse", 
        "qubitAEF_pi": "qAEF_EF_gaussian_pi_pulse", 
        "qubitCEF_pi": "qC_EF_gaussian_pi_pulse", 
        "qB_sel_pulse": "qB_gaussian_very_sel_pi_pulse",
        "qubitBEF_pi": "qBEF_gaussian_pi_pulse", 
        "readoutA_pulse": "rrA_GF_CLEAR_readout_pulse",
        "readoutB_pulse": "rrB_GF_CLEAR_readout_pulse",
        "readoutC_pulse": "rrC_GF_readout_pulse",
    }
                    
                                       
    ############################## CONTROL PARAMETERS ##################################
    parameters = {
        "wait_time": 7e6,
        "ro_ampx": 1,
        "plot_single_shot": True,
    }

    ######################## SWEEP (INDEPENDENT) VARIABLES #############################
    # must include an outermost averaging Sweep named "N"
    # must include all primary sweeps defined by the Experiment subclass

    # set number of repetitions for this Experiment run
    N.num = 10000

    # set the qubit frequency sweep for this Experiment run
    FREQ.name = "drive_frequency"
    FREQ.start = 199e6
    FREQ.stop = 202e6
    FREQ.num = 11

    LENGTH = Sweep (name="drive_length", dtype=int, units = "ns") # keep this in ns, divide duration on top
    LENGTH.start = 16
    LENGTH.stop = 2000
    LENGTH.step = 40

    sweeps = [N, LENGTH, FREQ]
    #sweeps = [N, FREQ]

    IA = Dataset(name="IA", save=False, plot=False)
    QA = Dataset(name="QA", save=False, plot=False)
    SINGLE_SHOT_A = Dataset(name="single_shot_A", save=True, plot=True)
    IB = Dataset(name="IB", save=False, plot=False)
    QB = Dataset(name="QB", save=False, plot=False)
    SINGLE_SHOT_B = Dataset(name="single_shot_B", save=True, plot=True)
    IC = Dataset(name="IC", save=False, plot=False)
    QC = Dataset(name="QC", save=False, plot=False)
    SINGLE_SHOT_C = Dataset(name="single_shot_C", save=True, plot=True)

    ######################## DATASET (DEPENDENT) VARIABLES #############################
    # must include all primary datasets defined by the Experiment subclass
    SINGLE_SHOT_A.plot_args["plot_type"] = "image"
    SINGLE_SHOT_B.plot_args["plot_type"] = "image"
    SINGLE_SHOT_C.plot_args["plot_type"] = "image"

    datasets = [IA, QA, SINGLE_SHOT_A, IB, QB, SINGLE_SHOT_B, IC, QC, SINGLE_SHOT_C]

    ######################## INITIALIZE AND RUN EXPERIMENT #############################

    expt = ResonantExchange(FOLDER, modes, pulses, sweeps, datasets, **parameters)
    expt.run(simulate=False)
    # expt.run(simulate=True)
